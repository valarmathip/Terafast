'use strict';

/******************************************************************************
 *     Filter to return Abbreviation of product class
 *****************************************************************************/
angular.module('p2AdvanceApp')
    .filter('productClassAbbr', function() {
        /*jshint maxcomplexity:false */
        return function(input) {
            if (!input || input.toString().length === 0) {
                // throw 'Product Class is invalid';
                return 'n/a';
            }

            //var compare;
            switch (input.toString()) {
                case 'Medical':
                case 'medical':
                    return 'M';
                case 'Dental':
                case 'dental':
                    return 'D';
                case 'Vision':
                case 'vision':
                    return 'V';
                case 'Pharmacy':
                case 'pharmacy':
                    return 'P';
                default:
                    // throw 'Product Class is invalid';
                    return 'n/a';
            }
        };
    });

/******************************************************************************
 *     Filter to calculate the due days
 * ----------------------------------------------------------------------------
 * Note: This filter need the underscore lib
 ******************************************************************************/
angular.module('p2AdvanceApp')
    .filter('dueDays', function(ppmUtils) {
        return function(date) {
            var result = '';

            var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
            date = ppmUtils.jsonOrNumberToDate(date);
            var today = new Date();
            date = Math.floor(date.getTime() / oneDay);
            today = Math.floor(today.getTime() / oneDay);
            var diff = (date - today);
            var diffDays = Math.abs(diff);
            result += diffDays + ' day';

            if (diffDays > 1) {
                result += 's';
            } else if (diffDays === 0) {
                result = 'ondue';
            }
            if (diff < 0) {
                result += ' overdue';
            }

            return result;
        };
    })
    .filter('overDuleStyle', function(ppmUtils) {
        return function(date) {
            var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
            date = ppmUtils.jsonOrNumberToDate(date);
            var today = new Date();
            date = Math.floor(date.getTime() / oneDay);
            today = Math.floor(today.getTime() / oneDay);
            var diff = (date - today);
            //var result = diff < 0;
            return diff < 0 ? 'ppm-overdue' : (diff === 0 ? 'ppm-ondue' : '');
        };
    });

//////////////////////////////////////////////////////////////////////////////////
//   ppmTel  format 1234567890 to (123) 456-7890
//////////////////////////////////////////////////////////////////////////////////
angular.module('p2AdvanceApp')
    .filter('ppmTel', function($log) {
        var phoneRegex = /[^0-9A-Za-z]/;

        return function(tel) {
            $log.log(tel);
            if (!tel) {
                return '';
            }

            var value = tel.toString().trim().replace(/^\+/, '');

            if (value.match(phoneRegex)) {
                return tel;
            }

            var city, number;

            switch (value.length) {
                case 1:
                case 2:
                case 3:
                    city = value;
                    break;

                default:
                    city = value.slice(0, 3);
                    number = value.slice(3);
            }

            if (number) {
                if (number.length > 3) {
                    number = number.slice(0, 3) + '-' + number.slice(3, 7);
                } else {
                    number = number;
                }

                return ('(' + city + ') ' + number).trim();
            } else {
                return '(' + city;
            }

        };
    });

angular.module('p2AdvanceApp')
    .filter('ppmSoftHyphen', function() {
        var softHypen = '\u00AD';
        // var zeroWidthSpace = '\u200B'; 

        function addSoftHyphen(str) {
            return str.replace(/[\w\d]/g, function(match, offset) {
                if (offset === 0) {
                    return match;
                } else {
                    return softHypen + match;
                }
            });
        }

        return function(name) {
            if (!name || name.trim().length === 0) {
                return name;
            }

            var words = name.split(/ +/);
            var ret = [];

            angular.forEach(words, function(word, index) { /*jshint ignore:line*/
                var newWord = addSoftHyphen(word);
                ret.push(newWord);
            });

            return ret.join(' ');
        };
    });

angular.module('p2AdvanceApp')
    .filter('ppmHtmlId', function() {
        return function(name) {
            if (!name) {
                return name;
            }
            // by test, the following characters cannot be used find tag by id.
            // http://stackoverflow.com/questions/70579/what-are-valid-values-for-the-id-attribute-in-html
            return name.replace(/[\@\ \.]/g, '_');
        };
    });

angular.module('p2AdvanceApp')
    .filter('ppmCapitalizeFirstLetter', function() {
        return function(input) {
            return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
        };
    });

angular.module('p2AdvanceApp')
    .filter('qaHrafAttribute', function() {
        return function(name) {
            if (!name) {
                return name;
            }
            //Filter to assist test-automation by helping maintain uniqueness
            // for dynamically generated elements
            name = name.toString();
            name = name.toLowerCase();
            name = name.replace(/[ \/]/g, '-');
            name = name.replace(/\?/g, '');
            name = name.replace(/\./g, '');
            return name;
        };
    });
angular.module('p2AdvanceApp')
    .filter('removeSpaces', function() {
        return function(string) {
            if (!angular.isString(string)) {
                return string;
            }
            return string.replace(/[\s]/g, '');
        };
    });