'use strict';

angular.module('p2AdvanceApp', [
        'ngCookies',
        'ngResource',
        'ngSanitize',
        'ngRoute',
        'ui.bootstrap',
        'ui.select2',
        'ui.router',
        'ui.utils',
        'angularMoment',
        //'ngCacheBuster',
        'config',
        'pascalprecht.translate',
        'cfp.hotkeys',
        'ngCsv',
        'ui.grid',
        'ui.grid.cellNav',
        'ui.grid.edit',
        'ui.grid.resizeColumns',
        'ui.grid.pinning',
        'ui.grid.selection',
        'ui.grid.moveColumns',
        'ui.grid.exporter',
        'ui.grid.pagination',
        'ui.grid.autoResize',
        'ui.grid.expandable',
        'LocalStorageModule',
        'angularFileUpload',
        'ngSlider',
        'schemaForm',
        'timer',
        'ngAside',
        'pageslide-directive',
        'ngJSONPath'
    ])
    .run(function($rootScope, $state, $stateParams, $auth, $window, $log, userAuthorizationManager) {
        // It's very handy to add references to $state and $stateParams to the $rootScope
        // so that you can access them from any scope within your applications.For example,
        // <li ui-sref-active="active }"> will set the <li> // to active whenever
        // 'contacts.list' or one of its decendents is active.
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;

        // capture window or tab close event
        angular.element($window).bind('beforeunload', function() {
            if (!$auth.isDeepLinkStoraged() && !$auth.isProcessing()) {
                // $auth.setForceLogout(true);
                $auth.invalidateCredentials();
            }
        });

        $auth.initEvents();
        $rootScope.parser = parser;

        $rootScope.$on('$stateChangeStart', function(event, toState) {
            $log.info('Next State -> ' + toState.name);
        });

        $rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams, error) {
            $log.error('to State -> ' + toState.name + ', from State -> ' + fromState.name + ', error -> ' + error);
        });

        // skip Role Permission Validation, only recommended  
        // for development 
        userAuthorizationManager.skipRoleRoutesValidation(true);
        userAuthorizationManager.skipPermissionUIValidation(false);
        userAuthorizationManager.skipPermissionHTTPValidation(true);

    })
    .run(function(amMoment) {
        amMoment.changeLocale('en-gb'); // default language for Time is great britain english (en-gb)
    })
    .run(['$rootScope', '$location', '$window', function($rootScope, $location, $window){
         $rootScope
            .$on('$stateChangeSuccess',
                function(){
                    if (!$window.ga) {
                        return;
                    }
                    $window.ga('send', 'pageview', { page: $location.path() });
            });
    }])
    // .config(function(httpRequestInterceptorCacheBusterProvider) {
    //     // Cache Buster for Angular JS $http and $resource.
    //     httpRequestInterceptorCacheBusterProvider.setMatchlist([/.*gateway.*/, /.*views.*/], true);
    // })
    .config(['$translateProvider', function($translateProvider) {
        $translateProvider.useStaticFilesLoader({
            prefix: '/app/i18n/',
            suffix: '.json'
        });
        $translateProvider.preferredLanguage('en');
    }])
    .constant('uiConfig', {
        debug: true,
        version: '1.0.0',
        appName: 'p2AdvanceApp',
        OK: 200,
        Created: 201,
        NoContent: 204
    })
    .config(function(localStorageServiceProvider) {
        localStorageServiceProvider
        // localStorage is valid per Browser and all tabs 
        // sessionStorage is valid per Tab
            .setStorageType('localStorage')
            .setPrefix('p2a');
    })
    .config(['$routeProvider', '$httpProvider', '$urlRouterProvider', '$stateProvider', '$locationProvider', 
        function($routeProvider, $httpProvider, $urlRouterProvider, $stateProvider, $locationProvider) {

            // Ajax Caching: IE caches the XHR requests. In order to avoid this, we set an HTTP
            // response header to mimic default behaviors of moderns browsers.
            $httpProvider.defaults.headers.common['Cache-Control'] = 'no-cache';

            // Apply CORS preflight cache to an entire domain
            $httpProvider.defaults.useXDomain = true;
            delete $httpProvider.defaults.headers.common['X-Requested-With'];

            // For any unmatched url, redirect to /home
            // But the normal usage creates INFDG error
            // $urlRouterProvider.otherwise('/p2a/landing-page');
            // we need instead
            $urlRouterProvider.otherwise( function($injector) {
              var $state = $injector.get('$state');
              $state.go('home.landing-page');
            });

            // $http request interceptor for SSO session timeout
            $httpProvider.interceptors.push('httpRequestInterceptor');

            // Add API token to all http request
            $httpProvider.interceptors.push('APIInterceptor');

            $httpProvider.interceptors.push('SpinnerInterceptor');

            // remove # from the browser url path. 
            $locationProvider.html5Mode(true);

            $stateProvider
                .state('home', {
                    url: '/p2a',
                    'abstract': true,
                    templateUrl: 'views/ui-framework/main.html',
                    controller: 'MainCtrl',
                    resolve: {
                        authUser: function($auth) {
                            return $auth.validateUser();
                        },
                        userInfo: function(authUser, $auth) {
                            return $auth.resolveUserInfo();
                        }
                    }
                })
                .state('auth', {
                    url: '/auth?opentoken',
                    controller: 'AuthCtrl',
                    resolve: {
                        apiToken: function($auth, $stateParams) {
                            // Request an API token passing the open token from IDP
                            return $auth.resolveApiToken($stateParams.opentoken);
                        }
                    }
                });
        }
    ]);
