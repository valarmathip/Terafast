'use strict';

angular.module('p2AdvanceApp')
    .controller('FindandReplaceRuleDefCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $log,
        ConfirmationModalFactory,
        ModalDialogFactory,
        RuleDataService
    ) {
        $scope.isFormEdited = false;
        $scope.currentRule = {};
        $scope.selectedFieldIds = [];
        $scope.options = RuleDataService.getoptionFindReplaceList();
        if ($stateParams.ruleId !== null || $stateParams.ruleId.trim().toString().length > 0) {

            RuleDataService.getFindReplaceRuleById($stateParams.ruleId)
                .success(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close() // slq looks reduntant
                    $scope.currentRule = data;
                    $scope.BindDataToUI();
                });
        }

        $scope.BindDataToUI = function() {
            //populate the rule definiton on UI element
            if ($scope.currentRule != null && $stateParams.ruleId.trim().toString().length > 0) {
                $scope.objectId = $scope.currentRule.objectId;
                $scope.ruleName = $scope.currentRule.ruleName;
                $scope.selectedFields = RuleDataService.getCurrentRuleDataFields();
                $scope.selectedFieldIds = RuleDataService.getCurrentRuleDataFieldsPair();
                var findType = $scope.currentRule.findType;
                $scope.findOption = RuleDataService.updateOptionDropdown(findType);
                $scope.findWord = $scope.currentRule.find;
                $scope.replaceWord = $scope.currentRule.replace;
                $scope.findIgnoreCase = $scope.currentRule.ignoreCase;
                $scope.findIgnoreSpace = $scope.currentRule.ignoreSpaces;
                $scope.findRegExp = $scope.currentRule.regexInFind;
                $scope.lastModificationDate = $scope.currentRule.lastModificationDate;
                $scope.modifier = $scope.currentRule.modifier;
                $scope.templates = $scope.currentRule.templates;
                $scope.ruleStatus = $scope.currentRule.ruleStatus;
                $scope.selectedFieldsPair = RuleDataService.getCurrentRuleDataFieldsPair();
            } else {
                $scope.findOption = $scope.options[0];
            }
        };

        $scope.selectTags = function() {
            $scope.availableTags = [];

            RuleDataService.getDataFields('findreplace').then(function (data) {
                $scope.availableTags = data;
                $scope.displayTagModelPopup();
            });
        };

        $scope.displayTagModelPopup = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/list-tags.html',
                controller: 'TagsModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    tagsAvailable: function() {
                        return $scope.availableTags;
                    },
                    tagsSelected: function() {

                        return $scope.selectedFieldIds;

                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.selectedFields = [];
                $scope.selectedFieldIds = [];

                angular.forEach(result, function(tag) {
                    $scope.selectedFields.push(tag.dataFieldName);
                    $scope.selectedFieldIds.push({
                        objectId: tag.objectId
                    });
                    $scope.selectedFields.sort();
                });
            });
        };

        $scope.ruleDefList = [{
            'id': '1',
            'label': 'Condition',
            'isEnabled': true,
            'state': 'home.admin.media-management.condition-expression-definition'
        }, {
            'id': '2',
            'label': 'Show',
            'isEnabled': true,
            'state': 'home.admin.media-management.showhide-rule-definition'
        }, {
            'id': '3',
            'label': 'Find/Replace',
            'isEnabled': true,
            'state': 'home.admin.media-management.findandreplace-rule-definition'

        }, {
            'id': '4',
            'label': 'Trim',
            'isEnabled': true,
            'state': 'home.admin.media-management.delete-rule-definition'
        }];

        $scope.isFormDirty = function() {
            return $scope.isFormEdited === true;
        };

        $scope.isValidated = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.selectedFields) || $scope.selectedFields.length === 0) {
                return false;
            } else {
                return true;
            }
        };

        // rule validation, one or more of the four options are selected: 
        // find word or phrase, ignore case, ignore spaces, options or use regular expression and replace word or phrase
        /*jshint maxcomplexity:false */
        $scope.validateRule = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.selectedFields) || $scope.selectedFields.length === 0) {
                return false;
            } else {
                var findWordValid = true;
                var replaceWordValid = true;
                var findIgnoreCaseValid = true;
                var findIgnoreSpaceValid = true;
                var findRegExpValid = true;
                var findOptionValid = true;
                //findWord is mandatory
                if ($scope.findWord === null || !angular.isDefined($scope.findWord) || $scope.findWord === '') {
                    findWordValid = false;
                } else {
                    findWordValid = true;
                }

                if ($scope.findIgnoreCase === null || !angular.isDefined($scope.findIgnoreCase) || $scope.findIgnoreCase === '') {
                    findIgnoreCaseValid = false;
                } else {
                    findIgnoreCaseValid = true;
                }

                if ($scope.findIgnoreSpace === null || !angular.isDefined($scope.findIgnoreSpace) || $scope.findIgnoreSpace === '') {
                    findIgnoreSpaceValid = false;
                } else {
                    findIgnoreSpaceValid = true;
                }

                if ($scope.findRegExp === null || !angular.isDefined($scope.findRegExp) || $scope.findRegExp === '') {
                    findRegExpValid = false;
                } else {
                    findRegExpValid = true;
                }

                if ($scope.findOption === null || !angular.isDefined($scope.findOption) || $scope.findOption === '') {
                    findOptionValid = false;
                } else {
                    findOptionValid = true;
                }


                var checkFind = true;
                if (findRegExpValid === true) {
                    checkFind = true;
                } else if (findOptionValid === true && (findIgnoreSpaceValid === true || findIgnoreSpaceValid === false) && (findIgnoreCaseValid === true || findIgnoreCaseValid === false)) {
                    checkFind = true;
                } else {
                    checkFind = false;
                }

                // one or more must be true: number of spaces before, number of spaces after, remove paragraph before, remove paragraph after
                if (findWordValid === true && replaceWordValid === true && checkFind === true) {
                    return true;
                } else {
                    return false;
                }

            }
        };

        $scope.saveFindReplaceRuleList = function() {
            $scope.isFormEdited = true;
            if ($scope.validateRule()) {
                var findType = '';
                var ignoreCase = false;
                var ignoreSpaces = false;
                var regexInFind = false;
                if (angular.isDefined($scope.findRegExp) && $scope.findRegExp === true) {
                    findType = 'FindAll';
                    ignoreCase = false;
                    ignoreSpaces = false;
                    regexInFind = true;
                } else {
                    findType = $scope.findOption.name;
                    ignoreCase = $scope.findIgnoreCase || false;
                    ignoreSpaces = $scope.findIgnoreSpace || false;
                    regexInFind = false;
                }
                if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                    var ruleToBeUpdated = {
                        ruleName: $scope.ruleName,
                        find: $scope.findWord,
                        findType: findType,
                        ignoreCase: ignoreCase,
                        ignoreSpaces: ignoreSpaces,
                        replace: $scope.replaceWord,
                        regexInFind: regexInFind
                    };
                    RuleDataService.updateFindandReplaceRule(ruleToBeUpdated, $scope.objectId, $scope.selectedFieldIds, $scope.selectedFieldsPair).then(function() {
                        $state.go('home.admin.media-management.rules.findreplacerules');
                    });
                } else {

                    var ruleToBeCreated = {
                        ruleName: $scope.ruleName,
                        name: $scope.ruleName,
                        find: $scope.findWord,
                        findType: findType,
                        ignoreCase: ignoreCase,
                        ignoreSpaces: ignoreSpaces,
                        replace: $scope.replaceWord,
                        regexInFind: regexInFind,
                        ruleStatus: 'Active'
                    };
                    RuleDataService.createFindandReplaceRule(ruleToBeCreated, $scope.selectedFieldIds).then(function(data) {
                        $state.go('home.admin.media-management.rules.findreplacerules', {
                            'ruleId': data
                        });
                    }, function (error) {
                        $log.error(error);
                    });
                }
            }
        };
    });