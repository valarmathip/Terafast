﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('CriteriaCtrl', function(
        $scope
    ) {
        $scope.message = 'Criteria page is under development';
    });