﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('AdminLandingPageCtrl', function($scope) {

        $scope.modules = [
        // 
        // {
        //     name: 'Account Management',
        //     icon: 'fa-users',
        //     disabled: true
        //         // sref: 'home.admin.account-managements'
        // }, 
        // {
        //     name: 'Distribution',
        //     icon: 'fa-share-alt',
        //     disabled: true
        //         // sref: 'home.admin.distribution'
        // }, 
        {
            name: 'Media Management',
            icon: 'fa-file-text-o',
            //sref: 'home.admin.media-management.rule-builder'
            sref: 'home.admin.media-management.landing-page'
        }, 
        {
            name: 'Product/Plan Management',
            icon: 'fa-file-text-o',
            //disabled: true
            // sref: 'home.admin.ppm'
            sref: 'home.admin.ppm.landing-page'
        }];

    });