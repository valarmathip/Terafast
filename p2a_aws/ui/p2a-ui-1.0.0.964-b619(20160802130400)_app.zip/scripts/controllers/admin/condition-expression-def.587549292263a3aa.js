'use strict';

angular.module('p2AdvanceApp')
    .controller('ConditionExpressionDefCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        ModalDialogFactory,
        RuleDataService,
        ENV_MEDIA_MANAGEMENT,
        ShortNameDictionaryService,
        modalBaseFactory

    ) {

        modalBaseFactory.addShortNameModalState($state.current.name, $scope);
        $scope.isFormEdited = false;
        $scope.currentRule = {};
        $scope.expressionEntries = [];

        $scope.showErrorMsg = ' ';
        $scope.optionOperators = RuleDataService.getoptionConitionList();
        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {

            /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the condition expression, please wait...')

            RuleDataService.getBooleanExpressionById($stateParams.ruleId)
                .success(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()

                    $scope.currentRule = data;
                    $scope.BindDataToUI();
                });
        } else {
            $scope.operatorOption = $scope.optionOperators[0];
        }



        $scope.BindDataToUI = function() {
            //populate the rule definiton on UI element
            if ($scope.currentRule != null && $stateParams.ruleId.trim().toString().length > 0) {
                $scope.objectId = $scope.currentRule.objectId;
                $scope.ruleName = $scope.currentRule.name;
                $scope.operatorOption = $scope.optionOperators[0];
                $scope.lastModificationDate = $scope.currentRule.lastModificationDate;
                $scope.modifier = $scope.currentRule.modifier;
                $scope.templates = $scope.currentRule.templates;
                $scope.ruleStatus = $scope.currentRule.ruleStatus;
                $scope.expression = $scope.currentRule.expression;
            } else {
                $scope.operatorOption = $scope.optionOperators[0];
            }
        };

        $scope.selectTags = function() {
            $scope.availableTags = [];
            ShortNameDictionaryService.getShortNames().then(function(data) {
                $scope.availableTags = data;
                $scope.displayTagModelPopup();
            });
        };

        $scope.displayTagModelPopup = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/list-shortname.html',
                controller: 'ShortNameModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    tagsAvailable: function() {
                        return $scope.availableTags;
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                angular.forEach(result, function(tag) {
                    $scope.insertTextInPosition(tag.shortName + ' ');
                });
            });
        };

        $scope.ruleDefList = [{
            'id': '1',
            'label': 'Condition',
            'isEnabled': true,
            'state': 'home.admin.media-management.condition-expression-definition'
        }, {
            'id': '2',
            'label': 'Show',
            'isEnabled': true,
            'state': 'home.admin.media-management.showhide-rule-definition'
        }, {
            'id': '3',
            'label': 'Find/Replace',
            'isEnabled': true,
            'state': 'home.admin.media-management.findandreplace-rule-definition'
        }, {
            'id': '4',
            'label': 'Trim',
            'isEnabled': true,
            'state': 'home.admin.media-management.delete-rule-definition'
        }];

        $scope.isFormDirty = function() {
            return $scope.isFormEdited === true;
        };

        $scope.saveCondition = function() {

            if ($scope.validateRule()) {
                var expression = $scope.expression;
                expression = RuleDataService.unescapeText(expression).trim();
                var checkExpression = {
                    'expression': expression
                };
                RuleDataService.checkSyntax(checkExpression).then(function(data) {
                    if (data === 'True') {
                        var ruleName = $scope.ruleName;
                        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                            var ruleToBeUpdated = {
                                'expression': expression,
                                'name': ruleName
                            };
                            RuleDataService.updateBooleanExpression(ruleToBeUpdated, $scope.objectId).then(function() {
                                $state.go('home.admin.media-management.rules.conditions');
                            });
                        } else {
                            var expressionToBeCreated = {
                                'expression': expression,
                                'name': ruleName
                            };

                            RuleDataService.createBooleanExpression(expressionToBeCreated).then(function(data) {
                                $state.go('home.admin.media-management.rules.conditions', {
                                    'ruleId': data
                                });
                            });
                        }
                    } else {
                        $scope.showErrorMsg = 'Syntax check failed. Please correct the condition.';
                    }
                });
            }
        };

        $scope.validateRule = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.expression) || $scope.expression.trim() === '') {
                return false;
            } else {
                return true;
            }

        };

        $scope.hideErrorMessage = function() {
            if (angular.isDefined($scope.showErrorMsg) && $scope.showErrorMsg.trim() !== ' ') {
                $scope.showErrorMsg = ' ';
            }
        };

        $scope.checkSyntax = function() {
            if (angular.isDefined($scope.expression) && $scope.expression.trim() !== '') {
                var expression = $scope.expression;
                expression = RuleDataService.unescapeText(expression).trim();
                var ruleToBeUpdated = {
                    'expression': expression
                };
                RuleDataService.checkSyntax(ruleToBeUpdated).then(function(data) {
                    if (data === 'True') {
                        $scope.showErrorMsg = 'Syntax check passed.';
                    } else {
                        $scope.showErrorMsg = 'Syntax check failed. Please correct the condition.';
                    }
                });
            }
        };

        $scope.addOperator = function() {
            if ($scope.operatorOption.dispname !== 'Insert Operator') {
                $scope.insertTextInPosition($scope.operatorOption.name + ' ');
            }
        };

        $scope.setCursorPositionLast = function() {
            $scope.divElement = document.getElementById('txtexpression');
            if ($scope.divElement.lastChild !== null) {
                var range = document.createRange();
                var sel = window.getSelection();
                range.setStart($scope.divElement.lastChild, $scope.divElement.lastChild.length);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
                $scope.divElement.focus();
            }
        };

        $scope.insertTextInPosition = function(value) {
            document.getElementById('txtexpression').focus();
            var sel, range, node;
            if (window.getSelection) {
                sel = window.getSelection();
                if (sel.getRangeAt && sel.rangeCount) {
                    range = window.getSelection().getRangeAt(0);
                    node = range.createContextualFragment(value);
                    range.insertNode(node);
                }
            }
            $scope.setCursorPositionLast();
        };
    });