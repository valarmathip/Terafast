﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ShortNamesCtrl', function (
        $scope,
        $log,
        $filter,
        shortNamesPromise,
        ShortNameDictionaryService,
        ModalDialogFactory,
        ENV,
        uiGridExporterConstants
    ) {
        //The default sort order is "creationDate" in descending order
        $scope.shortNames = $filter('orderBy')(shortNamesPromise, '-creationDate');

        $scope.editShortName = function(id, alias) {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/edit-short-name.html',
                controller: 'ShortNameDetailsCtrl',
                resolve: {
                    shortNameAvailable: function() {                      
                        return ShortNameDictionaryService.getShortNameById(id).then(function (data) {
                            return data;
                        }, function (reason) {
                            $log.error(reason);
                            //ConfirmationModalFactory.open('Error Message', 'Error occured when loading short name.', ENV.modalErrorTimeout);
                        });
                    },
                    isToAddNew: function () {   //if Alias is null means we'll add a new ShortName instead of modifying an Alias
                        var toAdd = true;
                        toAdd = alias === null ? true : false;
                        return toAdd;
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                $scope.gridShortNames.data = $filter('orderBy')(result, '-creationDate');  //refresh the list after modal dialog closed 
            });
        };

        $scope.exportGridToCSV = function ()  {
            $scope.gridApi.exporter.csvExport(uiGridExporterConstants.ALL, uiGridExporterConstants.ALL);
        };

        //used by advanced grid
        $scope.gridShortNames = {
            data: $scope.shortNames,
            enableColumnResizing: false,
            enableFiltering: false,
            enableGridMenu: false,
            enableCellEdit: false,
            showGridFooter: true,
            showColumnFooter: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 55,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'shortName',
                displayName: 'System Name',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">' +
                    '<span class="padding-left-5px" rel="tooltip" title="{{row.entity.shortName}}">{{row.entity.shortName}}</span></div>',
                type: 'string',
                width: '35%',
                enableHiding: false
            }, {
                name: 'path',
                displayName: 'Data Path',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents"><span rel="tooltip" title="{{row.entity.path}}">{{row.entity.path}}</span></div>',
                type: 'string',
                width: '50%',
                enableHiding: false
            }, {
                name: 'businessDataType',
                displayName: 'Output',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.businessDataType}}</div>',
                type: 'string',
                width: '15%',
                enableHiding: false
            }],
            onRegisterApi: function(gridApi){
                $scope.gridApi = gridApi;
            }
        };

    });