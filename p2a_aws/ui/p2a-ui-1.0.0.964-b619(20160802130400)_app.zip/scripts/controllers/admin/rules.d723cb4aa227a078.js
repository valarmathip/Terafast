﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('RulesCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $window,
        RuleDataService,
        moment,
        $q,
        authorizedUserInfo,
        $timeout
    ) {

        $scope.go = function(route) {
            if (route.indexOf('conditions') > 0) {
                $scope.pageHeader = 'Previously Built Conditions';
            } else {
                $scope.pageHeader = 'Previously Built Rules';
            }
            $scope.selectedIdToObjsMap = [];
            inactivateTab(route);
            $state.go(route);
            $rootScope.$broadcast('clearAllSelected');
        };

        $scope.active = function(route) {
            return $state.is(route);
        };

        $scope.showStatusFilter = true;

        $scope.tabs = [{
            heading: 'Conditions',
            route: 'home.admin.media-management.rules.conditions',
            active: false
        }, {
            heading: 'Show',
            route: 'home.admin.media-management.rules.showrules',
            active: false
        }, {
            heading: 'Find/Replace',
            route: 'home.admin.media-management.rules.findreplacerules',
            active: false
        }, {
            heading: 'Trim',
            route: 'home.admin.media-management.rules.trim',
            active: false
        }];
        $scope.$on('$stateChangeSuccess', function() {
            $scope.tabs.forEach(function(tab) {
                tab.active = $scope.active(tab.route);
                isConditionsTabActive(tab, tab.active);
            });
        });

        $scope.userInformation = authorizedUserInfo;

        var isConditionsTabActive = function(tab, isActive) {
            if (tab.heading === 'Conditions' && isActive) {
                $scope.showStatusFilter = false;
            } else if (tab.heading !== 'Conditions' && isActive) {
                $scope.showStatusFilter = true;
            }
        };

        var getActiveTabRoute = function() {
            var routeURL;
            $scope.tabs.forEach(function(tab) {
                if (tab.active) {
                    routeURL = tab.route;
                }
            });
            return routeURL;
        };

        var inactivateTab = function(route) {
            $scope.tabs.forEach(function(tab) {
                if (tab.route === route) {
                    tab.active = true;
                } else {
                    tab.active = false;
                }
            });
        };

        $scope.$on('setRules', function() {
            $scope.rules = RuleDataService.getListData();
            initializeRulesFilterGroups();
        });

        $scope.rules = [];
        $scope.selectedIdToObjsMap = [];
        $scope.filterOptions = [];
        $scope.filteredData = [];

        //get passed data to filter the grid
        $scope.queryData = function(selectedId, objs) {

            var activeTab = getActiveTabRoute();
            $scope.rules = RuleDataService.getListData();

            var obj = $scope.updateSelectIdToObjsMap(selectedId, objs);
            if (obj && $scope.isAnyFilters() === false) {
                $state.go(activeTab, {
                    'rulesData': $scope.rules,
                    'isRuleNOTEmpty': false //
                });
            } else {
                filterItems($scope.rules).then(function(data) {
                    $state.go(activeTab, {
                        'rulesData': data,
                        'isRuleNOTEmpty': true //
                    });
                });

            }
        };

        $scope.updateSelectIdToObjsMap = function(selectedId, objs) {
            var defer = $q.defer();
            // look if selectedId exists in the map
            var isFound = false;
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                if (selectedIdToObjs.selectedId === selectedId) {
                    selectedIdToObjs.objs = objs;
                    isFound = true;
                    defer.resolve(true);
                }
            });
            if (isFound === false) { // create new selectedId 
                $scope.selectedIdToObjsMap[$scope.selectedIdToObjsMap.length] = {
                    'selectedId': selectedId,
                    'objs': objs
                };
                defer.resolve(true);
            }
            deleteEmptyIds();
            return defer.promise;
        };

        var deleteEmptyIds = function() {
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs, index) {
                if (selectedIdToObjs.selectedId === '' && selectedIdToObjs.objs.length) {
                    $scope.selectedIdToObjsMap.splice(index, 1);
                }
            });
        };

        //for filters other than date filter
        var filterItems = function(rules) {

            var rulesClone = angular.copy(rules);
            var defer = $q.defer();
            $scope.filterOptions = setFilterOptions();
            var filterMap = mapFilterOptions();

            filterRulesBySelectedId(rulesClone, filterMap).then(function(filteredrules) {
                $scope.filteredData = filteredrules;

                var activeTab = getActiveTabRoute();
                var rulesList = getRulesList(activeTab);
                defer.resolve(rulesList);
            });

            return defer.promise;
        };

        //Push map objects to filteroptions
        var setFilterOptions = function() {
            $scope.filterOptions = []; //need to clean up the data everytime we do new filtering
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                if (selectedIdToObjs.objs.length > 0) {
                    angular.forEach(selectedIdToObjs.objs, function(item) {
                        $scope.filterOptions.push({
                            'AttributeId': selectedIdToObjs.selectedId,
                            'AttributeValue': item
                        });

                    });
                }
            });
            return $scope.filterOptions;
        };

        //Create filter map
        var mapFilterOptions = function() {
            var lastModifiedBy = [];
            var ruleStatus = [];
            var createdBy = [];
            var modifiedWithin = [];

            var filterMap = {};

            var attrId, attrValue;

            angular.forEach($scope.filterOptions, function(opt) {
                attrId = opt.AttributeId;
                attrValue = opt.AttributeValue;
                switch (attrId) {
                    case 'ruleStatus':
                        ruleStatus.push(attrValue);
                        break;

                    case 'lastModifiedBy':
                        lastModifiedBy.push(attrValue);
                        break;

                    case 'createdBy':
                        createdBy.push(attrValue);
                        break;

                    case 'modifiedWithin':
                        modifiedWithin.push(attrValue);
                        break;
                }
            });

            filterMap['ruleStatus'] = ruleStatus;
            filterMap['lastModifiedBy'] = lastModifiedBy;
            filterMap['createdBy'] = createdBy;
            filterMap['modifiedWithin'] = modifiedWithin;

            return filterMap;
        };

        //Filter Rules by selected Id
        var filterRulesBySelectedId = function(rulesClone, filterMap) {
            var defer = $q.defer();
            var filteredrules = [];
            var allRules = [];
            var resultObjIds = [];
            var filterMapKeyCount = 0;
            var resultRules = [];

            angular.forEach(filterMap, function(filterOpt, filterMapKey) {
                filteredrules = [];
                if (filterOpt.length > 0) {
                    angular.forEach(filterOpt, function(opt) {
                        filteredrules = pushRulesToFilter(rulesClone, filterMapKey, opt, filteredrules);
                    });
                    allRules.push(filteredrules); //Push rules array into an array for every filter option
                }
                filterMapKeyCount++;
                if (Object.keys(filterMap).length === filterMapKeyCount) {
                    getRulesFromObjIds(allRules, resultObjIds, rulesClone, resultRules).then(function(resultRules) {
                        defer.resolve(resultRules);
                    });
                }
            });
            return defer.promise;
        };

        //Compare AttributeValue against rule value and push to an Array
        var pushRulesToFilter = function(rulesClone, attrId, attrValue, filteredrules) {
            var isTruthyval = false;
            angular.forEach(rulesClone, function(rule) {
                if (attrValue === rule[attrId] && attrId !== 'modifiedWithin') {
                    filteredrules.push(rule);
                } else if (attrId === 'modifiedWithin') {
                    var ruleDate = rule['lastModificationDate'];
                    isTruthyval = filterDateItems(rule, attrValue, ruleDate);
                    if (isTruthyval) {
                        filteredrules.push(rule);
                    }
                }
            });
            return filteredrules;
        };

        //Get rule objects from rule objectIds
        var getRulesFromObjIds = function(allRules, resultObjIds, rulesClone, resultRules) {
            var defer = $q.defer();
            resultObjIds = splitRuleArr(allRules);
            var ruleCount = 0;
            angular.forEach(resultObjIds, function(objId) {
                ruleCount++;
                angular.forEach(rulesClone, function(rule) {
                    if (objId === rule.objectId) {
                        resultRules.push(rule);
                        if (resultObjIds.length === ruleCount) {
                            defer.resolve(resultRules);
                        }
                    }
                });
            });

            if (resultObjIds.length === 0) {
                defer.resolve(resultRules);
            }
            return defer.promise;
        };

        //Split allRules array
        var splitRuleArr = function(allRules) {
            var resultObjsColl = [];
            angular.forEach(allRules, function(ruleSlice) {
                resultObjsColl.push(retrieveObjIds(ruleSlice));
            });
            var intersectedArr = intersectRules(resultObjsColl);
            return intersectedArr;
        };

        //Get objectIds from every rule obj
        var retrieveObjIds = function(ruleSlice) {
            var objIds = [];
            angular.forEach(ruleSlice, function(ruleSlice) {
                angular.forEach(ruleSlice, function(ruleSliceVal, ruleSliceKey) {
                    if (ruleSliceKey === 'objectId') {
                        objIds.push(ruleSliceVal);
                    }
                });
            });
            return objIds;
        };

        //Send the objId arrays to intersection function to get the common values.
        var intersectRules = function(resultArr) {
            var args = [];
            for (var i = 0; i < resultArr.length; i++) {
                args.push(resultArr[i]);
            }
            var intersectedArr = $window._.intersection.apply(this, args);
            return intersectedArr;
        };

        var filterDateItems = function(rule, attrValue, ruleDate) {
            if (!ruleDate) {
                return false;
            }
            var today = new Date();
            var modifiedDate = moment(ruleDate).format('YYYY-MM-DD');

            switch (attrValue) {
                case 'Last 15 Days':
                    return modifiedDate > moment(today.setDate(today.getDate() - 15)).format('YYYY-MM-DD');
                case 'Last 30 Days':
                    return modifiedDate > moment(today.setDate(today.getDate() - 30)).format('YYYY-MM-DD');
                case 'Last 60 Days':
                    return modifiedDate > moment(today.setDate(today.getDate() - 60)).format('YYYY-MM-DD');
            }
        };

        $scope.isAnyFilters = function() {
            var length = 0;
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                length += selectedIdToObjs.objs.length;
            });
            if (length > 0) {
                return true;
            }
            return false;
        };

        var getRulesList = function(activeTab) {
            var rulesList = [];
            if (activeTab === 'home.admin.media-management.rules.conditions') {
                rulesList = pushConditionRules();
            } else if (activeTab === 'home.admin.media-management.rules.showrules') {
                rulesList = pushShowRules();
            } else if (activeTab === 'home.admin.media-management.rules.findreplacerules') {
                rulesList = pushFindReplaceRules();
            } else if (activeTab === 'home.admin.media-management.rules.trim') {
                rulesList = pushTrimRules();
            }
            return rulesList;
        };

        var pushConditionRules = function() {
            $scope.allRules = [];
            angular.forEach($scope.filteredData, function(item) {
                $scope.allRules.push({
                    objectId: item.objectId,
                    name: angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                    ruleStatus: item.ruleStatus,
                    createdBy: item.createdBy,
                    lastModifiedBy: item.lastModifiedBy,
                    lastModificationDate: item.lastModificationDate,
                    creationDate: item.creationDate,
                    condition: angular.isDefined(item.expression) ? item.expression : angular.isDefined(item.condition) ? item.condition : ''
                });
            });
            return $scope.allRules;
        };

        var pushShowRules = function() {
            $scope.allRules = [];
            angular.forEach($scope.filteredData, function(item) {
                $scope.allRules.push({
                    'objectId': item.objectId,
                    'name': item.name,
                    'dataFieldsPair': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'dataFields': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'booleanExpressionsPair': angular.isDefined(item.expression) ? item.expression : '',
                    'templates': angular.isDefined(item.templates) ? item.templates : '',
                    'ruleStatus': item.ruleStatus,
                    'expression': angular.isDefined(item.expression) ? item.expression : '',
                    'lastModificationDate': item.lastModificationDate,
                    'modifier': item.modifier,
                    'creationDate': item.creationDate
                });
            });
            return $scope.allRules;
        };

        var pushFindReplaceRules = function() {
            $scope.allRules = [];
            angular.forEach($scope.filteredData, function(item) {
                $scope.allRules.push({
                    'objectId': item.objectId,
                    'name': angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                    'dataFields': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'dataFieldsPair': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'templates': angular.isDefined(item.templates) ? item.templates : '',
                    'ruleStatus': item.ruleStatus,
                    'lastModificationDate': item.lastModificationDate,
                    'find': item.find,
                    'regexInFind': item.regexInFind,
                    'ignoreCase': item.ignoreCase,
                    'ignoreSpaces': item.ignoreSpaces,
                    'replace': item.replace,
                    'findType': item.findType,
                    'modifier': item.modifier,
                    'creationDate': item.creationDate
                });
            });
            return $scope.allRules;
        };

        var pushTrimRules = function() {
            $scope.allRules = [];
            angular.forEach($scope.filteredData, function(item) {
                $scope.allRules.push({
                    'objectId': item.objectId,
                    'name': angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                    'ruleStatus': item.ruleStatus,
                    'spaceBefore': item.spaceBefore,
                    'spacesAfter': item.spacesAfter,
                    'newLineBefore': item.newLineBefore,
                    'newLineAfter': item.newLineAfter,
                    'creationDate': item.creationDate,
                    'modifier': item.modifier,
                    'lastModificationDate': item.lastModificationDate,
                    'dataFields': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'dataFieldsPair': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'templates': angular.isDefined(item.templates) ? item.templates : ''
                });
            });
            return $scope.allRules;
        };

        $scope.modifiedDate = {
            'name': 'modifiedWithin',
            'enum': ['Last 15 Days', 'Last 30 Days', 'Last 60 Days']
        };

        initializeRulesFilterGroups();
        var ruleFilters = {};

        function triggerRemoveAll() {
            if ($scope.rules.length) {
                $timeout(function() {
                    $scope.$apply(function() {
                        $rootScope.$broadcast('removeAllOpt');
                    });
                }, 0);
            }
        }

        function initializeRulesFilterGroups() {
            ruleFilters = {
                '$scope.modifiedByAttributes': $scope.modifiedByAttributes,
                '$scope.createdByAttributes': $scope.createdByAttributes,
                '$scope.modifiedWithinAttributes': $scope.modifiedWithinAttributes,
                '$scope.statusAttributes': $scope.statusAttributes
            };
            ruleFilters = Object.keys(ruleFilters);
            iterateRulesFilters();
        }

        function iterateRulesFilters() {
            var resultArr = [];
            angular.forEach(ruleFilters, function(ruleFilter) {
                resultArr = assignPropName(ruleFilter);
            });
            triggerRemoveAll();
        }

        function assignPropName(ruleFilter) {
            var propertyName = '';
            var attrName = '';
            var resultArr = [];
            switch (ruleFilter) {
                case '$scope.modifiedByAttributes':
                    propertyName = 'lastModifiedBy';
                    attrName = 'Modified By';
                    resultArr = pushAttrObjToRuleArr(propertyName, attrName);
                    $scope.modifiedByAttributes = resultArr;
                    break;
                case '$scope.createdByAttributes':
                    propertyName = 'createdBy';
                    attrName = 'Created By';
                    resultArr = pushAttrObjToRuleArr(propertyName, attrName);
                    $scope.createdByAttributes = resultArr;
                    break;
                case '$scope.modifiedWithinAttributes':
                    propertyName = 'modifiedWithin';
                    attrName = 'Modified Within';
                    resultArr = pushAttrObjTomodifiedDateArr(propertyName, attrName);
                    $scope.modifiedWithinAttributes = resultArr;
                    break;
                case '$scope.statusAttributes':
                    propertyName = 'ruleStatus';
                    attrName = 'ruleStatus';
                    resultArr = pushAttrObjToRuleArr(propertyName, attrName);
                    $scope.statusAttributes = resultArr;
                    break;
            }
            return resultArr;
        }

        function assignValToAttrObj(attrObj, propertyName, attrName, attrVal, displayVal) {
            attrObj['AttributeId'] = propertyName;
            attrObj['AttributeName'] = attrName;
            attrObj['AttributeValue'] = attrVal;
            attrObj['DisplayValue'] = displayVal;

            return attrObj;
        }

        function pushAttrObjToRuleArr(propertyName, attrName) {
            var objArr = [];
            var modifier = propertyName === 'lastModifiedBy' || propertyName === 'createdBy' ? $scope.userInformation.data.user.email : null;
            angular.forEach($scope.rules, function(rule) {
                var attrObj = attrName + rule[propertyName];
                attrObj = {};
                if (modifier) {
                    attrObj = assignValToAttrObj(attrObj, propertyName, attrName, modifier, 'Me');
                } else{
                    attrObj = assignValToAttrObj(attrObj, propertyName, attrName, rule[propertyName], rule[propertyName]);
                }

                if(rule[propertyName]){
                    objArr.push(attrObj);
                }
            });
            objArr = pushUniqueObj(objArr);
            return objArr;
        }

        function pushAttrObjTomodifiedDateArr(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.modifiedDate['enum'], function(enumVal) {
                var attrObj = attrName + enumVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.modifiedDate['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = enumVal;
                attrObj['DisplayValue'] = enumVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushUniqueObj(objArr) {
            for (var i = 0; i < objArr.length; ++i) {
                for (var j = i + 1; j < objArr.length; ++j) {
                    if (objArr[i]['AttributeValue'] === objArr[j]['AttributeValue']) {
                        objArr.splice(j--, 1);
                    }
                }
            }
            return objArr;
        }
    });