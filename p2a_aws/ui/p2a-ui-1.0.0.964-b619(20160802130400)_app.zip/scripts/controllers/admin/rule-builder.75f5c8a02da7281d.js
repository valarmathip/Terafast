﻿'use strict';

angular.module('p2AdvanceApp')
   .controller('RuleBuilderCtrl', function($scope) {
      //initial data for tab-list-directive tabs
      $scope.ruleDefList = [{
         'id': '1',
         'label': 'Condition',
            'isEnabled': true,
            'state': 'home.admin.media-management.condition-expression-definition'
      }, {
         'id': '2',
         'label': 'Show',
            'isEnabled': true,
            'state': 'home.admin.media-management.showhide-rule-definition'
      }, {
         'id': '3',
         'label': 'Find/Replace',
         'isEnabled': true,
         'state': 'home.admin.media-management.findandreplace-rule-definition'
      }, {
         'id': '4',
         'label': 'Trim',
         'isEnabled': true,
         'state': 'home.admin.media-management.delete-rule-definition'
      }];

   });
