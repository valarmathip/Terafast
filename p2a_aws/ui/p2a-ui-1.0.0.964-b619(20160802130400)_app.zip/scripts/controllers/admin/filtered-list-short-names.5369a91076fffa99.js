'use strict';

angular.module('p2AdvanceApp')
    .controller('ListShortNamesCtrl', function (
        $scope, $timeout, ShortNameDictionaryService, PaginationService, $log, ENV, uiGridExporterConstants, isModal, filterList) {

        $scope.isModal = isModal;

        $scope.filterList = filterList;

        $scope.totalSNDRecods = 0;

        $scope.visibleRows = 0;

        $scope.selectedFilterObj = {};

        $scope.filterMessage = 'Please select filter to see the list of Field References.';

        $scope.status = 'ok';

        $scope.select2Options = {
            allowClear:true,
            width: '100%',
            closeOnSelect: false
        };

        /* START modified from attr-filter-directive*/
        $scope.isServiceCollapsed = true;
        $scope.filterName = 'serviceNames';
        $scope.toggleServicePane = function() {
            $scope.isServiceCollapsed = !$scope.isServiceCollapsed;
        };
        $scope.updateSelectFilterObj = function(selectedId, objs) {
            $scope.selectedFilterObj[selectedId] = objs;
        };
        /* END modified from attr-filter-directive*/

        $scope.selectAllChecker = false;
        $scope.selectChecker = false;
        $scope.checkList = [];

        var setOrResetCheckList = function (row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };
        var setCheckList = function () {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };

        $scope.toggleSelection = function (row) {
            if (!$scope.checkList[row.entity.ShortName]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = true;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }

            $scope.$parent.selectedTags = $scope.gridApi.selection.getSelectedRows();
            $scope.checkList[row.entity.ShortName] = $scope.selectChecker;
        };

        $scope.selectAllItems = function () {
            if (!$scope.selectAllChecker) {
                var rows = $scope.gridApi.grid.getVisibleRows();  // select rows on one page of the grid

                angular.forEach(rows, function (row) {
                    row.isSelected = true;
                    row.enableSelection = true;
                    $scope.gridApi.selection.selectRow(row);
                });

                $scope.selectAllChecker = true;

            } else {
                angular.forEach($scope.gridApi.grid.rows, function (row) {
                    row.enableSelection = true;
                    row.isSelected = false;
                });

                $scope.gridApi.selection.clearSelectedRows();
                $scope.selectAllChecker = false;
            }

            $scope.$parent.selectedTags = $scope.gridApi.selection.getSelectedRows();
            angular.forEach($scope.selectedTags, function (tag) {
                $scope.checkList[tag.ShortName] = $scope.selectAllChecker;
            });
        };

        $scope.shortNamesGrid = {
            data: null,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 85,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'objectId',   //actually we use 'ShortName' because it is also unique and 'objectId' is not in the returned data
                displayName: '',
                enableColumnMenu: false,
                headerCellTemplate: '<input type="checkbox" class="grid-checkbox-position" ng-model="grid.appScope.master" ng-click="grid.appScope.selectAllItems()">',
                cellTemplate: '<div class="grid-row-header-position"><input type="checkbox" class="grid-checkbox-position"' +
                              'ng-model="grid.appScope.checkList[row.entity.ShortName]" ng-checked="grid.appScope.master && grid.appScope.checkList[row.entity.ShortName]"' +
                              'ng-click="grid.appScope.toggleSelection(row)" /></div>',
                width: 60,
                enableHiding: false
            }, {
                name: 'ShortName',
                displayName: 'Field Reference',
                cellTemplate: '<div class="ui-grid-cell-contents">' +
                    '<div class="col-cell-full-break">' +
                    '{{row.entity.ShortName}}' +
                    '<div class="hr-small-gray-light">' +
                    '<span ng-show="!angular.isUndefined(row.entity.BusinessDataType)">({{row.entity.BusinessDataType}})</span>' +
                    '</div></div></div>',
                width: '40%',
                enableColumnMenu: false,
                enableHiding: false
            }, {
                name: 'ServiceLevel',
                displayName: 'Service Level',
                cellTemplate: '<div class="ui-grid-cell-contents grid-cell-line-break">{{row.entity.ServiceLevel}}</div>',
                type: 'string',
                width: '15%',
                enableColumnMenu: false,
                enableHiding: false
            }, {
                name: 'ServiceCategory',
                displayName: 'Service Category',
                cellTemplate: '<div class="ui-grid-cell-contents grid-cell-line-break">{{row.entity.ServiceCategory}}</div>',
                width: '15%',
                enableColumnMenu: false,
                enableHiding: false
            }, {
                name: 'ServiceSubCategory',
                displayName: 'Service Subcaterory',
                cellTemplate: '<div class="ui-grid-cell-contents grid-cell-line-break">{{row.entity.ServiceSubCategory}}</div>',
                width: '15%',
                enableColumnMenu: false,
                enableHiding: false
            }, {
                name: 'ServiceName',
                displayName: 'Service Name',
                cellTemplate: '<div class="ui-grid-cell-contents grid-cell-line-break">{{row.entity.ServiceName}}</div>',
                enableColumnMenu: false,
                enableHiding: false
            }, {
                name: 'CostShareLevel',
                displayName: 'Cost Share Level',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.CostShareLevel}}</div>',
                visible: false,
                enableHiding: false
            }, {
                name: 'CostShareTier',
                displayName: 'Cost Share Tier',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.ServiceName}}</div>',
                visible: false,
                enableHiding: false
            }, {
                name: 'CostShareType',
                displayName: 'Cost Share Type',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.CostShareType}}</div>',
                visible: false,
                enableHiding: false
/*  TODO include Entity Attribute once available from the API call
            }, {
                name: 'Attribute',
                displayName: 'Entity Attribute',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.EntityAttribute}}</div>',
                visible: false
*/
            }, {
                name: 'BusinessDataType',
                displayName: 'Business Data Type',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.BusinessDataType}}</div>',
                type: 'string',
                visible: false
            }, {
                name: 'IsMultiValue',
                displayName: 'Multi Values',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.IsMultiValue}}</div>',
                visible: false
            }],

            onRegisterApi : function(gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;

                $scope.$watch(function($scope){
                    return $scope.gridApi.grid.getVisibleRows().length;
                },
                function(newValue) {
                    $scope.visibleRows = newValue; 
                });

                gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
                gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
                
                //gridApi.selection.on.rowSelectionChanged($scope, function() {
                //    $scope.$parent.selectedTags = $scope.gridApi.selection.getSelectedRows();
                //});

                //gridApi.selection.on.rowSelectionChangedBatch($scope, function() {
                //    $scope.$parent.selectedTags = $scope.gridApi.selection.getSelectedRows();
                //});
                gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                    $scope.shortNamesGrid.virtualizationThreshold = pageSize;
                });
            }
        };

        $scope.shortNamesGrid.columnDefs[0].visible = $scope.isModal;

        $scope.showRecords = function() {
             var SHORT_NAMES_RESULT_STATUS_OK = 8;
             return ShortNameDictionaryService.getFilteredShortNames($scope.selectedFilterObj).then(function(data) {

                 if (data.Status === SHORT_NAMES_RESULT_STATUS_OK) {
                    $scope.shortNamesGrid.data = data.ShortNames;
                    $scope.totalSNDRecods = data.TotalRecords;
                    $scope.status = 'ok';
                 } else {
                    $scope.shortNamesGrid.data = null;
                    $scope.totalSNDRecods = 0;
                    $scope.visibleRows = 0;
                    $scope.filterMessage = data.Message;
                    $scope.status = 'error';
                 }

            }, function(reason) {
                $log.error(reason);
            });
        };

        $scope.exportGridToCSV = function ()  {
            $scope.gridApi.exporter.csvExport(uiGridExporterConstants.ALL, uiGridExporterConstants.ALL);
        };

    });
