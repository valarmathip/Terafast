﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ShowHideCtrl', function(
        $scope
    ) {
        $scope.message = 'Show/Hide page is under development';
    });