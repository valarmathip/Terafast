﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ShowHideRuleDefCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        ModalDialogFactory,
        RuleDataService,
        ConfirmationModalFactory,
        ENV_MEDIA_MANAGEMENT
    ) {

        $scope.isFormEdited = false;
        $scope.currentRule = {};
        $scope.selectedBoolean = [];
        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
            /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the show rule, please wait...')

            RuleDataService.getShowRuleById($stateParams.ruleId)
                .success(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    $scope.currentRule = data;
                    $scope.BindDataWithUI();
                });
        }


        $scope.BindDataWithUI = function() {
            //populate the rule definiton on UI element 
            if ($scope.currentRule != null && $stateParams.ruleId.trim().toString().length > 0) {
                $scope.objectId = $scope.currentRule.objectId;
                $scope.ruleName = $scope.currentRule.ruleName;
                //$scope.selectedFields = RuleDataService.getCurrentRuleDataFields();
                $scope.ruleStatus = $scope.currentRule.ruleStatus;
                $scope.selectedBoolean = RuleDataService.getCurrentRuleBooleanExpressionsPair();
                $scope.selectedFields = RuleDataService.getCurrentRuleDataFieldsRulePair();
                $scope.selectedBooleanPair = RuleDataService.getCurrentRuleBooleanExpressionsPair();
                $scope.selectedFieldsPair = [];
                angular.forEach($scope.selectedFields, function(tag) {
                    $scope.selectedFieldsPair.push(tag);
                });
            }
        };


        $scope.selectTags = function() {
            $scope.availableTags = [];

            RuleDataService.getDataFieldsForShowRule().then(function(data) {
                $scope.availableTags = data;
                angular.forEach($scope.selectedFieldsPair, function(item) {
                    $scope.availableTags.unshift({
                        objectId: item.objectId,
                        dataFieldName: item.dataFieldName,
                        templates: item.templates
                    });
                });

                $scope.displayTagModelPopup();
            });
        };

        $scope.displayTagModelPopup = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/list-tags.html',
                controller: 'ShowDataFieldModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    tagsAvailable: function() {
                        return $scope.availableTags;
                    },
                    tagsSelected: function() {

                        return $scope.selectedFields;

                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.selectedFields = [];
                //$scope.selectedFieldIds = [];

                angular.forEach(result, function(tag) {
                    $scope.selectedFields.push(tag);
                    //$scope.selectedFieldIds.push(tag.objectId);
                });
            });
        };

        $scope.removeEntry = function(id) {
            for (var obj in $scope.selectedFields) {
                if ($scope.selectedFields[obj].objectId === id) {
                    $scope.selectedFields.splice(obj, 1);
                }
            }
        };
        $scope.selectConditionTags = function() {
            $scope.availableTags = [];

            RuleDataService.getShowDataFields().then(function(data) {
                $scope.availableConditionTags = data.response.docs;
                $scope.displayConditionTagModelPopup();
            });
        };

        $scope.displayConditionTagModelPopup = function() {
            var dialogConditionOptions = {
                templateUrl: 'views/admin/media-management/list-show-tags.html',
                controller: 'showConditionsModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    tagsAvailable: function() {
                        return $scope.availableConditionTags;
                    },
                    tagsSelected: function() {


                        return $scope.selectedBoolean;

                    }
                }
            };

            ModalDialogFactory.showDialog(dialogConditionOptions).then(function(result) {
                $scope.selectedBoolean = result;

            });
        };

        $scope.ruleDefList = [{
            'id': '1',
            'label': 'Condition',
            'isEnabled': true,
            'state': 'home.admin.media-management.condition-expression-definition'
        }, {
            'id': '2',
            'label': 'Show',
            'isEnabled': true,
            'state': 'home.admin.media-management.showhide-rule-definition'
        }, {
            'id': '3',
            'label': 'Find/Replace',
            'isEnabled': true,
            'state': 'home.admin.media-management.findandreplace-rule-definition'
        }, {
            'id': '4',
            'label': 'Trim',
            'isEnabled': true,
            'state': 'home.admin.media-management.delete-rule-definition'
        }];

        $scope.isFormDirty = function() {
            return $scope.isFormEdited === true;
        };

        $scope.isValidated = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.selectedFields) || $scope.selectedFields.length === 0) {
                return false;
            } else {
                return true;
            }
        };

        $scope.validateRule = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.selectedFields) || $scope.selectedFields.length === 0) {
                return false;
            } else {
                return true;
            }
        };

        $scope.saveConditionRule = function() {
            $scope.isFormEdited = true;

            if ($scope.validateRule()) {
                if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                    var ruleToBeUpdated = {
                        ruleName: $scope.ruleName
                    };
                    RuleDataService.updateShowRule(ruleToBeUpdated, $scope.objectId, $scope.selectedFields, $scope.selectedBoolean[0].objectId, $scope.selectedFieldsPair, $scope.selectedBooleanPair[0].objectId).then(function() {
                        $state.go('home.admin.media-management.rules.showrules');
                    });

                } else {
                    var ruleToBeCreated = {
                        ruleName: $scope.ruleName,
                        name: $scope.ruleName,
                        ruleStatus: 'Active'
                    };

                    RuleDataService.createShowRule(ruleToBeCreated, $scope.selectedBoolean[0].objectId, $scope.selectedFields).then(function(data) {
                        $state.go('home.admin.media-management.rules.showrules', {
                            'ruleId': data
                        });
                    }, function(error) {
                        var msgtitle = 'Unable to Save the Rule';
                        var msg = '';

                        // check if the error message from CM contains the rule name which the current one is duplicated with
                        if (error.developerMessage != null && JSON.stringify(error.developerMessage[0]).indexOf($scope.ruleName) > -1) {
                            msg = 'Rule name "' + $scope.ruleName + '" is already in use. Use a different name.';
                        }
                        else {
                            msg = 'An error occurred while saving the Rule. ' + JSON.stringify(error.developerMessage[0]);
                        }

                        ConfirmationModalFactory.open(msgtitle, msg, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    });

                }
            }
        };

    });