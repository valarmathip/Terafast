﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('PPMRulesCtrl', function(
        $scope,
        $rootScope,
        $state,
        ValidationRuleDataService,
        ENV_MEDIA_MANAGEMENT,
        $q,
        ConfirmationModalFactory,
        $log,
        $stateParams,
        $filter,
        ModalDialogFactory,
        rules,
        newlyAddedRule,
        userAuthorizationManager,
        FilterService,
        PaginationService,
        ENV,
        metaData,
        DatePickerFilterService,
        FilterDataService
    ) {
        $scope.ENV_MEDIA_MANAGEMENT = ENV_MEDIA_MANAGEMENT;
        $scope.rules = [];
        $scope.ruleName = '';
        var preSearchQuery = null;
        $scope.selectedFilters = {};
        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };
        $scope.filters = FilterDataService.updateValidationFilters(metaData);

        var pageSize = 20;
        var isRecordManually = false;

        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim() !== '') { //from create or edit rule screen
            var semiColon = $stateParams.ruleId.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end
            var ruleId = '';
            if (semiColon !== -1) {
                ruleId = $stateParams.ruleId.slice(0, semiColon);
            } else {
                ruleId = $stateParams.ruleId;
            }
            var doesRuleExistInGrid = false;
            var ruleList = rules.response.docs;
            //angular.forEach doesn't support break; use the native for loop
            for (var i = 0, j = ruleList.length; i < j; i++) {
                if (ruleList[i].objectId === ruleId) {
                    doesRuleExistInGrid = true;
                    break;
                }
            }
            if (!doesRuleExistInGrid) {
                $scope.rules.push(newlyAddedRule);
                isRecordManually = true;
            }
        }

        $scope.newlyAddedRule = {};

        $scope.hoverItems = [{
            label: 'Edit This Rule',
            icon: 'fa-pencil',
            isEnabled: true,
            permission: '|all.update,|rulesexpression.update'
        }, {
            label: 'Create New Validation Rule From This Rule',
            icon: 'fa-share-square-o',
            isEnabled: true,
            permission: '|all.create,|rulesexpression.create'
        }, {
            label: 'Make This Rule Active',
            icon: 'fa-check-square-o',
            isShown: function(row) {
                var hasPermission = userAuthorizationManager.hasPermission('all.update') || userAuthorizationManager.hasPermission('rulesexpression.update');

                return hasPermission && row.ruleStatus === 'Inactive';
            }

        }, {
            label: 'Make This Rule Inactive',
            icon: 'fa-ban',
            isShown: function(row) {
                var hasPermission = userAuthorizationManager.hasPermission('all.update') || userAuthorizationManager.hasPermission('rulesexpression.update');

                return hasPermission && row.ruleStatus === 'Active';
            }

        }];

        $scope.hoverItems[0].action = function(row) {
            var editableObject = ValidationRuleDataService.symbols['_' + row.name.toString()];
            if (editableObject && editableObject.objectId === row.objectId) {
                delete ValidationRuleDataService.symbols['_' + row.name.toString()];
            }
            $state.go('home.admin.ppm.validation-rule-builder', {
                'ruleId': row.objectId
            });

        };

        $scope.hoverItems[1].action = function(row) {
            $scope.ruleName = 'Copy of ' + row.name;
            var msgtitle = 'Failed';
            var msg = '';
            var expressionToBeCreated = {
                'expression': row.condition,
                'name': $scope.ruleName,
                'severity': row.severity,
                'validationMessage': row.errorText,
                'ruleStatus': 'Active'
            };
            ValidationRuleDataService.createValidationRule(expressionToBeCreated).then(function(data) {
                $state.go('home.admin.ppm.validation-rule-builder', {
                    'ruleId': data
                });
            }, function(error) {
                if (error.developerMessage && JSON.stringify(error.developerMessage[0].indexOf($scope.ruleName)) > -1) {
                    msg = 'The name of the validation rule conflicts with that of another validation rule. Enter another name';
                    ConfirmationModalFactory.open(msgtitle, msg, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                } else {
                    ConfirmationModalFactory.open(msgtitle, JSON.stringify(error.developerMessage[0]), ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                }
            });


        };

        $scope.hoverItems[2].action = function(row) {
            var patchData = {
                'ruleStatus': 'Active'
            };
            $scope.updateValidationRule(patchData, row.objectId);

        };

        $scope.hoverItems[3].action = function(row) {
            var patchData = {
                'ruleStatus': 'Inactive'
            };
            $scope.updateValidationRule(patchData, row.objectId);

        };

        $scope.updateValidationRule = function(patchData, objectId) {
            ValidationRuleDataService.updateValidationRule(patchData, objectId).then(function() {
                // $state.go('home.admin.ppm.rules', {
                //     'ruleId': data
                // }, {
                //     reload: true
                // });
                event.stopPropagation();
                refreshRuleStatus(patchData.ruleStatus, objectId);
            });
        };
        
        function refreshRuleStatus(ruleStatus, ruleId) {
            var rule = findRuleFromRuleListById(ruleId);
            if (rule) {
                rule.ruleStatus = ruleStatus;
                rule.lastModificationDate = new Date();
            }
        }

        function findRuleFromRuleListById(ruleId) {
            for (var i = 0; i < $scope.rules.length; i++) {
                if (ruleId === $scope.rules[i].objectId) {
                    return $scope.rules[i];
                }
            }

            return null;
        }

        $scope.viewRule = function(currentRule) {
            var dialogOptions = {
                templateUrl: 'views/admin/product-plan/view-rule.html',
                controller: 'ViewPPMRuleCtrl',
                size: 'lg',
                resolve: {
                    ruleAvailable: function() {
                        return currentRule;
                    },
                    ruleType: function() {
                        return 'validationRule';
                    }
                }
            };
            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.gridRules.data = $filter('orderBy')(result, '-creationDate');
            });
        };

        //used by advanced grid
        $scope.gridRules = {
            data: 'rules',
            //'excessRows': 400,
            enablePaginationControls: false,
            useExternalPagination: true,
            useExternalSorting: true,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 70,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                cellTemplate: '<div class="ui-grid-cell-contents">' +
                    '<span><a class="fa fa-eye" href="" ng-click="grid.appScope.viewRule(row.entity)"></a></span> ' +
                    '</div>',
                width: '5%',
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Validation Name',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents ppm-ellipsis-name-style-group admin-ellipsis-and-full-name-style-group-NOT-USED">' +
                    '<div class="col-cell-break">' +
                    //'<hr-hover-menu-widget context="row.entity" items="grid.appScope.hoverItems" grid-options="grid.appScope.gridRules" class="ng-isolate-scope"></hr-hover-menu-widget><br/>' +
                    '<div class="ppm-bfc-ellipsis">' +
                    '   <strong><span class="ellipsis" ppm-hover-menu="grid.appScope.hoverItems" ppm-hover-menu-context-path="row.entity" ppm-long-name-tooltip="{{row.entity.name}}">{{row.entity.name}}</span></strong>' +
                    '</div>' +
                    //'{{row.entity.name}}' +
                    '<div><span ng-show="row.entity.ruleStatus === \'Active\'">({{row.entity.ruleStatus}})</span>' +
                    '<span ng-show="row.entity.ruleStatus === \'Inactive\'">({{row.entity.ruleStatus}})</span> </div>' +
                    '</div>' +
                    '</div>',
                type: 'string',
                width: '20%',
                enableHiding: false
            }, {
                name: 'condition',
                displayName: 'Condition',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.condition}}</div><div context="row.entity" grid-options="grid.appScope.gridRules"></div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'errorText',
                displayName: 'Error Text',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.errorText}}</div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'severity',
                displayName: 'Severity',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.severity}}</div>',
                type: 'string',
                width: '10%',
                enableHiding: false
            }, {
                name: 'lastModificationDate',
                displayName: 'Last modified',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModificationDate | amDateFormat: "' + ENV.dateFormat + '"}}</div>',
                type: 'string',
                width: '15%',
                enableHiding: false,
                enableColumnMenu: false
            }]
        };
        updateRulesList(rules);

        function updateRulesList(data) {

            $scope.loadedRuleList = [];
            $scope.gridRules.totalItems = data.response.numFound;
            $scope.loadedRuleList = data.response.docs;
            if (!isRecordManually) {
                $scope.rules = [];
            }
            angular.forEach($scope.loadedRuleList, function(item) {
                if ($scope.rules.length < $scope.loadedRuleList.length) {
                    $scope.rules.push({
                        objectId: item.objectId,
                        name: item.name,
                        modifier: item.lastModifiedBy,
                        lastModificationDate: item.lastModificationDate,
                        creationDate: item.creationDate,
                        severity: item.severity,
                        errorText: item.validationMessage,
                        condition: angular.isDefined(item.expression) ? item.expression : '',
                        ruleStatus: item.ruleStatus
                    });
                }
            });

        }


        //filterId should be added on adding date widget to a filter
        $scope.datePicker = {
            fromDate: {
                lastModificationDate: [],
                creationDate: []
            },
            toDate: {
                lastModificationDate: [],
                creationDate: []
            }
        };
        $scope.attrYear = {
            field: ''
        };
        $scope.dateOptions = {
            showWeeks: false
        };

        $scope.queryData = function(selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridRules);
            loadData();
        };
        $scope.loaded = function() {
            PaginationService.setSortColumns(null);
            if ($scope.datePicker.fromDate !== '' && $scope.datePicker.toDate !== '') {
                loadData();
            }
        };

        $scope.openCalendar = function($event, $index, effectiveDate) {
            $scope.calendarOpened = {};
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[effectiveDate]) {
                $scope.calendarOpened[effectiveDate] = [];
            }

            $scope.calendarOpened[effectiveDate][$index] = true;
        };

        $scope.setDatePickerAttrId = function(rangeAttr) {
            $scope.selectedFilters = DatePickerFilterService.pushDatePickerAttr(rangeAttr, $scope.selectedFilters);
        };


        $scope.gridRules.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                loadData();
            });
            $scope.gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                loadData();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
                $scope.gridRules.virtualizationThreshold = pageSize;
            });
        };



        function loadData() {
            var filterQuery = '?q=TYPE:"rulesExpression"';
            var currentSearchQuery = FilterService.getFilterQuery($scope.gridApi, $scope.ruleSearchQuery, $scope.gridRules, $scope.selectedFilters, filterQuery, 'name', $scope.matchCase, 'ruleSubmittedDate',
                $scope.datePicker.fromDate, $scope.datePicker.toDate, 0, 'yes');
            currentSearchQuery += PaginationService.getSortQuery();

            if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                return;
            }
            preSearchQuery = currentSearchQuery;
            ValidationRuleDataService.getPaginationAPI(currentSearchQuery).then(function(data) {
                isRecordManually = false;
                updateRulesList(data.data);
            });
        }

        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };

        $scope.pageSizeChanged = function() {
            $scope.gridRules.paginationCurrentPage = 1;
        };

        $scope.lastCompiledDate = function() {
            ValidationRuleDataService.getLastCompiledDate().then(function(data) {
                $scope.lastCompiled = data;

            }, function() {
                $scope.lastCompiled = '';
            });
        };
        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridRules.paginationCurrentPage = 1;
                loadData();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };
        $scope.clearAll = function() {
            $rootScope.$broadcast('clearAllSelected');
        };

        $scope.lastCompiledDate();

        $scope.runGenerator = function() {

            var validationMsgDict = {};

            $scope.insertSymbolTable().then(function() {
                    var outObj = ValidationRuleDataService.generateNetwork('packageName', validationMsgDict);
                    ValidationRuleDataService.getAndUploadScriptFilesInCM(outObj).then(function(objectId) {
                        ValidationRuleDataService.getLastCompiledDate(objectId).then(function(data) {
                            $scope.lastCompiled = data;
                        }, function() {
                            $scope.lastCompiled = '';
                        });
                        if (objectId !== '') {

                            $scope.status = 'Build Success';
                        } else {

                            $scope.status = 'Build failed. Correct the build error(s) and try again';
                        }
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()  // This one looks reduntant
                    }, function() {

                        $scope.status = 'Build failed. Correct the build error(s) and try again';

                    });
                },
                function(reason) {
                    $log.error(reason);
                });


        };


        $scope.insertSymbolTable = function() {
            $scope.defer = $q.defer();
            ValidationRuleDataService.getValidationRuleList().then(function(data) {

                    var validationRulesList = data;
                    var activeValidationRules = [];
                    angular.forEach(validationRulesList, function(validationRule) {
                        if (validationRule.ruleStatus && validationRule.ruleStatus === 'Active') {
                            activeValidationRules.push(validationRule);
                        }

                    });
                    if (Object.keys($state.params).length > 0 && $state.params.ruleId !== '') {
                        ValidationRuleDataService.getNewlyAddedRuleObject($state.params.ruleId, activeValidationRules).then(function(newRecord) {
                            if (newRecord !== '') {
                                activeValidationRules.push(newRecord);
                            }
                            addListIntoSymbolTable(activeValidationRules);
                        }, function(reason) {
                            $log.error(reason);
                            $scope.defer.reject(reason);
                        });

                    } else {
                        addListIntoSymbolTable(activeValidationRules);
                    }

                },
                function(reason) {
                    $log.error(reason);
                    $scope.defer.reject(reason);
                });
            return $scope.defer.promise;
        };

        function addListIntoSymbolTable(validationRulesList) {

            ValidationRuleDataService.createFreshSymbolTable().then(function() {
                var validatioListIterationCount = 0;
                angular.forEach(validationRulesList, function(validationRuleData) {

                    var entry = {
                        symbol: '_' + validationRuleData.name,
                        kind: 'validation',
                        type: 'UNDEFINED',
                        source: validationRuleData.expression,
                        bindings: undefined,
                        level: validationRuleData.severity,
                        message: validationRuleData.validationMessage,
                        hasUnsafeSelfReference: undefined,
                        objectId: validationRuleData.objectId
                    };
                    validatioListIterationCount++;
                    fetchSNDList(entry, ValidationRuleDataService.symbols);
                    if (validationRulesList.length === validatioListIterationCount) {

                        ValidationRuleDataService.insertValidShortNameToSymbols(ValidationRuleDataService.shortNamesList).then(function() {

                            $scope.defer.resolve('success');

                        }, function(reason) {
                            $log.error(reason);
                        });

                    }

                });
            });

        }

        function fetchSNDList(entry, symbolTable) {

            var result;

            var validationMsgs = [];
            try {
                result = $rootScope.parser.parse(entry.source);
            } catch (e) {
                validationMsgs.push('<p>==> ' + String(e) + '</p>');
                return null;
            }
            entry.bindings = ValidationRuleDataService.collectBindings(result, symbolTable, []);

            entry = ValidationRuleDataService.upsertSymbol(symbolTable, entry); // 'pre'-add the symbol to the table for safe self refs

            if (ValidationRuleDataService.hasUnsafeSelfReferences(entry, result, false, false)) {
                entry.hasUnsafeSelfReference = true;
            }
            var annotationMsgs = ValidationRuleDataService.annotateParseTree(result, true, symbolTable, []);
            validationMsgs.push.apply(validationMsgs, annotationMsgs);

            entry = ValidationRuleDataService.upsertSymbol(symbolTable, entry); // refresh the symbol table with updated entry


        }

        $scope.insertSymbolTable();



    });