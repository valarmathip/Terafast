'use strict';

angular.module('p2AdvanceApp')
    .controller('ValidationRuleBuilderCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $window,
        ConfirmationModalFactory,
        ModalDialogFactory,
        ENV_MEDIA_MANAGEMENT,
        ShortNameDictionaryService,
        ValidationRuleDataService,
        modalBaseFactory,
        currentRule,
        $log,
        $q,
        ValidationReportPageslideSvc, ENV, $document
    ) {
        modalBaseFactory.addShortNameModalState($state.current.name, $scope);
        $scope.isFormEdited = false;
        $scope.currentRule = currentRule;
        $scope.expressionEntries = [];
        $scope.showErrorMsg = ' ';
        $scope.showValidationMsg = '';
        $scope.checkSyntaxFlag = false;
        var symbols = ValidationRuleDataService.symbols;
        var functionsAvailable = ValidationRuleDataService.functionsAvailable;
        $scope.optionOperators = ValidationRuleDataService.optionOperators;

        $scope.severity = 'Warning';
        $scope.operatorOption = $scope.optionOperators[0];

        if ($scope.currentRule !== null && $scope.currentRule !== {}) {
            $scope.objectId = $scope.currentRule.objectId;
            $scope.ruleName = $scope.currentRule.name;
            $scope.lastModificationDate = $scope.currentRule.lastModificationDate;
            $scope.modifier = $scope.currentRule.lastModifiedBy;
            $scope.expression = $scope.currentRule.expression;
            $scope.severity = $scope.currentRule.severity;
            $scope.errorText = $scope.currentRule.validationMessage;
        }

        $scope.selectTags = function() {
            $scope.availableTags = [];
            ShortNameDictionaryService.getShortNames().then(function(data) {
                $scope.availableTags = data;
                $scope.displayTagModelPopup();
            });
        };

        $scope.displayTagModelPopup = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/list-shortname.html',
                controller: 'ShortNameModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    tagsAvailable: function() {
                        return $scope.availableTags;
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                angular.forEach(result, function(tag) {
                    $scope.setCursorPositionLast();
                    $scope.insertTextInPosition(tag.shortName + ' ');
                });
            });
        };

        $scope.displayFunctionModelPopup = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/product-plan/list-functions.html',
                controller: 'FunctionModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    functionsAvailable: function() {
                        return functionsAvailable;
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                angular.forEach(result, function(fun) {
                    var modifiedDisplayName = $scope.getPlaceHolders(fun.displayName);
                    $scope.setCursorPositionLast();
                    $scope.insertTextInPosition(modifiedDisplayName + ' ');
                });
            });
        };


        $scope.checkSyntax = function() {
            var defer = $q.defer();
            if (angular.isDefined($scope.expression) && $scope.expression.trim() !== '') {
                ValidationRuleDataService.shortNamesList = [];
                var expWithPlaceHolderValues = replacePlaceholderWithValues($scope.expression);
                var outputString = '';
                var result;
                var symbol = $scope.ruleName;
                var source = ValidationRuleDataService.unescapeText(expWithPlaceHolderValues.trim());
                var validationMsgs = [];
                try {
                    var entry = {
                        symbol: '_' + symbol,
                        type: 'UNDEFINED',
                        kind: 'variable',
                        source: source,
                        bindings: undefined,
                        hasUnsafeSelfReference: undefined
                    };
                    entry = ValidationRuleDataService.upsertSymbol(symbols, entry);
                    result = $rootScope.parser.parse(entry.source);
                    entry.bindings = ValidationRuleDataService.collectBindings(result, symbols, []);
                    entry = ValidationRuleDataService.upsertSymbol(symbols, entry);
                    var annotationMsgs = ValidationRuleDataService.annotateParseTree(result, true, symbols, []);
                    validationMsgs.push.apply(validationMsgs, annotationMsgs);

                    ValidationRuleDataService.insertValidShortNameToSymbols(ValidationRuleDataService.shortNamesList).then(function() {
                        var annotationMsgs = ValidationRuleDataService.annotateParseTree(result, true, symbols, []);
                        validationMsgs.push.apply(validationMsgs, annotationMsgs);
                        var vmsgs = ValidationRuleDataService.validateParseTree(result, true, entry, symbols, []);
                        validationMsgs.push.apply(validationMsgs, vmsgs);
                        entry = ValidationRuleDataService.upsertSymbol(symbols, entry); // refresh
                        if (angular.isDefined(result)) {
                            if ((validationMsgs !== null && validationMsgs.length > 0)) {
                                validationMsgs.forEach(function(m) {
                                    if (outputString === '') {
                                        outputString = m;
                                    } else {
                                        outputString = outputString + ',' + m;
                                    }
                                });

                                $scope.checkSyntaxFlag = false;
                            } else {

                                $scope.checkSyntaxFlag = true;
                            }
                            openPopUp(symbol, validationMsgs);
                            $log.log('result after parsing the exception : ' + JSON.stringify(result));

                            return defer.resolve($scope.checkSyntaxFlag);

                        }
                    }, function(reason) {
                        $log.log(reason);
                        defer.reject(reason);
                    });

                } catch (e) {
                    $log.log('exception while parsing the expression ' + e);
                    validationMsgs.push(e.message);

                    openPopUp(symbol, validationMsgs);
                    $scope.checkSyntaxFlag = false;
                    return defer.resolve($scope.checkSyntaxFlag);
                }

            }
            return defer.promise;
        };

        function replacePlaceholderWithValues(expression) {
            var modifiedExp = expression;
            while (modifiedExp.indexOf('<') > -1) {
                var elementpart = modifiedExp.substring(modifiedExp.indexOf('<'), modifiedExp.indexOf('>') + 1);
                var inputElement = $document[0].createElement('input');
                inputElement.innerHTML = elementpart;
                var elementId = inputElement.firstChild.id;
                if (document.getElementById(elementId)) {
                    modifiedExp = modifiedExp.replace(elementpart, document.getElementById(elementId).value);
                } else {
                    break;
                }
            }
            return modifiedExp;

        }

        function openPopUp(planName, messages) {
            var validatedDate = new Date();
            if ($scope.currentRule !== null && $scope.currentRule !== {}) {
                validatedDate = $scope.lastModificationDate;
            }
            // show result
            var resultObject = {
                warnings: '',
                errors: messages,
                planName: planName,
                validatedDate: validatedDate,
                isFromCheckSyntax: 'true'
            };
            if (resultObject.warnings.length === 0 && resultObject.errors.length === 0) { // no error
                var msgtitle = 'Success';
                var msg = 'Check Syntax Passed';
                ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
            } else {
                ValidationReportPageslideSvc.openPageslide('left', resultObject)
                    .then(function() {
                        $scope.checkSyntax();
                    });
            }

        }

        $scope.isFormDirty = function() {
            return $scope.isFormEdited === true;
        };


        $scope.validateRule = function() {
            return ValidationRuleDataService.validateRule($scope.ruleName, $scope.expression, $scope.errorText);
        };

        $scope.hideErrorMessage = function() {
            if (angular.isDefined($scope.showErrorMsg) && $scope.showErrorMsg.trim() !== ' ') {
                $scope.showErrorMsg = ' ';
            }
            $scope.savePosition();
        };


        $scope.addOperator = function() {
            if ($scope.operatorOption.name !== 'InsertOperator') {
                $scope.insertTextInPosition($scope.operatorOption.name + ' ');
                $scope.savePosition();
            }
        };

        $scope.insertTextInPosition = function(value) {
            angular.element('#txtexpression').focus();
            var sel, range, node, tempVar;
            if ($window.getSelection()) {
                sel = $window.getSelection();
                if (sel.getRangeAt && sel.rangeCount) {
                    range = $window.getSelection().getRangeAt(0);
                    /* Chrome & IE - range.commonAncestorContainer.wholeText, for Firefox - range.commonAncestorContainer.textContent */
                    tempVar = range.commonAncestorContainer.wholeText ? range.commonAncestorContainer.wholeText : range.commonAncestorContainer.textContent;
                    if (ValidationRuleDataService.getNodeSelected() !== null && tempVar === ValidationRuleDataService.getNodeSelected().wholeText) {
                        range.setStart(ValidationRuleDataService.getNodeSelected(), ValidationRuleDataService.getCursorPosition());
                    }
                    node = range.createContextualFragment(value);
                    range.insertNode(node);
                }
            }
            $window.getSelection().removeAllRanges();
            ValidationRuleDataService.setNodeSelected(null);
            $scope.setCursorPositionLast();
        };

        $scope.setCursorPositionLast = function() {
            $scope.divElement = angular.element('#txtexpression');
            if ($scope.divElement[0].lastChild !== null) {
                var range = $window.document.createRange();
                var sel = $window.getSelection();
                range.setStart($scope.divElement[0].lastChild, $scope.divElement[0].lastChild.length);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
                $scope.divElement[0].focus();
            }
        };

        $scope.savePosition = function() {
            var sel = $window.getSelection();
            ValidationRuleDataService.setNodeSelected(null);
            ValidationRuleDataService.setCursorPosition(null);
            if (sel.anchorNode !== null && sel.anchorNode.parentNode.id === 'txtexpression') {
                ValidationRuleDataService.setNodeSelected(sel.anchorNode);
                ValidationRuleDataService.setCursorPosition(sel.anchorOffset);
            }
        };

        $scope.onPaste = function(event) {
            $scope.onPaste(event);
        };

        $scope.saveCondition = function() {
            $scope.checkSyntax().then(function(checkSyntaxFlag) {
                $scope.saveIfcheckSyntaxPass(checkSyntaxFlag);
            }, function(reason) {
                $log.log(reason);
            });
        };

        function removeQuotesFromMsg(validationMessage) {
            validationMessage = validationMessage.replace(/'/g, '"');
            validationMessage = validationMessage.replace(/"/g, '');
            return validationMessage;
        }

        $scope.saveIfcheckSyntaxPass = function(checkSyntaxFlag) {
            if ($scope.validateRule() && checkSyntaxFlag) {
                var expression = $scope.expression;
                expression = ValidationRuleDataService.unescapeText(expression).trim();
                var expAfterReplacePlaceholders = replacePlaceholderWithValues(expression);
                var ruleName = $scope.ruleName;
                var severity = $scope.severity;
                var validationMessage = $scope.errorText;
                validationMessage = ValidationRuleDataService.unescapeText(validationMessage).trim();
                validationMessage = removeQuotesFromMsg(validationMessage);
                var expressionToBeCreated = {
                    'expression': expAfterReplacePlaceholders,
                    'name': ruleName,
                    'severity': severity,
                    'validationMessage': validationMessage,
                    'ruleStatus': 'Active'
                };
                if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                    ValidationRuleDataService.updateValidationRule(expressionToBeCreated, $scope.objectId).then(function(data) {
                        $state.go('home.admin.ppm.rules', {
                            'ruleId': data
                        });
                    }, function(reason) {
                        $log.log(JSON.stringify(reason));
                        // DOGHR-1911: http exception has been handled by UI framework, remove this one.
                        //ConfirmationModalFactory.open('Error Message', 'Error in ' + JSON.stringify(reason), ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    });

                } else {
                    ValidationRuleDataService.createValidationRule(expressionToBeCreated).then(function(data) {
                        $state.go('home.admin.ppm.rules', {
                            'ruleId': data
                        });
                    }, function(reason) {
                        $log.log(JSON.stringify(reason));
                        // DOGHR-1911: http exception has been handled by UI framework, remove this one.
                        // ConfirmationModalFactory.open('Error Message', 'Error in ' + JSON.stringify(reason), ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    });
                }
            }

        };

        $scope.onPaste = function(e) {
            var content;
            e.preventDefault();
            if (e.originalEvent.clipboardData) {
                content = (e.originalEvent || e).clipboardData.getData('text/plain');
                /*remove new line in expression*/
                content = content.replace(/\n/g, '');
                $document[0].execCommand('insertText', false, content);
            } else if ($window.clipboardData) {
                content = $window.clipboardData.getData('Text');
                if ($window.getSelection) {
                    $window.getSelection().getRangeAt(0).insertNode($document[0].createTextNode(content));
                }
            }
        };

        $scope.getPlaceHolders = function(displayname) {
            var nameWithPlaceHolder = displayname;
            if (displayname.indexOf('string') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('string', nameWithPlaceHolder);
            }
            if (displayname.indexOf('num') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('num', nameWithPlaceHolder);
            }
            if (displayname.indexOf('searchValue') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('searchValue', nameWithPlaceHolder);
            }
            if (displayname.indexOf('fromIndex') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('fromIndex', nameWithPlaceHolder);
            }
            if (displayname.indexOf('start') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('start', nameWithPlaceHolder);
            }
            if (displayname.indexOf('length') !== -1 && displayname.indexOf('length()') === -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('length', nameWithPlaceHolder);
            }
            if (displayname.indexOf('num1') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('num1', nameWithPlaceHolder);
            }
            if (displayname.indexOf('num2') !== -1) {
                nameWithPlaceHolder = ValidationRuleDataService.getNameWithPlaceholder('num2', nameWithPlaceHolder);
            }

            return nameWithPlaceHolder;

        };

    });