'use strict';

angular.module('p2AdvanceApp')
    .controller('FunctionModalInstanceCtrl', function(
        $scope,
        ConfirmationModalFactory,
        ModalDialogFactory,
        $modalInstance,
        functionsAvailable
    ) {
        $scope.functions = functionsAvailable;
        $scope.selectedFunctions = [];
        $scope.toggleSelection = function(functionName, description, displayName) {
            $scope.selectedFunctions = [];
            $scope.selectedObject = {};
            $scope.selectedObject['name'] = functionName;
            $scope.selectedObject['description'] = description;
            $scope.selectedObject['displayName'] = displayName;
            $scope.selectedFunctions.push($scope.selectedObject);
        };

        $scope.ok = function() {
            $modalInstance.close($scope.selectedFunctions);
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

    });