'use strict';

angular.module('p2AdvanceApp')
    .controller('ValidationRuleListctrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $log,
        $filter,
        ConfirmationModalFactory,
        ModalDialogFactory,
        rules,
        ValidationRuleDataService,
        ENV_MEDIA_MANAGEMENT,
        userAuthorizationManager,
        ENV
    ) {
        $scope.rules = [];
        $scope.ruleName = '';
        angular.forEach(rules, function(item) {
            $scope.rules.push({
                objectId: item.objectId,
                name: item.name,
                modifier: item.lastModifiedBy,
                lastModificationDate: item.lastModificationDate,
                creationDate: item.creationDate,
                severity: item.severity,
                errorText: item.validationMessage,
                condition: angular.isDefined(item.expression) ? item.expression : '',
                ruleStatus: item.ruleStatus

            });
        });

        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim() !== '') { //from create or edit rule screen
            var semiColon = $stateParams.ruleId.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end
            var ruleId = '';
            if (semiColon !== -1) {
                ruleId = $stateParams.ruleId.slice(0, semiColon);
            } else {
                ruleId = $stateParams.ruleId;
            }
            var doesRuleExistInGrid = false;

            //angular.forEach doesn't support break; use the native for loop
            for (var i = 0, j = $scope.rules.length; i < j; i++) {
                if ($scope.rules[i].objectId === ruleId) {
                    doesRuleExistInGrid = true;
                    break;
                }
            }

            // if the newly added condition haven't got pulled in by cm yet we need to add it by the way as shown below
            if (!doesRuleExistInGrid) {
                ValidationRuleDataService.getValidationRuleById(ruleId)
                    .success(function(data) {
                        // retrieve ruleDataFields and templates if this rule is just created, PONHR-219
                        $scope.newlyAddedRule = {
                            'objectId': data.objectId,
                            'name': data.name,
                            'modifier': data.lastModifiedBy,
                            'lastModificationDate': data.lastModificationDate,
                            'creationDate': data.creationDate,
                            'severity': data.severity,
                            'errorText': data.validationMessage,
                            'condition': angular.isDefined(data.expression) ? data.expression : '',
                            'ruleStatus': data.ruleStatus
                        };
                        $scope.rules.push($scope.newlyAddedRule);
                        $scope.gridRules.data = $filter('orderBy')($scope.rules, '-creationDate');

                    })
                    .error(function() {
                        $scope.rules = $filter('orderBy')($scope.rules, '-creationDate'); // return the original list if error occurs
                    });

            }
        }

        $scope.rules = $filter('orderBy')($scope.rules, '-creationDate');

        $scope.newlyAddedRule = {};

        $scope.hoverItems = [{
            label: 'Edit This Rule',
            icon: 'fa-pencil',
            isEnabled: true,
            permission: '|all.update,|rulesexpression.update'
        }, {
            label: 'Create New Validation Rule From This Rule',
            icon: 'fa-share-square-o',
            isEnabled: true,
            permission: '|all.create,|rulesexpression.create'
        }, {
            label: 'Make This Rule Active',
            icon: 'fa-check-square-o',
            isShown: function(row) {
                var hasPermission = userAuthorizationManager.hasPermission('all.update') || userAuthorizationManager.hasPermission('rulesexpression.update');

                return hasPermission && row.ruleStatus === 'Inactive';
            }

        }, {
            label: 'Make This Rule Inactive',
            icon: 'fa-ban',
            isShown: function(row) {
                var hasPermission = userAuthorizationManager.hasPermission('all.update') || userAuthorizationManager.hasPermission('rulesexpression.update');

                return hasPermission && row.ruleStatus === 'Active';
            }

        }];

        $scope.hoverItems[0].action = function(row) {
            var editableObject = ValidationRuleDataService.symbols['_' + row.name.toString()];
            if (editableObject && editableObject.objectId === row.objectId) {
                delete ValidationRuleDataService.symbols['_' + row.name.toString()];
            }
            $state.go('home.admin.ppm.validation-rule-builder', {
                'ruleId': row.objectId
            });

        };

        $scope.hoverItems[1].action = function(row) {
            $scope.ruleName = 'Copy of ' + row.name;
            var msgtitle = 'Failed';
            var msg = '';
            var expressionToBeCreated = {
                'expression': row.condition,
                'name': $scope.ruleName,
                'severity': row.severity,
                'validationMessage': row.errorText,
                'ruleStatus': 'Active'
            };
            ValidationRuleDataService.createValidationRule(expressionToBeCreated).then(function(data) {
                $state.go('home.admin.ppm.rules.validation-rule-list', {
                    'ruleId': data
                });
            }, function(error) {
                if (error.developerMessage && JSON.stringify(error.developerMessage[0].indexOf($scope.ruleName)) > -1) {
                    msg = 'The name of the validation rule conflicts with that of another validation rule. Enter another name';
                    ConfirmationModalFactory.open(msgtitle, msg, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                } else {
                    ConfirmationModalFactory.open(msgtitle, JSON.stringify(error.developerMessage[0]), ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                }
            });


        };

        $scope.hoverItems[2].action = function(row) {
            var patchData = {
                'ruleStatus': 'Active'
            };
            $scope.updateValidationRule(patchData, row.objectId);

        };

        $scope.hoverItems[3].action = function(row) {
            var patchData = {
                'ruleStatus': 'Inactive'
            };
            $scope.updateValidationRule(patchData, row.objectId);

        };


        $scope.updateValidationRule = function(patchData, objectId) {
            ValidationRuleDataService.updateValidationRule(patchData, objectId).then(function(data) {
                $state.go('home.admin.ppm.rules.validation-rule-list', {
                    'ruleId': data
                }, {
                    reload: true
                });
            });
        };

        $scope.viewRule = function(currentRule) {
            var dialogOptions = {
                templateUrl: 'views/admin/product-plan/view-rule.html',
                controller: 'ViewPPMRuleCtrl',
                size: 'lg',
                resolve: {
                    ruleAvailable: function() {
                        return currentRule;
                    },
                    ruleType: function() {
                        return 'validationRule';
                    }
                }
            };
            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.gridRules.data = $filter('orderBy')(result, '-creationDate');
            });
        };

        //used by advanced grid
        $scope.gridRules = {
            data: $scope.rules,
            enableColumnResizing: false,
            enableFiltering: false,
            enableGridMenu: false,
            enableCellEdit: false,
            showGridFooter: true,
            showColumnFooter: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 70,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                cellTemplate: '<div class="ui-grid-cell-contents">' +
                    '<span><a class="fa fa-eye" href="" ng-click="grid.appScope.viewRule(row.entity)"></a></span> ' +
                    '</div>',
                width: '5%',
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Validation Name',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents ppm-ellipsis-name-style-group admin-ellipsis-and-full-name-style-group-NOT-USED">' +
                    '<div class="col-cell-break">' +
                    //'<hr-hover-menu-widget context="row.entity" items="grid.appScope.hoverItems" grid-options="grid.appScope.gridRules" class="ng-isolate-scope"></hr-hover-menu-widget><br/>' +
                    '<div class="ppm-bfc-ellipsis">' +
                    '   <strong><span class="ellipsis" ppm-hover-menu="grid.appScope.hoverItems" ppm-hover-menu-context-path="row.entity" ppm-long-name-tooltip="{{row.entity.name}}">{{row.entity.name}}</span></strong>' +
                    '</div>' +
                    //'{{row.entity.name}}' +
                    '<div><span ng-show="row.entity.ruleStatus === \'Active\'">({{row.entity.ruleStatus}})</span>' +
                    '<span ng-show="row.entity.ruleStatus === \'Inactive\'">({{row.entity.ruleStatus}})</span> </div>' +
                    '</div>' +
                    '</div>',
                type: 'string',
                width: '20%',
                enableHiding: false
            }, {
                name: 'condition',
                displayName: 'Condition',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.condition}}</div><div context="row.entity" grid-options="grid.appScope.gridRules"></div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'errorText',
                displayName: 'Error Text',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.errorText}}</div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'severity',
                displayName: 'Severity',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.severity}}</div>',
                type: 'string',
                width: '10%',
                enableHiding: false
            }, {
                name: 'lastModificationDate',
                displayName: 'Last modified',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModificationDate | amDateFormat: "' + ENV.dateFormat + '"}}</div>',
                type: 'string',
                width: '15%',
                enableHiding: false,
                enableColumnMenu: false
            }]
        };

    });