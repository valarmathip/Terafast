﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ViewPPMRuleCtrl', function(
        $scope,
        $state,
        ENV,
        $modalInstance,
        ruleAvailable,
        ruleType
    ) {
        $scope.currentRule = ruleAvailable;
        $scope.currentRuleType = ruleType; // need this 'cuz all rules share this view page  
        $scope.editRuleName = 'Edit this Rule';
        if ($scope.currentRuleType === 'validationRule') {
            $scope.editRuleName = 'Edit this Rule';
        }

        $scope.editRule = function() {
            $modalInstance.dismiss('cancel');
            if ($scope.currentRuleType === 'validationRule') {
                $state.go('home.admin.ppm.validation-rule-builder', {
                    'ruleId': $scope.currentRule.objectId
                });
            }
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

    });