'use strict';

angular.module('p2AdvanceApp')
   .controller('ShortNameModalInstanceCtrl', function(
      $scope,
      ModalDialogFactory,
      $modalInstance,
      tagsAvailable
   ) {

      //used by advanced grid
      $scope.gridTags = {
         data: tagsAvailable,
         enableColumnResizing: false,
         enableFiltering: false,
         enableGridMenu: false,
         enableCellEdit: false,
         showGridFooter: true,
         showColumnFooter: false,
         enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
         enableVerticalScrollbar: 2,
         rowHeight: 35,
         paginationPageSizes: [20, 40, 60],
         paginationPageSize: 20,
         columnDefs: [{
            name: 'shortName',
            displayName: 'System Name',
            enableColumnMenu: false,
            cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.shortName}}</div>',
            width: '50%',
            enableHiding: false
         }, {
            name: 'path',
            displayName: 'Data Path',
            cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.path}}</div>',
            width: '50%',
            enableHiding: false
         }]
      };

      $scope.gridTags.multiSelect = true;

      $scope.gridTags.onRegisterApi = function(gridApi) {
         //set gridApi on scope
         $scope.gridApi = gridApi;

         gridApi.selection.on.rowSelectionChanged($scope, function() {
            $scope.selectedTags = $scope.gridApi.selection.getSelectedRows();
         });

         gridApi.selection.on.rowSelectionChangedBatch($scope, function() {
            $scope.selectedTags = $scope.gridApi.selection.getSelectedRows();
         });

      };

      $scope.ok = function() {
         $modalInstance.close($scope.selectedTags);
      };

      $scope.cancel = function() {
         $modalInstance.dismiss('cancel');
      };

   });