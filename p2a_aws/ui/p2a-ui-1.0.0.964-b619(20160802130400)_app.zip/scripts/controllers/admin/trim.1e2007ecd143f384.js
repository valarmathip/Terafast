﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('TrimCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $log,
        $filter,
        RuleDataService,
        ModalDialogFactory,
        rules
    ) {
        $scope.rules = [];
        $scope.selectedIdToObjsMap = [];
        $scope.filterOptions = [];
        $scope.filteredData = $scope.rules;
        if ($stateParams.isRuleNOTEmpty) {
            rules = $stateParams.rulesData;
            angular.forEach(rules, function(item) {
                $scope.rules.push({
                    'objectId': item.objectId,
                    'name': angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                    'ruleStatus': item.ruleStatus,
                    'spaceBefore': item.spaceBefore,
                    'spacesAfter': item.spacesAfter,
                    'newLineBefore': item.newLineBefore,
                    'newLineAfter': item.newLineAfter,
                    'creationDate': item.creationDate,
                    'lastModifiedBy': item.lastModifiedBy,
                    'createdBy': item.createdBy,
                    'lastModificationDate': item.lastModificationDate,
                    'dataFields': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'dataFieldsPair': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'templates': angular.isDefined(item.templates) ? item.templates : ''
                });
            });
        } else {
            angular.forEach(rules, function(item) {
                $scope.rules.push({
                    'objectId': item.objectId,
                    'name': angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                    'ruleStatus': item.ruleStatus,
                    'spaceBefore': item.spaceBefore,
                    'spacesAfter': item.spacesAfter,
                    'newLineBefore': item.newLineBefore,
                    'newLineAfter': item.newLineAfter,
                    'creationDate': item.creationDate,
                    'lastModifiedBy': item.lastModifiedBy,
                    'createdBy': item.createdBy,
                    'lastModificationDate': item.lastModificationDate,
                    'dataFields': angular.isDefined(item.dataFields) ? RuleDataService.getGridDataFields(item.dataFields) : '',
                    'dataFieldsPair': angular.isDefined(item.dataFields) ? item.dataFields : '',
                    'templates': angular.isDefined(item.templates) ? item.templates.join(', ') : ''
                });
            });
            RuleDataService.setListData($scope.rules);
            $rootScope.$broadcast('setRules');
        }

        $scope.rules = $filter('orderBy')($scope.rules, '-creationDate');
        $rootScope.$broadcast('setRules');

        $scope.newlyAddedRule = {};

        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim() !== '') { //from create or edit rule screen

            var semiColon = $stateParams.ruleId.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end
            var ruleId = '';

            if (semiColon !== -1) {
                ruleId = $stateParams.ruleId.slice(0, semiColon);
            } else {
                ruleId = $stateParams.ruleId;
            }

            var doesRuleExistInGrid = false;

            //angular.forEach doesn't support break; use the native for loop
            for (var i = 0, j = $scope.rules.length; i < j; i++) {
                if ($scope.rules[i].objectId === ruleId) {
                    doesRuleExistInGrid = true;
                    break;
                }
            }

            // if the newly added rule haven't got pulled in by cm yet we need to add it by the way as shown below
            if (!doesRuleExistInGrid) {
                RuleDataService.getMMDeletionRuleById(ruleId)
                    .success(function(item) {
                        // retrieve ruleDataFields and templates if this rule is just created, PONHR-219
                        $scope.newlyAddedRule = {
                            'objectId': item.objectId,
                            'name': angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                            'ruleStatus': item.ruleStatus,
                            'spaceBefore': item.spaceBefore,
                            'spacesAfter': item.spacesAfter,
                            'newLineBefore': item.newLineBefore,
                            'newLineAfter': item.newLineAfter,
                            'creationDate': item.creationDate,
                            'lastModifiedBy': item.lastModifiedBy,
                            'createdBy': item.createdBy,
                            'lastModificationDate': item.lastModificationDate,
                            'dataFields': angular.isDefined(item.dataFields) ? RuleDataService.getGridDataFields(item.dataFields) : '',
                            'dataFieldsPair': angular.isDefined(item.dataFields) ? item.dataFields : '',
                            'templates': angular.isDefined(item.templates) ? item.templates.join(', ') : ''
                        };
                        $scope.rules.push($scope.newlyAddedRule);
                        $scope.gridRules.data = $scope.rules;
                    })
                    .error(function() {
                        $scope.rules = $filter('orderBy')($scope.rules, '-creationDate'); // return the original list if error occurs
                    });
            }
        }

        $scope.hoverItems = [{
            label: 'Edit this Rule',
            icon: 'fa-pencil',
            isEnabled: true
        }, {
            label: 'Deactivate',
            icon: '',
            isEnabled: true
        }];

        $scope.hoverItems[0].action = function(row) {
            RuleDataService.setCurrentRuleDataFieldNamesPair(row.dataFieldsPair);
            RuleDataService.setCurrentRuleDataFieldNames(row.dataFields);
            $state.go('home.admin.media-management.delete-rule-definition', {
                'ruleId': row.objectId
            });
        };

        $scope.hoverItems[1].action = function(row) {
            row.ruleStatus = 'Inactive';
            RuleDataService.deactivateRule(row.objectId, 'deletionRule').then(function() {
                $state.go('home.admin.media-management.rules.trim');
            });
        };

        $scope.viewRule = function(currentRule) {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/view-rule.html',
                controller: 'ViewRuleCtrl',
                size: 'lg',
                resolve: {
                    ruleAvailable: function() {
                        return currentRule;
                    },
                    ruleType: function() {
                        return 'deletionRule'; //TODO: might need a place to set a constant for different rule type        
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.gridRules.data = $filter('orderBy')(result, '-creationDate');
            });
        };

        //used by advanced grid
        $scope.gridRules = {
            data: $scope.rules,
            enableColumnResizing: false,
            enableFiltering: false,
            enableGridMenu: false,
            enableCellEdit: false,
            showGridFooter: true,
            showColumnFooter: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 85,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                //headerCellTemplate: '<input type="checkbox" class="grid-checkbox-position-batch">',   //hide checkbox for future use
                cellTemplate: '<div class="ui-grid-cell-contents text-center">' +
                    //'<div class="grid-row-header-position"><input type="checkbox" class="grid-checkbox-position" /><span class="pull-left-11px"> ' +
                    '<a class="fa fa-eye" href="" ng-click="grid.appScope.viewRule(row.entity)"></a>' +
                    '</div>',
                width: '5%',
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Rule Name',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents admin-ellipsis-and-full-name-style-group">' +
                    '<hr-hover-menu-widget context="row.entity" items="grid.appScope.hoverItems" grid-options="grid.appScope.gridRules" ng-show="row.entity.ruleStatus === \'Active\'"></hr-hover-menu-widget>' +
                    '<div><span class="ellipsis" ppm-long-name-tooltip="{{row.entity.name}}" ng-show="row.entity.ruleStatus !== \'Active\'">{{row.entity.name}}</span></div>' +
                    '<div ng-class="{\'after-hover-menu\': row.entity.ruleStatus === \'Active\'}">({{row.entity.ruleStatus}})</div>' +
                    '</div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'dataFields',
                displayName: 'Fields',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents"><span ppm-long-name-tooltip="{{row.entity.dataFields}}">{{row.entity.dataFields}}</span></div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'templates',
                displayName: 'Templates',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents" title="{{row.entity.templates}}">{{row.entity.templates}}</div>',
                type: 'string',
                width: '25%',
                enableHiding: false
            }, {
                name: 'lastModificationDate',
                displayName: 'Last modified',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModificationDate | date:"yyyy-MM-dd h:mma"}}</div>',
                type: 'string',
                enableHiding: false,
                enableColumnMenu: false
            }],
            onRegisterApi: function(gridApi) {
                gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                    $scope.gridRules.virtualizationThreshold = pageSize;
                });
            }
        };
    });