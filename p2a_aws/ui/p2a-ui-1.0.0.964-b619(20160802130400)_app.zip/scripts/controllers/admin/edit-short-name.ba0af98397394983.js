﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ShortNameDetailsCtrl', function (
        $scope,
        $state,
        $modalInstance,
        $http,
        $filter,
        $log,
        ShortNameDictionaryService,
        ConfirmationModalFactory,
        shortNameAvailable,
        isToAddNew,
        ENV_MEDIA_MANAGEMENT
    ) {

        $scope.currentShortName = shortNameAvailable;
        $scope.remainingChars = ENV_MEDIA_MANAGEMENT.shortNameMaxLength;
        $scope.toAddNew = isToAddNew,

        /*jshint expr:true*/
        $scope.validateAlias = function () {
            if (angular.isUndefined($scope.alias)) {
                return false;
            }
            
            if ($scope.alias.length === 0) {
                return false;
            }
            else {
                return true;
            }         
        };

        // need to call this with keydown otherwise "white space" is not counted 
        $scope.updateChars = function () {
            if (!angular.isUndefined($scope.alias) || angular.isObject($scope.alias)) {
                // when key pressed the character count in the textbox is already 1 not 0, so we need to set it to 1
                var aliasInitialValue = 1;

                if (ENV_MEDIA_MANAGEMENT.shortNameMaxLength - ($scope.alias.length + aliasInitialValue) >= 0) {
                    $scope.remainingChars = ENV_MEDIA_MANAGEMENT.shortNameMaxLength - ($scope.alias.length + aliasInitialValue);
                }
                else {
                    $scope.remainingChars = 0;  // remainingChars cannot be negative integer
                }
            }
        };

        $scope.$watch(function ($scope) {
                return $scope.alias;
            },
            function (newValue) {
                if (!angular.isUndefined(newValue)) {
                    $scope.remainingChars = ENV_MEDIA_MANAGEMENT.shortNameMaxLength - newValue.length;  //update $scope.remainingChars with newValue
                }
                else {
                    $scope.remainingChars = ENV_MEDIA_MANAGEMENT.shortNameMaxLength;
                }
            }
        );

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

        $scope.saveShortName = function () {
            // check if any duplicated name exists
            ShortNameDictionaryService.getShortNameByName($scope.alias)
            .success(function (data) {
                // retrieve the search returned object with path: data.response.docs
                if (!angular.isUndefined(data.response.docs) && data.response.docs.length > 0) {
                    ConfirmationModalFactory.open('Error Occurred', '"' + $scope.alias + '" already exists', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                }
                else {
                    // to create a new ShortName
                    if ($scope.toAddNew) {
                        // call CRUD Api to create a new short name.
                        ShortNameDictionaryService.createShortName($scope.currentShortName, $scope.alias)
                        .then(function () {
                            // after creating reload the shortNameDictionary list and send back to the calling page
                            ShortNameDictionaryService.getShortNames().then(function (data) {
                                $modalInstance.close(data);
                            }, function () {
                                $scope.cancel();
                                $state.go('home.admin.media-management.short-name-list');
                            });

                        }, function () {
                            //ConfirmationModalFactory.open('Error Message', 'Error Occurred when saving ' + $scope.alias, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                            $scope.cancel();
                        });
                    }
                    else {  // to edit an existing Alias
                        ShortNameDictionaryService.editShortNameAlias($scope.currentShortName, $scope.alias)
                        .then(function () {
                            // after editing reload the shortNameDictionary list and send back to the calling page
                            ShortNameDictionaryService.getShortNames().then(function (data) {
                                $modalInstance.close(data);
                            }, function () {
                                $scope.cancel();
                                $state.go('home.admin.media-management.short-name-list');
                            });

                        }, function () {
                            //ConfirmationModalFactory.open('Error Message', 'Error Occurred when saving ' + $scope.alias, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                            $scope.cancel();
                        });
                    }
                }
            });
        };

    });