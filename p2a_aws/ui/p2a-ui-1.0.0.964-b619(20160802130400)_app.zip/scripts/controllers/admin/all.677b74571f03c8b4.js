﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('AllCtrl', function(
        $scope
    ) {
        $scope.message = 'All page is under development';
    });