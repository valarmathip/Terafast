'use strict';

angular.module('p2AdvanceApp')
  .controller('ModalBaseCtrl', function ($scope, $state, $modalInstance, parentName, modalTitle) {

      $scope.modalTitle = modalTitle;

      $scope.ok = function() {
          $modalInstance.close($scope.selectedTags);
          $state.go(parentName);
      };

      $scope.cancel = function() {
          $modalInstance.dismiss('cancel');
          $state.go(parentName);
      };
  });
