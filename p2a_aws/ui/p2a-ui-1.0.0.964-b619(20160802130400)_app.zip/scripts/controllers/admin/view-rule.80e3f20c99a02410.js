﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ViewRuleCtrl', function(
        $scope,
        $state,
        ENV,
        $modalInstance,
        RuleDataService,
        ruleAvailable,
        ruleType
    ) {
        $scope.currentRule = ruleAvailable;
        $scope.currentRuleType = ruleType; // need this 'cuz all rules share this view page  
        $scope.editRuleName = 'Edit this Rule';
        if ($scope.currentRuleType === 'booleanExpression') {
            $scope.editRuleName = 'Edit this condition';
        }

        $scope.editRule = function() {
            $modalInstance.dismiss('cancel');
            //we need to know the rule type so we can go to different state
            if ($scope.currentRuleType === 'deletionRule') {
                RuleDataService.setCurrentRuleDataFieldNamesPair($scope.currentRule.dataFieldsPair);
                RuleDataService.setCurrentRuleDataFieldNames($scope.currentRule.dataFields);
                $state.go('home.admin.media-management.delete-rule-definition', {
                    'ruleId': $scope.currentRule.objectId
                });
            }
            //For find/replace rule
            if ($scope.currentRuleType === 'findReplaceRule') {
                RuleDataService.setCurrentRuleDataFieldNamesPair($scope.currentRule.dataFieldsPair);
                RuleDataService.setCurrentRuleDataFieldNames($scope.currentRule.dataFields);
                $state.go('home.admin.media-management.findandreplace-rule-definition', {
                    'ruleId': $scope.currentRule.objectId
                });
            }
            if ($scope.currentRuleType === 'booleanExpression') {

                $state.go('home.admin.media-management.condition-expression-definition', {
                    'ruleId': $scope.currentRule.objectId
                });
            }
            if ($scope.currentRuleType === 'showRule') {
                $scope.rulesObject = {};
                RuleDataService.getTemplateName().then(function(result) {
                    angular.forEach(result, function(itemNew) {
                        $scope.rulesObject[itemNew.objectId] = itemNew.name;
                    });


                    RuleDataService.setCurrentRuleDataFieldNames($scope.currentRule.dataFields);
                    RuleDataService.setCurrentRuleBooleanExpressions($scope.currentRule.expression);
                    RuleDataService.setCurrentRuleDataFieldNamesRulePair($scope.currentRule.dataFieldsPair, $scope.rulesObject);
                    RuleDataService.setCurrentRuleBooleanExpressionsPair($scope.currentRule.booleanExpressionsPair);
                    $state.go('home.admin.media-management.showhide-rule-definition', {
                        'ruleId': $scope.currentRule.objectId
                    });
                });
            }
        };

        $scope.deactivateRule = function() {
            RuleDataService.deactivateRule($scope.currentRule.objectId, $scope.currentRuleType).then(function() {
                $scope.currentRule.ruleStatus = 'Inactive';
                //refresh data
                //we need to know the rule type so we can call diffrent api
                if ($scope.currentRuleType === 'deletionRule') {
                    $state.go('home.admin.media-management.rules.trim');
                }
                //For find/replace rule
                if ($scope.currentRuleType === 'findReplaceRule') {
                    $state.go('home.admin.media-management.rules.findreplacerules');
                }
                //For showRule rule  
                if ($scope.currentRuleType === 'showRule') {
                    $state.go('home.admin.media-management.rules.showrules');
                }
                $modalInstance.close();
            });

        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

        $scope.numberOfSpaceText = function() {
            var text = '';

            if ($scope.currentRule != null) {
                if ($scope.currentRule.spaceBefore != null && $scope.currentRule.spaceBefore !== '') {
                    text += $scope.currentRule.spaceBefore + ' ' + 'Before';
                }
                if ($scope.currentRule.spacesAfter != null && $scope.currentRule.spacesAfter !== '') {
                    //if text contains some character, means we have 'xx Before' so we can add 'and', otherwise don't need 'and'
                    if (text.length > 0) {
                        text += ' ' + 'and' + ' ';
                    }

                    text += $scope.currentRule.spacesAfter + ' ' + 'After';
                }
            }

            return text;
        };

        $scope.newLineText = function() {
            var text = '';

            if ($scope.currentRule != null) {
                if ($scope.currentRule.newLineBefore != null && angular.lowercase($scope.currentRule.newLineBefore) === 'true') {
                    text += 'Before';
                }
                if ($scope.currentRule.newLineAfter != null && angular.lowercase($scope.currentRule.newLineAfter) === 'true') {
                    //if text contains some character, means we have 'Before' so we can add 'and', otherwise don't need 'and'
                    if (text.length > 0) {
                        text += ' ' + 'and' + ' ';
                    }
                    text += 'After';
                }
            }

            return text;
        };

    });