﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ConditionCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $log,
        $filter,
        RuleDataService,
        ModalDialogFactory,
        rules,
        ENV
    ) {
        $scope.rules = [];
        $scope.selectedIdToObjsMap = [];
        $scope.filterOptions = [];
        $scope.filteredData = $scope.rules;
        if ($stateParams.isRuleNOTEmpty) {
            rules = $stateParams.rulesData;
        } else {
            RuleDataService.setListData($scope.rules);
        }
        angular.forEach(rules, function(item) {
            $scope.rules.push({
                'objectId': item.objectId,
                'name': angular.isDefined(item.ruleName) ? item.ruleName : item.name,
                //'ruleStatus': item.ruleStatus,
                'createdBy': item.createdBy,
                'lastModifiedBy': item.lastModifiedBy,
                'lastModificationDate': item.lastModificationDate,
                'creationDate': item.creationDate,
                'condition': angular.isDefined(item.expression) ? item.expression : angular.isDefined(item.condition) ? item.condition : ''
            });
        });
        $scope.rules = $filter('orderBy')($scope.rules, '-creationDate');
        $rootScope.$broadcast('setRules');

        $scope.newlyAddedRule = {};

        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim() !== '') { //from create or edit rule screen

            var semiColon = $stateParams.ruleId.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end
            var ruleId = '';

            if (semiColon !== -1) {
                ruleId = $stateParams.ruleId.slice(0, semiColon);
            } else {
                ruleId = $stateParams.ruleId;
            }

            var doesRuleExistInGrid = false;

            //angular.forEach doesn't support break; use the native for loop
            for (var i = 0, j = $scope.rules.length; i < j; i++) {
                if ($scope.rules[i].objectId === ruleId) {
                    doesRuleExistInGrid = true;
                    break;
                }
            }

            // if the newly added condition haven't got pulled in by cm yet we need to add it by the way as shown below
            if (!doesRuleExistInGrid) {
                RuleDataService.getBooleanExpressionById(ruleId)
                    .success(function(data) {
                        // retrieve ruleDataFields and templates if this rule is just created, PONHR-219
                        $scope.newlyAddedRule = {
                            'objectId': data.objectId,
                            'name': data.name,
                            'createdBy': data.createdBy,
                            'lastModifiedBy': data.lastModifiedBy,
                            'lastModificationDate': data.lastModificationDate,
                            'condition': data.expression,
                            'creationDate': data.creationDate
                        };
                        $scope.rules.push($scope.newlyAddedRule);
                        $scope.gridRules.data = $scope.rules;
                    })
                    .error(function() {
                        $scope.rules = $filter('orderBy')($scope.rules, '-creationDate'); // return the original list if error occurs
                    });

            }
        }

        $scope.hoverItems = [{
            label: 'Edit this Condition',
            icon: 'fa-pencil',
            permission: '|all.read,|contentrule.update',
            isEnabled: true
        }];


        $scope.hoverItems[0].action = function(row) {
            $state.go('home.admin.media-management.condition-expression-definition', {
                'ruleId': row.objectId
            });
        };

        $scope.viewRule = function(currentRule) {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/view-rule.html',
                controller: 'ViewRuleCtrl',
                size: 'lg',
                resolve: {
                    ruleAvailable: function() {
                        return currentRule;
                    },
                    ruleType: function() {
                        return 'booleanExpression';
                    }
                }
            };
            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.gridRules.data = $filter('orderBy')(result, '-creationDate');
            });
        };

        //used by advanced grid
        $scope.gridRules = {
            data: $scope.rules,
            enableColumnResizing: false,
            enableFiltering: false,
            enableGridMenu: false,
            enableCellEdit: false,
            showGridFooter: true,
            showColumnFooter: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 70,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                //headerCellTemplate: '<input type="checkbox" class="grid-checkbox-position-batch">',   //hide checkbox for future use
                cellTemplate: '<div class="ui-grid-cell-contents text-center">' +
                    //'<div class="grid-row-header-position"><input type="checkbox" class="grid-checkbox-position" />' +
                    '<a class="fa fa-eye" href="" ng-click="grid.appScope.viewRule(row.entity)"></a>' +
                    '</div>',
                width: '5%',
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Condition Name',
                enableSorting: true,
                cellTemplate: '<div data-hraf-id="condition-{{row.entity.objectId}}-name"' +
                ' data-hraf-class="condition-name" ' +
                'class="ui-grid-cell-contents admin-ellipsis-and-full-name-style-group">' +
                    '<hr-hover-menu-widget context="row.entity" items="grid.appScope.hoverItems" grid-options="grid.appScope.gridRules" ng-show="row.entity.objectId.length > 0" ></hr-hover-menu-widget>' +
                    //'{{row.entity.name}}' +
                    '</div>',
                type: 'string',
                width: '20%',
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'condition',
                displayName: 'Condition',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.condition}}</div><div context="row.entity" grid-options="grid.appScope.gridRules"></div>',
                type: 'string',
                width: '25%',
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'lastModifiedBy',
                displayName: 'Last Modified By',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModifiedBy}}</div>',
                type: 'string',
                width: '25%',
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'lastModificationDate',
                displayName: 'Last modified',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModificationDate | amDateFormat: "'+ENV.dateFormat+'"}}</div>',
                type: 'string',
                enableHiding: false,
                enableColumnMenu: false
            }],
            onRegisterApi: function(gridApi) {
                gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                    $scope.gridRules.virtualizationThreshold = pageSize;
                });
            }
        };
    });
