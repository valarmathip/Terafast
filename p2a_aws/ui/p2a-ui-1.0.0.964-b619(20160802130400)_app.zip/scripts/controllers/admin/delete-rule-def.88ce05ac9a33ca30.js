﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('DeleteRuleDefCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $log,
        ModalDialogFactory,
        RuleDataService
    ) {

        $scope.isFormEdited = false;
        $scope.currentRule = {};

        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
            /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the trim rule, please wait...')

            RuleDataService.getDeletionRuleById($stateParams.ruleId) //cm always retrieve the latest version
                .success(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    $scope.currentRule = data;
                    $scope.BindDataWithUI();
                });
        }

        $scope.BindDataWithUI = function() {
            //populate the rule definiton on UI element
            if ($scope.currentRule != null && $stateParams.ruleId.trim().toString().length > 0) {
                $scope.objectId = $scope.currentRule.objectId;
                $scope.ruleName = $scope.currentRule.ruleName;
                $scope.selectedFields = RuleDataService.getCurrentRuleDataFields();
                $scope.selectedFieldIds = RuleDataService.getCurrentRuleDataFieldsPair();
                $scope.spaceBefore = $scope.currentRule.spaceBefore;
                $scope.spacesAfter = $scope.currentRule.spacesAfter;
                $scope.newLineBefore = $scope.currentRule.newLineBefore;
                $scope.newLineAfter = $scope.currentRule.newLineAfter;
                $scope.ruleStatus = $scope.currentRule.ruleStatus;
                $scope.selectedFieldsPair = RuleDataService.getCurrentRuleDataFieldsPair();
            }
        };


        $scope.selectTags = function() {
            $scope.availableTags = [];

            RuleDataService.getDataFields('trim').then(function(data) {
                $scope.availableTags = data;
                $scope.displayTagModelPopup();
            });
        };

        $scope.displayTagModelPopup = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/list-tags.html',
                controller: 'TagsModalInstanceCtrl',
                size: 'lg',
                resolve: {
                    tagsAvailable: function() {
                        return $scope.availableTags;
                    },
                    tagsSelected: function() {

                        return $scope.selectedFieldIds;

                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
                $scope.selectedFields = [];
                $scope.selectedFieldIds = [];

                angular.forEach(result, function(tag) {
                    $scope.selectedFields.push(tag.dataFieldName);
                    $scope.selectedFieldIds.push({
                        objectId: tag.objectId
                    });
                    $scope.selectedFields.sort();
                });
            });
        };

        $scope.ruleDefList = [{
            'id': '1',
            'label': 'Condition',
            'isEnabled': true,
            'state': 'home.admin.media-management.condition-expression-definition'
        }, {
            'id': '2',
            'label': 'Show',
            'isEnabled': true,
            'state': 'home.admin.media-management.showhide-rule-definition'
        }, {
            'id': '3',
            'label': 'Find/Replace',
            'isEnabled': true,
            'state': 'home.admin.media-management.findandreplace-rule-definition'
        }, {
            'id': '4',
            'label': 'Trim',
            'isEnabled': true,
            'state': 'home.admin.media-management.delete-rule-definition'
        }];

        $scope.isFormDirty = function() {
            return $scope.isFormEdited === true;
        };

        $scope.isValidated = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.selectedFields) || $scope.selectedFields.length === 0) {
                return false;
            } else {
                return true;
            }
        };

        // rule validation, one or more of the four options are selected: 
        // number of spaces before, number of spaces after, remove paragraph before, remove paragraph after

        $scope.validateRule = function() {
            if (!angular.isDefined($scope.ruleName) || $scope.ruleName === '') {
                return false;
            } else if (!angular.isDefined($scope.selectedFields) || $scope.selectedFields.length === 0) {
                return false;
            } else {

                var isValid = verifySpaceBeforeOrInsert();
                return isValid;

            }
        };

        function verifySpaceBeforeOrInsert() {
            var spaceBeforeValid = true;
            var spaceAfterValid = true;

            //number of space before is not mandatory
            if ($scope.spaceBefore === null || !angular.isDefined($scope.spaceBefore) || $scope.spaceBefore === '') {
                spaceBeforeValid = false;
            } else {
                if (!isNaN(parseInt($scope.spaceBefore, 10)) && parseInt($scope.spaceBefore, 10) > 0) { // number of spaces Before value must be great than 0
                    spaceBeforeValid = true;
                } else {
                    spaceBeforeValid = false;
                }
            }
            //number of space after is not mandatory
            if ($scope.spacesAfter === null || !angular.isDefined($scope.spacesAfter) || $scope.spacesAfter === '') {
                spaceAfterValid = false;
            } else {
                if (!isNaN(parseInt($scope.spacesAfter, 10)) && parseInt($scope.spacesAfter, 10) > 0) { // number of spaces After value must be great than 0
                    spaceAfterValid = true;
                } else {
                    spaceAfterValid = false;
                }
            }

            var isValid = $scope.checkSpacesValid(spaceBeforeValid, spaceAfterValid);
            return isValid;

        }
        // one or more must be true: number of spaces before, number of spaces after, remove paragraph before, remove paragraph after
        $scope.checkSpacesValid = function(spaceBeforeValid, spaceAfterValid) {
            if (spaceBeforeValid === true || spaceAfterValid === true) {
                return true;
            } else {
                if ($scope.newLineBefore || $scope.newLineAfter) {
                    return true;
                } else {
                    return false;
                }
            }

            return true;
        };

        $scope.saveDeletionRule = function() {
            $scope.isFormEdited = true;

            if ($scope.validateRule()) {
                if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                    var ruleToBeUpdated = {
                        spaceBefore: $scope.spaceBefore,
                        spacesAfter: $scope.spacesAfter,
                        newLineBefore: $scope.newLineBefore,
                        newLineAfter: $scope.newLineAfter,
                        ruleName: $scope.ruleName
                    };

                    RuleDataService.updateDeletionRule(ruleToBeUpdated, $scope.objectId, $scope.selectedFieldIds, $scope.selectedFieldsPair).then(function() {
                        $state.go('home.admin.media-management.rules.trim');
                    });

                } else {
                    var ruleToBeCreated = {
                        spaceBefore: $scope.spaceBefore,
                        spacesAfter: $scope.spacesAfter,
                        newLineBefore: $scope.newLineBefore,
                        newLineAfter: $scope.newLineAfter,
                        ruleName: $scope.ruleName,
                        name: $scope.ruleName,
                        ruleStatus: 'Active'
                    };

                    RuleDataService.createDeletionRule(ruleToBeCreated, $scope.selectedFieldIds).then(function(data) {
                        //Potential Alfresco bug. PONHR-220
                        //Each time the PATCH command is issued from the API, the version of the object (in this case contentRule) automatically increments – which is great.  
                        //However, the initial version i.e. v1.0 does not retain associations to other objects (in this case dataFields). 
                        //The interesting thing is every other version i.e. 1.1, 1.2, 1.3 etc. retain the associations. For some reason version 1.0 dose not retain its associations.
                        //This is a workaround, change versionLabel to 1.1 right after creation so we can keep the original dataFields association in verison 1.1

                        $state.go('home.admin.media-management.rules.trim', {
                            'ruleId': data
                        });

                    }, function (error) {
                        $log.error(error);
                    });

                }
            }
        };

    });