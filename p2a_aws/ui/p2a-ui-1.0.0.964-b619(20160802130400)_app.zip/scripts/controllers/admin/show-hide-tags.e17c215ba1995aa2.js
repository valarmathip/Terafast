﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('showConditionsModalInstanceCtrl', function (
        $scope,
        ModalDialogFactory,
        $modalInstance,
        RuleDataService,
        PaginationService,
        tagsAvailable,
        tagsSelected,
        $timeout
    ) {

        $scope.tags = [];

        //Mapping the items for formatting the templates
        angular.forEach(tagsAvailable, function(item) {
            $scope.tags.push({
                objectId: item.objectId,
                expression: item.expression,
                name: item.name
            });
        });

        var setOrResetCheckList = function (row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };

        $scope.checkList = [];

        // do not allow multi-selection
        $scope.toggleSelection = function (row) {
            $scope.gridApi.selection.clearSelectedRows();

            if (!row.isSelected && !$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                //$scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = false;
                $scope.gridApi.selection.unSelectRow(row);
                //$scope.selectChecker = false;
            }

            $scope.checkList = [];
            $scope.checkList[row.entity.objectId] = row.isSelected;
            $scope.selectedTags = $scope.gridApi.selection.getSelectedRows();
        };

        //used by advanced grid
        $scope.gridTags = {
            data: $scope.tags,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 35,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableColumnMenu: false,
                headerCellTemplate: '<input data-hraf-id="select-all-conditions-checkbox" type="checkbox" class="grid-checkbox-position">',
                cellTemplate: '<input data-hraf-id="condition-{{row.entity.objectId}}-checkbox" type="checkbox" class="grid-checkbox-position"' +
                              'ng-model="grid.appScope.checkList[row.entity.objectId]" ng-checked="grid.appScope.checkList[row.entity.objectId]"' +
                              'ng-click="grid.appScope.toggleSelection(row)"/>',
                width: 60,
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Condition Name',
                enableColumnMenu: false,
                cellTemplate: '<div data-hraf-id="condition-{{row.entity.objectId}}-name" class="ui-grid-cell-contents">{{row.entity.name}}</div>',
                width: '20%',
                enableHiding: false
            }, {
                name: 'expression',
                displayName: 'Condition',
                enableColumnMenu: false,
                cellTemplate: '<div data-hraf-id="condition-{{row.entity.objectId}}-expression" class="ui-grid-cell-contents">{{row.entity.expression}}</div>',
                enableHiding: false
            }]
        };

        $scope.gridTags.multiSelect = false;

        $scope.gridTags.onRegisterApi = function(gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;

            gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
        };

        $timeout(function() {
            RuleDataService.setPreSelectedRow($scope.tags, tagsSelected, $scope.gridApi, 'showHideConditions');
        }, 200);


        $scope.ok = function() {
            $modalInstance.close($scope.selectedTags);
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

    });