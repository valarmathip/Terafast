﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('TagsModalInstanceCtrl', function(
        $scope,
        ModalDialogFactory,
        $modalInstance,
        RuleDataService,
        PaginationService,
        tagsAvailable,
        tagsSelected,
        $timeout
    ) {

        $scope.tags = [];

        $scope.selectAllChecker = false;
        $scope.selectChecker = false;
        $scope.checkList = [];

        var setOrResetCheckList = function (row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };
        var setCheckList = function () {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };

        //Mapping the items for formatting the templates
        angular.forEach(tagsAvailable, function(item) {
            $scope.tags.push({
                objectId: item.objectId,
                dataFieldName: item.dataFieldName,
                shortNamePath: item.shortNamePath,
                templates: angular.isDefined(item.templates) ? item.templates.join(', ') : ''
            });
        });

        $scope.toggleSelection = function (row) {
            if (!$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = true;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }

            $scope.selectedTags = $scope.gridApi.selection.getSelectedRows();
            $scope.checkList[row.entity.objectId] = $scope.selectChecker;
        };

        $scope.selectAllItems = function () {
            if (!$scope.selectAllChecker) {
                var rows = $scope.gridApi.grid.getVisibleRows();  // select rows on one page of the grid

                angular.forEach(rows, function (row) {
                    row.isSelected = true;
                    row.enableSelection = true;
                    $scope.gridApi.selection.selectRow(row);
                });
               
                $scope.selectAllChecker = true;

            } else {
                angular.forEach($scope.gridApi.grid.rows, function (row) {
                    row.isSelected = false;
                    row.enableSelection = true;
                });

                $scope.gridApi.selection.clearSelectedRows();
                $scope.selectAllChecker = false;
            }

            $scope.selectedTags = $scope.gridApi.selection.getSelectedRows();

            angular.forEach($scope.selectedTags, function (tag) {
                $scope.checkList[tag.objectId] = $scope.selectAllChecker;
            });
        };

        //used by advanced grid
        $scope.gridTags = {
            data: $scope.tags,
            enableColumnResizing: false,
            enableFiltering: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 35,
            paginationPageSizes: [20, 40, 60],
            paginationPageSize: 20,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableColumnMenu: false,
                headerCellTemplate: '<input data-hraf-id="select-all-fields" type="checkbox" class="grid-checkbox-position" ng-model="grid.appScope.master" ng-click="grid.appScope.selectAllItems()">',
                cellTemplate: '<input data-hraf-id="field-{{row.entity.objectId}}-checkbox" type="checkbox" class="grid-checkbox-position"' +
                              'ng-model="grid.appScope.checkList[row.entity.objectId]" ng-checked="grid.appScope.master && grid.appScope.checkList[row.entity.objectId]"' +
                              'ng-click="grid.appScope.toggleSelection(row)"/>',
                width: 60,
                enableHiding: false
            }, {
                name: 'dataFieldName',
                displayName: 'Field',
                enableColumnMenu: false,
                cellTemplate: '<div data-hraf-id="field-{{row.entity.objectId}}-name" class="ui-grid-cell-contents" title="{{row.entity.dataFieldName}}">{{row.entity.dataFieldName}}</div>',
                width: '20%'
            }, {
                name: 'shortNamePath',
                displayName: 'Data Path',
                enableColumnMenu: false,
                cellTemplate: '<div data-hraf-id="field-{{row.entity.objectId}}-data-path" class="ui-grid-cell-contents" title="{{row.entity.shortNamePath}}">{{row.entity.shortNamePath}}</div>',
                width: '40%'
            }, {
                name: 'templates',
                displayName: 'Templates',
                enableColumnMenu: false,
                cellTemplate: '<div data-hraf-id="field-{{row.entity.objectId}}-templates" class="ui-grid-cell-contents" title="{{row.entity.templates}}">{{row.entity.templates}}</div>',
                type: 'string'
            }]
        };

        $scope.gridTags.multiSelect = true;

        $scope.gridTags.onRegisterApi = function(gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;

            gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);

        };

        $timeout(function() {
            RuleDataService.setPreSelectedRow($scope.tags, tagsSelected, $scope.gridApi, 'tags');
        }, 200);

        $scope.ok = function() {
            $modalInstance.close($scope.selectedTags);
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

    });