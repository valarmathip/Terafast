﻿'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: GenerateDocCtrl
 * @description
 * # GenerateDocCtrl
 * Controller of Document Generation under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('GenerateDocCtrl',
        function ($scope,
            $rootScope,
            $log,
            $state,
            $stateParams,
            $filter,
            moment,
            docTypePromise,
            docFormatPromise,
            allTemplatesPromise,
            selectedDocType,
            batchObjectIdParam,
            businessEntity,
            ConfirmationModalFactory,
            ModalDialogFactory,
            DocumentDataFactory,
            DocumentBatchHelper,
            OfferingAccountService,
            BatchService,
            FilterService,
            PaginationService,
            FileSelectFactory,
            ENV,
            ENV_MEDIA_MANAGEMENT) {

            /*jshint maxstatements:89 */
            var setInitialState = function () {
                PaginationService.setSortColumns(null);

                $scope.docDefinition = {};  //top object for the document details on this page
                $scope.docDefinition.isMultiSource = true;  //show multi-source view as default

                if (businessEntity && businessEntity.entityType && businessEntity.entityType !== '' && businessEntity.dataSourceId && businessEntity.dataSourceId !== '') {
                    $scope.docDefinition.isMultiSource = false;
                    $scope.isFromOtherModule = true;   // means called from Plan listing or Offering listing UI
                }

                $scope.batch = { 'name': '', 'objectId': '', 'batchJobs': null };  // $scope.batch holds the properties matching those from the cm/batch API
                $scope.currentBatch = {};   // $scope.currentBatch holds additional properties for the UI usage purpose
                $scope.currentBatch.isEditingBatch = false; 

                // if stateParam batchObjectId has no value, means come from Doc Gen, not from Batch listing / edit Batch
                if (batchObjectIdParam) {
                    $scope.batch.objectId = batchObjectIdParam;
                    $scope.currentBatch.isEditingBatch = true;
                }

                if ($scope.currentBatch.isEditingBatch) {
                    $scope.isBatchPaneCollapsed = true;
                } else {
                    $scope.isBatchPaneCollapsed = false;  //Generate Document Pane is opened as default initially
                }

                if ($scope.docDefinition.isMultiSource) {
                    if ($scope.batch && $scope.batch.objectId !== '') {
                        $state.transitionTo('home.media-management.generateDocument.multiSource', {
                            'batchObjectId': $scope.batch.objectId
                        });
                    }
                    else {
                        $state.transitionTo('home.media-management.generateDocument.multiSource');
                    }
                }
                else {
                    if ($scope.batch && $scope.batch.objectId !== '') {
                        $state.transitionTo('home.media-management.generateDocument.singleSource', {
                            'batchObjectId': $scope.batch.objectId
                        });
                    }
                    else {
                        if (businessEntity && businessEntity.entityType && businessEntity.dataSourceId) {
                            $state.transitionTo('home.media-management.generateDocument.singleSource', {
                                'businessEntity': businessEntity.entityType,
                                'dataSourceId': businessEntity.dataSourceId
                            });
                        }
                        else {
                            $state.transitionTo('home.media-management.generateDocument.singleSource');
                        }
                    }
                }

                $scope.docDefinition.selectedTemplate = null;
                $scope.docDefinition.selectedPlans = null;
                $scope.docDefinition.selectedPlanNames = null;
                $scope.docDefinition.selectedOfferings = null;   //just in case Offering can be multi-selection
                $scope.docDefinition.selectedOfferingPlans = null;
                $scope.docDefinition.selectedAccounts = null;   //just in case Account can be multi-selection
                $scope.docDefinition.selectedSources = [];  //store multi source view selectedPlans or selectedOfferingPlans and selectedAccount

                $scope.docDefinition.selectedSingleSourceTypes = [];   // only those selected single source types on the UI
                $scope.docDefinition.selectedMultiSourceTypes = [];  // only those selected multi source types on the UI

                $scope.documentValidationNeeded = false;  //a flag, form validation purpose

                $scope.selectedRadioTemplate = { id: '' };
                $scope.selectedCheckBoxDocFormats = {};
                $scope.docDefinition.selectedWatermark = { 'type': 'none', 'text': '' };  // initial watermark is "None"

                $scope.batch.documentNameEdited = [];   // to remember a list of document name changed by user in the batch job grid

                $scope.currentBatch = {};
                $scope.currentBatch.batchJobList = [];
                $scope.currentBatch.loadedBatchJobList = [];
                $scope.currentBatch.transformedBatchJobList = [];
                $scope.currentBatch.transformedLoadedBatchJobList = [];
                $scope.currentBatch.previouslySavedBatchJobs = [];

            };

            setInitialState();

            //stop page from going to previous screen when pressing “Backspace” with cursor inside the ready-only “Browse plan(s)” textbox, etc.
            $('input[type=text][readonly]').on('keydown', function (e) {
                if (e.which === 8) {
                    e.preventDefault();
                }
            });

            // We need to make this hack model to adapt the bad design of the page...
            $scope.$watch(
                    'selectedRadioDocumentType.docType',
                    function (newValue) {
                        $scope.docDefinition.selectedDocumentType = findDocumentTypeByName(newValue);
                        if (newValue !== null) {
                            loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
                        }
                    }
            );

            // We need to make this hack model to adapt the bad design of the page...
            $scope.$watch(
                    'selectedCheckBoxDocFormats',
                    function () {
                        $scope.docDefinition.selectedDocFormats = [];
                        angular.forEach($scope.selectedCheckBoxDocFormats, function (value, key) {
                            if (value) {
                                $scope.docDefinition.selectedDocFormats.push(key);
                                $scope.documentValidationNeeded = false;
                            }
                        });
                    },
                    true
            );

            // clear text in the Watermark textbox if "custom" radio button is not selected
            $scope.$watch(
                    'docDefinition.selectedWatermark.type',
                    function (newValue) {
                        if (newValue !== 'custom') {
                            $scope.docDefinition.selectedWatermark.text = '';
                        }
                    }
            );

            $scope.$watch(
                    'docDefinition.selectedWatermark.text',
                    function (newValue) {
                        if ($scope.docDefinition.selectedWatermark.type === 'custom') {
                            if (newValue) {
                                $scope.documentValidationNeeded = false;
                            }
                        }
                    }
            );

            $scope.$watch(
                    'docDefinition.selectedPlans',
                    function (newValue) {
                        if (newValue && newValue.length > 0) {
                            $scope.documentValidationNeeded = false;
                            $scope.docDefinition.selectedPlanNames = [];

                            for (var i = 0; i < newValue.length; i++) {
                                $scope.docDefinition.selectedPlanNames.push(newValue[i].name);
                            }
                        } else {
                            $scope.docDefinition.selectedPlanNames = null;
                        }
                    }
            );

            $scope.$watch(
                   'docDefinition.selectedTemplate',
                   function (newValue) {
                       if (newValue) {
                           $scope.documentValidationNeeded = false;
                       }
                   }
            );

            $scope.$watch(
                   'docDefinition.selectedAccounts',
                   function (newValue) {
                       if (newValue && newValue.length > 0) {
                           $scope.documentValidationNeeded = false;
                       }
                   }
            );

            $scope.$watch(
                   'docDefinition.selectedMultiSourceTypes[4]',
                   function (newValue) {
                       if (!newValue || newValue === '') {
                           $scope.documentValidationNeeded = false;
                       }
                   }
            );

            $scope.$watch(
                    'batch.name',
                    function (newValue) {
                        if (newValue && newValue !== '') {
                            $scope.documentValidationNeeded = false;
                            $scope.currentBatch.batchNameChanged = true;
                        }
                    }
            );

            // ngModel + ngList binding to array does not update view when model changes
            $scope.$watch(
                    'docDefinition.selectedPlanNames',
                    function (newValue) {
                        $scope.selectedPlanNamesList = newValue;
                    }
            );

            var docTypesAndTemplates;
            //populate "Select Document Type" section using doctypes from existing templates and ordering from docTypePromise
            var populateDocumentTypes = function () {
                var docTypes = [];
                $scope.selectedRadioDocumentType = { docType: ($stateParams.docType) ? $stateParams.docType : '' };
                docTypesAndTemplates = {};
                if (allTemplatesPromise && allTemplatesPromise.response && allTemplatesPromise.response.docs) {
                    var allTemplates = allTemplatesPromise.response.docs;
                    for (var i = 0; i < allTemplates.length; i++) {
                        var template = allTemplates[i];
                        var docType = template.documentType;
                        if (docType !== undefined && template.templateStatus === 'Published' &&
                           (!$scope.docDefinition.isMultiSource && (template.numSources && parseInt(template.numSources, 10) === 1) ||
                           ($scope.docDefinition.isMultiSource && (template.numSources && parseInt(template.numSources, 10) > 1)))) {
                            var templateArray = [];
                            if (docTypes.indexOf(docType) === -1) {
                                docTypes.push(docType);
                            } else {
                                templateArray = docTypesAndTemplates[docType];
                            }
                            templateArray.push(template);
                            docTypesAndTemplates[docType] = templateArray;
                        }

                    }
                    buildOrderedDocTypeArray(docTypes, $stateParams.docType);

                    if (angular.isDefined($scope.docTypeIndex)) {
                        $scope.docDefinition.selectedDocumentType = $scope.documentTypeJSON[$scope.docTypeIndex];
                        $scope.selectedRadioDocumentType.docType = $scope.documentTypeJSON[$scope.docTypeIndex].value;
                    } else {
                        if (angular.isDefined($scope.documentTypeJSON[0])) {
                            $scope.docDefinition.selectedDocumentType = $scope.documentTypeJSON[0];  // when this page initially loaded selected Document Type is the first type like "SBC"
                            $scope.selectedRadioDocumentType.docType = $scope.documentTypeJSON[0].value;
                        }
                    }
                }
            };

            var findDocumentTypeByName = function (name) {
                if ($scope.documentTypeJSON != null && angular.isDefined($scope.documentTypeJSON)) {
                    for (var i = 0, j = $scope.documentTypeJSON.length; i < j; i++) {
                        if ($scope.documentTypeJSON[i].value === name) {
                            return $scope.documentTypeJSON[i];
                        }
                    }
                }

                return false;
            };

            var buildOrderedDocTypeArray = function (docTypes, docTypeParam) {
                $scope.documentTypeJSON = [];

                if (docFormatPromise != null) {
                    if (angular.isArray(docTypePromise)) {
                        for (var k = 0; k < docTypePromise.length; k++) {
                            for (var j = 0; j < docTypes.length; j++) {
                                if (docTypePromise[k] === docTypes[j]) {
                                    /*jshint -W073 */
                                    if (angular.isDefined(selectedDocType) && selectedDocType !== '') {
                                        $scope.docTypeIndex = j;
                                    }
                                    var json = { 'id': j, 'value': docTypes[j] };
                                    $scope.documentTypeJSON.push(json);
                                    break;
                                }
                            }
                        }
                        for (var i = 0; i < $scope.documentTypeJSON.length; i++) {
                            if (docTypeParam !== null && $scope.documentTypeJSON[i].value === docTypeParam) {
                                $scope.docTypeIndex = i;
                                break;
                            }
                        }
                    }
                } else {
                    ConfirmationModalFactory.open('Error Message', 'Error occurred when loading available document types.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                }
            };

            //populate "Format" section from docFormatPromise
            var populateDocumentFormats = function () {
                $scope.documentFormatJSON = [];

                if (docFormatPromise != null) {    // docFormatPromise at normal case would be ['Word', 'PDF']
                    // need to construct a JSON object from an array for UI usage
                    if (angular.isArray(docFormatPromise)) {
                        for (var i = 0; i < docFormatPromise.length; i++) {
                            var json = { 'id': i, 'value': docFormatPromise[i] };
                            $scope.documentFormatJSON.push(json);
                        }
                    }
                }
                else {
                    ConfirmationModalFactory.open('Error Message', 'Error occured when loading available document formats.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                }

                $scope.docDefinition.selectedDocFormats = [];    //$scope.selectedDocFormats needs to be an array
                if (angular.isDefined($scope.documentFormatJSON[0])) {
                    var index =$scope.docDefinition.selectedDocFormats.indexOf($scope.documentFormatJSON[0].value);

                    if (index === -1) {
                       $scope.docDefinition.selectedDocFormats.push($scope.documentFormatJSON[0].value);  //document format can be multi-selection, 'Word' is the default
                        $scope.selectedCheckBoxDocFormats[$scope.documentFormatJSON[0].value] = true;
                    }
                }
            };

            var showPlanOrOfferingSelections = function () {
                $scope.docDefinition.selectedMultiSourceTypes = ['', '', '', '', ''];  // set initial states

                // clean up all the previously selected if any
                $scope.docDefinition.selectedSources = [];
                $scope.docDefinition.selectedPlans = null;
                $scope.docDefinition.selectedOfferings = null;
                $scope.docDefinition.selectedOfferingPlans = null;
                $scope.docDefinition.selectedAccounts = null;
                $scope.invalidMultiSourceTags = [];
                $scope.invalidMultiSourceTagsJson = [];

                var containsOffering = false;
                var containsPlan = false;
                var containsAccount = false;

                for (var i = 0, j = $scope.docDefinition.selectedTemplate.templateSources.length; i < j; i++) {
                    // if there is one templateSource's sourceType is "Offering" then this is an Offering template
                    if ($scope.docDefinition.selectedTemplate.templateSources[i].sourceType === 'Offering') {
                        containsOffering = true;
                    }
                    else if ($scope.docDefinition.selectedTemplate.templateSources[i].sourceType === 'Plan') {
                        containsPlan = true;
                    }
                    else if ($scope.docDefinition.selectedTemplate.templateSources[i].sourceType === 'Account') {
                        containsAccount = true;
                    }
                }

                if (containsPlan) {
                    $scope.docDefinition.selectedMultiSourceTypes[0] = 'Plan';
                }
                if (containsOffering) {
                    $scope.docDefinition.selectedMultiSourceTypes = ['', '', '', 'Offering', ''];  // don't allow Plan and Offering both selected
                }
                if (containsAccount) {
                    $scope.docDefinition.selectedMultiSourceTypes[4] = 'Account';  // Offering and Account can be both selected
                }
            };

            var loadTemplatesByDocType = function (docType, toKeepSelectedTemplate) {
                if (docType) {
                    $scope.documentValidationNeeded = false;

                    if (!angular.isDefined(toKeepSelectedTemplate) || (angular.isDefined(toKeepSelectedTemplate) && toKeepSelectedTemplate === false)) {
                        $scope.templatesByDocType = null;  //clean templates, related to selected document type
                        $scope.docDefinition.selectedTemplate = null;  //clean up the previously highlighted template
                    }

                    if ($scope.docDefinition.isMultiSource) {
                        if (docTypesAndTemplates[docType.value] && docTypesAndTemplates[docType.value].length === 1) {
                            $scope.docDefinition.selectedTemplate = docTypesAndTemplates[docType.value][0];
                            $scope.docDefinition.selectedTemplate.objectId = docTypesAndTemplates[docType.value][0].objectId;
                            $scope.disableBrowseTemplate = true;

                            showPlanOrOfferingSelections();

                        } else {
                            $scope.disableBrowseTemplate = false;
                        }

                    } else {
                        $scope.templatesByDocType = [];  //re-fill templates, related to selected document type
                        angular.forEach(docTypesAndTemplates[docType.value], function (item) {
                            if (item.numSources && parseInt(item.numSources, 10) === 1) {
                                $scope.templatesByDocType.push(item);
                            }
                        });

                        if ($scope.templatesByDocType.length === 1) { // If only one template matches, the template is auto-selected for the user.
                            $scope.docDefinition.selectedTemplate = $scope.templatesByDocType[0];
                            $scope.disableBrowseTemplate = true;  // if under certain doc type there is only one template, disable "Browse" button besides Template textbox
                            $scope.docDefinition.selectedSingleSourceTypes[0] = 'Plan';  // select "Plan" radio button under single source view
                        }
                        else {
                            if ($scope.templatesByDocType.length === 0) {
                                $scope.disableBrowseTemplate = true;  // if under certain doc type there is no template, disable "Browse" button besides Template textbox
                            }
                            else {
                                $scope.disableBrowseTemplate = false;
                            }
                        }
                    }
                }
            };

            var populateBusinessEntity = function () {
                if (businessEntity && businessEntity.entityType.toLowerCase() === 'plan' && businessEntity.dataSourceId !== null && businessEntity.dataSourceId !== '') {
                    DocumentDataFactory.getPlanById(businessEntity.dataSourceId)
                    .success(function (data) {
                        $scope.docDefinition.selectedPlans = [];
                        $scope.docDefinition.selectedPlanNames = [];

                        $scope.docDefinition.selectedSingleSourceTypes[0] = 'Plan';

                        var planJSON = { 'objectId': data.objectId, 'name': data.name, 'planYear': data.planYear };
                        $scope.docDefinition.selectedPlans.push(planJSON);
                        $scope.docDefinition.selectedPlanNames.push(data.name);
                    })
                    .error(function (reason) {
                        $log.error(reason);
                    });
                }
                else if ($stateParams.businessEntity && $stateParams.businessEntity.toLowerCase() === 'product' && $stateParams.dataSourceId != null) {
                    DocumentDataFactory.getProductById($stateParams.dataSourceId)
                    .success(function (data) {
                        $scope.selectedProductNames = [];
                        $scope.selectedProductIds = [];
                        $scope.selectedProductIds.push(data.objectId);
                        $scope.selectedProductNames.push(data.name);
                    })
                    .error(function (reason) {
                        $log.error(reason);
                    });
                }
            };

            // set watermark text because of the way data-binding, custom type can have user input value
            var setWatermark = function () {
                if ($scope.docDefinition.selectedWatermark.type === 'none') {
                    $scope.docDefinition.selectedWatermark.text = '';
                }
                else if ($scope.docDefinition.selectedWatermark.type === 'draft') {
                    $scope.docDefinition.selectedWatermark.text = 'Draft';
                }
            };

            // validation when click "Generate" button for multi source
            var validateMultiSourceDocGen = function () {
                var validationPassed = true;

                if (!$scope.docDefinition.selectedTemplate || !$scope.docDefinition.selectedTemplate.name || $scope.docDefinition.selectedTemplate.name === '') {
                    return false;
                }

                if ($scope.docDefinition.selectedDocFormats.length === 0) {
                    return false;
                }

                if ($scope.docDefinition.selectedWatermark.type === 'custom' && !$scope.docDefinition.selectedWatermark.text) {
                    return false;
                }

                if ($scope.docDefinition.selectedMultiSourceTypes[4] === 'Account' &&
                    ($scope.docDefinition.selectedAccounts === null || $scope.docDefinition.selectedAccounts.length === 0)) {
                    return false;
                }

                if (validationPassed) {
                    if (!DocumentBatchHelper.validateSourceIndicators($scope.docDefinition, $scope.documentValidationNeeded)) {
                        validationPassed = false;
                    }
                }

                return validationPassed;
            };

            // validation when click "Generate" button for single source
            var validateSingleSourceDocGen = function (skipPlanCountCheck) {
                var validationPassed = true;

                if (!$scope.docDefinition.selectedTemplate) {
                    validationPassed = false;
                }
                else if (!$scope.docDefinition.selectedPlans || $scope.docDefinition.selectedPlans.length === 0) {
                    validationPassed = false;
                }

                if ($scope.docDefinition.selectedDocFormats.length === 0) {
                    validationPassed = false;
                }

                if ($scope.docDefinition.selectedWatermark.type === 'custom' && !$scope.docDefinition.selectedWatermark.text) {
                    validationPassed = false;
                }

                /* make sure only one plan/unit and one template can be selected when clicking "Generate" */
                if (!$scope.docDefinition.isMultiSource && !skipPlanCountCheck) {
                    if ($scope.docDefinition.selectedPlans !== null && angular.isDefined($scope.docDefinition.selectedPlans) && $scope.docDefinition.selectedPlans.length > 1) {
                        validationPassed = false;
                        $scope.documentValidationNeeded = false;
                        ConfirmationModalFactory.open('Error Message', 'Only one plan can be selected when generating a single source document.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    }
                }

                return validationPassed;
            };

            //pop up "Name Your Document" modal window for user to input document name
            var promptDocumentName = function (systemDocName) {
                var dialogOptions = {
                    templateUrl: 'views/media-management/add-document-name.html',
                    controller: 'DocGenNameCtrl',
                    size: 'md',
                    backdrop: false,
                    resolve: {
                        systemGeneratedName: function () {
                            return systemDocName;
                        }
                    }
                };

                ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                    $scope.manuallyAddedDocName = result;   // put it to $scope variable, need to access it from multiple functions 

                    if ($scope.docDefinition.isMultiSource) {
                        generateDocumentMultiSource(systemDocName);
                    } else {
                        // if it is a single source with prefix such as "rx;"
                        if ($scope.docDefinition.selectedTemplate !== null &&
                            angular.isDefined($scope.docDefinition.selectedTemplate.templateSources) &&
                            $scope.docDefinition.selectedTemplate.templateSources.length === 1 &&
                            $scope.docDefinition.selectedTemplate.templateSources[0].sourceIndicator !== 'NA') {
                            generateSingleDocument($scope.docDefinition.selectedTemplate.templateSources[0].sourceIndicator); // single source doc generation with prefix
                        }
                        else {
                            generateSingleDocument();  // single source doc generation without prefix
                        }
                    }
                }, function () {
                    $scope.documentValidationNeeded = false;
                });
            };

            var generatePlanDoc = function (singleSourcePrefix) {
                var docName = '';
                var planYear = '';

                if ($scope.docDefinition.selectedPlans[0].planYear) {  //planYear returned as "planYear": "2015" or "planYear": "2015, 2016", etc.
                    planYear = $scope.docDefinition.selectedPlans[0].planYear;
                }
                // to generate a document with pattern "<plan year>-<plan name>-<document type>"
                if (angular.isObject($scope.docDefinition.selectedPlans) && angular.isObject($scope.docDefinition.selectedDocumentType)) {

                    if ($scope.manuallyAddedDocName && $scope.manuallyAddedDocName.length > 0) {  // if document name is user added from "Name Your Document" dialog
                        docName = $scope.manuallyAddedDocName;
                    } else {
                        docName = DocumentBatchHelper.generateSysPlanDocName($scope.docDefinition.selectedPlans[0].name, planYear, $scope.docDefinition.selectedDocumentType.value);
                    }

                    if (docName !== '') {  // we need a valid document name to generate the document

                        var docGenJson = {};

                        if (!angular.isDefined(singleSourcePrefix) || singleSourcePrefix === '') {
                            docGenJson = {
                                documentName: docName,
                                fileFormat: $scope.docDefinition.selectedDocFormats.toString(),
                                generationType: 'Single',
                                documentAssociatons: [],
                                templateId: $scope.docDefinition.selectedTemplate.objectId,
                                templateSources: {
                                    baseSourceIndicator: $scope.docDefinition.selectedSingleSourceTypes[0] + '-NA',
                                    dataSources: [{
                                            ID: $scope.docDefinition.selectedPlans[0].objectId,
                                            SourceType: $scope.docDefinition.selectedSingleSourceTypes[0],
                                            SourceIndicator: 'NA'
                                        }]
                                },
                                watermark: $scope.docDefinition.selectedWatermark.text
                            };
                        }
                        else {
                            docGenJson = {
                                documentName: docName,
                                fileFormat: $scope.docDefinition.selectedDocFormats.toString(),
                                generationType: 'Single',
                                documentAssociatons: [],
                                templateId: $scope.docDefinition.selectedTemplate.objectId,
                                templateSources: {
                                    baseSourceIndicator: $scope.docDefinition.selectedSingleSourceTypes[0] + '-' + singleSourcePrefix,
                                    dataSources: [
                                        {
                                            ID: $scope.docDefinition.selectedPlans[0].objectId,
                                            SourceType: $scope.docDefinition.selectedSingleSourceTypes[0],
                                            SourceIndicator: singleSourcePrefix
                                        }]
                                },
                                watermark: $scope.docDefinition.selectedWatermark.text
                            };
                        }

                        DocumentDataFactory.generateDocuments(docGenJson)
                            .then(function (data) {
                                var returnedDocuments = [];

                                //the returned data is JSON (from a .net dictionary) but has no id and name, adding them for UI
                                angular.forEach(data, function (value, key) {
                                    var json = { 'id': key, 'name': value };
                                    returnedDocuments.push(json);
                                });
                                // add format for better display (Word or PDF) on "document ganareated" page
                                for (var i = 0; i <$scope.docDefinition.selectedDocFormats.length; i++) {
                                    returnedDocuments[i].format =$scope.docDefinition.selectedDocFormats[i];
                                }

                                //save the generated documents JSON data so it can be retrieved from another page
                                DocumentDataFactory.setGeneratedDocJson(returnedDocuments);

                                $scope.documentValidationNeeded = false;
                                $state.go('home.media-management.finalGenerateDoc');

                            }, function (response) {
                                $log.error(response);
                                $scope.documentValidationNeeded = false;
                            });
                    }
                    else {  //if for some reason documentName is null or empty
                        ConfirmationModalFactory.open('Error Message', 'Invalid auto-generated document name.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                        $scope.documentValidationNeeded = false;
                    }
                }
            };

            var generateSingleDocument = function (sourceIndicator) {
                if ($scope.docDefinition.selectedPlans &&
                    $scope.docDefinition.selectedPlans.length > 0 &&
                    $scope.docDefinition.selectedDocFormats.length > 0 &&
                    $scope.docDefinition.selectedTemplate) {  
                    //generate plan document
                    if ($scope.docDefinition.selectedSingleSourceTypes[0].toLowerCase() === 'plan') {
                        generatePlanDoc(sourceIndicator);
                    }
                }
            };

            var generateDocumentMultiSource = function (sysName) {
                if (validateMultiSourceDocGen()) {
                    var multiSourceDocName = '';

                    if ($scope.manuallyAddedDocName && $scope.manuallyAddedDocName.length > 0) {
                        multiSourceDocName = $scope.manuallyAddedDocName;
                    }
                    else {
                        multiSourceDocName = sysName;
                    }

                    var docGenPayload = {};
                    docGenPayload = DocumentBatchHelper.buildMultiSourceDocumentJson($scope.docDefinition, multiSourceDocName);

                    DocumentDataFactory.generateDocuments(docGenPayload)
                        .then(function (data) {
                            var returnedDocuments = [];

                            // the returned data is JSON (from a .net dictionary) but has no id and name, adding them for UI
                            angular.forEach(data, function (value, key) {
                                var json = { 'id': key, 'name': value };
                                returnedDocuments.push(json);
                            });
                            // add format for better display (Word or PDF) on "document ganareated" page
                            for (var i = 0; i <$scope.docDefinition.selectedDocFormats.length; i++) {
                                returnedDocuments[i].format =$scope.docDefinition.selectedDocFormats[i];
                            }

                            // save the generated documents JSON data so it can be retrieved from another page
                            DocumentDataFactory.setGeneratedDocJson(returnedDocuments);

                            $scope.documentValidationNeeded = false;
                            $state.go('home.media-management.finalGenerateDoc');

                        }, function (response) {
                            $log.error(response);
                            $scope.documentValidationNeeded = false;
                        });
                }
            };

            var paginationOptions = {
                pageNumber: 1,
                pageSize: 20,
                sort: null
            };

            /* search api has a slight delay affects batch job grid refresh */
            var loadBatchAndJobGrid = function () {
                if (angular.isDefined($scope.batch.objectId) && $scope.batch.objectId !== '') {
                    // before we use search api, get batch by id to determine if returned records less than 1000, if less we can take the performance hit 'cuz it is not much
                    BatchService.getBatchDetails($scope.batch.objectId)
                    .success(function (data) {
                        $scope.batch = data;
                        $scope.currentBatch.isEditingBatch = true;
                        $scope.gridBatchDocs.totalItems = angular.isDefined($scope.batch.batchJobs) ? $scope.batch.batchJobs.length : 0;

                        if ($scope.batch.batchJobs && $scope.batch.batchJobs.length < 1000) {
                            angular.forEach($scope.batch.batchJobs, function (batchJob) {  // transform the data 'cuz we'll need to show info from batchJobTaskBody, not batchJob
                                if (batchJob.batchJobTasks && batchJob.batchJobTasks.length > 0) {
                                    $scope.currentBatch.transformedBatchJobList.push({
                                        'objectId': batchJob.objectId,
                                        'batchJobTaskObjectId': batchJob.batchJobTasks[0].objectId,
                                        'batchJobTaskDocObjectId': batchJob.batchJobTasks[0].taskDocument ? batchJob.batchJobTasks[0].taskDocument[0].objectId : batchJob.batchJobTasks[0].associations.taskDocument[0].objectId,
                                        'templateDocType': batchJob.batchJobTasks[0].taskDocument ?
                                            batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentDocumentType : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateDocType,
                                        'documentName': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).documentName,
                                        'dataSourceNames': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).dataSourceNames,
                                        'dataSourceIds': batchJob.batchJobTasks[0].taskDocument ?
                                            batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentDataSourceIds : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).dataSourceId,
                                        'templateName': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateName,
                                        'templateId': batchJob.batchJobTasks[0].taskDocument ?
                                            batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentTemplateId : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateId,
                                        'sourceTypes': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).sourceTypes,
                                        'watermark': batchJob.batchJobTasks[0].taskDocument ?
                                            batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentWatermark : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).watermark,
                                        'docFormats': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).fileFormat,
                                        'templateSources': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateSources,
                                        'batchJobStatus': batchJob.batchJobStatus,
                                        'batchJobStatusDetails': batchJob.batchJobStatusDetails,
                                        'creationDate': batchJob.creationDate,
                                        'dataSourceYear': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).dataSourceYear,
                                        'isBatchJobMultiSource': batchJob.batchJobTasks[0].taskDocument ?
                                            batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentIsMultiSource : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).isBatchJobMultiSource,
                                        'sourceTypesAndNames': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).sourceTypesAndNames
                                    });
                                }
                            });

                            $scope.gridBatchDocs.useExternalPagination = false;
                            $scope.gridBatchDocs.data = $filter('orderBy')($scope.currentBatch.transformedBatchJobList, '-creationDate'); // sort grid data by creation time DESC
                            $scope.currentBatch.transformedBatchJobList = [];

                        } else {   // if $scope.batch.batchJobs.length === 1000, it could mean we reached the 1000 limit by alfreso, so we have to re-search by using search api
                            $scope.currentBatch.loadedBatchJobList = [];
                            $scope.currentBatch.transformedLoadedBatchJobList = [];

                            var queryStr = 'TYPE:"batchJob"';
                            var currentSearchQuery = FilterService.getFilterQueryBatchJobsOfOneBatch($scope.batch.objectId, queryStr, $scope.gridBatchDocs, $scope.gridApi) + PaginationService.getSortQuery();

                            BatchService.getBatchJobsOfOneBatch(currentSearchQuery).then(function (response) {
                                $scope.gridBatchDocs.totalItems = response.data.response.numFound;
                                $scope.currentBatch.loadedBatchJobList = response.data.response.docs;
                                $scope.currentBatch.batchJobList = FilterService.filterAndrefresh($scope.currentBatch.loadedBatchJobList, $scope.currentBatch.batchJobList);

                                if ($scope.batch.batchJobs !== null && angular.isDefined($scope.batch.batchJobs)) {
                                    if ($scope.batch.batchJobs.length > 0) {
                                        angular.forEach($scope.currentBatch.batchJobList, function (batchJob) {
                                            if (batchJob.batchJobTasks && batchJob.batchJobTasks.length > 0) {
                                                $scope.currentBatch.transformedBatchJobList.push({
                                                    'objectId': batchJob.objectId,
                                                    'batchJobTaskObjectId': batchJob.batchJobTasks[0].objectId,
                                                    'batchJobTaskDocObjectId': batchJob.batchJobTasks[0].taskDocument ? batchJob.batchJobTasks[0].taskDocument[0].objectId : batchJob.batchJobTasks[0].associations.taskDocument[0].objectId,
                                                    'templateDocType': batchJob.batchJobTasks[0].taskDocument ?
                                                        batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentDocumentType : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateDocType,
                                                    'documentName': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).documentName,
                                                    'dataSourceNames': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).dataSourceNames,
                                                    'dataSourceIds': batchJob.batchJobTasks[0].taskDocument ?
                                                        batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentDataSourceIds : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).dataSourceId,
                                                    'templateName': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateName,
                                                    'templateId': batchJob.batchJobTasks[0].taskDocument ?
                                                        batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentTemplateId : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateId,
                                                    'sourceTypes': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).sourceTypes,
                                                    'watermark': batchJob.batchJobTasks[0].taskDocument ?
                                                        batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentWatermark : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).watermark,
                                                    'docFormats': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).fileFormat,
                                                    'templateSources': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).templateSources,
                                                    'batchJobStatus': batchJob.batchJobStatus,
                                                    'batchJobStatusDetails': batchJob.batchJobStatusDetails,
                                                    'creationDate': batchJob.creationDate,
                                                    'dataSourceYear': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).dataSourceYear,
                                                    'isBatchJobMultiSource': batchJob.batchJobTasks[0].taskDocument ?
                                                        batchJob.batchJobTasks[0].taskDocument[0].batchJobTaskDocumentIsMultiSource : parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).isBatchJobMultiSource,
                                                    'sourceTypesAndNames': parseBatchTaskBody(batchJob.batchJobTasks[0].batchJobTaskBody).sourceTypesAndNames
                                                });
                                            }
                                        });
                                    }

                                    $scope.currentBatch.transformedBatchJobList = FilterService.filterAndrefresh($scope.currentBatch.transformedLoadedBatchJobList, $scope.currentBatch.transformedBatchJobList);
                                    $scope.gridBatchDocs.useExternalPagination = true;
                                    $scope.gridBatchDocs.data = $scope.currentBatch.transformedBatchJobList;

                                    $scope.currentBatch.previouslySavedBatchJobs = [];
                                }
                                else {
                                    $scope.gridBatchDocs.data = [];
                                }

                            });
                        }
                    })
                    .error(function () {
                        $scope.documentValidationNeeded = false;
                    });
                }
            };

            var processBatchWorkflow = function () {
                setWatermark();

                if (angular.isDefined($scope.batch.objectId) && $scope.batch.objectId !== '') {
                    var scopeObj = {
                        selectedDocFormats: $scope.docDefinition.selectedDocFormats.toString(),
                        selectedTemplate: { objectId: $scope.docDefinition.selectedTemplate.objectId, name: $scope.docDefinition.selectedTemplate.name, templateSources: $scope.docDefinition.selectedTemplate.templateSources },
                        selectedWatermark: { text: $scope.docDefinition.selectedWatermark.text },
                        selectedDocumentType: { value: $scope.docDefinition.selectedDocumentType.value },
                        selectedSources: $scope.docDefinition.selectedSources,
                        selectedOfferings: $scope.docDefinition.selectedOfferings,
                        currentBatch: { objectId: $scope.batch.objectId, name: $scope.batch.name, isMultiSource: $scope.docDefinition.isMultiSource }
                    };

                    if (!$scope.docDefinition.isMultiSource) {    // single source add to batch, currently only Plan supported
                        // selected plan(s) can be one or multiple
                        angular.forEach($scope.docDefinition.selectedPlans, function (plan) {
                            DocumentBatchHelper.createBatchJobForSingleSource('Plan', plan, scopeObj)
                                .then(function (data) {
                                    cleanUpBatchJobEditingData();
                                    $scope.documentValidationNeeded = false;
                                    loadBatchAndJobGrid();   //always refresh the grid at the end
                                    $scope.currentBatch.previouslySavedBatchJobs.push(data);

                                }, function () {
                                    loadBatchAndJobGrid();   //always refresh the grid at the end
                                });
                        });

                    } else {    // multi source add to batch
                        DocumentBatchHelper.createBatchJobForMultiSource(scopeObj)
                            .then(function (data) {
                                cleanUpBatchJobEditingData();
                                $scope.documentValidationNeeded = false;
                                loadBatchAndJobGrid();
                                $scope.currentBatch.previouslySavedBatchJobs.push(data);

                            }, function () {
                                loadBatchAndJobGrid();
                            });
                    }

                    BatchService.setCurrentBatch($scope.batch);
                }
            };

            // clean up the leftover data in the UI fields after add/editing a batch job
            var cleanUpBatchJobEditingData = function () {
                if ($scope.templatesByDocType && $scope.templatesByDocType.length > 1) {
                    $scope.docDefinition.selectedTemplate = null;  //clean up the previously selected template
                }

                if (!$scope.docDefinition.isMultiSource) {
                    $scope.docDefinition.selectedSingleSourceTypes = [];
                    $scope.docDefinition.selectedPlans = null;
                }
                else {
                    // clean up any selected plans in the multi source plan grid
                    $scope.docDefinition.selectedSources = [];

                    $scope.docDefinition.selectedPlans = null;
                    $scope.docDefinition.selectedOfferings = null;
                    $scope.docDefinition.selectedGridOfferingPlans = null;
                    $scope.docDefinition.selectedAccounts = null;

                    $scope.docDefinition.selectedMultiSourceTypes = [];

                    loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
                }

                $scope.templatesByDocType = null;  //clean templates, related to selected document type
                $scope.docDefinition.selectedWatermark = { 'type': 'none', 'text': '' };  // reset watermark to "None"

                angular.forEach($scope.documentFormatJSON, function (formatJson) {
                    $scope.selectedCheckBoxDocFormats[formatJson.value] = false;// clean up all the selected formats                        
                });

                $scope.selectedCheckBoxDocFormats[$scope.documentFormatJSON[0].value] = true;   //set default doc format to "Word"

                $scope.currentBatch.isEditingBatchJob = false;
                $scope.documentValidationNeeded = false;
                $scope.currentBatch.currentBatchJobInEditing = null;

                $scope.invalidMultiSourceTags = [];   //clean up sources validation alerts
                $scope.invalidMultiSourceTagsJson = [];   //clean up sources validation alerts
            };

            var gridItemRemoved = function () {
                var pageSize = $scope.gridBatchDocs.paginationPageSize;
                var totalItems = $scope.batch.batchJobs.length - 1;  // substract 1 'cuz one item already removed when this is called

                if (totalItems % pageSize === 0) {  //if all items on the current page removed, go to previous page
                    if ($scope.gridBatchDocs.paginationCurrentPage > 1) {
                        $scope.gridBatchDocs.paginationCurrentPage -= 1;
                    }
                }
            };

            // load common details for single source and multi source batch job
            var loadCommonBatchJobInfo = function (row) {
                $scope.selectedRadioDocumentType.docType = row.templateDocType;
                $scope.docDefinition.selectedDocumentType = { 'docType': row.templateDocType };
                $scope.docDefinition.selectedDocFormats = row.docFormats ? row.docFormats.split(',') : '';

                angular.forEach($scope.documentFormatJSON, function (formatJson) {
                    // clean up the default selected format "Word"
                    $scope.selectedCheckBoxDocFormats[formatJson.value] = false;

                    if (row.docFormats.indexOf(formatJson.value) > -1) {
                        $scope.selectedCheckBoxDocFormats[formatJson.value] = true;
                    }
                });

                if (row.watermark === '') {
                    $scope.docDefinition.selectedWatermark = { 'type': 'none', 'text': '' };
                } else if (row.watermark === 'Draft') {
                    $scope.docDefinition.selectedWatermark = { 'type': 'draft', 'text': '' };
                } else {
                    $scope.docDefinition.selectedWatermark = { 'type': 'custom', 'text': row.watermark };
                }
            };

            // populate single source batch job details when editing, just load those info needed for display on UI
            var loadSingleSourceBatchJob = function (row) {

                $scope.docDefinition.isMultiSource = false;
                loadCommonBatchJobInfo(row);
                populateDocumentTypes();
                loadTemplatesByDocType($scope.docDefinition.selectedDocumentType, true); // re-fill templates
                $scope.selectedRadioDocumentType.docType = row.templateDocType;

                //currently only support Plan for single source
                $scope.docDefinition.selectedPlans = [];
                $scope.docDefinition.selectedPlanNames = [];
                $scope.docDefinition.selectedPlanNames.push(row.dataSourceNames);

                // for single source batch, there is only one plan in a row
                var planJSON = { 'objectId': row.dataSourceIds, 'name': $scope.docDefinition.selectedPlanNames[0], 'planYear': row.dataSourceYear };
                $scope.docDefinition.selectedPlans.push(planJSON);

                $state.transitionTo('home.media-management.generateDocument.singleSource', {
                    'batchObjectId': $scope.batch.objectId
                });

                DocumentDataFactory.getTemplateById(row.templateId)  // need to load template by api for more template data
                .then(function (data) {
                    $scope.docDefinition.selectedTemplate = data;
                    $scope.docDefinition.selectedSingleSourceTypes[0] = 'Plan';

                    row.isSelected = true;
                    row.enableSelection = true;
                    $scope.gridApi.selection.selectRow(row);
                    $('html, body').animate({ scrollTop: 0 }, 800);

                    // save the current selected batchJob object for Save button
                    $scope.batch.batchJobInEditing = {
                        'batchJobObjectId': row.objectId,
                        'batchJobTaskObjectId': row.batchJobTaskObjectId,
                        'batchJobTaskDocumentObjectId': row.batchJobTaskDocObjectId,
                        'originalDocName': row.documentName
                    };

                });
            };

            // populate multi source batch job details when editing, just load those info needed for display on UI
            var loadMultiSourceBatchJob = function (row) {

                $scope.docDefinition.isMultiSource = true;

                loadCommonBatchJobInfo(row);  // for multi source we need to load common batch job details first because of a slight delay
                loadTemplatesByDocType($scope.docDefinition.selectedDocumentType); // re-fill templates

                DocumentDataFactory.getTemplateById(row.templateId)
                .then(function (data) {
                    $scope.docDefinition.selectedTemplate = data;

                    row.isSelected = true;
                    row.enableSelection = true;
                    $scope.gridApi.selection.selectRow(row);
                    $('html, body').animate({ scrollTop: 0 }, 800);

                    if (row.templateSources && row.templateSources.dataSources && row.templateSources.dataSources.length > 0) {
                        $scope.docDefinition.selectedSources = [];  //clean up the selectedSources grid
                        $scope.docDefinition.selectedPlans = [];

                        var selectedTemplateSources = $scope.docDefinition.selectedTemplate.templateSources;

                        angular.forEach(row.templateSources.dataSources, function (source) {
                            if (source.SourceType && source.SourceType.toLowerCase() !== 'offering') {
                                for (var i = 0, j = selectedTemplateSources.length; i < j; i++) {
                                    if (selectedTemplateSources[i].sourceIndicator === source.SourceIndicator && selectedTemplateSources[i].sourceType === source.SourceType) {
                                        source.isBaseSource = selectedTemplateSources[i].isBaseSource;
                                        source.isRequiredSource = selectedTemplateSources[i].isRequiredSource;
                                        break;
                                    }
                                }

                                var sourceJson = {
                                    'objectId': source.ID,
                                    'name': source.SourceName,
                                    'sourceType': source.SourceType,
                                    'sourceIndicator': source.SourceIndicator,
                                    'isBaseSource': source.isBaseSource,
                                    'isRequiredSource': source.isRequiredSource
                                };
                                $scope.docDefinition.selectedSources.push(sourceJson);

                                if (source.SourceType && source.SourceType.toLowerCase() === 'plan') {
                                    $scope.docDefinition.selectedMultiSourceTypes[0] = 'Plan';
                                    $scope.docDefinition.selectedPlans.push({ 'objectId': source.ID, 'name': source.SourceName });
                                }
                                if (source.SourceType && source.SourceType.toLowerCase() === 'account') {
                                    $scope.docDefinition.selectedMultiSourceTypes[4] = 'Account';
                                    $scope.docDefinition.selectedAccounts = [{ 'objectId': source.ID, 'name': source.SourceName }];
                                }

                            }
                            else {
                                $scope.docDefinition.selectedOfferings = [{ 'objectId': source.ID, 'name': source.SourceName }];
                                $scope.docDefinition.selectedMultiSourceTypes[3] = 'Offering';   // make the Offering checkbox selected
                            }
                        });
                        // if Offering checkbox is selected, deselect Plan checkbox, they cannot be both selected
                        if ($scope.docDefinition.selectedMultiSourceTypes[3] === 'Offering') {   
                            $scope.docDefinition.selectedMultiSourceTypes[0] = '';
                        }
                    }

                    $scope.$emit('selectSourcesFromBatchJob', { 'selectedSources': $scope.docDefinition.selectedSources });
                    
                    // save the current selected batchJob object for Save button
                    $scope.batch.batchJobInEditing = {
                        'batchJobObjectId': row.objectId,
                        'batchJobTaskObjectId': row.batchJobTaskObjectId,
                        'batchJobTaskDocumentObjectId': row.batchJobTaskDocObjectId,
                        'originalDocName': row.documentName
                    };

                });

                $state.transitionTo('home.media-management.generateDocument.multiSource', {
                    'batchObjectId': $scope.batch.objectId
                });

            };

            var saveBatchJobUpdates = function () {
                var scopeObj = {
                    isMultiSource: $scope.docDefinition.isMultiSource,
                    documentNameEdited: $scope.batch.documentNameEdited,
                    selectedDocFormats: $scope.docDefinition.selectedDocFormats,
                    selectedPlans: $scope.docDefinition.selectedPlans,
                    selectedPlanNames: $scope.docDefinition.selectedPlanNames,
                    selectedTemplate: { objectId: $scope.docDefinition.selectedTemplate.objectId, name: $scope.docDefinition.selectedTemplate.name, templateSources: $scope.docDefinition.selectedTemplate.templateSources },
                    selectedWatermark: { text: $scope.docDefinition.selectedWatermark.text },
                    selectedDocumentType: { value: $scope.docDefinition.selectedDocumentType.value },
                    selectedSources: $scope.docDefinition.selectedSources,
                    currentBatch: { objectId: $scope.batch.objectId, name: $scope.batch.name },
                    currentBatchJobInEditing: $scope.batch.batchJobInEditing
                };

                DocumentBatchHelper.saveBatchJobUpdates(scopeObj)
                    .then(function () {
                        cleanUpBatchJobEditingData();
                        loadBatchAndJobGrid();
                        $scope.batch.batchJobInEditing = null;
                        $scope.gridApi.selection.clearSelectedRows();
                        BatchService.setCurrentBatch($scope.batch);

                    }, function () {
                        loadBatchAndJobGrid();
                    });
            };

            /* main function to save after creating a batch job */
            var saveBatchAndJobCreation = function (batchJson) {
                if ($scope.docDefinition.isMultiSource) {
                    if (validateMultiSourceDocGen()) {
                        BatchService.updateBatch(batchJson, $scope.batch.objectId)
                        .then(function () {
                            processBatchWorkflow();  // if there are plans and template selected, add to batch
                        }, function (reason) {
                            $log.error(reason);
                        });
                    } else {
                        return;  // if validation failed
                    }
                } else {
                    if (validateSingleSourceDocGen(true)) {
                        BatchService.updateBatch(batchJson, $scope.batch.objectId)
                        .then(function () {
                            processBatchWorkflow();  //if there are plans and template selected, add to batch
                        }, function (reason) {
                            $log.error(reason);
                        });
                    } else {
                        return;  // if validation failed
                    }
                }
            };

            /* main function to save after editing a batch */
            var saveBatchAndJobEditing = function (batchJson) {
                if ($scope.docDefinition.isMultiSource) {
                    if ($scope.currentBatch.batchNameChanged) {   // if batch name changed
                        BatchService.updateBatch(batchJson, $scope.batch.objectId)
                        .then(
                            function () {
                                // if this is to save a batch job after editing
                                if ($scope.batch.batchJobInEditing) {
                                    if (validateMultiSourceDocGen()) {
                                        setWatermark();
                                        saveBatchJobUpdates();
                                    }
                                    else {
                                        return;  // if validation failed
                                    }
                                }
                                // reset currentBatchNameChanged so Save button can be disabled
                                $scope.currentBatch.batchNameChanged = false;

                            }, function (reason) {
                                $log.error(reason);
                            });

                    } else {
                        if (validateMultiSourceDocGen()) {
                            setWatermark();
                            saveBatchJobUpdates();
                        }
                        else {
                            return;  // if validation failed
                        }
                    }
                } else {  // single source
                    if ($scope.currentBatch.batchNameChanged) {   // if batch name changed
                        BatchService.updateBatch(batchJson, $scope.batch.objectId)
                        .then(
                            function () {
                                if ($scope.batch.batchJobInEditing) {
                                    if (validateSingleSourceDocGen(true)) {
                                        setWatermark();
                                        saveBatchJobUpdates();
                                    }
                                    else {
                                        return;  // if validation failed
                                    }
                                }
                                // reset currentBatchNameChanged so Save button can be disabled
                                $scope.currentBatch.batchNameChanged = false;

                            }, function (reason) {
                                $log.error(reason);
                            });

                    } else {
                        if (validateSingleSourceDocGen(true)) {
                            setWatermark();
                            saveBatchJobUpdates();
                        }
                        else {
                            return;  // if validation failed
                        }
                    }
                }
            };

            var parseBatchTaskBody = function (jsonText) {
                var jsonData = {};

                if (jsonText !== null && angular.isDefined(jsonText) && jsonText !== '') {
                    jsonData = JSON.parse(jsonText);
                }

                return jsonData;
            };

            var cleanUpStorageBatch = function () {
                if (BatchService.getCurrentBatch() !== null) {
                    BatchService.setCurrentBatch(null);
                }
            };


            // switch between single source and multi source view
            $scope.navigateToSourceView = function (goMultiSrc) {
                // prompt the confirmation modal only when something changed
                if ($scope.docDefinition && ($scope.docDefinition.selectedTemplate || $scope.docDefinition.selectedPlans || $scope.docDefinition.selectedOfferings)) {
                    var dialogOptions = {
                        templateUrl: 'views/media-management/confirm-transition.html',
                        controller: 'transitionCtrl',
                        size: 'md',
                        backdrop: false
                    };

                    ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                        if (result) {
                            $scope.docDefinition.selectedTemplate = null;
                            $scope.docDefinition.selectedPlans = null;
                            $scope.docDefinition.selectedOfferings = null;
                            $scope.docDefinition.selectedOfferingPlans = null;
                            $scope.docDefinition.selectedAccounts = null;

                            if (goMultiSrc) {
                                $scope.docDefinition.selectedSingleSourceTypes = [];
                                $scope.docDefinition.isMultiSource = true;
                                populateDocumentTypes();
                                loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
                                $state.go('home.media-management.generateDocument.multiSource');
                            }
                            else {
                                $scope.docDefinition.selectedMultiSourceTypes = [];
                                $scope.docDefinition.selectedSources = [];
                                $scope.docDefinition.isMultiSource = false;
                                populateDocumentTypes();
                                loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
                                $state.go('home.media-management.generateDocument.singleSource');
                            }                            
                        }
                        else {
                            if (goMultiSrc) {
                                $scope.docDefinition.isMultiSource = false;
                            }
                            else {
                                $scope.docDefinition.isMultiSource = true;
                            }
                        }
                    });
                }
                else {
                    if (goMultiSrc) {
                        $scope.docDefinition.selectedSingleSourceTypes = [];
                        $scope.docDefinition.isMultiSource = true;
                        populateDocumentTypes();
                        loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
                        $state.go('home.media-management.generateDocument.multiSource');
                    }
                    else {
                        $scope.docDefinition.selectedMultiSourceTypes = [];
                        $scope.docDefinition.isMultiSource = false;
                        populateDocumentTypes();
                        loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
                        $state.go('home.media-management.generateDocument.singleSource');
                    }
                }
            };

            $scope.selectTemplateModal = function (isMultiSrc, docType) {

                var dialogOptions = {
                    templateUrl: 'views/media-management/select-template.html',
                    controller: 'SelectTemplateCtrl',
                    size: 'lg',
                    backdrop: false,
                    resolve: {
                        templatesPromise: ['DocumentDataFactory',
                            function (DocumentDataFactory) {
                                return DocumentDataFactory.getAllTemplates(isMultiSrc ? 'multi' : 'single', docType).then(function (data) {
                                    return data;
                                });
                            }
                        ],

                        templateFiltersMetaData: ['DocumentDataFactory',
                            function (DocumentDataFactory) {
                                return DocumentDataFactory.getTemplateSchema().then(function (data) {
                                    return data;
                                });
                            }
                        ],

                        aspectsMetaData: ['DocumentDataFactory',
                            function (DocumentDataFactory) {
                                return DocumentDataFactory.getAspectDefinitions().then(function (data) {
                                    return data;
                                });
                            }
                        ],

                        isMultiSourceDoc: function () {
                            return isMultiSrc;
                        },

                        documentType: function () {
                            return docType;
                        },

                        authorizedUserInfo: ['$auth', function ($auth) {
                            return $auth.requestUserInfo();
                        }]
                    }
                };

                ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                    if (result != null) {
                        $scope.docDefinition.selectedSources = [];  //clean up any existing selectedSources in the grid

                        $scope.docDefinition.selectedTemplate = result;
                        $scope.docDefinition.selectedTemplate.templateSources = [];

                        angular.forEach(result.sources, function (source) {
                            $scope.docDefinition.selectedTemplate.templateSources.push(source);                                                
                        });

                        if ($scope.docDefinition.isMultiSource) {
                            showPlanOrOfferingSelections();
                        }
                        else {
                            $scope.docDefinition.selectedSingleSourceTypes[0] = 'Plan';  // select "Plan" radio button under single source view
                        }
                    }
                });

            };

            $scope.clearTemplates = function () {
                $scope.docDefinition.selectedTemplate = null;
                $scope.docDefinition.selectedSources = [];  //clean up previously selected sources

                if ($scope.docDefinition.isMultiSource) {
                    $scope.docDefinition.selectedMultiSourceTypes = [];
                }
            };

            populateDocumentTypes();    //populate "Select Document Type" section when page load
            populateDocumentFormats();  //populate "Format" section when page load
            populateBusinessEntity();  //enable calling Document Generation page from outside media management by passing parameters

            loadTemplatesByDocType($scope.docDefinition.selectedDocumentType);
            loadBatchAndJobGrid();  //populate Batch object and Batch Job grid

            // Click "Generate" button to start document generation
            $scope.generateFinalDoc = function () {
                $scope.documentValidationNeeded = true;
                $scope.isFromOtherModule = false;
                var sysDocName = '';

                setWatermark();

                if ($scope.docDefinition.isMultiSource) {
                    if (validateMultiSourceDocGen()) {
                        var scopeObj = {
                            selectedTemplate: {
                                objectId: $scope.docDefinition.selectedTemplate.objectId,
                                name: $scope.docDefinition.selectedTemplate.name,
                                templateSources: $scope.docDefinition.selectedTemplate.templateSources
                            },
                            selectedDocumentType: { value: $scope.docDefinition.selectedDocumentType.value },
                            selectedSources: $scope.docDefinition.selectedSources
                        };

                        DocumentBatchHelper.createMultiSourceDocName(scopeObj).then(function (genDocName) {
                            sysDocName = genDocName;
                            promptDocumentName(sysDocName);
                        }, function () {
                            $log.error('Error occurred when generating system document name.');
                            ConfirmationModalFactory.open('Error Message', 'Error occurred when generating system document name.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                        });
                    }
                } else {
                    if (validateSingleSourceDocGen()) {
                        if ($scope.docDefinition.selectedPlans && $scope.docDefinition.selectedPlans.length > 0) {  //generate plan document single source
                            sysDocName = DocumentBatchHelper.generateSysPlanDocName($scope.docDefinition.selectedPlans[0].name, $scope.docDefinition.selectedPlans[0].planYear, $scope.docDefinition.selectedDocumentType.value);

                            promptDocumentName(sysDocName);
                        }
                    }
                }
            };

            $scope.selectTemplate = function (template) {
                $scope.docDefinition.selectedTemplate = template;
            };

            $scope.selectWatermark = function (type) {
                $scope.docDefinition.selectedWatermark.type = type;
            };

            $scope.showTemplateMsgError = function () {
                if ($scope.docDefinition.selectedTemplate === null) {
                    if ($scope.documentValidationNeeded) {
                        if (!$scope.isFromOtherModule) {
                            return true;
                        } 
                    }

                    if ($scope.docDefinition.isMultiSource) {   // for multi source
                        var counter = 0;
                        /* This is to check if any of the source type checkboxes selected */
                        for (var i = 0, j = $scope.docDefinition.selectedMultiSourceTypes.length; i < j; i++) {
                            if ($scope.docDefinition.selectedMultiSourceTypes[i] === '') {
                                counter++;
                            }
                        }

                        if ($scope.docDefinition.selectedMultiSourceTypes.length !== counter) {
                            return true;
                        }
                    }
                    else {  // for single source
                        if ($scope.docDefinition.selectedSingleSourceTypes.length > 0) {
                            if (!$scope.isFromOtherModule && $scope.documentValidationNeeded) {
                                return true;
                            }
                        }
                    }
                }
            };

            $scope.showWatermarkMsgError = function () {
                return ($scope.docDefinition.selectedWatermark.type === 'custom' && !$scope.docDefinition.selectedWatermark.text) &&
                    ($scope.documentValidationNeeded === true || $scope.addToBatchButtonClicked === true || $scope.saveBatchButtonClicked === true);
            };

            // pagination
            $scope.navBatchJobPage = function ($event, delta) {
                PaginationService.navPage($event, delta, $scope.gridApi);
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            };
            // pagination
            $scope.viewBatchJobPages = function () {
                var ps = [];
                ps = PaginationService.viewPages($scope.gridApi, ps);
                return ps;
            };
            // pagination
            $scope.batchJobPageSizeChanged = function () {
                $scope.gridBatchDocs.paginationCurrentPage = 1;
            };
            // pagination
            $scope.goToBatchJobPage = function (keyEvent, pageNumberObject) {
                PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
            };

            $scope.gridBatchDocs = {
                'excessRows': 400,
                enableHorizontalScrollbar: 0,  //never show the horizontal scroll bar
                enableVerticalScrollbar: 2,
                rowHeight: 85,
                multiSelect: false,
                enableSorting: true,
                enablePaginationControls: false,
                enableRowSelection: false,
                enableRowHeaderSelection: false,
                paginationPageSizes: ENV.settings.paginationPageSizes,
                paginationPageSize: 20,
                useExternalPagination: false,
                useExternalSorting: false,
                columnDefs: [
                    {
                        name: 'objectId',
                        displayName: '',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/icon-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: false,
                        width: '4%'
                    },
                    {
                        name: 'templateDocType',
                        displayName: 'Type',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/doc-type-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '8%'
                    },
                    {
                        name: 'documentName',
                        displayName: 'Document Name',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/name-col.html',
                        enableCellEdit: true,
                        enableCellEditOnFocus: true,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '22%'
                    },
                    {
                        name: 'creationDate',
                        displayName: 'Job Added',
                        cellTemplate: '<div class="ui-grid-cell-contents col-cell-full-break">{{row.entity.creationDate | amDateFormat:"' + ENV.dateFormat + '"}}</div>',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '8%'
                    },
                    {
                        name: 'sourceType',
                        displayName: 'Source Type',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/source-type-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '20%'
                    },
                    {
                        name: 'templateName',
                        displayName: 'Template Name',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/template-name-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '20%'
                    },
                    {
                        name: 'watermark',
                        displayName: 'Watermark',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/watermark-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        width: '10%'
                    },
                    {
                        name: 'docFormats',
                        displayName: 'Format',
                        cellTemplate: 'views/media-management/template/batch-grid-generate-document/doc-format-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '8%'
                    },
                    {
                        name: 'batchJobTaskObjectId',
                        visible: false,
                        width: '0'
                    }
                ],

                onRegisterApi: function (gridApi) {
                    $scope.gridApi = gridApi;
                    $scope.gridApi.core.on.sortChanged($scope, function (grid, sortColumns) {
                        if (sortColumns.length >= 0) {
                            PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                        }
                    });
                    gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {

                        paginationOptions.pageNumber = newPage;
                        paginationOptions.pageSize = pageSize;

                        loadBatchAndJobGrid();

                        if (!PaginationService.isGoToPageEnabled) {
                            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                        }

                        PaginationService.setGoToPageEnabled(false);
                    });
                    gridApi.edit.on.beginCellEdit($scope, function (rowEntity) {
                        $scope.originalDocNameInGrid = rowEntity.documentName;  // need to save the original document name in the cell
                    });
                    gridApi.edit.on.afterCellEdit($scope, function (rowEntity, newValue, oldValue) {
                        if (oldValue) {
                            if (oldValue === $scope.originalDocNameInGrid) {  //if document name not changed, don't proceed further
                                return;
                            }

                            var newDocName = oldValue;  // yes it is the oldValue! newValue is an object represents the cell
                            var regex = new RegExp(/"|\*|\\|>|<|\?|\/|:|\|/);  // characters ", *, \, >, <, ?, /, :, | are not allowed in filenames.

                            if (!newDocName.match(regex)) {
                                BatchService.getBatchJobTaskById(rowEntity.batchJobTaskObjectId)
                                .success(function (data) {
                                    var newbatchJobTaskBody = {};
                                    var batchJobTaskBody = parseBatchTaskBody(data.batchJobTaskBody);
                                    newbatchJobTaskBody = angular.copy(batchJobTaskBody);
                                    newbatchJobTaskBody.documentName = newDocName;

                                    var jsonPayload = { batchJobTaskBody: JSON.stringify(newbatchJobTaskBody) };

                                    BatchService.updateBatchJobTask(jsonPayload, rowEntity.batchJobTaskObjectId)
                                    .then(function () {
                                        var newNameJson = { 'batchJobObjectId': rowEntity.objectId, 'newDocName': newDocName };
                                        $scope.batch.documentNameEdited.push(newNameJson);   // remember if the document name is changed by user

                                        loadBatchAndJobGrid();

                                    }, function (reason) {
                                        $log.error(reason);
                                    });

                                })
                                .error(function (reason) {
                                    //ConfirmationModalFactory.open('Error Message', 'Error occured when loading Batch Job Task.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                                    $log.info(reason);
                                });
                            } else {
                                rowEntity.documentName = $scope.originalDocNameInGrid;
                                ConfirmationModalFactory.open('Error Message',
                                    'Characters &#34;, &#42;, &#92;, &#62;, &#60;, &#63;, &#47;, &#58;, | are not allowed in document name.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);

                            }
                        } else {
                            rowEntity.documentName = $scope.originalDocNameInGrid;
                        }
                    });
                }
            };

            $scope.showStatusTextColor = function (status) {
                var cssClass = '';

                if (status === 'Successful') {
                    cssClass = 'hr-color-success';
                } else if (status === 'Partially Successful') {
                    cssClass = 'hr-color-warning';
                } else if (status === 'Failed') {
                    cssClass = 'hr-color-error';
                } else if (status === 'Pending' || status === 'Draft') {
                    cssClass = 'hr-color-pending';
                } else {
                    cssClass = 'hr-color-brand-info';
                }

                return cssClass;
            };

            $scope.showBatchJobStatusDetails = function (status) {
                var toDisplay = true;

                if (status === 'Successful') {
                    toDisplay = false;
                }

                return toDisplay;
            };

            $scope.displayDateInFormat = function (date) {
                if (date) {
                    return moment(date).format(ENV.dateFormat);
                } else {
                    return '';
                }
            };

            /*jshint maxcomplexity:12*/
            $scope.canResubmitBatch = function (action) {
                if ($scope.batch === null || !angular.isDefined($scope.batch)) {
                    return false;
                }

                var batchStatus = $scope.batch.batchStatus;
                var canResubmit = false;

                if (batchStatus === 'Successful') {
                    if (!action || action === 'all') {
                        canResubmit = true;
                    }
                }
                else if (batchStatus === 'Failed' || batchStatus === 'Cancelled' || batchStatus === 'Partially Successful') {

                    if (!action || action === 'all') {
                        canResubmit = true;
                    }
                    else if (action === 'cancelfailed') {
                        canResubmit = true;
                    }
                }

                return canResubmit;
            };

            $scope.batchObjectExists = function () {
                if ($scope.batch === null || !angular.isDefined($scope.batch)) {
                    return false;
                }

                return angular.isDefined($scope.batch.objectId) && $scope.batch.objectId !== '';
            };

            $scope.batchJobsExist = function () {
                if ($scope.batch === null || !angular.isDefined($scope.batch)) {
                    return false;
                }

                if ($scope.batch.batchJobs === null || !angular.isDefined($scope.batch.batchJobs)) {
                    return false;
                }

                return $scope.batch.batchJobs.length > 0;
            };

            $scope.notAbleToGenerate = function () {
                return $scope.documentValidationNeeded || ($scope.batchObjectExists() && $scope.batchJobsExist());
            };

            $scope.editBatchJob = function (row) {
                cleanUpBatchJobEditingData();    // clean up any previous data if any
                $scope.currentBatch.isEditingBatchJob = true;
                $scope.isBatchPaneCollapsed = false;  // open up the bacth job details section if closed

                // load specific details about single source or multi source
                if (row.isBatchJobMultiSource) {
                    loadMultiSourceBatchJob(row);
                } else {
                    loadSingleSourceBatchJob(row);
                }
            };

            $scope.removeBatchJob = function (batchId) {
                BatchService.getBatchJobDetails(batchId)
                .success(function (data) {
                    var row = data;

                    BatchService.deleteBatchAndBatchJobAssociation($scope.batch.objectId, row.objectId)
                    .then(function () {
                        /* Currently CM does not delete the subordinate/child objects when the parent object is deleted due to the way they are modelled in Alfresco. 
                        there is a task in the backlog to make some modifications to the model to make that happen */
                        BatchService.deleteBatchJob(row.objectId)
                        .then(function () {
                            loadBatchAndJobGrid();  // we can reload the grid here 'cuz the batchJob is already deleted, it won't show anymore
                            gridItemRemoved();

                            angular.forEach(row.batchJobTasks, function (batchJobTask) {
                                BatchService.deleteBatchJobTask(batchJobTask.objectId)
                                .then(function () {
                                    $log.info('BatchJobTask ' + batchJobTask.objectId + ' is deleted successfully.');

                                    angular.forEach(batchJobTask.taskDocument, function (batchJobTaskDocument) {
                                        BatchService.deleteBatchJobTaskDocument(batchJobTaskDocument.objectId)
                                        .then(function () {
                                            $log.info('BatchJobTaskDocument ' + batchJobTaskDocument.objectId + ' is deleted successfully.');
                                        }, function (reason) {
                                            $log.error(reason);
                                        });
                                    });
                                }, function (reason) {
                                    $log.error(reason);
                                });
                            });

                        }, function (reason) {
                            $log.error(reason);
                            loadBatchAndJobGrid();
                        });

                    }, function (reason) {
                        $log.error(reason);
                        loadBatchAndJobGrid();
                    });
                })
                .error(function (reason) {
                    //ConfirmationModalFactory.open('Error occured when deleting BatchJob', 'Unable to find BatchJob "' + batchId + '".', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    $log.erro(reason);
                });
            };

            $scope.saveBatchObject = function (saveButtonClicked) {
                if ($scope.batch === null || !angular.isDefined($scope.batch)) {
                    $scope.batch = { 'name': '', 'objectId': '', 'batchJobs': null };
                }

                $scope.documentValidationNeeded = true;

                if ($scope.batch.name.length === 0 && $scope.batch.objectId !== '') {  //check if batch name is empty
                    return;
                }

                if ($scope.batch.name.match(new RegExp(/"|\*|\\|>|<|\?|\/|:|\|/))) {  //check special characters
                    return;
                }

                // if no batch created yet, prompt 'Name your batch' modal window to create a batch object
                if ((!angular.isDefined($scope.batch.name) || $scope.batch.name === '') && (!angular.isDefined($scope.batch.objectId) || $scope.batch.objectId === '')) {
                    var dialogOptions = {
                        templateUrl: 'views/media-management/add-batch-name.html',
                        controller: 'BatchNameCtrl',
                        size: 'md',
                        backdrop: false
                    };

                    ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                        $scope.batch.name = result.name;
                        $scope.batch.objectId = result.objectId;
                        $scope.batch.batchJobs = [];

                        processBatchWorkflow();
                    });
                }
                else {
                    if (saveButtonClicked) {  // Save button clicked
                        var jsonData = { 'name': $scope.batch.name };

                        if (!$scope.currentBatch.isEditingBatch) {  // creating a batch or batch job
                            saveBatchAndJobCreation(jsonData);
                        } else {  // editing a batch
                            if ($scope.batch.batchJobInEditing) {
                                saveBatchAndJobEditing(jsonData);
                            }
                            else {
                                saveBatchAndJobCreation(jsonData);  // create a new batchJob when editing a batch
                            }
                        }

                        //$scope.documentValidationNeeded = false;
                    }
                    else {  // Add to Batch clicked
                        processBatchWorkflow();
                    }
                }
            };

            $scope.submitBatch = function () {
                /* PONHR-1808, we will need to display "Submit" button instead of "Resubmit" when batch status is "Draft" after editting,
                but what we really need is to "Resubmit All". */
                if ($scope.currentBatch.batchSubmittedBy && $scope.currentBatch.batchSubmittedDate) {  //batch has been submitted before
                    $scope.reSubmitBatch('resubmit_all');
                }
                else {
                    $scope.submitBatchButtonClicked = true;

                    var batchIdsToBeSubmitted = [];
                    batchIdsToBeSubmitted.push($scope.batch.objectId);

                    if ($scope.batchObjectExists() && $scope.batchJobsExist() && $scope.batch.name && $scope.batch.name.length > 0) {
                        BatchService.submitBatch(batchIdsToBeSubmitted)
                        .then(function () {
                            $scope.submitBatchButtonClicked = false;
                            //cleanUpStorageData();
                            cleanUpStorageBatch();   //clean batch data
                            $state.go('home.media-management.finalGenerateDoc',
                                { 'generatorType': 'batch', 'batchName': $scope.batch.name, 'multiSource': $scope.docDefinition.isMultiSource, 'editingBatch': $scope.currentBatch.isEditingBatch });
                        }, function (error) {
                            $scope.submitBatchButtonClicked = false;
                            $log.error('Error submitting batch' + error.message);
                        });
                    }
                }
            };

            $scope.reSubmitBatch = function (action) {
                $scope.submitBatchButtonClicked = true;

                var batchIdsToBeSubmitted = [];
                batchIdsToBeSubmitted.push($scope.batch.objectId);

                // let the backend check the batch status and see if it can be re-submitted with the flag "resubmit_all" or "cancelfailed"
                BatchService.reSubmitBatch(batchIdsToBeSubmitted, action)
                    .then(
                        function () {
                            $scope.submitBatchButtonClicked = false;
                            cleanUpStorageBatch();   //clean batch data
                            $state.go('home.media-management.finalGenerateDoc',
                                { 'generatorType': 'batch', 'batchName': $scope.batch.name, 'multiSource': $scope.docDefinition.isMultiSource, 'editingBatch': $scope.currentBatch.isEditingBatch });
                        },
                        function (error) {
                            $scope.submitBatchButtonClicked = false;
                            $log.error('Error occured when re-submitting batch' + error.message);
                        });
            };

            $scope.cancelBatch = function () {
                var dialogOptions = {
                    templateUrl: 'views/media-management/confirm-cancel-batch.html',
                    controller: 'CancelBatchCtrl',
                    size: 'md',
                    backdrop: false
                };

                ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                    if (result) {
                        if (!$scope.batch.batchJobInEditing) {   // if not in editing BatchJob mode, leave the page
                            if (batchObjectIdParam) {
                                $state.go('home.media-management.listBatch');
                            }
                            else if ($stateParams.businessEntity === 'plan' && $stateParams.dataSourceId != null) {
                                $state.go('home.ppm.plan.plan-list');
                            }
                            else {
                                $state.go('home.media-management.documents');
                            }
                        } else {   // in batch job editing mode
                            cleanUpBatchJobEditingData();
                            $scope.batch.batchJobInEditing = null;
                            $scope.gridApi.selection.clearSelectedRows();
                        }
                    }
                });
            };

            $scope.toggleBatchPane = function () {
                $scope.isBatchPaneCollapsed = !$scope.isBatchPaneCollapsed;
            };

            $scope.addToBatch = function () {
                $scope.documentValidationNeeded = true;

                if ($scope.docDefinition.isMultiSource) {
                    if (!validateMultiSourceDocGen()) {
                        return;
                    }
                }
                else {
                    // form not valid if plan or template not selected
                    if (!validateSingleSourceDocGen(true)) {
                        return;
                    }
                }

                $scope.saveBatchObject(false);
            };

        });
