﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ProductsModalInstanceCtrl', function($scope, productsAvailable, ModalDialogFactory, $modalInstance) {
        $scope.products = productsAvailable;
        $scope.selectedProductIds = [];

        $scope.toggleSelection = function(productId) {
            var idx = $scope.selectedProductIds.indexOf(productId);
            // is currently selected
            if (idx > -1) {
                $scope.selectedProductIds.splice(idx, 1);
            }
            // is newly selected
            else {
                $scope.selectedProductIds.push(productId);
            }
        };

        $scope.ok = function() {
            if ($scope.selectedProductIds.length === 1) {
                $scope.onlyOneSelected = true;
            } else {
                $scope.onlyOneSelected = false;
            }

            $modalInstance.close($scope.selectedProductIds.sort());
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };
    });