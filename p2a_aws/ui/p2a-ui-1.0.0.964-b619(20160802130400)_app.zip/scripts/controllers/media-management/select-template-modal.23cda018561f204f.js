'use strict';

angular.module('p2AdvanceApp')
  .controller('SelectTemplateModalCtrl', function (
      $scope,
      $state,
      $modalInstance,
      DocumentDataFactory,
      ModalDialogFactory,
      modalTitle,
      parentState)
  {
      $scope.modalTitle = modalTitle;

      $scope.ok = function () {
          ModalDialogFactory.closeDialog($scope.selectedGridUnits);
          var unitJSON = null;
          if ($scope.selectedGridUnits != null) {
              var selectedTemplate = $scope.selectedGridUnits[0];
              unitJSON = { 'objectId': selectedTemplate.objectId, 'name': selectedTemplate.name, 'description': selectedTemplate.description, 'sources': selectedTemplate.templateSources};
          }
          $scope.$emit('templateSelectedEvt', unitJSON);
          $state.go(parentState);
      };

      $scope.cancel = function () {
          $modalInstance.dismiss('cancel');
          $state.go(parentState);
      };
  });
