﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('ViewDocumentCtrl', function($scope, $modalInstance, $sce, documentAvailable, ENV_MEDIA_MANAGEMENT) {
        $scope.document = documentAvailable;

        $scope.getDocumentUrl = function() {
            return $sce.trustAsResourceUrl(ENV_MEDIA_MANAGEMENT.mediaApiEndpoint + '/600214HR_Blue_Choice_5_80-0236LG1-1-15.pdf');
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };
    });