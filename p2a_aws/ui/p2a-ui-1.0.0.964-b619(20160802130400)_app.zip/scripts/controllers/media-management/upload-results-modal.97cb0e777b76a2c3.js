﻿'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: UploadResultsCtrl
 * @description
 * # UploadResultsCtrl
 * Controller of the p2AdvanceApp under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('UploadResultsCtrl',
        function ($scope, files, $modalInstance
           ) {

            $scope.files = files;

            var uploadedNumber = 0;
            var total = $scope.files.length;
            angular.forEach($scope.files, function (file) {
                if (file.isUploaded) {
                    ++uploadedNumber;
                }
            });
            if (uploadedNumber === $scope.files.length) {
                $scope.result = total + ' of ' + total + ' documents did upload';
                $scope.title = 'Successfully Upload';
            } else if (uploadedNumber === 0) {
                $scope.result = total + ' of ' + total + ' documents did not upload';
                $scope.title = 'Upload Failed';
            } else {
                $scope.result = (total - uploadedNumber) + ' of ' + total + ' documents did not upload';
                $scope.title = 'Partially Successful Upload';
            }

            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        });
