﻿'use strict';

angular.module('p2AdvanceApp')
  .controller('BatchNameCtrl', function (
        $scope,
        $modalInstance,
        $auth,
        $log,
        BatchService,
        ModalDialogFactory) {

      $scope.addBatchName = function () {
          if (angular.isDefined($scope.batchName) && $scope.batchName.length > 0) {
              if ($scope.batchName.match(new RegExp(/"|\*|\\|>|<|\?|\/|:|\|/))) {  //check special characters
                  return;
              }

              // according to latest dev info, UI doesn't add user token to batch
              var postJsonData = {
                  name: $scope.batchName,
                  batchStatus: 'Draft',
                  batchClass: 'Concurrent',
                  batchStatusDetails: ''
              };
              //call cm to create the batch
              BatchService.createBatch(postJsonData)
                .then(function (data) {
                    var returnJSON = {
                        'name': $scope.batchName,
                        'objectId': data
                    };

                    ModalDialogFactory.closeDialog(returnJSON);
                }, function (reason) {
                    $log.error(reason);
                });
          }
      };

      $scope.closeBatchNameModal = function () {
          $modalInstance.dismiss('cancel');
      };

      $scope.showBatchNameInvalidErrMsg = function () {
          var regex = new RegExp(/"|\*|\\|>|<|\?|\/|:|\|/);

          if ($scope.batchName && $scope.batchName.match(regex)) {
              return true;
          } else {
              return false;
          }
      };

      $scope.batchNameNotAdded = function () {
          return !angular.isDefined($scope.batchName) || $scope.batchName.length === 0;
      };
  });
