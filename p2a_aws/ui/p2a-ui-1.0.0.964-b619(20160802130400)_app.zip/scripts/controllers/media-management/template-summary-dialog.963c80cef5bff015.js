'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:TemplateSummaryDialogCtrl
 * @description
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('TemplateSummaryDialogCtrl', function ($scope, $modalInstance, getTemplate) {

        $scope.close = function () {
            $modalInstance.dismiss('cancel');
        };

        function getTemplateSources(templateSources) {
            var sourcesInfo = [];
            angular.forEach(templateSources, function (source) {
                if (source.sourceType.toLowerCase() !== 'account' && source.sourceType.toLowerCase() !== 'offering') {
                    sourcesInfo.push({
                        type: { name: source.sourceType, value: source.sourceIndicator },
                        sourceProp: getSourceProp(source)
                    });
                }
            });
            return sourcesInfo;
        }

        function getSourceProp(source) {
            var sourceProp = [
                    {
                        name: ['Is this a base ', source.sourceType].join(''), value: (source.isBaseSource ? 'Yes' : 'No')
                    },
                    {
                        name: ['Is this ', source.sourceType, ' required'].join(''), value: (source.isRequiredSource ? 'Yes' : 'No')
                    },
                    {
                        name: 'Product', value: ((source.productClasses && source.productClasses.length) ? source.productClasses.join(', ') : '-')
                    },
                    {
                        name: 'Product Types', value: ((source.productTypes && source.productTypes.length) ? source.productTypes.join(', ') : '-')
                    },
                    {
                        name: 'Market Segment', value: ((source.marketSegments && source.marketSegments.length) ? source.marketSegments.join(', ') : '-')
                    },
                     {
                         name: 'Number of Providers', value: (source.numProviderTiers ? source.numProviderTiers : '-')
                     },
                    {
                        name: 'Funding Arrangements', value: ((source.fundingArrangements && source.fundingArrangements.length) ? source.fundingArrangements.join(', ') : '-')
                    }];
            return sourceProp;
        }
        
        function isInfoIncluded(templateSources, info) {
            if (templateSources && templateSources.length) {
                for (var a = 0; a < templateSources.length; a++) {
                    if (templateSources[a].sourceType.toLowerCase() === info) {
                        return 'Yes';
                    }
                }
            }
            return 'No';

        }

        var templateInfo = [ 
            {
                name: 'Effective Date', value:  {
                    'start': getTemplate.effectiveDate,
                    'end': getTemplate.endDate
                }
            },
            {
                name: 'Document Type', value: getTemplate.documentType
            },
            {
                name: 'Document Class', value: getTemplate.businessEntity
            },
            {
                name: 'Template Plan Year', value: ((getTemplate.templatePlanYear && getTemplate.templatePlanYear.length) ? getTemplate.templatePlanYear.join(', ') : 'NA')
            },
            {
                name: 'Description', value: getTemplate.description
            },
            {
                name: 'Account information included', value: isInfoIncluded(getTemplate.templateSources, 'account')
            },
            {
                name: 'Offering information included', value: isInfoIncluded(getTemplate.templateSources, 'offering')
            }];

        $scope.getTemplateData = {
            sources: getTemplateSources(getTemplate.templateSources),
            info: templateInfo,
            name: getTemplate.name,           
            status: getTemplate.templateStatus
        };

        


    });