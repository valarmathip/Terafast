'use strict';

angular.module('p2AdvanceApp')
    .controller('UnitsCtrl', function(
        $scope,
        $filter,
        DocumentDataFactory,
        FilterDataService,
        ConfirmationModalFactory,
        ModalDialogFactory,
        $log,
        $state,
        ENV,
        unitFiltersMetaData,
        aspectsMetaData,
        unitsPromise,
        PaginationService,
        FilterService,
        authorizedUserInfo) {
        $scope.units = unitsPromise.response.docs;
        $scope.userInformation = authorizedUserInfo;
        $scope.allFiltersData = [];
        $scope.allFiltersData = FilterDataService.getUnitFilters(unitFiltersMetaData, aspectsMetaData, unitsPromise.response.docs, $scope.userInformation.data.user.email);

        $scope.selectedIdToObjsMap = [];
        var pageSize = 20; // SLQ
        $scope.currentPage = {
            all: 1,
            draft: 1,
            override: 1,
            published: 1
        };

        $scope.selectAllChecker = false;
        $scope.selectChecker = false;
        $scope.checkList = [];

        $scope.toggleSelection = function (row) {
            if (!$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = true;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }

            $scope.$parent.selectedGridUnits = $scope.gridApi.selection.getSelectedRows();
            $scope.checkList[row.entity.objectId] = $scope.selectChecker;
        };

        $scope.selectAllItems = function () {
            if (!$scope.selectAllChecker) {
                var rows = $scope.gridApi.core.getVisibleRows();  // select rows on one page of the grid

                angular.forEach(rows, function (row) {
                    row.isSelected = true;
                    row.enableSelection = true;
                    $scope.gridApi.selection.selectRow(row);
                });

                $scope.selectAllChecker = true;
            } else {
                angular.forEach($scope.gridApi.grid.rows, function (row) {
                    row.enableSelection = true;
                    row.isSelected = false;
                });

                $scope.gridApi.selection.clearSelectedRows();
                $scope.selectAllChecker = false;
            }

            $scope.$parent.selectedGridUnits = $scope.gridApi.selection.getSelectedRows();

            angular.forEach($scope.selectedUnits, function (unit) {
                $scope.checkList[unit.objectId] = $scope.selectAllChecker;
            });
        };

        $scope.gridUnits = {
            totalItems: unitsPromise.response.numFound,
            data: $scope.units,
            enableColumnResizing: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            multiSelect: true,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 2,
            rowHeight: 70,
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            useExternalPagination: true,
            useExternalSorting: true,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableColumnMenu: false,
                headerCellTemplate: '<input type="checkbox" class="grid-checkbox-position" ng-model="grid.appScope.master" ng-click="grid.appScope.selectAllItems()">',
                cellTemplate: '<input type="checkbox" class="grid-checkbox-position"' +
                              'ng-model="grid.appScope.checkList[row.entity.objectId]" ng-checked="grid.appScope.master && grid.appScope.checkList[row.entity.objectId]"' +
                              'ng-click="grid.appScope.toggleSelection(row)"/>',
                width: 60,
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Unit Name',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.name}}</div>',
                width: '20%',
                enableHiding: false
            }, {
                name: 'med',
                displayName: 'Medical Plan Name',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.med}}</div>',
                type: 'string',
                width: '20%',
                enableHiding: false
            }, {
                name: 'rx',
                displayName: 'Pharmacy Plan Name',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.rx}}</div>',
                width: '20%',
                enableHiding: false
            }, {
                name: 'den',
                displayName: 'Dental Plan Name',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.den}}</div>',
                width: '20%',
                enableHiding: false
            }, {
                name: 'vis',
                displayName: 'Vision Plan Name',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.vis}}</div>',
                enableHiding: false
            }],

            onRegisterApi: function(gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                    if (sortColumns.length === 0) {
                        paginationOptions.sort = null;
                    } else {
                        paginationOptions.sort = sortColumns[0].sort.direction;
                    }
                    loadData();
                });
                gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                    paginationOptions.pageNumber = newPage;
                    paginationOptions.pageSize = pageSize;
                    $scope.gridUnits.virtualizationThreshold = pageSize;
                    loadData();
                    if (!PaginationService.isGoToPageEnabled) {
                        $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                    }
                    PaginationService.setGoToPageEnabled(false);
                });
            }

        };

        function loadData() {

            $scope.gridUnits.data = [];
            var currentSearchQuery = FilterService.getFilterQueryDocGen($scope.gridApi, $scope.unitSearchQuery, $scope.gridUnits, $scope.selectedIdToObjsMap, 'TYPE:"unit"', $scope.matchCase);

            DocumentDataFactory.getUnits(currentSearchQuery).then(function(data) {
                $scope.gridUnits.data = data.response.docs;
                $scope.gridUnits.totalItems = data.response.numFound;
            });
        }

        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };

        $scope.isAnyFilters = function() {
            var length = 0;
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                length += selectedIdToObjs.objs.length;
            });
            if (length > 0) {
                return true;
            }
            return false;
        };
        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridUnits.paginationCurrentPage = 1;
                loadData();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };
        $scope.pageSizeChanged = function() {
            $scope.gridUnits.paginationCurrentPage = 1;
        };
        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };
        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };
        $scope.loaded = function() {
            loadData();
        };


        $scope.updateSelectIdToObjsMap = function(selectedId, objs) {
            // look if selectedId exists in the map
            var isFound = false;
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                if (selectedIdToObjs.selectedId === selectedId) {
                    selectedIdToObjs.objs = objs;
                    isFound = true;
                }
            });
            if (isFound === false) { // create new selectedId 
                $scope.selectedIdToObjsMap[$scope.selectedIdToObjsMap.length] = {
                    'selectedId': selectedId,
                    'objs': objs
                };
            }
        };

        //get the filtered data by selections
        $scope.queryData = function(selectedId, objs) {
            $scope.updateSelectIdToObjsMap(selectedId, objs);

            $scope.gridUnits.paginationCurrentPage = 1;
            loadData();
        };

    });