﻿'use strict';

angular.module('p2AdvanceApp')
  .controller('UnitsModalCtrl', function (
      $scope,
      $state,
      $modalInstance,
      ModalDialogFactory,
      modalTitle,
      parentState)
  {
      $scope.modalTitle = modalTitle;

      $scope.ok = function () {
          ModalDialogFactory.closeDialog($scope.selectedGridUnits);

          var selectedUnits = [];
          angular.forEach($scope.selectedGridUnits, function (unit) {
              var unitJSON = { 'id': unit.objectId, 'name': unit.name, 'documentName': unit.documentName, 'unitPlanYear': unit.unitPlanYear };
              selectedUnits.push(unitJSON);
          });

          $scope.$emit('unitsSelectedEvt', selectedUnits);

          $state.go($state.$current.parent.name);
      };

      $scope.cancel = function () {
          $modalInstance.dismiss('cancel');
          $state.go(parentState);
      };
  });
