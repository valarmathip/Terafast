﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('DocGeneratedCtrl', function ($scope, $state, $stateParams, DocumentDataFactory) {
        var pageType = $stateParams.generatorType;
        var idParam = $stateParams.documentId;
        var isMultiSrc = $stateParams.multiSource;
        var isEditingBatch = $stateParams.editingBatch;

        $scope.showBatchSubmittedMsg = function() {           
            $scope.batchName = $stateParams.batchName;

            if (pageType && pageType === 'batch') {
                return true;
            }
            else {
                if (idParam !== null) {
                    $scope.generatedDocumentId = idParam;
                }

                return false;
            }
        };

        $scope.backToPreviousPage = function () {
            if (pageType && pageType === 'batch') {
                if (!isEditingBatch) {
                    if (isMultiSrc) {
                        $state.go('home.media-management.generateDocument', { isMultiSource: true });
                    } else {
                        $state.go('home.media-management.generateDocument');
                    }
                } else {    //editing a batch
                    $state.go('home.media-management.listBatch');
                }
            } else {
                $state.go('home.media-management.documents');
            }
        };

        $scope.generatedDocs = DocumentDataFactory.getGeneratedDocJson();

    });