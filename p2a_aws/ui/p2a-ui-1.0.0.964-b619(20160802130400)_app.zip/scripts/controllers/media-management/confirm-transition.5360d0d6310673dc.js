﻿'use strict';

angular.module('p2AdvanceApp')
  .controller('transitionCtrl', function (
        $scope,
        $modalInstance,
        ModalDialogFactory)
    {

      $scope.confirmTransition = function (toConfirm) {
        ModalDialogFactory.closeDialog(toConfirm);
      };

  });
