'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: OfferingsAndPlansCtrl
 * @description
 * # OfferingsAndPlansCtrl
 * Controller of the p2AdvanceApp under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('OfferingsAndPlansCtrl', function (
        $scope,
        $state,
        parentState,
        $modalInstance,
        ModalDialogFactory) {

        $scope.selectedGridOfferings = [];
        $scope.selectedState = 'offering';
        $scope.selectedTitle = 'Select Offering';
        $scope.selectedGridOfferingPlans = [];

        $scope.loadState = function (url, param) {
            $state.go(url, param);
        };

        $scope.ok = function () {
            ModalDialogFactory.closeDialog($scope.selectedGridOfferingPlans);
            $scope.$emit('offeringPlansSelectedEvt', {'selectedGridOfferingPlans': $scope.selectedGridOfferingPlans, 'selectedGridOfferings': $scope.selectedGridOfferings });
            $state.go(parentState);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
            $state.go(parentState);
        };

    });