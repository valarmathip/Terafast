﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('DocsCtrl', function (
        $scope,
        $rootScope,
        $log,
        $filter,
        $stateParams,
        $state,
        $upload,
        $auth,
        $timeout,
        ENV,
        ConfirmationModalFactory,
        DocumentDataFactory,
        docFiltersMetaData,
        docFiltersProductPropertiesMetaData,
        filtersGroupsMeta,
        ModalDialogFactory,
        ENV_MEDIA_MANAGEMENT,
        CommonGrid,
        Common,
        uiGridConstants,
        PaginationService,
        FilterService,
        uiConfig,
        authorizedUserInfo) {
        PaginationService.setSortColumns(null);
        $scope.searchQuery = $stateParams.searchquery;
        $scope.checkList = {};
        $scope.currentPageSize = {};
        $scope.documents = [];
        //temporary object to store each filtering result
        $scope.filteredData = $scope.documents;
        //stores checkboxes selected attribute values, could come from multiple filters
        $scope.filterOptions = [];
        // stores multiple filter options
        $scope.selectedIdToObjsMap = [];
        $scope.selectedFilters = {};

        $scope.ENV_MEDIA_MANAGEMENT = ENV_MEDIA_MANAGEMENT;

        $scope.docFiltersProperties = docFiltersMetaData[0] !== null ? docFiltersMetaData[0].properties : [];
        $scope.docFiltersMetaDataProductProperties = docFiltersProductPropertiesMetaData;

        $scope.docFiltersProductProperties = $scope.docFiltersMetaDataProductProperties[0].properties;

        $scope.numProviderTiers = {
            'name': 'numProviderTiers',
            'enum': [
                1, 2, 3, 4, 5, 6, 7, 8
            ]
        };

        $scope.effectiveDate = {
            'name': 'effectiveDate',
            'enum': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
        };

        $scope.endDate = {
            'name': 'endDate',
            'enum': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
        };

        $scope.filtersGroups = filtersGroupsMeta;
        $scope.userInformation = authorizedUserInfo;

        // Media Management Document file formats and extensions
        var docFormats = [{ format: 'Word', extension: 'docx' }, { format: 'PDF', extension: 'pdf' }];

        var preSearchQuery = null;

        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };

        var gridDocumentsTpl = {};
        $scope.loadedDocList = [];
        $scope.docList = [];

        $scope.selectall = true;

        initializeDocArrays();

        //used by advanced grid
        gridDocumentsTpl = {
            'excessRows': 400,
            enableSorting: true,
            enableVerticalScrollbar: uiGridConstants.scrollbars.NEVER,
            rowHeight: 85,
            // pagination
            enablePaginationControls: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: 20,
            useExternalPagination: true,
            useExternalSorting: true,
            gridMenuShowHideColumns: false,
            menuShown: true,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                headerCellTemplate: 'views/media-management/template/document-list/icon-col-header.html',
                cellTemplate: 'views/media-management/template/document-list/icon-col.html',
                width: 70,
                enableHiding: false
            }, {
                name: 'docName',
                displayName: 'Document Name',
                cellTemplate: '<div class="ui-grid-cell-contents mm-ellipsis-and-full-name-style-group">' +
                    '<div class="col-cell-break">' +
                    '<div><span data-hraf-id="document-{{row.entity.objectId}}-name" class="ellipsis" ppm-long-name-tooltip="{{row.entity.docName}}">{{row.entity.docName}}</span></div>' +
                    '<div ng-show="angular.isObject(row.entity.effectiveDate) || angular.isObject(row.entity.endDate)">' +
                    '(Valid: {{row.entity.effectiveDate | amDateFormat:"' + ENV.dateFormat + '"}} - {{row.entity.endDate | amDateFormat:"' + ENV.dateFormat + '"}})</div>' +
                    '<div><span data-hraf-id="document-{{row.entity.objectId}}-status" ng-show="!angular.isUndefined(row.entity.documentStatus)" ng-class=grid.appScope.setTextClass(row.entity.documentStatus)>({{row.entity.documentStatus}}) </span>' +
                    '<span ng-show="!angular.isUndefined(row.entity.documentFormat) && row.entity.documentFormat === \'Word\'"><i class="fa fa-file-word-o icon-color-word" ></i></span>' +
                    '<span ng-show="!angular.isUndefined(row.entity.documentFormat) && row.entity.documentFormat === \'PDF\'"><i class="fa fa-file-pdf-o icon-color-pdf"></i></span></div>' +
                    '</div>' +
                    '<div class="text-right">' +
                    '<span data-hraf-id="document-{{row.entity.objectId}}-type" class="badge mm-badge">{{row.entity.documentType}}</span>' +
                    '</div>' +
                    '</div>',
                width: '50%',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: true
            }, {
                name: 'businessEntity',
                displayName: 'Document Class',
                cellTemplate: '<div data-hraf-id="document-{{row.entity.objectId}}-business-entity" class="ui-grid-cell-contents">{{row.entity.businessEntity}}</div>',
                type: 'string',
                width: '12%',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: true
            }, {
                name: 'createdBy',
                cellTemplate: '<div data-hraf-id="document-{{row.entity.objectId}}-created-by" class="ui-grid-cell-contents">{{row.entity.createdBy}}</div>',
                displayName: 'Generated By',
                width: '15%',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: true
            }, {
                name: 'lastModificationDate',
                displayName: 'Last modified',
                cellTemplate: '<div data-hraf-id="document-{{row.entity.objectId}}-last-modified" class="ui-grid-cell-contents">{{row.entity.lastModificationDate | amDateFormat:"' + ENV.dateFormat + '"}}</div>',
                type: 'string',
                enableColumnMenu: false,
                enableSorting: true,
                enableHiding: false
            }]
        };


        gridDocumentsTpl.onRegisterApi = function (gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.core.on.sortChanged($scope, function (grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                loadDocList();
            });
            gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                loadDocList();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
            gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
        };

        var setOrResetCheckList = function (row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };
        var setCheckList = function () {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };

        $scope.gridDocuments = gridDocumentsTpl;
        $scope.gridDocuments.data = 'docList';

        loadDocList();

        $scope.viewDoc = function (objectId, name, documentFormat) {
            Common.downloadAndNotify($scope.ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents/' + objectId + '/content', name, documentFormat);
        };

        $scope.setTextClass = function (value) {
            if (value === 'Final') {
                return {
                    'text-success': true
                };
            } else if (value === 'Outdated') {
                return {
                    'text-warning': true
                };
            } else if (value === 'Expired') {
                return {
                    'text-danger': true
                };
            } else {
                return {
                    'text-success': false
                };
            }
        };

        $scope.navPage = function ($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };

        $scope.selectCell = function (row) {
            $scope.checkList[row.entity.objectId] = PaginationService.selectCell($scope.gridApi, row, $scope.gridDocuments, $scope.checkList);
        };

        $scope.selectAllCell = function () {
            var selectAllCellVal = [];
            selectAllCellVal = PaginationService.selectAllCell($scope.selectAllChecker, $scope.gridApi, $scope.loadedDocList, $scope.checkList);
            $scope.checkList = selectAllCellVal[0];
            $scope.selectAllChecker = selectAllCellVal[1];
        };

        $scope.viewPages = function () {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.pageSizeChanged = function () {
            $scope.gridDocuments.paginationCurrentPage = 1;
        };
        $scope.loaded = function () {
            PaginationService.setSortColumns(null);
            loadDocList();
        };

        $scope.doSearch = function (keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridDocuments.paginationCurrentPage = 1;
                loadDocList();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };

        $scope.goToPage = function (keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };


        function loadDocList() {
            if ($scope.searchQuery === undefined) {
                var filterQuery = 'TYPE:"document"';
                var currentSearchQuery = FilterService.getFilterQuery($scope.gridApi, $scope.docSearchQuery, $scope.gridDocuments, $scope.selectedFilters, filterQuery, 'docName', $scope.matchCase) + PaginationService.getSortQuery();
                //Do not call API with same search query, which was in prvious API call
                if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                    return;
                }
                // Load data goes here
                $scope.loadedDocList = [];
                preSearchQuery = currentSearchQuery;

                DocumentDataFactory.getDocuments(encodeURI(currentSearchQuery)).then(function (data) {
                    angular.copy(data, $scope.documents);
                    $scope.gridDocuments.totalItems = data.response.numFound;
                    $scope.loadedDocList = FilterService.transformInput(data.response.docs);
                    /*
                    Jira Id: DOGVT-193,
                    Description: The looping used for initialize all customized grid selection.
                */
                    angular.forEach($scope.loadedDocList, function (row) {
                        $scope.checkList[row.objectId] = false;
                    });
                    // refresh data
                    $scope.docList = FilterService.filterAndrefresh($scope.loadedDocList, $scope.docList);
                    var attributesCollection = FilterService.updateFilterMeta(filtersNeedToBeUpdateWithDocList, $scope.loadedDocList, $scope.filtersGroups, 'document');
                    assignAttributes(attributesCollection);
                    //updateFilterMeta();

                    checkIfGridLoadedProperly();

                });
            }
        }

        var filtersNeedToBeUpdateWithDocList = {
            'createdBy': 'Generated by',
            'numProviderTiers': 'Number of Tiers'
        };

        function assignAttributes(attributesCollection) {
            angular.forEach(attributesCollection, function (attrListVal) {
                angular.forEach(attrListVal, function (attrCollVal, attrCollKey) {
                    $scope[attrCollKey] = attrCollVal;
                });
            });
        }

        //get passed data to filter the grid
        $scope.queryData = function (selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridDocuments);
            loadDocList();
        };

        var docArray = {};
        var docPlanArr = {};

        function initializeDocArrays() {
            docPlanArr = {
                '$scope.productAttributes': $scope.productAttributes,
                '$scope.productTypeAttributes': $scope.productTypeAttributes,
                '$scope.marketSegmentAttributes': $scope.marketSegmentAttributes,
                '$scope.productTiersAttributes': $scope.productTiersAttributes,
                '$scope.fundingArrangementAttributes': $scope.fundingArrangementAttributes
            };
            docArray = {
                '$scope.statusAttributes': $scope.statusAttributes,
                '$scope.docTypeAttributes': $scope.docTypeAttributes,
                '$scope.businessEntityAttributes': $scope.businessEntityAttributes,
                '$scope.effectiveDateAttributes': $scope.effectiveDateAttributes,
                '$scope.endDateAttributes': $scope.endDateAttributes,
                '$scope.formatAttributes': $scope.formatAttributes,
                '$scope.generatedByAttributes': $scope.generatedByAttributes
            };
            docPlanArr = Object.keys(docPlanArr);
            docArray = Object.keys(docArray);
            iterateDocArr();
        }

        function iterateDocArr() {
            var resultArr = [];
            angular.forEach(docPlanArr, function (arrval) {
                resultArr = assignPlanPropName(arrval);
            });

            angular.forEach(docArray, function (arrval) {
                resultArr = assignPropertyName(arrval);
            });
        }

        function assignPlanPropName(arrVal) {
            var propertyName = '';
            var attrName = '';
            var resultArr = [];
            switch (arrVal) {
                case '$scope.productAttributes':
                    propertyName = 'productClasses';
                    attrName = 'Products';
                    resultArr = pushProdAttrObjToDocArr(propertyName, attrName);
                    $scope.productAttributes = resultArr;
                    break;
                case '$scope.productTypeAttributes':
                    propertyName = 'productTypes';
                    attrName = 'Product Types';
                    resultArr = pushProdAttrObjToDocArr(propertyName, attrName);
                    $scope.productTypeAttributes = resultArr;
                    break;
                case '$scope.marketSegmentAttributes':
                    propertyName = 'marketSegments';
                    attrName = 'Market Segments';
                    resultArr = pushProdAttrObjToDocArr(propertyName, attrName);
                    $scope.marketSegmentAttributes = resultArr;
                    break;
                case '$scope.fundingArrangementAttributes':
                    propertyName = 'fundingArrangements';
                    attrName = 'Funding Arrangements';
                    resultArr = pushProdAttrObjToDocArr(propertyName, attrName);
                    $scope.fundingArrangementAttributes = resultArr;
                    break;
                case '$scope.productTiersAttributes':
                    propertyName = 'numProviderTiers';
                    attrName = 'Number of Tiers';
                    resultArr = pushProvidertiersObj(propertyName, attrName);
                    $scope.productTiersAttributes = resultArr;
                    break;
            }
            return resultArr;
        }

        function assignPropertyName(arrval) {
            var propertyName = '';
            var attrName = '';
            var resultArr = [];
            switch (arrval) {
                case '$scope.statusAttributes':
                    propertyName = 'documentStatus';
                    attrName = 'Status';
                    resultArr = pushAttrObjToDocArr(propertyName, attrName);
                    $scope.statusAttributes = resultArr;
                    break;
                case '$scope.docTypeAttributes':
                    propertyName = 'documentType';
                    attrName = 'Document Type';
                    resultArr = pushAttrObjToDocArr(propertyName, attrName);
                    $scope.docTypeAttributes = resultArr;
                    break;
                case '$scope.businessEntityAttributes':
                    propertyName = 'businessEntity';
                    attrName = 'Business Entity';
                    resultArr = pushAttrObjToDocArr(propertyName, attrName);
                    $scope.businessEntityAttributes = resultArr;
                    break;
                case '$scope.effectiveDateAttributes':
                    propertyName = 'effectiveDate';
                    attrName = 'Effective Date';
                    resultArr = pushEffectiveDateObj(propertyName, attrName);
                    $scope.effectiveDateAttributes = resultArr;
                    break;
                case '$scope.endDateAttributes':
                    propertyName = 'endDate';
                    attrName = 'End Date';
                    resultArr = pushEndDateObj(propertyName, attrName);
                    $scope.endDateAttributes = resultArr;
                    break;
                case '$scope.formatAttributes':
                    propertyName = 'documentFormat';
                    attrName = 'Format';
                    resultArr = pushAttrObjToDocArr(propertyName, attrName);
                    $scope.formatAttributes = resultArr;
                    break;
                case '$scope.generatedByAttributes':
                    propertyName = 'createdBy';
                    attrName = 'Generated By';
                    resultArr = pushAttrObjToDocOwnerArr(propertyName, attrName);
                    $scope.generatedByAttributes = resultArr;
                    break;
            }
            return resultArr;
        }

        function pushAttrObjToDocArr(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.docFiltersProperties[propertyName]['enum'], function (arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.docFiltersProperties[propertyName]['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushProdAttrObjToDocArr(propertyName, attrName) {
            var objArr = [];

            if (angular.isDefined($scope.docFiltersProductProperties[propertyName]['items']['enum'])) {

                angular.forEach($scope.docFiltersProductProperties[propertyName]['items']['enum'], function (arrVal) {
                    var attrObj = attrName + arrVal;
                    attrObj = {};
                    attrObj['AttributeId'] = $scope.docFiltersProductProperties[propertyName]['name'];
                    attrObj['AttributeName'] = attrName;
                    attrObj['AttributeValue'] = arrVal;
                    attrObj['DisplayValue'] = arrVal;
                    objArr.push(attrObj);
                });
            }
            return objArr;
        }

        function pushProvidertiersObj(propertyName, attrName) {
            var objArr = [];
            var count = 0;
            angular.forEach($scope.numProviderTiers['enum'], function (arrVal) {
                count++;
                var attrObj = attrName + arrVal;
                attrObj = {};
                if (count <= 4) {
                    attrObj['AttributeId'] = $scope.numProviderTiers['name'];
                    attrObj['AttributeName'] = attrName;
                    attrObj['AttributeValue'] = compareNumProvidertiersValues(arrVal);
                    attrObj['DisplayValue'] = compareNumProvidertiersValues(arrVal);
                    objArr.push(attrObj);
                }
            });
            return objArr;
        }

        function pushEffectiveDateObj(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.effectiveDate['enum'], function (arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.effectiveDate['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushEndDateObj(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.endDate['enum'], function (arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.endDate['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushAttrObjToDocOwnerArr(propertyName, attrName) {
            var objArr = [];
            var arrVal = 'Me';
            var attrObj = attrName + arrVal;
            attrObj = {};
            attrObj['AttributeId'] = $scope.docFiltersProperties[propertyName]['name'];
            attrObj['AttributeName'] = attrName;
            attrObj['AttributeValue'] = $scope.userInformation.data.user.email;
            attrObj['DisplayValue'] = arrVal;
            objArr.push(attrObj);
            return objArr;
        }

        function compareNumProvidertiersValues(arrVal) {
            if (arrVal >= 4) {
                arrVal = '>=4';
            }
            return arrVal;
        }


        //Check is the grid is refreshed with the latest document loaded, if not, do the hack
        function checkIfGridLoadedProperly() {
            var previouslyGeneratedDocs = DocumentDataFactory.getGeneratedDocJson();
            var docsExistInGrid = [];
            var ignoreDocExistInGrid = false; //flag to mark if it is from document generated page

            if (angular.isObject(previouslyGeneratedDocs) && previouslyGeneratedDocs.length > 0) {
                // could have more than one document generated, like "Word" and "PDF"
                angular.forEach(previouslyGeneratedDocs, function (doc) {
                    for (var j = 0; j < $scope.loadedDocList.length; j++) {
                        if ($scope.loadedDocList[j].objectId === doc.id) {
                            docsExistInGrid.push({
                                'id': doc.id,
                                'name': doc.name
                            });
                        }
                    }
                });
            } else {
                ignoreDocExistInGrid = true;
            }

            // if the newly added document hasn't got pulled in by Solr yet we need to add it by the way as shown below
            if (!ignoreDocExistInGrid && previouslyGeneratedDocs.length > 0) {
                //var identicalGridIds = [];
                var semiColon = '';
                var docIdWithoutSemiColon = '';

                angular.forEach(previouslyGeneratedDocs, function (doc) {

                    semiColon = doc.id.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end

                    if (semiColon > -1) {
                        docIdWithoutSemiColon = doc.id.slice(0, semiColon);
                    } else {
                        docIdWithoutSemiColon = doc.id;
                    }

                    if (docsExistInGrid.length > 0) {
                        angular.forEach(docsExistInGrid, function (document) {
                            if (doc.id !== document.id) { //could have one exists and one doesn't exist in the grid, only add the one doesn't exist
                                if (!isDocIdExist(docIdWithoutSemiColon)) {
                                    injectNewlyAddedDoc(doc.id);
                                }
                            }
                        });
                    } else {
                        // Checks if the item is already in the document  list grid --- (Just to be sure, it shouldn't be anyways!)
                        if (!isDocIdExist(docIdWithoutSemiColon)) {
                            injectNewlyAddedDoc(doc.id);
                        }
                    }

                    /*
                    // check if duplicated items in the document list grid (PONHR-1175, caused by the fix of PONHR-1125)
                    angular.forEach($scope.loadedDocList, function(doc) {
                        if (doc.objectId === docIdWithoutSemiColon) {
                            identicalGridIds.push(doc.objectId);
                        }
                    });

                    // remove the duplicated one at the top of list if it exists
                    if (identicalGridIds.length > 0) {
                        var idx = 0;

                        for (var i = 0; i < identicalGridIds.length; i++) {
                            idx = $scope.loadedDocList.indexOf(identicalGridIds[i]);

                            $scope.loadedDocList.splice(idx, 1); // remove the duplicated item at the right index
                            $scope.docList.splice(idx, 1);
                        }
                    }
                    */

                });

            }
        }

        function injectNewlyAddedDoc(docId) {
            var newlyAddedDoc = {};
            DocumentDataFactory.getDocumentById(docId)
                .success(function (item) {
                    newlyAddedDoc = {
                        'objectId': item.objectId,
                        'docName': item.docName,
                        'businessEntity': item.businessEntity,
                        'creationDate': item.creationDate,
                        'createdBy': item.createdBy,
                        'author': item.author,
                        'content': item.content,
                        'documentFormat': item.documentFormat,
                        'documentStatus': item.documentStatus,
                        'docTemplate': {},
                        'documentType': item.documentType,
                        'effectiveDates': item.effectiveDates,
                        'endDate': item.endDate,
                        'fundingArrangements': item.fundingArrangements,
                        'globalCostShare': item.globalCostShare,
                        'isUnit': item.isUnit,
                        'lastModificationDate': item.lastModificationDate,
                        'lastModifiedBy': item.lastModifiedBy,
                        'lastThumbnailModification': item.lastThumbnailModification,
                        'marketSegments': item.marketSegments,
                        'numProviderTiers': item.numProviderTiers,
                        'numSources': item.numSources,
                        'objectType': item.objectType,
                        'productClasses': item.productClasses,
                        'productTypes': item.productTypes,
                        'versionLabel': item.versionLabel
                    };

                    $scope.docList = FilterService.filterAndrefresh($scope.loadedDocList, $scope.docList);

                    $scope.loadedDocList.unshift(newlyAddedDoc);
                    $scope.docList.unshift(newlyAddedDoc);

                    DocumentDataFactory.setGeneratedDocJson(null);
                })
                .error(function () {
                    $scope.gridDocuments.data = 'docList';
                });
        }
        /* Upload Documents */
        $scope.uploader = {
            isHTML5: true,
            progress: 0
        };

        /* Assign attributes dialog */
        $scope.doUpload = function () {
            var nameExists = false;
            $scope.messageStatus = null;
            $scope.files = $scope.uploader.files;

            if ($scope.files && $scope.files.length) {

                // Check if the files are Media Management Documents
                var fileNames = '';
                var notMMDNames = '';
                var num = 0;


                angular.forEach($scope.files, function (file) {
                    var extension = file.name.replace(/^.*\./, '');
                    angular.forEach(docFormats, function (doc) {
                        if (doc.extension === extension) {
                            file.format = doc.format;
                        }
                    });

                    if (file.format) {
                        if (fileNames !== '') { fileNames += ', '; }
                        fileNames += file.name;
                    } else {
                        if (notMMDNames !== '') { notMMDNames += ', '; }
                        notMMDNames += file.name;
                        ++num;
                    }
                });

                if (notMMDNames.length > 0) {
                    var message = 'File';
                    message += num > 1 ? 's ' : ' ';
                    message += '\"' + notMMDNames + '\"';
                    message += num > 1 ? ' are' : ' is';
                    message += ' not ';
                    message += num === 1 ? 'a ' : '';
                    message += 'Media Management Document';
                    message += num > 1 ? 's' : '';
                    message += '.<br/>Please, select  Media Management Document file';
                    message += num > 1 ? 's' : '';
                    message += '!';
                    ConfirmationModalFactory.open('Document Uploader', message, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    return;
                }

                var dialogOptions = {
                    templateUrl: 'views/media-management/assign-properties.html',
                    controller: 'AssignPropertiesCtrl',
                    size: 'lg',
                    backdrop: false,
                    resolve: {
                        defineDocumentFieldsMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                            return DocumentDataFactory.getDocumentMetadata();
                        }],
                        documentProductPropertiesMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                            return DocumentDataFactory.defineTemplateProductProperties();   // get "types/aspectDefinitions"
                        }],
                        numProviderTiers: function () {
                            return $scope.numProviderTiers;
                        },
                        isMultiSourceDoc: function () {
                            return $scope.files.length > 1;
                        },
                        nameExists: function () {
                            return nameExists;
                        },
                        documentNames: function () {
                            return fileNames;
                        }
                    }
                };

                if ($scope.files.length === 1) {
                    DocumentDataFactory.getDocumentByName($scope.files[0].name)  //check if the name is unique
                        .success(function (result) {
                            if (result.response.docs.length > 0) {
                                nameExists = true;
                            }
                            showAssignAttributesDialog(dialogOptions);
                        })
                        .error(function (response) {
                            $log.error(response);
                        });
                } else {
                    showAssignAttributesDialog(dialogOptions);
                }

            }
        };

        function showAssignAttributesDialog(dialogOptions) {
            ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                if (result != null) {
                    result.isClientSourced = true;
                    result.isUnit = false;
                    result.numSources = 0;
                    if (result.numProviderTiers) {
                        result.numProviderTiers = +result.numProviderTiers;
                    }
                    uploadFiles(result);
                }
            });
        }

        /* Close upload message */
        $scope.closeMessage = function () {
            $scope.messageStatus = null;
        };

        /* Show details dialog box */
        $scope.showDetails = function () {
            var dialogOptions = {
                templateUrl: 'views/media-management/upload-results.html',
                controller: 'UploadResultsCtrl',
                size: 'md',
                backdrop: false,
                resolve: {
                    files: function () {
                        return $scope.files;
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions);
        };

        /* Iterate through files */
        function uploadFiles(properties) {

            /* Initialize the first time */
            if (properties) {
                $scope.docProperties = properties;
                $scope.totalNumber = $scope.files.length;
                $scope.currentFile = 0;
                $scope.docProperties.docName = $scope.totalNumber === 1 ? properties.docName + '.' + $scope.files[0].name.replace(/^.*\./, '') : $scope.files[0].name;
                $scope.files[0].docName = $scope.docProperties.docName;
                showMessage('process', 'uploading ' + ($scope.currentFile + 1) + ' of ' + $scope.files.length + '.....');

            }
            else {
                if (++$scope.currentFile === $scope.totalNumber)  // check if all files are uploaded
                {
                    var uploadedNumber = 0;
                    var total = $scope.files.length;
                    angular.forEach($scope.files, function (file) {
                        if (file.isUploaded) {
                            ++uploadedNumber;
                        }
                    });
                    if (uploadedNumber === $scope.files.length) {
                        showMessage('success', total + ' of ' + total + ' Uploaded');
                    } else if (uploadedNumber === 0) {
                        showMessage('failed', total + ' of ' + total + ' Failed');
                    } else {
                        showMessage('partially', (total - uploadedNumber) + ' of ' + total + ' Failed');
                    }
                    return;
                }
                else {
                    $scope.uploadMessage = 'uploading ' + ($scope.currentFile + 1) + ' of ' + $scope.files.length + '.....';
                    $scope.docProperties.docName = $scope.files[$scope.currentFile].name;
                    $scope.files[$scope.currentFile].docName = $scope.files[$scope.currentFile].name;
                }
            }
            $scope.docProperties.documentFormat = $scope.files[$scope.currentFile].format;
            checkName($scope.files[$scope.currentFile], $scope.docProperties);
        }

        /* Check name */
        function checkName(item, properties) {

            DocumentDataFactory.uniqueNameCheck(item.docName, item.format)
                .success(function (result) {
                    item.uploadMessage = result;
                    uploadFile(item, properties);
                })
                .error(function (response) {
                    item.isUploaded = false;
                    item.uploadMessage = 'Error of checking name! Status: ' + response.httpStatus;
                    $log.error(response);
                    uploadFiles();
                });
        }

        /* Upload file */
        function uploadFile(item, properties) {

            var file = [];
            file.push(item);

            var metadata = JSON.stringify({
                'properties': properties
            });

            file.push(new Blob([metadata], {
                type: 'application/json'
            }));
            $upload.upload({
                url: $scope.ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents',
                headers: {
                    'Content-Type': undefined,
                    'Authorization': $auth.getApiToken()
                },

                fileFormDataName: ['file', 'metadata'],
                file: file
            }).success(function (data, status) {

                if (status === uiConfig.OK || status === uiConfig.Created) {
                    item.isUploaded = true;
                    item.uploadMessage += ' Uploaded successfully!';
                    var objectId = null;
                    if (data.indexOf(';') > 0) {
                        objectId = data.split(';')[0];
                    } else {
                        objectId = data;
                    }
                } else {
                    item.isUploaded = false;
                    item.uploadMessage += ' Error of uploading! Status: ' + status;
                }
                uploadFiles();
            })
              .error(function (response) {
                  item.isUploaded = false;
                  item.uploadMessage += ' Error of uploading! Status: ' + response.httpStatus;
                  $log.error(response);
                  uploadFiles();
              });
        }

        /* Download Documents */
        var selectedDocs = [];
        $scope.download = function () {
            if (selectedDocs.length > 0) {
                var docIds = selectedDocs.join(',');
                downloadDocuments(docIds);
            } else {
                ConfirmationModalFactory.open('Document Download', 'Please select documents to download.', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
            }
        };

        /* select/unselect document */
        $scope.selectDoc = function (objectId) {

            var ctrl = document.getElementById('document-' + objectId + '-checkbox');
            if (ctrl) {
                if (ctrl.checked) {
                    selectedDocs.push(objectId);
                } else {
                    var index = selectedDocs.indexOf(objectId);
                    if (index > -1) {
                        selectedDocs.splice(index, 1);
                    }
                }
            }
        };

        /* Downloading documents... */
        function downloadDocuments(docIds) {
            DocumentDataFactory.downloadDocuments(docIds)
                .success(function (data, status, headers) {
                    if (status === uiConfig.OK) {
                        var file = new Blob([data]);
                        var content = headers()['content-disposition'];
                        var name = content.split('=')[1];
                        showMessage('process', 'downloading  ' + name + '.....', 5000);
                        saveAs(file, name);
                    } else {
                        showMessage('failed', 'Error of downloading! Status: ' + status, 5000);
                    }
                })
                .error(function (response) {
                    $log.error(response);
                });
        }
        // Show message
        function showMessage(status, message, delay) {
            $scope.messageStatus = status;
            $scope.uploadMessage = message;
            if (delay) {
                setTimeout(function () {
                    $timeout(function () {
                        $scope.$apply(function () {
                            $scope.messageStatus = null;
                        });
                    });
                }, delay);
            }
        }

        function isDocIdExist(docIdWithoutSemiColon) {

            // check if duplicated items in the document list grid (PONHR-1175, caused by the fix of PONHR-1125)
            angular.forEach($scope.loadedDocList, function (doc) {
                if (doc.objectId === docIdWithoutSemiColon) {
                    return true;
                }
            });
            return false;
        }

    });