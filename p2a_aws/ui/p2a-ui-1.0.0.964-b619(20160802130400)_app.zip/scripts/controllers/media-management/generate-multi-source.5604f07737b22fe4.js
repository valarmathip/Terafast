﻿'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: GenerateDocMultiSourceCtrl
 * @description
 * # GenerateDocMultiSourceCtrl
 * Controller of Multi Source Document Generation under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('GenerateDocMultiSourceCtrl',
        function ($scope,
            $rootScope,
            $log,
            $state,
            $stateParams,
            $filter,
            moment,
            ModalDialogFactory,
            DocumentDataFactory,
            DocumentBatchHelper,
            OfferingAccountService,
            FilterService,
            PaginationService,
            FileSelectFactory,
            ENV) {

            $rootScope.$on('offeringPlansSelectedEvt', function (event, data) {
                if (data != null) {
                    if (data.selectedGridOfferingPlans && data.selectedGridOfferingPlans.length > 0) {
                        $scope.docDefinition.selectedOfferingPlans = data.selectedGridOfferingPlans;
                    }

                    if (data.selectedGridOfferings && data.selectedGridOfferings.length > 0) {
                        $scope.docDefinition.selectedOfferings = data.selectedGridOfferings;
                    }
                }

                var tempSources = [];

                // if previous selected plans, clean up all plans from the selectedSources grid
                if ($scope.docDefinition.selectedPlans && $scope.docDefinition.selectedPlans.length > 0) {
                    /* clean up any existing selectedSources in the grid, in this case is plans */
                    deleteRecursively($scope.docDefinition.selectedSources, 'plan');
                    $scope.docDefinition.selectedPlans = null;
                }
                
                angular.forEach($scope.docDefinition.selectedOfferingPlans, function (plan) {
                    var planJson = { 'objectId': plan.objectId, 'name': plan.name, 'sourceType': 'Plan', 'sourceIndicator': '' };
                    var uniqueCount = 0;

                    if ($scope.docDefinition.selectedSources && $scope.docDefinition.selectedSources.length > 0) {
                        for (var i = 0, j = $scope.docDefinition.selectedSources.length; i < j; i++) {
                            if ($scope.docDefinition.selectedSources[i].objectId !== planJson.objectId) {
                                uniqueCount++;
                            }
                        }

                        if (uniqueCount === $scope.docDefinition.selectedSources.length) {
                            tempSources.push(planJson); //make sure we add unique value
                        }
                    }
                    else {
                        tempSources.push(planJson);
                    }
                });

                angular.forEach(tempSources, function (source) {
                    $scope.docDefinition.selectedSources.push(source);
                });

                $scope.gridSelectedSources.data = $scope.docDefinition.selectedSources;

            });
            /* this is to detect editing multi source batch job grid part of data loaded */
            $rootScope.$on('selectSourcesFromBatchJob', function (event, data) {
                if (data != null) {
                    $scope.gridSelectedSources.data = data.selectedSources;
                }
            });

            var addAccountsToSelectedSources = function () {
                var dialogOptions = {
                    templateUrl: 'views/media-management/offering-account-list.html',
                    controller: 'OfferingAccountListCtrl',
                    size: 'lg',
                    backdrop: false,
                    resolve: {
                        accountSchema: ['OfferingAccountService', function (OfferingAccountService) {
                            return OfferingAccountService.getAccountSchema();
                        }],
                        accountListData: ['OfferingAccountService', function (OfferingAccountService) {
                            var associationExpansionLevel = -1;
                            var searchQuery = 'TYPE:"account"&start=0&rows=20&sort=accountName asc&properties=objectId, name, groups, groupParentId, accountName, renewalStartDate, renewalEndDate, accountStatus, marketSegments, accountofferings, offerings';

                            return OfferingAccountService.getAccountListViaSearchApi(searchQuery, associationExpansionLevel);
                        }],
                        selectedOfferingId: function () {
                            return $scope.docDefinition.selectedOfferings && $scope.docDefinition.selectedOfferings[0] ? $scope.docDefinition.selectedOfferings[0].objectId : null;
                        },
                        authorizedUserInfo: ['$auth', function ($auth) {
                            return $auth.requestUserInfo();
                        }]
                    }
                };

                ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                    if (result) {
                        $scope.docDefinition.selectedAccounts = result;   // only one account can be selected, and it can also be group or sub group

                        var tempSources = [];
                        /*jshint maxcomplexity:11*/
                        angular.forEach($scope.docDefinition.selectedAccounts, function (account) {
                            var accountJson = {};
                            var groupJson = {};

                            if (account.objectType === 'account') {
                                accountJson = { 'objectId': account.objectId, 'name': account.accountName, 'sourceIndicator': '', 'sourceType': 'Account' };

                                var uniqueCount = 0;

                                if ($scope.docDefinition.selectedSources && $scope.docDefinition.selectedSources.length > 0) {
                                    for (var i = 0, j = $scope.docDefinition.selectedSources.length; i < j; i++) {
                                        if ($scope.docDefinition.selectedSources[i].objectId !== accountJson.objectId) {
                                            uniqueCount++;
                                        }
                                    }

                                    if (uniqueCount === $scope.docDefinition.selectedSources.length) {
                                        tempSources.push(accountJson); //make sure we add unique value
                                    }
                                }
                                else {
                                    tempSources.push(accountJson);
                                }

                                angular.forEach(tempSources, function (source) {
                                    $scope.docDefinition.selectedSources.push(source);
                                });

                                $scope.gridSelectedSources.data = $scope.docDefinition.selectedSources;
                            }
                            else if (account.objectType === 'group') {
                                /* In MarkLogic data model we don't have "Group" as sourceType, but Doc Gen backend takes "Group" to differ "Account" from "Group" */
                                groupJson = { 'objectId': account.objectId, 'name': account.accountName, 'sourceIndicator': '', 'sourceType': 'Group' };
                                accountJson = { 'objectId': account.objectIds[0], 'name': account.pathDsp[0], 'sourceIndicator': '', 'sourceType': 'Account' };

                                var uniCount = 0;

                                if ($scope.docDefinition.selectedSources && $scope.docDefinition.selectedSources.length > 0) {
                                    for (var m = 0, n = $scope.docDefinition.selectedSources.length; m < n; m++) {
                                        if ($scope.docDefinition.selectedSources[m].objectId !== groupJson.objectId) {
                                            uniCount++;
                                        }
                                    }

                                    if (uniCount === $scope.docDefinition.selectedSources.length) {
                                        tempSources.push(accountJson); //make sure we add unique value
                                        tempSources.push(groupJson);
                                    }
                                }
                                else {
                                    tempSources.push(accountJson);
                                    tempSources.push(groupJson);
                                }

                                angular.forEach(tempSources, function (source) {
                                    $scope.docDefinition.selectedSources.push(source);
                                });

                                $scope.gridSelectedSources.data = $scope.docDefinition.selectedSources;
                            }

                        });
                    }
                });
            };

            var deleteRecursively = function (selectedList, type) {
                var index = 0;
                var selection = selectedList;
                var typeMatched = false;

                for (var i = 0, j = selection.length; i < j; i++) {
                    if (selection[i].sourceType && selection[i].sourceType.toLowerCase() === type.toLowerCase()) {
                        index = i;
                        typeMatched = true;
                        break;
                    }
                }

                if (index > -1 && typeMatched) {
                    selection.splice(index, 1);

                    if (selection && selection.length > 0) {
                        deleteRecursively(selection, type);
                    }
                }
            };

            var itemRemovedFromGrid = function () {
                var pageSize = $scope.gridSelectedSources.paginationPageSize;
                var totalItems = $scope.docDefinition.selectedSources.length;

                if (totalItems % pageSize === 0) {  //if all items on the current page removed, go to previous page
                    if ($scope.gridSelectedSources.paginationCurrentPage > 1) {
                        $scope.gridSelectedSources.paginationCurrentPage -= 1;
                    }
                }
            };

            $scope.$parent.invalidMultiSourceTags = [];
            $scope.$parent.invalidMultiSourceTagsJson = [];

            $scope.setMultiSourceIndicator = function (id, indicator, isBase, isRequired, rowSourceIndicator) {
                for (var i = 0, j = $scope.docDefinition.selectedSources.length; i < j; i++) {
                    if ($scope.docDefinition.selectedSources[i].objectId === id) {
                        $scope.docDefinition.selectedSources[i].isBaseSource = isBase;
                        $scope.docDefinition.selectedSources[i].isRequiredSource = isRequired;

                        $scope.$parent.documentValidationNeeded = false;
                    }
                    else {
                        if ($scope.docDefinition.selectedSources[i].sourceIndicator === indicator) {
                            if ($scope.$parent.invalidMultiSourceTags.indexOf(id) === -1) {
                                $scope.$parent.invalidMultiSourceTags.push(id);

                                var json = { 'objectId': id, 'sourceIndicator': indicator };
                                $scope.$parent.invalidMultiSourceTagsJson.push(json);
                            }
                        }
                    }
                }

                var idx = $scope.$parent.invalidMultiSourceTags.indexOf(id);

                if (idx > -1) {
                    if (rowSourceIndicator === null) {
                        $scope.$parent.invalidMultiSourceTags.splice(idx, 1);
                        $scope.$parent.invalidMultiSourceTagsJson.splice(idx, 1);
                    }
                    else if (rowSourceIndicator !== $scope.$parent.invalidMultiSourceTagsJson[idx].sourceIndicator) {
                        $scope.$parent.invalidMultiSourceTags.splice(idx, 1);
                        $scope.$parent.invalidMultiSourceTagsJson.splice(idx, 1);
                    }
                }

            };

            $scope.verifyMultiSourceIndicator = function (id) {
                var isValid = true;

                for (var i = 0, j = $scope.$parent.invalidMultiSourceTags.length; i < j; i++) {
                    if ($scope.$parent.invalidMultiSourceTags[i] === id) {
                        isValid = false;
                        break;
                    } 
                }

                return isValid;
            };

            $scope.showPlanOrOfferingRelated = function (sourceType) {
                if (sourceType.toLowerCase() === 'plan') {
                    if ($scope.docDefinition.selectedMultiSourceTypes[0] === 'Plan') {
                        $scope.docDefinition.selectedMultiSourceTypes[3] = '';
                    }
                }
                else if (sourceType.toLowerCase() === 'offering') {
                    if ($scope.docDefinition.selectedMultiSourceTypes[3] === 'Offering') {
                        $scope.docDefinition.selectedMultiSourceTypes[0] = '';
                    }
                }
            };

            $scope.clearPlans = function (property) {
                if (!property || property === '') {  //clear plans under multi source view
                    if ($scope.docDefinition.selectedPlans && $scope.docDefinition.selectedPlans.length > 0) {
                        $scope.docDefinition.selectedPlans = null;
                        deleteRecursively($scope.docDefinition.selectedSources, 'plan');
                        itemRemovedFromGrid();  //refresh the grid 'cuz this grid is not data bind to search query
                    }

                } else {  //clear one of the plans under single source view
                    var idx = -1;

                    angular.forEach($scope.docDefinition.selectedPlans, function (plan) {
                        if (plan.name === property) {
                            idx = $scope.docDefinition.selectedPlans.indexOf(plan);
                        }
                    });

                    if (idx > -1) {
                        $scope.docDefinition.selectedPlans.splice(idx, 1);
                    }
                }
            };

            $scope.clearOfferings = function () {
                $scope.docDefinition.selectedOfferings = null;
                $scope.docDefinition.selectedOfferingPlans = null;
                $scope.docDefinition.selectedAccounts = null;
                $scope.docDefinition.selectedSources = [];
            };

            $scope.clearAccounts = function () {
                if ($scope.docDefinition.selectedAccounts && $scope.docDefinition.selectedAccounts.length > 0) {
                    $scope.docDefinition.selectedAccounts = null;
                    deleteRecursively($scope.docDefinition.selectedSources, 'account');
                    deleteRecursively($scope.docDefinition.selectedSources, 'group');
                    itemRemovedFromGrid();  //refresh the grid 'cuz this grid is not data bind to search query
                }
            };

            // when call File Selector to select plans, it doesn't return the whole plan JSON from CRUD api, it only returns a couple of properties like id, name, etc.
            $scope.browseFiles = function (entity, fromMultiSource) {
                var selectorType = 'multiple';

                //if we're in batch job editing mode, only allow select one plan from modal dialog 'cuz each row contains only one plan for single source
                if ($scope.currentBatch && $scope.currentBatch.currentBatchJobInEditing) {
                    selectorType = 'single';
                }

                if (entity.toLowerCase() === 'plan') {
                    FileSelectFactory.openModalDialog(entity, selectorType).then(function (result) {
                        var jsonObj = JSON.parse(result);              
                        $scope.docDefinition.selectedPlans = [];

                        angular.forEach(jsonObj.selectedObjects, function (obj) {
                            var planJSON = { 'objectId': obj.objectId, 'name': obj.name, 'planYear': obj.planYear };
                            $scope.docDefinition.selectedPlans.push(planJSON);
                        });

                        if (fromMultiSource) {                                
                            var tempSources = [];
                            // if previous selected Offering, clean up all Offering plans from the selectedSources grid
                            if ($scope.docDefinition.selectedOfferings && $scope.docDefinition.selectedOfferings.length > 0) {
                                /* clean up any existing selectedSources in the grid, in this case is plans */
                                deleteRecursively($scope.docDefinition.selectedSources, 'plan');

                                $scope.docDefinition.selectedOfferings = null;
                            }

                            angular.forEach($scope.docDefinition.selectedPlans, function (plan) {
                                var planJson = { 'objectId': plan.objectId, 'name': plan.name, 'sourceIndicator': '', 'sourceType': 'Plan' };
                                var uniqueCount = 0;

                                if ($scope.docDefinition.selectedSources && $scope.docDefinition.selectedSources.length > 0) {
                                    for (var i = 0, j = $scope.docDefinition.selectedSources.length; i < j; i++) {
                                        if ($scope.docDefinition.selectedSources[i].objectId !== planJson.objectId) {
                                            uniqueCount++;
                                        }
                                    }

                                    if (uniqueCount === $scope.docDefinition.selectedSources.length) {
                                        tempSources.push(planJson); //make sure we add unique value
                                    }
                                }
                                else {
                                    tempSources.push(planJson);
                                }
                            });

                            angular.forEach(tempSources, function (source) {
                                $scope.docDefinition.selectedSources.push(source);
                            });

                            $scope.gridSelectedSources.data = $scope.docDefinition.selectedSources;
                        }
                    });
                }
                else if (entity.toLowerCase() === 'offering') {
                    var selectedAccounts = $scope.docDefinition.selectedAccounts;

                    if (selectedAccounts && selectedAccounts.length > 0) {
                        $state.go('home.media-management.generateDocument.multiSource.offeringsAndPlans',
                            { accountId: selectedAccounts[0].objectId, accountType: selectedAccounts[0].objectType });
                    } else {
                        if ($scope.docDefinition.selectedOfferings && $scope.docDefinition.selectedOfferings.length > 0) {
                            $state.go('home.media-management.generateDocument.multiSource.offeringsAndPlans.plans', { 'offeringId': $scope.docDefinition.selectedOfferings[0].objectId });
                        } else {
                            $state.go('home.media-management.generateDocument.multiSource.offeringsAndPlans');
                        }
                    }
                }
                else if (entity.toLowerCase() === 'account') {
                    addAccountsToSelectedSources();                  
                }
            };
          
            $scope.showPlanMsgError = function () {
                return ($scope.docDefinition.selectedPlans === null || $scope.docDefinition.selectedPlans.length === 0) &&
                       ($scope.$parent.documentValidationNeeded === true || $scope.addToBatchButtonClicked === true || $scope.saveBatchButtonClicked === true);
            };

            $scope.showOfferingMsgError = function () {
                return ($scope.docDefinition.selectedOfferings === null || $scope.docDefinition.selectedOfferings.length === 0) &&
                       ($scope.$parent.documentValidationNeeded === true || $scope.addToBatchButtonClicked === true || $scope.saveBatchButtonClicked === true);
            };

            $scope.showAccountMsgError = function () {
                return $scope.docDefinition.selectedMultiSourceTypes[4] === 'Account' && $scope.$parent.documentValidationNeeded &&
                    ($scope.docDefinition.selectedAccounts === null || $scope.docDefinition.selectedAccounts.length === 0);
            };

            $scope.showTemplateSourceMsgError = function () {
                return DocumentBatchHelper.validateSourceIndicators($scope.docDefinition, $scope.documentValidationNeeded) === false;
            };

            $scope.getTemplateSourceErrorMsg = function () {
                return DocumentDataFactory.getTemplateSourceErrorMsg();
            };
           
            var paginationOptions = {
                pageNumber: 1,
                pageSize: 20,
                sort: null
            };

            // pagination
            $scope.navPage = function ($event, delta) {
                PaginationService.navPage($event, delta, $scope.gridApi);
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            };
            // pagination
            $scope.viewPages = function () {
                var ps = [];
                ps = PaginationService.viewPages($scope.gridApi, ps);
                return ps;
            };
            // pagination
            $scope.pageSizeChanged = function () {
                $scope.gridBatchDocs.paginationCurrentPage = 1;
            };
            // pagination
            $scope.goToPage = function (keyEvent, pageNumberObject) {
                PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
            };

            $scope.gridSelectedSources = {
                'excessRows': 400,
                data: $scope.docDefinition.selectedSources,
                totalItems: $scope.docDefinition.selectedSources.length,
                enableHorizontalScrollbar: 0,  //never show the horizontal scroll bar
                enableVerticalScrollbar: 2,
                rowHeight: 100,
                multiSelect: false,
                enableSorting: true,
                enablePaginationControls: false,
                enableRowSelection: false,
                enableRowHeaderSelection: false,
                paginationPageSizes: ENV.settings.paginationPageSizes,
                paginationPageSize: 20,
                useExternalPagination: false,
                useExternalSorting: false,
                columnDefs: [
                    {
                        name: 'name',
                        displayName: 'Source Name',
                        cellTemplate: 'views/media-management/template/generate-document/source-name-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: false,
                        width: '45%'
                    },
                    {
                        name: 'sourceType',
                        displayName: 'Source Type',
                        cellTemplate: 'views/media-management/template/generate-document/source-type-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '10%'
                    },
                    {
                        name: 'sourceIndicator',
                        displayName: 'Template Tag',
                        cellTemplate: 'views/media-management/template/generate-document/template-tag-col.html',
                        enableCellEdit: false,
                        enableColumnMenu: false,
                        enableSorting: true,
                        width: '40%'
                    },
                    {
                         name: 'objectId',
                         displayName: '',
                         cellTemplate: 'views/media-management/template/generate-document/warning-col.html',
                         enableCellEdit: false,
                         enableColumnMenu: false,
                         enableSorting: true,
                         width: '5%'
                     }
                ],

                onRegisterApi: function (gridApi) {
                    $scope.gridApi = gridApi;

                    gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {

                        paginationOptions.pageNumber = newPage;
                        paginationOptions.pageSize = pageSize;

                        if (!PaginationService.isGoToPageEnabled) {
                            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                        }

                        PaginationService.setGoToPageEnabled(false);
                    });
                }
            };

        });
