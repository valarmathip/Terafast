'use strict';

angular.module('p2AdvanceApp')
    .controller('DefineTemplateCtrl', 
                function($scope, 
                         $q, 
                         $rootScope, 
                         $log, 
                         DocumentDataFactory, 
                         defineTemplateFieldsMetaData, 
                         defineTemplateProductPropertiesMetaData, 
                         ConfirmationModalFactory, 
                         $state, 
                         $stateParams, 
                         getTemplate, 
                         getTemplateList, 
                         moment, 
                         ENV, 
                         TemplateService,
                         actionItem,
                         ENV_MEDIA_MANAGEMENT) {
        $scope.defineTemplateFieldsMetaData = defineTemplateFieldsMetaData;
        $scope.defineTemplateProperties = $scope.defineTemplateFieldsMetaData[0].properties;
        $scope.requiredFields = $scope.defineTemplateFieldsMetaData[0].required;

        $scope.defineTemplateProductMetaData = defineTemplateProductPropertiesMetaData;
        $scope.defineTemplateProductProp = $scope.defineTemplateProductMetaData[0].properties;
        $scope.defineTemplateProductReqFields = $scope.defineTemplateProductMetaData[0].required;

        $scope.getTemplateList = getTemplateList;
        $scope.templateProdProp = {
            'name': 'numProviderTiers',
            'numProviderTiers': [
                1, 2, 3, 4, 5, 6, 7, 8
            ]
        };
                    
        $scope.templatePlanYearOptions = getPlanYearRange();  // only "SBC" document type has "Template Plan Year" dropdown enabled

        $scope.getTemplateData = getTemplate;

        $scope.templateName = $stateParams.docName;
        $scope.templateId = $stateParams.templateId;

        $scope.getTemplateData.name = $scope.templateName;

        $scope.templateDetails = {};
        $scope.templateDetailsData = {};

        $scope.isUnit = $scope.getTemplateData.isUnit;

        initTemplateDetails();

        var globalIsOneBaseSourceSelected = false;
        function initTemplateDetails() {
            angular.forEach($scope.getTemplateData, function(formattedVal, selectedKey) {
                $scope.templateDetails[selectedKey] = formattedVal;
            });

            angular.forEach($scope.templateDetails.templateSources, function(source) {
                if (!source.productClasses) {
                    source.productClasses = [];
                }
                if (!source.productTypes) {
                    source.productTypes = [];
                }
                if (!source.marketSegments) {
                    source.marketSegments = [];
                }
                if (!source.numProviderTiers) {
                    source.numProviderTiers = null;
                }
                if (!source.fundingArrangements) {
                    source.fundingArrangements = [];
                }
                angular.forEach(source, function(val, key) {
                    setUIValuesForTemplateSources(key, val, source);
                });
            });

            if (globalIsOneBaseSourceSelected) {
                angular.forEach($scope.templateDetails.templateSources, function(source) {
                    if (!source.isBaseSource) {
                        source.isBaseSourceHidden = true;
                    }
                });
            }
        }

        // Status of opened calendar, internal use only
        $scope.calendarOpened = {};

        // Calendar function
        $scope.openCalendar = function($event, $index, effectiveDate) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[effectiveDate]) {
                $scope.calendarOpened[effectiveDate] = [];
            }

            $scope.calendarOpened[effectiveDate][$index] = true;

            $log.log('$scope.calendarOpened[effectiveDate][$index] = ' + $scope.calendarOpened[effectiveDate][$index]);
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));

        };

        $scope.saveClicked = false;

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function

        $scope.saveClick = function(andPublishing) {
            $scope.saveClicked = true;

            validateTemplate();

            if (!$scope.isOneBaseSourceMissing && !$scope.templateNameMissing &&
                !$scope.documentTypeMissing && !$scope.businessEntityMissing &&
                !$scope.effectiveDateMissing && !$scope.effectiveDateCheck && !$scope.templateNameLength &&
                $scope.templateSourcesNotValid.productClasses.length === 0 && $scope.templateSourcesNotValid.productTypes.length === 0 &&
                $scope.templateSourcesNotValid.marketSegments.length === 0 && $scope.templateSourcesNotValid.fundingArrangements.length === 0) {
                /*comment-out-for-spinner manually*/ // ConfirmationModalFactory.open(msgBody, '');

                TemplateService.uniqueNameCheck($scope.templateDetails.name)  //check if name unique
                    .success(function () {
                        $scope.updateTemplate()
                        .then(function (data) {
                            updateTemplateSources(andPublishing).then(function (isSuccess) {
                                if (isSuccess) {
                                    if (andPublishing) {
                                        $scope.publishTemplate();
                                    } else {
                                        $scope.showSuccessInfo(data, andPublishing);
                                    }
                                }
                                else {
                                    $scope.saveClicked = false;
                                }
                            }, function (error) {
                                $log.error(error);
                                $scope.saveClicked = false;
                            });

                        }, function (error) {
                            $log.error(error);
                            $scope.saveClicked = false;
                        });
                    })
                    .error(function (response) {
                        $log.error(response);
                        $scope.saveClicked = false;
                        // var errorTitle = 'Template name check';
                        // $scope.errorMessage = 'Error occurred when checking the uniqueness of template name "' + $scope.templateDetails.name + '".';
                        // ConfirmationModalFactory.close($scope.showError(errorTitle));
                    });
            } else {
                $scope.saveClicked = false;
            }

        };

        $scope.showError = function (errTitle) {
            ConfirmationModalFactory.open(errTitle, $scope.errorMessage, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
        };

        $scope.publishTemplate = function() {

            // Publish Template
            TemplateService.updateStatus(actionItem.objectId, 'Published')
                .success(function(data, status) {
                    if (status === 200) {
                        $scope.showSuccessInfo(data, true);
                    } else {
                        $scope.showErrorInfo(data, true);
                    }
                })
                .error(function(response) {
                    $log.error(response);
                    // ConfirmationModalFactory.close( // close old one if exist and open one one
                    //     ConfirmationModalFactory.open('Unable to Publish Template', response, ENV_MEDIA_MANAGEMENT.modalErrorTimeout)
                    // );
                });

        };

        $scope.updateTemplate = function() {
            cleanAndCopyTemplateDetails();
            return DocumentDataFactory.updateTemplate($scope.templateDetailsData, $scope.templateId);
        };

        function updateTemplateSources(andPublishing) {
            var defer = $q.defer();
            cleanAndCopyTemplateSources();
            var isSuccess = true;
            var promises = [];
            angular.forEach($scope.templateDetailsData.templateSources, function(source) {
                promises.push(DocumentDataFactory.updateTemplateSource(source, source.objectId));
            });

            $q.all(promises).then(function(data) {
                angular.forEach(data, function(result){
                    if (result !== '') {
                        isSuccess = false;
                        $scope.showErrorInfo(result, andPublishing);
                    }
                });
            }).then(function() {
               defer.resolve(isSuccess);
            });
            return defer.promise;
        }

        function cleanAndCopyTemplateSources() {
            // applying only 8 predefined properties for Restful API call
            var sourceProps = ['productClasses','productTypes','marketSegments','numProviderTiers','fundingArrangements', 'isBaseSource', 'isRequiredSource', 'objectId'];
            var newTemplateSources = [];
            angular.forEach($scope.templateDetails.templateSources, function(source) {
                var newSource = {};
                angular.forEach(sourceProps, function(key) {
                    var val = source[key];
                    if (typeof val !== 'undefined') {
                        if (val !== null) {
                            if (typeof val === 'object') {
                                if (key === 'fundingArrangements') {
                                    newSource[key] = val;
                                } else {
                                    var cleanedSelection = [];
                                    angular.forEach(val, function (objVal, objKey) {
                                        if (objVal) {
                                            cleanedSelection.push(objKey);
                                        }
                                    });
                                    newSource[key] = cleanedSelection;
                                }
                            } else if (key === 'numProviderTiers') {  // could be a string or a number
                                newSource[key] = parseInt(val, 10);
                            } else {
                                newSource[key] = val;
                            }
                        } else {
                            newSource[key] = val;
                        }
                    }
                });
                newTemplateSources.push(newSource);
            });
            $scope.templateDetailsData['templateSources'] = newTemplateSources;
        }

        $scope.showHideBaseSource = function(index) {
            var sources = $scope.templateDetails.templateSources;
            var baseTypeSelected = sources[index].isBaseSource === true;
            for (var i = 0; i < sources.length; i++) {
                if (i !== index) {
                    //if (baseTypeSelected && $scope.isOneBaseSourceMissing) {
                    //    $scope.isOneBaseSourceMissing[i] = false;
                    //}
                    if (baseTypeSelected) {
                        $scope.isOneBaseSourceMissing = false;
                    }
                    sources[i].isBaseSourceHidden = baseTypeSelected;
                    if (baseTypeSelected) {
                        sources[i].isBaseSource = !baseTypeSelected;
                    }
                } else {
                    if (baseTypeSelected) {
                        sources[i].isRequiredSource = baseTypeSelected;
                    }
                }
            }
        };

        $scope.validateSource = function (objectId, isRequiredSource, type) {
            if (!$scope.templateSourcesNotValid) {
                return true;
            }

            var isValid = true;

            if ($scope.templateSourcesNotValid && isRequiredSource) {
                if ($scope.templateSourcesNotValid.productClasses) {
                    angular.forEach($scope.templateSourcesNotValid.productClasses, function (productClass) {
                        if (productClass.objectId === objectId && productClass.type === type) {
                            isValid = false;
                        }
                    });
                }

                if ($scope.templateSourcesNotValid.productTypes) {
                    angular.forEach($scope.templateSourcesNotValid.productTypes, function (productType) {
                        if (productType.objectId === objectId && productType.type === type) {
                            isValid = false;
                        }
                    });
                }

                if ($scope.templateSourcesNotValid.marketSegments) {
                    angular.forEach($scope.templateSourcesNotValid.marketSegments, function (marketSegment) {
                        if (marketSegment.objectId === objectId && marketSegment.type === type) {
                            isValid = false;
                        }
                    });
                }

                if ($scope.templateSourcesNotValid.fundingArrangements) {
                    angular.forEach($scope.templateSourcesNotValid.fundingArrangements, function (fundingArrangement) {
                        if (fundingArrangement.objectId === objectId && fundingArrangement.type === type) {
                            isValid = false;
                        }
                    });
                }

                if ($scope.templateSourcesNotValid.numProviderTiers) {
                    angular.forEach($scope.templateSourcesNotValid.numProviderTiers, function (tier) {
                        if (tier.objectId === objectId && tier.type === type) {
                            isValid = false;
                        }
                    });
                }
            }

            return isValid;
        };

        /*jshint maxcomplexity:27*/
        function validateTemplate() {            
            $scope.isOneBaseSourceMissing = true;
            $scope.isRequiredSourceMissing = [];
            $scope.templateNameMissing = !$scope.templateDetails.name || $scope.templateDetails.name.length === 0;
            $scope.documentTypeMissing = !$scope.templateDetails.documentType || $scope.templateDetails.documentType.length === 0;
            $scope.businessEntityMissing = !$scope.templateDetails.businessEntity || $scope.templateDetails.businessEntity.length === 0;
            $scope.effectiveDateMissing = !$scope.templateDetails.effectiveDate || $scope.templateDetails.effectiveDate.length === 0;

            $scope.effectiveDateCheck = !$scope.effectiveDateRequired && dateFormatter($scope.templateDetails.effectiveDate, 'effectiveDate') > dateFormatter($scope.templateDetails.endDate, 'endDate');
            $scope.templateNameLength = $scope.templateDetails.name !== undefined && $scope.templateDetails.name.length > 50;

            var sources = $scope.templateDetails.templateSources;
            var containsAccount = false;
            var containsOffering = false;

            for (var h = 0; h < sources.length; h++) {
                if (sources[h].isBaseSource === true) {
                    $scope.isOneBaseSourceMissing = false;
                }

                if (sources[h].sourceType && sources[h].sourceType.toLowerCase() === 'account') {
                    containsAccount = true;
                }

                if (sources[h].sourceType && sources[h].sourceType.toLowerCase() === 'offering') {
                    containsOffering = true;
                }
            }

            // below is section to validate template sources
            var productClassesSelected = [];
            var productTypesSelected = [];
            var marketSegmentsSelected = [];
            var fundingArrangementsSelected = [];
            var numProviderTiersSelected = [];

            /*jshint -W024 */
            var productClassesEnum = $scope.defineTemplateProductProp.productClasses.items.enum;
            var productTypesEnum = $scope.defineTemplateProductProp.productTypes.items.enum;
            var marketSegmentsEnum = $scope.defineTemplateProductProp.marketSegments.items.enum;
            var fundingArrangementsEnum = $scope.defineTemplateProductProp.fundingArrangements.items.enum;

            $scope.templateSourcesNotValid = { 'productClasses': [], 'productTypes': [], 'marketSegments': [], 'fundingArrangements': [], 'numProviderTiers': [] };

            if (sources.length > 1 || (!containsAccount && !containsOffering)) {
                for (var i = 0; i < sources.length; i++) {
                    for (var x = 0; x < productClassesEnum.length; x++) {
                        if (sources[i].productClasses[productClassesEnum[x]] && sources[i].isRequiredSource) {
                            productClassesSelected.push(sources[i].objectId);
                        }
                    }

                    for (var y = 0; y < productTypesEnum.length; y++) {
                        if (sources[i].productTypes[productTypesEnum[y]] && sources[i].isRequiredSource) {
                            productTypesSelected.push(sources[i].objectId);
                        }
                    }

                    for (var j = 0; j < marketSegmentsEnum.length; j++) {
                        if (sources[i].marketSegments[marketSegmentsEnum[j]] && sources[i].isRequiredSource) {
                            marketSegmentsSelected.push(sources[i].objectId);
                        }
                    }

                    for (var m = 0; m < fundingArrangementsEnum.length; m++) {
                        if (sources[i][$scope.defineTemplateProductProp.fundingArrangements.name].indexOf(fundingArrangementsEnum[m]) > -1 && sources[i].isRequiredSource) {
                            fundingArrangementsSelected.push(sources[i].objectId);
                        }
                    }

                    if (sources[i].numProviderTiers !== null && sources[i].numProviderTiers !== '') {
                        numProviderTiersSelected.push(sources[i].objectId);
                    }

                    if (productClassesSelected.indexOf(sources[i].objectId) === -1 && sources[i].isRequiredSource) {
                        var productClassesObj = { 'objectId': sources[i].objectId, 'type': 'productClasses' };
                        $scope.templateSourcesNotValid.productClasses.push(productClassesObj);
                    }

                    if (productTypesSelected.indexOf(sources[i].objectId) === -1 && sources[i].isRequiredSource) {
                        var productTypesObj = { 'objectId': sources[i].objectId, 'type': 'productTypes' };
                        $scope.templateSourcesNotValid.productTypes.push(productTypesObj);
                    }

                    if (marketSegmentsSelected.indexOf(sources[i].objectId) === -1 && sources[i].isRequiredSource) {
                        var marketSegmentsObj = { 'objectId': sources[i].objectId, 'type': 'marketSegments' };
                        $scope.templateSourcesNotValid.marketSegments.push(marketSegmentsObj);
                    }

                    if (fundingArrangementsSelected.indexOf(sources[i].objectId) === -1 && sources[i].isRequiredSource) {
                        var fundingArrangementsObj = { 'objectId': sources[i].objectId, 'type': 'fundingArrangements' };
                        $scope.templateSourcesNotValid.fundingArrangements.push(fundingArrangementsObj);
                    }

                    if (numProviderTiersSelected.indexOf(sources[i].objectId) === -1 && sources[i].isRequiredSource) {
                        var numProviderTiersObj = { 'objectId': sources[i].objectId, 'type': 'numProviderTiers' };
                        $scope.templateSourcesNotValid.numProviderTiers.push(numProviderTiersObj);
                    }

                }
            }
        }

        function dateFormatter(inputVal, inputKey) {
            if (inputKey === 'effectiveDate' || inputKey === 'endDate') {
                if (inputVal !== undefined) {
                    inputVal = moment(inputVal).format('YYYY-MM-DD');
                }
            } else if (inputKey === 'numProviderTiers') {
                if (inputVal === null) {
                    inputVal = $scope.templateProdProp.numProviderTiers[0];
                }
                inputVal = parseInt(inputVal, 10);
            }
            return inputVal;
        }

        function cleanAndCopyTemplateDetails() {
            // applying only 6 predefined properties for Restful API call
            var props = ['name','effectiveDate','endDate','documentType','businessEntity','templatePlanYear','description'];
            angular.forEach(props, function(prop) {
                if ($scope.templateDetails[prop]) {

                    if (prop === 'templatePlanYear') {
                        if ($scope.templateDetails.documentType !== 'SBC') {
                            $scope.templateDetails[prop] = 'NA';
                        }
                    }
                   
                    $scope.templateDetailsData[prop] = $scope.templateDetails[prop];
                }
            });

            /** In PPM numProviderTiers gets calculated, providerTiers can't be empty so it is always 1 or more.
             PPM strips null values before sending to cm. So we won't send null to cm */
            angular.forEach($scope.templateDetails.templateSources, function (source) {
                if (source.numProviderTiers === null) {
                    source.numProviderTiers = 1;
                }
            });
        }

        function setUIValuesForTemplateSources(templateKey, templateVal, templateObject) {
            // needed because the btn-checkbox in the UI requires values that are of the form {key1: true, key2: false, ...}
            // instead of simply an array of strings which is what the backend returns
            if (templateKey === 'productClasses' ||
                templateKey === 'productTypes' ||
                templateKey === 'marketSegments') {
                templateObject[templateKey] = {};
                for (var i = 0; i < templateVal.length; i++) {
                    templateObject[templateKey][templateVal[i]] = true;
                }
            } else {
                if (templateKey === 'isBaseSource' && templateVal === true) {
                    globalIsOneBaseSourceSelected = true;
                }
                templateObject[templateKey] = templateVal;
            }
            return templateObject;
        }

        /* macth what ppm has in a plan's "planYear" as seen in "plan-details-fields-meta-data.json",
        can be replaced by loading from backend, currently backend is not implemented */
        function getPlanYearRange() {
            var today = new Date();
            var currentYear = today.getFullYear();

            var planYearOptions = [];

            var naPlanYear = {
                'optionNameId': 'na',
                'label': 'NA'
            };

            planYearOptions.push(naPlanYear);

            for (var i = 0; i < 10; i++) {
                var currPlanYear = {
                    'optionNameId': currentYear + i,
                    'label': currentYear + i
                };

                planYearOptions.push(currPlanYear);
            }

            return planYearOptions;
        }

        $scope.showErrorInfo = function(error, isPublished) {
            var msgtitle = 'Failed';
            var msg = '';

            if (isPublished) {
                msgtitle = 'Unable to Publish Template';
                // check if the error message contains the template name which the current one is duplicated with
                if (error.developerMessage != null && JSON.stringify(error.developerMessage[0]).indexOf($scope.templateDetails[$scope.defineTemplateProperties.name.name]) > -1) {
                    msg = $scope.templateDetails[$scope.defineTemplateProperties.name.name] + ' is already in use. Use a different name.';
                }
                else 
                {
                    msg = 'An error occurred while publishing the template. ' + JSON.stringify(error.developerMessage[0]);
                }
            }
            else {
                msg = 'An error occurred while saving the template. ' + JSON.stringify(error.developerMessage[0]);
            }

            $log.log(msgtitle + ' --> ' + msg);
            $scope.saveClicked = false;
            ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
        };

        $scope.showSuccessInfo = function(data, isPublished) {
            var msgtitle = 'Success';
            var msg = (isPublished) ? 'Template saved and Published successfully.' : 'Template saved successfully.' ;
            $log.log(msgtitle + ' --> ' + msg);
            $scope.saveClicked = false;
            ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout, function() {
                $state.go('home.media-management.templates', {});
            });
        };
    });
