'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:AccountListCtrl
 * @description
 * # AccountListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('OfferingAccountListCtrl', function (
        $rootScope, $filter, $scope, uiGridConstants, $state, $timeout, ENV, $stateParams, ProductPlanSearch, $log, $modalInstance, dialogFactorySvc,
        PaginationService, ModalDialogFactory, authorizedUserInfo, accountListData, selectedOfferingId, AccountMgmtSvc, ppmUtils,
        FilterDataService, FilterService, accountSchema, OfferingAccountService) {

        //$scope.scopeName = 'offering-account-list';
        $scope.searchQuery = $stateParams.searchquery;
        $scope.userInformation = authorizedUserInfo; // SLQ should be already available from $auth service, do not need to call the backend again

        $scope.tabUrl = 'views/media-management/template/offering-account-list/ui-grid.html';

        $scope.checkList = {};   // grid single selection


        // do not allow offering multi-selection
        $scope.toggleSelection = function (row) {
            $scope.gridApi.selection.clearSelectedRows();

            if (!row.isSelected && !$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
            } else {
                row.isSelected = false;
                row.enableSelection = false;
                $scope.gridApi.selection.unSelectRow(row);
            }

            $scope.checkList = {};
            $scope.checkList[row.entity.objectId] = row.isSelected;
            $scope.selectedGridAccounts = $scope.gridApi.selection.getSelectedRows();
        };

        var pageSize = 20;
        $scope.currentPage = 1;
        $scope.currentPageSize = pageSize;

        var gridOptionsTpl = {
            'excessRows': 400,
            enableSorting: true,
            // pagination
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            // height of row,Fixing DOGVT-196 QA- Height of the table row should be 105px.
            rowHeight: 105, // never put number in "", like "100"
            headerRowHeight: 35, // default 30 // seems not work
            minRowsToShow: 6,
            rowTemplate: 'views/account-management/template/account-list/row.html',
            enableRowHeaderSelection: false, // disable the head selection
            useExternalPagination: true,
            useExternalSorting: true,
            expandableRowHeight: 150, // keep the same value as .ppm-expandable-row
            enableExpandableRowHeader: false
        };
        $scope.pageVal = {
            pageNumber: ''
        };

        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };
        // var preSearchQuery = null;

        gridOptionsTpl.onRegisterApi = function (gridApi) {
            $scope.gridApi = gridApi;

            $scope.gridApi.core.on.sortChanged($scope, function (grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                //loadData();
            });
            gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                //loadData();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
        };

        gridOptionsTpl.columnDefs = [{
            displayName: '',
            name: 'X1',
            field: 'element1',
            width: '10%',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: false,
            headerCellTemplate: 'views/account-management/template/account-list/icon-col-header.html',
            cellTemplate: 'views/media-management/template/offering-account-list/icon-col.html'
        }, {
            displayName: 'Account Name',
            name: 'name',
            width: '80%',
            field: 'accountName',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/media-management/template/offering-account-list/name-col.html'
        }, {
            displayName: 'Plan Year',
            name: 'year',
            width: '10%',
            field: '',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true
        }];

        /*
        if (selectedOfferingId) { // if an offering is selected
            var accountsByOfferingId = DocumentBatchHelper.getAccountsByOfferingId(accountListData, selectedOfferingId);
            plainAccountList = getPlainAccountGroupList(accountsByOfferingId);
        } else {
            if (accountListData.response.docs) {
                plainAccountList = getPlainAccountGroupList(accountListData.response.docs);               
            }
        }
        */
        $scope.accountList = [];

        $scope.gridOptions = gridOptionsTpl;
        $scope.gridOptions.data = 'accountList';
        $scope.filtersGroups = [];
        $scope.selectedFilters = {};

        loadAccountList(accountListData);

        $scope.navPage = function ($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.currentPage = $scope.gridApi.pagination.getPage();
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        };

        $scope.viewPages = function () {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };

        $scope.pageSizeChanged = function (ps) {
            $scope.gridOptions.paginationCurrentPage = 1;
            $scope.currentPage = 1;
            $scope.currentPageSize = ps;
        };

        $scope.goToPage = function (keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject.pageVal, $scope.gridApi);
            $scope.currentPage = $scope.gridApi.pagination.getPage();
        };

        $scope.loaded = function () {
            if (!PaginationService.getSortColumns()) {
                PaginationService.setSortColumns(null);
            }
            //loadData();
        };

        //$scope.$on('$includeContentLoaded', function() {});

        $scope.doSearch = function (keyEvent) {
            // Not used by now
            if (keyEvent.which === 13) {
                $scope.gridOptions.paginationCurrentPage = 1;
                $scope.currentPage = 1;
                loadData();
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
        };

        // Currently not search available, and this part is commented out
        // function loadData() {
        //     if ($scope.searchQuery === undefined) {
        //         var currentSearchQuery = ''; //getFilterQuery();

        //         //Do not call API with same search query, which was in prvious API call
        //         if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
        //             return;
        //         }
        //         // Load data goes here
        //         preSearchQuery = currentSearchQuery;
        //         // AccountMgmtSvc.getAccountListViaSearchApi(currentSearchQuery).then(function(data) {
        //         //     $scope.gridOptions.totalItems = data.data.response.numFound;
        //         //     $scope.accountList = data.data.response.docs;

        //         //     angular.forEach($scope.accountList, function(row) {
        //         //         $scope.checkList[row.objectId] = false;
        //         //     });
        //         // }).then(function() {
        //         //     // Need to find a event to reset the current page value; Do not like to use timer
        //         //     // Think about use $q again, because it is call in next loop
        //         //     $timeout(function() {
        //         //         if ($scope.currentPage) {
        //         //             $scope.gridOptions.paginationCurrentPage = $scope.currentPage;
        //         //         }
        //         //     }, 50);
        //         // });
        //     } else { // SLQ do we really need this part // This part is get called from plan-search.js, not sure it still be used by now
        //         //$scope.searchQuery = '/searchPlans?query='+$scope.searchQuery;
        //         ProductPlanSearch.getSearchList($scope.searchQuery).then(function(accountList) {
        //             $scope.accountList = accountList;
        //         }).then(function() {
        //             // Need to find a event to reset the current page value; Do not like to use timer
        //             // Think about use $q again, because it is call in next loop
        //             $timeout(function() {
        //                 if ($scope.currentPage) {
        //                     $scope.gridOptions.paginationCurrentPage = $scope.currentPage;
        //                 }
        //             }, 50);
        //         });
        //     }
        // }

        $scope.getNamePath = function (account) {
            return account.pathDsp.join(' | ');
        };

        $scope.showAccountSummaryDialog = function (id, objectType) {
            var dlgUrl = 'views/account-management/account-summary.html';
            var controller = 'AccountSummaryDialogCtrl';
            var data = {
                accountDetails: function () {
                    var associationExpansionLevel = -1;
                    return AccountMgmtSvc.getAccountById(id, associationExpansionLevel, objectType);
                }
            };
            var options = {
                size: 'md'
            };
            dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
        };

        $scope.ok = function () {
            ModalDialogFactory.closeDialog($scope.selectedGridAccounts);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

        function loadAccountList(accountList) {
            var procAccountList = [];

            if (selectedOfferingId) {
                var accountsByOfferingId = OfferingAccountService.getAccountsByOfferingId(accountList.response.docs, selectedOfferingId);
                procAccountList = getPlainAccountGroupList(accountsByOfferingId);
            } else {
                procAccountList = getPlainAccountGroupList(accountList.response.docs);
            }

            $scope.accountList = procAccountList;
            // TODO: Big bug here. Incorrect totalItems
            $scope.gridOptions.totalItems = $scope.accountList ? $scope.accountList.length : 0;
        }

        function getPlainAccountGroupList(accountList) {
            var plainAccountList = [];

            planAccountGroupRcsv(accountList, [], [], plainAccountList);

            return plainAccountList;
        }

        function planAccountGroupRcsv(accountList, path, objectIdPath, planList) {

            angular.forEach(accountList, function (account) {
                if (!ppmUtils.isUuid(account)) {

                    var currentPath = path.concat([account.accountName]);
                    account.pathDsp = currentPath;
                    var currentObjectIdPath = objectIdPath.concat([account.objectId]);
                    account.objectIds = currentObjectIdPath;
                    planList.push(account);

                    if (account.groups && account.groups.length > 0) {
                        planAccountGroupRcsv(account.groups, currentPath, currentObjectIdPath, planList);
                    }
                } else {
                    $log.error('Maybe you not load all level of your subgroup!');
                }
            });
        }

        // load data according to the new criteria (pagination, sort and filter)
        function loadData() {
            // todo check for empty filter load.
            var queryString = getQueryString();
            queryString += '&properties=objectId, name, groups, groupParentId, accountName, renewalStartDate, renewalEndDate, accountStatus, marketSegments, accountofferings, offerings';
            var associationExpansionLevel = -1;

            OfferingAccountService.getAccountListViaSearchApi(queryString, associationExpansionLevel)
                .then(function (accountData) {
                    loadAccountList(accountData);
                });
        }

        function getQueryString() {
            var queryString;
            queryString = $scope.getFilterQuery();

            // pagination
            var curPage = ($scope.gridApi) ? $scope.gridApi.pagination.getPage() : 1;
            var pageSize = $scope.gridOptions.paginationPageSize;
            var startIndex = (curPage === 1) ? 0 : (curPage - 1) * pageSize;
            queryString += '&start=' + startIndex + '&rows=' + pageSize;
            // sorting
            queryString += PaginationService.getSortQuery();

            return queryString;
        }

        $scope.getFilterQuery = function () {
            var filterQuery = 'TYPE:"account"';
            var accountName = $scope.accountSearchQuery;
            angular.forEach($scope.selectedFilters, function (filterValues, filterId) {
                var isFirstfilterValue = true;
                filterQuery += ' AND ';
                if (filterValues) {
                    filterQuery += ' ( ';
                    angular.forEach(filterValues, function (filterValue) {
                        filterValue = FilterService.calculateDate(filterValue);
                        filterValue = FilterService.calculateYear(filterValue);
                        filterValue = FilterService.calculateDay(filterValue);
                        filterValue = FilterService.calculateWeek(filterValue);

                        if (isFirstfilterValue) {
                            if (filterId === 'renewalEndDate' || filterId === 'renewalStartDate') {
                                filterQuery += filterId + ': ' + filterValue;
                            } else {
                                filterQuery += filterId + ': "' + filterValue + '"';
                            }
                            isFirstfilterValue = false;
                        } else {
                            if (filterId === 'renewalEndDate' || filterId === 'renewalStartDate') {
                                filterQuery += ' OR ' + filterId + ': ' + filterValue;
                            } else {
                                filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
                            }
                        }
                    });
                    filterQuery += ' ) ';
                }
            });
            filterQuery += FilterService.getSearchQueryForName(accountName, $scope.matchCase, 'accountName');
            return filterQuery;

        };

        function initializeAccountFiltersGroup() {
            $scope.filtersGroups = FilterDataService.buildAccountFilters(accountSchema);
        }

        $scope.queryData = function (selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOptions);
            $scope.currentPage = 1;
            loadData();
        };


        /** Start Filters  */
        // Filter ui setup
        $scope.filtersGroups = [];
        $scope.selectedFilters = {};
        //var accountProp = accountSchema; 

        // initialize the $scope.filtersGroups which initialises the filters UI
        initializeAccountFiltersGroup();


    });