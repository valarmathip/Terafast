﻿'use strict';

angular.module('p2AdvanceApp')
.controller('PlansModalInstanceCtrl', ['$scope', 'plansAvailable', 'ModalDialogFactory', '$modalInstance', function ($scope, plansAvailable, ModalDialogFactory, $modalInstance) {
    $scope.plans = plansAvailable;
	$scope.selectedPlanNames=[];
	$scope.toggleSelection = function (planId, name) {
        $scope.selectedPlanNames=[];
		$scope.selectedPlanNames.push(name);
    };

    $scope.ok = function () {
		$modalInstance.close($scope.selectedPlanNames);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);