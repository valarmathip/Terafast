'use strict';

angular.module('p2AdvanceApp')
    .controller('batchSummaryCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $filter,
        $modalInstance,
        ENV,
        PaginationService,
        FilterService,
        BatchService,
        ConfirmationModalFactory,
        Common,
        ENV_MEDIA_MANAGEMENT,
        batchObject,
        ModalDialogFactory
    ) {
        $scope.batchObject = batchObject;
        $scope.close = function() {
            $('html').css('overflow', '');
            $modalInstance.dismiss('cancel');
        };
        var pageSize = 20;

        $scope.gridBatchJobs = {
            data: 'batchJobList',
            'excessRows': 400,
            showGridFooter: true,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            rowHeight: 90,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            columnDefs: [{
                displayName: '',
                name: 'X1',
                field: 'element1',
                width: 100,
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: false,
                cellTemplate: 'views/media-management/template/batch-summary/icon-col.html'
            }, {
                name: 'name',
                displayName: 'Document Name',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents mm-ellipsis-and-full-name-style-group">' +
                    '<div class="col-cell-break width-percent-80">' +
                    '<div><span class="ellipsis" ppm-long-name-tooltip="{{row.entity.name}}">{{row.entity.name}}</span></div>' +
                    '<div><span ng-class=grid.appScope.setTextClass(row.entity.status) ng-show="!angular.isUndefined(row.entity.status) && row.entity.status"><em>({{row.entity.status}})</em> </span></div>' +
                    '<div class="padding-top-5px"><span class="ellipsis width-percent-120" ng-class=grid.appScope.setTextClass(row.entity.status) ppm-long-name-tooltip="{{row.entity.statusDetails}}"' +
                    'ng-show="!angular.isUndefined(row.entity.statusDetails) && row.entity.statusDetails">({{row.entity.statusDetails}}) </span></div>' +
                    '</div>' +
                    '<div class="text-right">' +
                    '<span class="badge mm-badge">{{row.entity.DocType}}</span>' +
                    '</div>' +
                    '</div>',
                width: '35%',
                /* Commenting out to show sorting Icon in the header cell
                headerCellTemplate: '<div class="ui-grid-cell-contents padding-top-10px">Document Name</div>', 
                */
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'tempName',
                displayName: 'Template Name',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents padding-top-15px white-space-normal">{{row.entity.tempName}}</div>',
                /* Commenting out to show sorting Icon in the header cell
                headerCellTemplate: '<div class="ui-grid-cell-contents padding-top-10px">Template Name</div>',
                */
                type: 'string',
                width: '25%',
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'sourceName',
                displayName: 'Source Name(s)',
                enableSorting: true,
                headerCellTemplate: '<div class="ui-grid-cell-contents">Source Name(s) ' +
                    ' <i ng-show="grid.appScope.direction == asc" class="fa fa-sort-asc padding-left-15px"></i>' +
                    '<i ng-show = "grid.appScope.direction == desc"  class = "fa fa-sort-desc padding-left-15px"> </i>' +
                    ' <br/> <em> (Plan / Unit) </em></div > ',
                cellTemplate: '<div class="ui-grid-cell-contents padding-top-15px white-space-normal"><div>{{row.entity.sourceName}}</div>' +
                    '<div> <em>({{row.entity.sourceType}}) </em></div></div>',
                type: 'string',
                width: '30%',
                enableHiding: false,
                enableColumnMenu: false
            }]
        };

        $scope.gridBatchJobs.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                $scope.gridBatchJobs.virtualizationThreshold = pageSize;
            });
            $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                $scope.direction = '';
                if (sortColumns.length > 0 && sortColumns[0].displayName === 'Source Name(s)') {
                    $scope.direction = sortColumns[0].sort.direction;
                }
            });

        };

        $scope.setTextClass = function(value) {
            if (value === 'Successful') {
                return {
                    'text-success': true
                };
            } else if (value === 'Failed' || value === 'Cancelled') {
                return {
                    'text-danger': true
                };
            } else if (value === 'Partially Successful') {
                return {
                    'text-warning': true
                };
            } else if (value === 'Draft' || value === 'In progress' || value === 'Submitted') {
                return {
                    'text-gray': true
                };
            } else {
                return {
                    'text-info': true
                };
            }
        };


        function documentFormatsSpec(batchJobTaskDocumentPdfDocumentId, batchJobTaskDocumentWordDocumentId) {
            if ((angular.isDefined(batchJobTaskDocumentPdfDocumentId) && angular.isDefined(batchJobTaskDocumentWordDocumentId))) {
                return 'Both';
            } else if (angular.isDefined(batchJobTaskDocumentWordDocumentId)) {
                return 'Word';
            } else if (angular.isDefined(batchJobTaskDocumentPdfDocumentId)) {
                return 'PDF';
            } else {
                return '';
            }
        }

        function updateBatchDocuments() {
            $scope.batchJobList = [];
            angular.forEach($scope.batchObject.batchJobs, function(item) {
                var jobTask = item.batchJobTasks;
                var taskDocument = item.batchJobTasks[0].taskDocument;
                var document = JSON.parse(jobTask[0].batchJobTaskBody);

                $scope.batchJobList.push({
                    name: document.documentName,
                    DocType: taskDocument && taskDocument[0] ? taskDocument[0].batchJobTaskDocumentDocumentType : '',
                    tempName: document.templateName,
                    sourceName: document.dataSourceNames,
                    sourceType: taskDocument && taskDocument[0] ? taskDocument[0].batchJobTaskDocumentDataSourceType : '',
                    status: item.batchJobStatus,
                    statusDetails: item.batchJobStatusDetails,
                    batchJobTaskDocumentPdfId: taskDocument && taskDocument[0] ? taskDocument[0].batchJobTaskDocumentPdfDocumentId : '',
                    batchJobTaskDocumentWordId: taskDocument && taskDocument[0] ? taskDocument[0].batchJobTaskDocumentWordDocumentId : '',
                    documentFormat: taskDocument && taskDocument[0] ? documentFormatsSpec(taskDocument[0].batchJobTaskDocumentPdfDocumentId, taskDocument[0].batchJobTaskDocumentWordDocumentId) : '',
                    objectId: item.objectId
                });
            });

        }

        updateBatchDocuments();

        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };

        $scope.pageSizeChanged = function() {
            $scope.gridBatchJobs.paginationCurrentPage = 1;
        };

        $scope.downloadDocument = function(wordId, pdfId, name, documentFormat) {
            if (documentFormat === 'Both') {
                Common.downloadAndNotify(ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents/' + wordId + '/content', name, 'Word');
                Common.downloadAndNotify(ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents/' + pdfId + '/content', name, 'PDF');
            } else if (documentFormat === 'Word') {
                Common.downloadAndNotify(ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents/' + wordId + '/content', name, 'Word');
            } else if (documentFormat === 'PDF') {
                Common.downloadAndNotify(ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents/' + pdfId + '/content', name, 'PDF');
            } else {
                ConfirmationModalFactory.open('Message', 'Document format is unavailable can not download the document', ENV.modalErrorTimeout);
            }
        };

        $scope.canButtonEnabled = function(buttonName) {
            var batchObject = $scope.batchObject;
            var status = batchObject.status;
            var enableButton = false;
            if ((buttonName === 'Submit' || buttonName === 'Edit') && status === 'Draft') {
                enableButton = true;
            } else if ((buttonName === 'Resubmit' || buttonName === 'Edit') && (status === 'Cancelled' || status === 'Failed' || status === 'Partially Successful' || status === 'Successful')) {
                enableButton = true;
            }
            return enableButton;

        };

        $scope.editBatch = function() {
            $scope.close();
            var batchObject = $scope.batchObject;
            var isMultiSource = BatchService.isEditBatchMultiSource(batchObject);

            if (isMultiSource) {
                $state.go('home.media-management.generateDocument', {
                    'isMultiSource': true,
                    'batchObjectId': batchObject.objectId
                });
            } else {
                $state.go('home.media-management.generateDocument', {
                    'batchObjectId': batchObject.objectId
                });
            }
        };

        $scope.submitBatch = function() {

            var batchObject = $scope.batchObject;
            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-submit-batch.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            $scope.close();
                            BatchService.integrationWithSubmitBatch(batchObject);
                        }
                    });
        };

        $scope.reSubmitBatch = function() {
            var batchObject = $scope.batchObject;
            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-resubmit-batch.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            $scope.close();
                            BatchService.integrationWithReSubmitAllBatchJobs(batchObject);
                        }
                    });
        };

        $scope.reSubmitFailedCancelledJobs = function() {
            var batchObject = $scope.batchObject;
            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-resubmit-failed-cancelled-batch-jobs.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            BatchService.integrationWithReSubmitFailedCancelledJobsBatch(batchObject);
                        }
                    });
        };

        $scope.reSubmitAllJobsBatch = function() {

            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-resubmit-batch.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            BatchService.integrationWithReSubmitAllBatchJobs(batchObject);
                        }
                    });
        };
    });