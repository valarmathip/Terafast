'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: SelectOfferingCtrl
 * @description
 * # SelectOfferingCtrl
 * Controller of the p2AdvanceApp under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('SelectOfferingCtrl', function(
        $scope,
        $filter,
        OfferingAccountService,
        FilterDataService,
        ModalDialogFactory,
        ProductPlanMgmtSvc,
        PPMFilterMetaSvc,
        offeringsFieldsMeta,
        plansAspectDefs,
        DatePickerFilterService,
        $log,
        $state,
        ENV,
        uiGridConstants,
        offeringList,
        selectedAccount,
        PaginationService,
        FilterService) {
       
        $scope.$parent.selectedState = 'offering';
        $scope.$parent.selectedTitle = 'Select Offering';
        $scope.$parent.selectedGridOfferings = [];  //clean up the selected offering
        $scope.checkList = {};   // grid single selection

        // do not allow offering multi-selection
        $scope.toggleSelection = function (row) {
            $scope.gridApi.selection.clearSelectedRows();

            if (!row.isSelected && !$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);                
            } else {
                row.isSelected = false;
                row.enableSelection = false;
                $scope.gridApi.selection.unSelectRow(row);              
            }

            $scope.checkList = {};
            $scope.checkList[row.entity.objectId] = row.isSelected;
            $scope.$parent.selectedGridOfferings = $scope.gridApi.selection.getSelectedRows();
        };

        /** Start search opt setup*/
        $scope.currentPage = 1;

        /*end search opt*/
        var defaultPageSize = 20;

        $scope.gridOfferings = {
            'excessRows': 400, // SLQ need to more investigation
            enableSorting: true,
            // pagination
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: defaultPageSize,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            // height of row
            rowHeight: 105, // never put number in "", like "100"
            minRowsToShow: 6,
            rowTemplate: 'views/product-plan-management/template/offering-list/row.html',
            enableRowHeaderSelection: false, // disable the head selection
            // Pagination and sorting
            useExternalPagination: true,
            useExternalSorting: true

        };

        $scope.gridOfferings.columnDefs = [{
            name: 'objectId',
            displayName: '',
            enableColumnMenu: false,
            headerCellTemplate: 'views/media-management/template/offering-list/icon-col-header.html',
            cellTemplate: 'views/media-management/template/offering-list/icon-col.html',
            width: 60,
            enableHiding: false
        }, {
            displayName: 'Offering Name',
            name: 'name',
            field: 'name',
            width: '75%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-list/name-col.html'
        }, {
            displayName: 'Benefit Year',
            field: 'benefitYear',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-list/benefit-year-col.html'
        }];

        $scope.gridOfferings.data = 'offeringList';

        $scope.gridOfferings.onRegisterApi = function (gridApi) {
            $scope.gridApi = gridApi;
            // pagination
            gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                $log.log('newPage = ' + newPage + ', pageSize = ' + pageSize);
                loadData();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
            // sorting
            $scope.gridApi.core.on.sortChanged($scope, function (grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                loadData();
            });
        };

        /**
            Pagination
         */
        $scope.pageVal = {
            pageNumber: ''
        };

        $scope.navPage = function ($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.currentPage = $scope.gridApi.pagination.getPage();
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        };

        $scope.viewPages = function () {
            return PaginationService.viewPages($scope.gridApi, []);
        };

        $scope.pageSizeChanged = function (ps) { /* jshint ignore:line */
            // If page size changed, start the pages from beginning.
            // In fact, ui-grid can automatically reset the start page
            // if change page size larger and total page number reduced.
            // If you want the offering not start from begin, comment out this line.
            $scope.gridOfferings.paginationCurrentPage = 1;
        };

        $scope.goToPage = function (keyEvent) {
            PaginationService.goToPage(keyEvent, $scope.pageVal, $scope.gridApi);
        };
        /* End of Pagination */

        /** Start Filters  */
        // Filter ui setup
        $scope.filtersGroups = [];
        $scope.selectedFilters = {};
        var offeringProp = offeringsFieldsMeta[0].properties;
        var aspectDefProp = plansAspectDefs[0].properties;
        /** Start filter query generation */
        $scope.viewPages = function () {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.loaded = function () {
            if (!PaginationService.getSortColumns()) {
                PaginationService.setSortColumns(null);
            }

            loadData();
        };

        $scope.queryData = function (selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOfferings);
            $scope.currentPage = 1;
            loadData();
        };
        $scope.doSearch = function (keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridOfferings.paginationCurrentPage = 1;
                $scope.currentPage = 1;
                loadData();
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
        };
        //filterId should be added on adding date widget to a filter
        $scope.datePicker = {
            fromDate: {
                lastModificationDate: [],
                planDueDate: [],
                effectiveDate: []
            },
            toDate: {
                lastModificationDate: [],
                planDueDate: [],
                effectiveDate: []
            }
        };
        $scope.attrYear = {
            field: ''
        };
        $scope.setDatePickerAttrId = function (rangeAttr) {
            $scope.selectedFilters = DatePickerFilterService.pushDatePickerAttr(rangeAttr, $scope.selectedFilters);
        };

        function getDatePickerValues() {
            var allDateCollection = [];
            var fromDateObjs = $scope.datePicker.fromDate;
            var toDateObjs = $scope.datePicker.toDate;
            allDateCollection = DatePickerFilterService.getAllDateCollection(allDateCollection, fromDateObjs, toDateObjs);
            return allDateCollection;
        }

        $scope.getFilterQuery = function () {
            var fromToDateCollection = getDatePickerValues();
            var filterQuery = 'q=TYPE:"offering"';
            var isNOTRangeFilterValue = false;
            var filterIdClone;
            var offerName = $scope.offeringSearchQuery;
            angular.forEach($scope.selectedFilters, function (filterValues, filterId) {
                var isFirstfilterValue = true;
                var isRangeExist = false;
                isNOTRangeFilterValue = false;
                filterIdClone = filterId;
                filterQuery += ' AND ';
                if (filterValues) {
                    filterQuery += ' ( ';
                    angular.forEach(filterValues, function (filterValue) {
                        if (filterValue.toString().toLowerCase() !== 'date range') {
                            filterValue = FilterService.calculateDate(filterValue);
                            filterValue = FilterService.calculateYear(filterValue);
                            filterValue = FilterService.calculateDay(filterValue);
                            filterValue = FilterService.calculateWeek(filterValue);
                            if (isFirstfilterValue) {
                                filterQuery = determineFilterQueryForSingleFilter(filterValue, isFirstfilterValue, filterId, filterQuery);
                                isFirstfilterValue = false;
                                isNOTRangeFilterValue = true;
                            } else {
                                filterQuery = determineFilterQueryForMultipleFilters(filterValue, isFirstfilterValue, filterId, filterQuery);
                                isNOTRangeFilterValue = true;
                            }
                        } else if (!isRangeExist) {
                            filterQuery = FilterService.getFilterQueryForRange(filterQuery, isNOTRangeFilterValue, filterIdClone, fromToDateCollection);
                            isRangeExist = true;
                            isFirstfilterValue = false;
                        }
                    });
                    filterQuery += ' ) ';
                }
            });
            filterQuery += FilterService.getSearchQueryForName(offerName, $scope.matchCase, 'name');
            return filterQuery;

        };

        function determineFilterQueryForSingleFilter(filterValue, isFirstfilterValue, filterId, filterQuery) {
            if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'lastModificationDate' || filterId === 'planDueDate') {
                filterQuery += filterId + ': ' + filterValue;
            } else if (filterId === 'lastModifiedBy' || filterId === 'createdBy') {
                filterValue = $scope.userInformation.data.user.email;
                filterQuery += filterId + ': "' + filterValue + '"';
            } else if (filterId === 'grandfatheredPlan' && filterValue === 'Yes') {
                filterValue = true;
                filterQuery += filterId + ': "' + filterValue + '"';
            } else if (filterId === 'grandfatheredPlan' && filterValue === 'No') {
                filterValue = false;
                filterQuery += filterId + ': "' + filterValue + '"';
            } else if (filterId === 'marketSegment' && filterValue === 'No') {
                filterValue = false;
                filterQuery += filterId + ': "' + filterValue + '"';
            } else {
                filterQuery += filterId + ': "' + filterValue + '"';
            }
            return filterQuery;
        }

        function determineFilterQueryForMultipleFilters(filterValue, isFirstfilterValue, filterId, filterQuery) {
            if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'lastModificationDate' || filterId === 'planDueDate') {
                filterQuery += ' OR ' + filterId + ': ' + filterValue;
            } else if (filterId === 'lastModifiedBy' || filterId === 'createdBy') {
                filterValue = $scope.userInformation.data.user.email;
                filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
            } else if (filterId === 'grandfatheredPlan' && filterValue === 'Yes') {
                filterValue = true;
                filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
            } else if (filterId === 'grandfatheredPlan' && filterValue === 'No') {
                filterValue = false;
                filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
            } else if (filterId === 'marketSegment' && filterValue === 'No') {
                filterValue = false;
                filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
            } else {
                filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
            }
            return filterQuery;
        }

        /*End filter query generaition*/
        // Calendar function
        $scope.openCalendar = function ($event, $index, effectiveDate) {
            $scope.calendarOpened = {};
            $event.preventDefault();
            $event.stopPropagation();
            if (!$scope.calendarOpened[effectiveDate]) {
                $scope.calendarOpened[effectiveDate] = [];
            }
            $scope.calendarOpened[effectiveDate][$index] = true;
        };
        // Disable weekend selection
        $scope.disabled = function (date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };
        $scope.dateOptions = {
            showWeeks: false
        };
        $scope.getSelectedChecks = function (checkList) {
            var selectedChecks = [];
            angular.forEach(checkList, function (checkValue, planId) {
                if (checkValue) {
                    selectedChecks.push(planId);
                }
            });
            return selectedChecks;
        };
        // End of Calendar function
        // init filter ui
        initializeOfferingArrays();

        function initializeOfferingArrays() {
            var initArr = PPMFilterMetaSvc.initializeOfferArr();
            $scope.filtersGroups = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, offeringProp, aspectDefProp);
        }
        /* End Filters */
        // load data according to the new criteria (pagination, sort and filter)
        function loadData() {
            // todo check for empty filter load.
            var queryString = getQueryString();

            var associationExpansionLevel = 0;
            ProductPlanMgmtSvc.getOfferintListViaSearchApi(queryString, associationExpansionLevel)
                .then(function (offeringData) {
                    offeringListLoaded(offeringData);
                });
        }

        function getQueryString() {
            var queryString;
            queryString = $scope.getFilterQuery();

            // pagination
            var curPage = ($scope.gridApi) ? $scope.gridApi.pagination.getPage() : 1;
            var pageSize = $scope.gridOfferings.paginationPageSize;
            var startIndex = (curPage === 1) ? 0 : (curPage - 1) * pageSize;
            queryString += '&start=' + startIndex + '&rows=' + pageSize;
            // sorting
            queryString += PaginationService.getSortQuery();

            return queryString;
        }

        function offeringListLoaded(offeringsData) {
            /* when selectedAccount not null, means user selected an account first, then only retrieve offerings related to that account */
            if (selectedAccount) {
                $scope.offeringList = OfferingAccountService.getOfferingsOfAccount(selectedAccount);
                $scope.gridOfferings.totalItems = $scope.offeringList.length;
            }
            else {
                if (offeringsData) {
                    $scope.offeringList = offeringsData.response.docs;
                    $scope.gridOfferings.totalItems = offeringsData.response.numFound;
                } else {
                    $scope.offeringList = [];
                    $scope.gridOfferings.totalItems = 0;
                }
            }
        }

        offeringListLoaded(offeringList);

    });