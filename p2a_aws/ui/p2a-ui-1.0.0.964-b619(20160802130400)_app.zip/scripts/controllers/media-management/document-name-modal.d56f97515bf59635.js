﻿'use strict';

angular.module('p2AdvanceApp')
  .controller('DocGenNameCtrl', function (
        $scope,
        $modalInstance,
        systemGeneratedName,
        ModalDialogFactory,
        $timeout,
        ENV)
    {
        $scope.sysDocName = systemGeneratedName;   //populate the textbox with system generated doc name first

        $scope.showError = false;

        $scope.addDocumentName = function () {
            // Based on https://dev.my.highroads.com/index.php/Alfresco_Maintenance:_Tips,_Tricks,_and_Traps#Alfresco_Filename_Restrictions
            // In summary, the characters ", *, \, >, <, ?, /, :, | are not allowed in filenames.
            var regex = new RegExp(/"|\*|\\|>|<|\?|\/|:|\|/);
            if ($scope.newDocName && $scope.newDocName.match(regex)) {
                $scope.showError = true;
                $timeout(function() {
                    $scope.showError = false;
                }, ENV.modalErrorTimeout);
            } else {
                //no need to check if $scope.newDocName is empty , if it is, doc generation will use system generated name
                ModalDialogFactory.closeDialog($scope.newDocName);  
            }       
        };

        $scope.closeDocNameModal = function () {
            $modalInstance.dismiss('cancel');
        };
});
