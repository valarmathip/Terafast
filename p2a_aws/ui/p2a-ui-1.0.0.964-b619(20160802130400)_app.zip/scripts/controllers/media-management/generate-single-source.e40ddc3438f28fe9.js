﻿'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: GenerateDocSingleSourceCtrl
 * @description
 * # GenerateDocSingleSourceCtrl
 * Controller of Single Source Document Generation under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('GenerateDocSingleSourceCtrl',
        function ($scope,
            $rootScope,
            $log,
            $state,
            ModalDialogFactory,
            FileSelectFactory) {

            $scope.clearPlans = function (property) {
                if (!property || property === '') {
                    $scope.docDefinition.selectedPlans = null;
                } else {
                    var idx = -1;

                    angular.forEach($scope.docDefinition.selectedPlans, function (plan) {
                        if (plan.name === property) {
                            idx = $scope.docDefinition.selectedPlans.indexOf(plan);
                        }
                    });

                    if (idx > -1) {
                        $scope.docDefinition.selectedPlans.splice(idx, 1);
                    }
                }
            };

            // when call File Selector to select plans, it doesn't return the whole plan JSON from CRUD api, it only returns a couple of properties like id, name, etc.
            $scope.browseFiles = function (entity) {
                var selectorType = 'multiple';

                //if we're in batch job editing mode, only allow select one plan from modal dialog 'cuz each row contains only one plan for single source
                if ($scope.currentBatch && $scope.currentBatch.currentBatchJobInEditing) {
                    selectorType = 'single';
                }

                if (entity.toLowerCase() === 'plan') {
                    FileSelectFactory.openModalDialog(entity, selectorType).then(function (result) {
                        var jsonObj = JSON.parse(result);              
                        $scope.docDefinition.selectedPlans = [];

                        angular.forEach(jsonObj.selectedObjects, function (obj) {
                            var planJSON = { 'objectId': obj.objectId, 'name': obj.name, 'planYear': obj.planYear };
                            $scope.docDefinition.selectedPlans.push(planJSON);
                        });                      
                    });
                }
            };
          
            $scope.showPlanMsgError = function () {
                return ($scope.docDefinition.selectedPlans === null || $scope.docDefinition.selectedPlans.length === 0) &&
                       ($scope.$parent.documentValidationNeeded === true || $scope.addToBatchButtonClicked === true || $scope.saveBatchButtonClicked === true);
            };

        });
