﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('TemplatesCtrl', function(
        $scope,
        $filter,
        $http,
        $state,
        $upload,
        $stateParams,
        ENV,
        DocumentDataFactory,
        templateFiltersMetaData,
        templateFiltersProductPropertiesMetaData,
        filtersGroupsMeta,
        ConfirmationModalFactory,
        QueryDialog,
        ENV_MEDIA_MANAGEMENT,
        CommonGrid,
        $log,
        $auth,
        Common,
        moment,
        uiGridConstants,
        PaginationService,
        FilterService,
        TemplateService,
        uiConfig,
        authorizedUserInfo) {
        PaginationService.setSortColumns(null);
        $scope.searchQuery = $stateParams.searchquery;
        $scope.checkList = {};
        $scope.currentPageSize = {};
        $scope.templates = [];

        //temporary object to store each filtering result
        $scope.filteredData = $scope.templates;
        //stores checkboxes selected attribute values, could come from multiple filters
        $scope.filterOptions = [];
        // stores filter options
        $scope.selectedIdToObjsMap = [];
        $scope.selectedFilters = {};

        $scope.ENV_MEDIA_MANAGEMENT = ENV_MEDIA_MANAGEMENT;

        $scope.templateFiltersMetaDataProperties = templateFiltersMetaData;
        $scope.templateFiltersMetaDataProductProperties = templateFiltersProductPropertiesMetaData;

        $scope.templateFiltersProperties = $scope.templateFiltersMetaDataProperties[0].properties;
        $scope.templateFiltersProductProperties = $scope.templateFiltersMetaDataProductProperties[0].properties;

        $scope.numProviderTiers = {
            'name': 'numProviderTiers',
            'enum': [
                1, 2, 3, 4, 5, 6, 7, 8
            ]
        };

        $scope.effectiveDate = {
            'name': 'effectiveDate',
            'enum': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
        };

        $scope.endDate = {
            'name': 'endDate',
            'enum': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
        };

        $scope.planYearArr = {
            'name': 'templatePlanYear',
            'enum': ['Current Year + 1', 'Current Year', 'Current Year - 1', 'text']
        };

        $scope.attrYear = {
            field: ''
        };

        $scope.filtersGroups = filtersGroupsMeta;
        $scope.userInformation = authorizedUserInfo;

        var preSearchQuery = null;

        $scope.pageVal = {
            pageNumber: ''
        };

        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };

        var gridTemplatesTpl = {};
        $scope.loadedTemplateList = [];
        $scope.templateList = [];

        $scope.selectall = true;

        initializeTemplateArrays();
        $scope.hoverItems = [{
                label: 'Define Template',
                icon: 'fa-pencil',
                isShown: function(row) {
                    return row.templateStatus === 'Final';
                },
                action: function(row) {
                    $state.go('home.media-management.defineTemplate', {
                        templateId: row.objectId,
                        docName: row.name
                    });
                },
                permission:'|template.update,|all.update'

            },
            // Based on PONHR-795, publish template will be posible only from the define fields modal
            // using the Save & Publish button.  I'll leave this code commented just in case we need to 
            // reactive the "Publish this template" action in the Hoven Menu. -- JP 
            // {
            //     label: 'Publish this Template',
            //     icon: 'fa-share-square-o',
            //     isShown: function(row) {
            //         return row.templateStatus === 'Draft';
            //     },
            //     action: function(row) {
            //         ConfirmationModalFactory.open('Publishing...');
            //         $scope.extractContentControls(row.objectId);
            //         $scope.actionItem = row; // we need objectId and template name for PATCH request. The easiest way to pass them with scope.
            //     }
            // }, 
            {
                label: 'Expire this Template',
                icon: 'fa-calendar-times-o',
                isShown: function(row) {
                    return row.templateStatus === 'Published';
                },
                action: function(row) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Expiring...')
                    $scope.expireTemplate(row);
                    $scope.actionItem = row;
                },
                permission:'|template.update,|all.update'
            }, {
                label: 'Finalize this Template',
                icon: 'fa-calendar-times-o',
                isShown: function(row) {
                    return row.templateStatus === 'Draft';
                },
                action: function(row) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Finalizing...')
                    $scope.finalizeTemplate(row);
                    $scope.actionItem = row; // we need objectId and template name for PATCH request. The easiest way to pass them with scope.
                },
                permission:'|template.update,|all.update'
            }
        ];

        var upperCaseFirstLetter = function(text) {
            if (typeof text !== 'string') { return; }
            var textLowerCase = text.toLowerCase();
            var firstLetter = textLowerCase.charAt(0);
            return textLowerCase.replace(firstLetter, function(x) {
                return x.toUpperCase();
            });
        };

        $scope.finalizeTemplate = function (actionItem) {
            var errorTitle = 'Unable to Finalize Template';
            var errorBody = 'Error extracting content controls -';

            // Publish Template
            TemplateService.extractContentControls(actionItem.objectId)
                .success(function (data, status) {
                    if (status === uiConfig.OK) {
                        TemplateService.updateStatus(actionItem.objectId, 'Final')
                            .success(function (data, status) {
                                if (status === uiConfig.OK) {
                                    $scope.updateTemplateGrid('Final');
                                }
                                else {
                                    $scope.errorMessage = 'Error updating template status to Final - ' + upperCaseFirstLetter(data);
                                    $scope.showError(errorTitle);
                                }
                            })
                            .error(function (response) {
                                $log.error(response);
                            });
                    } else {
                        $scope.errorMessage = errorBody + upperCaseFirstLetter(data);
                        $scope.showError(errorTitle);
                    }
                }).error(function (response) {
                    $log.error(response);
                });
        };

        $scope.expireTemplate = function(actionItem) {
            var errorTitle = 'Unable to Expire Template';
            var errorBody = 'Error expiring template - ';

            TemplateService.updateStatus(actionItem.objectId, 'Expired')
                .success(function(data, status) {
                    if (status === uiConfig.OK) {
                        $scope.updateTemplateGrid('Expired');
                    } else {
                        $scope.errorMessage = errorBody + upperCaseFirstLetter(data);
                        ConfirmationModalFactory.close($scope.showError(errorTitle));
                    }
                })
                .error(function(response) {
                    $log.error(response); 
                });
        };

        $scope.errorMessage = '';

        $scope.showError = function(title) {
            ConfirmationModalFactory.open(title, $scope.errorMessage, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
        };

        $scope.updateTemplateGrid = function(templateStatus) {
            $scope.gridTemplates.data = $scope.templateList;
            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()

            var query = getSearchQuery();

            DocumentDataFactory.getTemplates(encodeURI(query))
                .then(function(data) {
                    var doesTemplateExistInGrid = false;

                    //angular.forEach doesn't support break; use the native for loop
                    for (var i = 0, j = data.response.docs.length; i < j; i++) {
                        if ($scope.actionItem && data.response.docs[i].objectId === $scope.actionItem.objectId) {
                            doesTemplateExistInGrid = true;
                            $scope.actionItem.templateStatus = templateStatus;
                            break;
                        }
                    }

                    //if the newly updated template hasn't got pulled in by cm yet we need to add it by the way as shown below
                    if ($scope.actionItem && !doesTemplateExistInGrid) {
                        $scope.actionItem.templateStatus = templateStatus;
                        // $scope.gridTemplates.data.unshift($scope.actionItem);
                        //add the newly published row to the top - PONHR-306
                    }
                });
        };

        $scope.addTemplate = function() {
            var up = angular.element(document.querySelector('#uploader'));
            up.click();
        };

        $scope.doSearch = function (keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridOptions.paginationCurrentPage = 1;
                loadTemplateList();
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
        };

        $scope.uploader = {
            isHTML5: true,
            progress: 0
        };

        $scope.doUpload = function() {
            var files = $scope.uploader.files;
            if (files && files.length) {
                var item = files[0];

                if (!item.name.toLowerCase().match('.docx$')) {
                    ConfirmationModalFactory.open('Template Uploader', 'Please, select .docx file!', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    return;
                }

                $scope.gridTemplates.data = $scope.templateList;

                var file = [];
                file.push(item);
                var templateName = item.name.substring(0, item.name.length - 5) + '-' + Date.now() + '.docx';

                TemplateService.uniqueNameCheck(templateName)  //check if name unique
                    .success(function () {
                        // file name contains more than 5 characters, because it ends with ".docx"
                        var today = moment(Date.now()).format('YYYY-MM-DDTHH:mm:ss Z');

                        // keep uploading item in the scope (to be able update template list later)
                        $scope.upItem = {
                            'name': templateName,
                            'contentStreamFileName': file[0].name,
                            'templateStatus': 'Draft',
                            'effectiveDate': today,
                            'createdBy': $auth.getUserFullName()
                        };

                        var metadata = JSON.stringify({
                            'properties': { 'name': templateName, 'templateStatus': 'Draft'}
                        });

                        file.push(new Blob([metadata], {
                            type: 'application/json'
                        }));
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Uploading template, please wait...')
                        $upload.upload({
                            url: $scope.ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/templates',
                            headers: {
                                'Content-Type': undefined,
                                'Authorization': $auth.getApiToken()
                            },
                            fileName: [file[0].name, 'metadata'],
                            fileFormDataName: ['file', 'metadata'],
                            file: file
                        }).success(function (data, status) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            if (status === uiConfig.OK || status === uiConfig.Created) {
                                if (data.indexOf(';') > 0) { // add item to template list
                                    $scope.upItem.objectId = data.split(';')[0];
                                } else {
                                    $scope.upItem.objectId = data;
                                }

                                $scope.upItem.objectType = 'template';
                                $scope.upItem.creationDate = $scope.upItem.effectiveDate;
                                $scope.gridTemplates.data.unshift($scope.upItem);
                                ConfirmationModalFactory.open('Template Uploader', 'Uploaded successfully!', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);

                            } else {
                                ConfirmationModalFactory.open('Template Uploader', 'Error of uploading! Status: ' + status, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                            }
                        })
                        .error(function (response) {
                            $log.error(response);
                        });
                    })
                    .error(function (response) {
                        $log.error(response);
                    });
            }
        };

        $scope.dateFormat = ENV.dateFormat;

        //used by advanced grid
        gridTemplatesTpl = {
            'excessRows': 400,
            enableSorting: true,
            enableVerticalScrollbar: uiGridConstants.scrollbars.NEVER,
            rowHeight: 85,
            // pagination
            enablePaginationControls: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: 20,
            useExternalPagination: true,
            useExternalSorting: true,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                headerCellTemplate: 'views/media-management/template/template-list/icon-col-header.html',
                cellTemplate: 'views/media-management/template/template-list/icon-col.html',
                width: 70,
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Template Name',
                cellTemplate: 'views/media-management/template/template-list/name-col.html',
                type: 'string',
                width: '38%',
                enableColumnMenu: false,
                enableSorting: true,
                enableHiding: false
            }, {
                name: 'businessEntity',
                displayName: 'Document Class',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.businessEntity}}</div>',
                type: 'string',
                width: '12%',
                enableColumnMenu: false,
                enableSorting: true,
                enableHiding: false
            }, {
                name: 'lastUsed',
                displayName: ' Last Used',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastUsed | amDateFormat:"'+ENV.dateFormat+'"}}</div>',
                type: 'string',
                width: '14%',
                enableColumnMenu: false,
                enableSorting: true,
                enableHiding: false
            }, {
                name: 'lastModificationDate',
                displayName: 'Last modified',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModificationDate | amDateFormat:"'+ENV.dateFormat+'"}}</div>',
                type: 'string',
                width: '14%',
                enableColumnMenu: false,
                enableSorting: true,
                enableHiding: false
            }, {
                name: 'createdBy',
                displayName: 'Created By',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.createdBy}}</div>',
                type: 'string',
                enableColumnMenu: false,
                enableSorting: true,
                enableHiding: false
            }]
        };

        gridTemplatesTpl.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                loadTemplateList();
            });
            gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                loadTemplateList();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
            gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
        };

        var setOrResetCheckList = function(row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };

        var setCheckList = function() {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };

        $scope.gridTemplates = gridTemplatesTpl;
        $scope.gridTemplates.data = 'templateList';

        loadTemplateList();

        $scope.viewTemplate = function(objectId, name, documentFormat) {
            Common.downloadAndNotify($scope.ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/templates/' + objectId + '/content', name, documentFormat);
        };

        $scope.quickViewTemplate = TemplateService.showTemplateSummaryDialog;

        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };

        $scope.selectCell = function(row) {
            $scope.checkList[row.entity.objectId] = PaginationService.selectCell($scope.gridApi, row, $scope.gridTemplates, $scope.checkList);
        };

        $scope.selectAllCell = function() {
            var selectAllCellVal = [];
            selectAllCellVal = PaginationService.selectAllCell($scope.selectAllChecker, $scope.gridApi, $scope.loadedTemplateList, $scope.checkList);
            $scope.checkList = selectAllCellVal[0];
            $scope.selectAllChecker = selectAllCellVal[1];
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };

        $scope.loaded = function() {
            PaginationService.setSortColumns(null);
            loadTemplateList();
        };

        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridTemplates.paginationCurrentPage = 1;
                loadTemplateList();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };
        $scope.pageSizeChanged = function() {
            $scope.gridTemplates.paginationCurrentPage = 1;
        };
        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };

        var filtersNeedToBeUpdateWithTemplateList = {
            'numProviderTiers': 'Number of Tiers'
        };

        function loadTemplateList() {
            if ($scope.searchQuery === undefined) {
                var currentSearchQuery = getSearchQuery();
                //Do not call API with same search query, which was in prvious API call
                if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                    return;
                }
                // Load data goes here
                $scope.loadedTemplateList = [];
                preSearchQuery = currentSearchQuery;

                DocumentDataFactory.getTemplates(encodeURI(currentSearchQuery)).then(function(data) {
                    angular.copy(data, $scope.templates);
                    $scope.gridTemplates.totalItems = data.response.numFound;
                    $scope.loadedTemplateList = FilterService.transformInput(data.response.docs);
                    /*
                            Jira Id: DOGVT-193,
                            Description: The looping used for initialize all customized grid selection.
                        */
                    angular.forEach($scope.loadedTemplateList, function(row) {
                        $scope.checkList[row.objectId] = false;
                    });
                    // refresh data
                    $scope.templateList = FilterService.filterAndrefresh($scope.loadedTemplateList, $scope.templateList);
                    //updateFilterMeta();
                    var attributesCollection = FilterService.updateFilterMeta(filtersNeedToBeUpdateWithTemplateList, $scope.loadedTemplateList, $scope.filtersGroups, 'template');
                    assignAttributes(attributesCollection);
                });
            }
        }

        function getSearchQuery() {
            var filterQuery = 'TYPE:"template"';
            var planYear = $scope.attrYear.field;

            if (planYear) {
                filterQuery += ' AND =templatePlanYear:"' + planYear + '" ';
            }

            var searchQuery = FilterService.getFilterQuery($scope.gridApi, $scope.templateSearchQuery, $scope.gridTemplates, $scope.selectedFilters, filterQuery, 'name', $scope.matchCase);
            return searchQuery + PaginationService.getSortQuery();
        }

        function assignAttributes(attributesCollection) {
            angular.forEach(attributesCollection, function(attrListVal) {
                angular.forEach(attrListVal, function(attrCollVal, attrCollKey) {
                    $scope[attrCollKey] = attrCollVal;
                });
            });
        }

        $scope.queryData = function(selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridTemplates);
            loadTemplateList();
        };

        // Template attributes are commented out because users can not search on these attributes due to multi-source templates
        // TODO: fix or remove them depending on whether filtering will be possible on those attributes
        //var templatePlanArr = {};
        var templateArray = {};

        function initializeTemplateArrays() {
            /*            templatePlanArr = {
                            '$scope.productAttributes': $scope.productAttributes,
                            '$scope.productTypeAttributes': $scope.productTypeAttributes,
                            '$scope.marketSegmentAttributes': $scope.marketSegmentAttributes,
                            '$scope.productTiersAttributes': $scope.productTiersAttributes,
                            '$scope.fundingArrangementAttributes': $scope.fundingArrangementAttributes
                        };*/

            templateArray = {
                '$scope.statusAttributes': $scope.statusAttributes,
                '$scope.docTypeAttributes': $scope.docTypeAttributes,
                '$scope.businessEntityAttributes': $scope.businessEntityAttributes,
                '$scope.effectiveDateAttributes': $scope.effectiveDateAttributes,
                '$scope.endDateAttributes': $scope.endDateAttributes,
                '$scope.createdByAttributes': $scope.createdByAttributes,
                '$scope.planYearAttributes': $scope.planYearAttributes
            };

            //templatePlanArr = Object.keys(templatePlanArr);
            templateArray = Object.keys(templateArray);
            iterateTemplateArr();
        }

        function iterateTemplateArr() {
            var resultArr = [];

            /*            angular.forEach(templatePlanArr, function(arrval) {
                            resultArr = assignPlanPropName(arrval);
                        });*/

            angular.forEach(templateArray, function(arrval) {
                resultArr = assignPropertyName(arrval);
            });
        }

        /*        function assignPlanPropName(arrVal) {
                    var propertyName = '';
                    var attrName = '';
                    var resultArr = [];
                    switch (arrVal) {
                        case '$scope.productAttributes':
                            propertyName = 'productClasses';
                            attrName = 'Products';
                            resultArr = pushProdAttrObjToTempArr(propertyName, attrName);
                            $scope.productAttributes = resultArr;
                            break;
                        case '$scope.productTypeAttributes':
                            propertyName = 'productTypes';
                            attrName = 'Product Types';
                            resultArr = pushProdAttrObjToTempArr(propertyName, attrName);
                            $scope.productTypeAttributes = resultArr;
                            break;
                        case '$scope.marketSegmentAttributes':
                            propertyName = 'marketSegments';
                            attrName = 'Market Segments';
                            resultArr = pushProdAttrObjToTempArr(propertyName, attrName);
                            $scope.marketSegmentAttributes = resultArr;
                            break;
                        case '$scope.fundingArrangementAttributes':
                            propertyName = 'fundingArrangements';
                            attrName = 'Funding Arrangements';
                            resultArr = pushProdAttrObjToTempArr(propertyName, attrName);
                            $scope.fundingArrangementAttributes = resultArr;
                            break;
                        case '$scope.productTiersAttributes':
                            propertyName = 'numProviderTiers';
                            attrName = 'Number of Provider Tiers';
                            resultArr = pushProvidertiersObj(propertyName, attrName);
                            $scope.productTiersAttributes = resultArr;
                            break;
                    }
                    return resultArr;
                }*/

        function assignPropertyName(arrval) {
            var propertyName = '';
            var attrName = '';
            var resultArr = [];
            switch (arrval) {
                case '$scope.statusAttributes':
                    propertyName = 'templateStatus';
                    attrName = 'Status';
                    resultArr = pushAttrObjToTempArr(propertyName, attrName);
                    $scope.statusAttributes = resultArr;
                    break;
                case '$scope.docTypeAttributes':
                    propertyName = 'documentType';
                    attrName = 'Document Type';
                    resultArr = pushAttrObjToTempArr(propertyName, attrName);
                    $scope.docTypeAttributes = resultArr;
                    break;
                case '$scope.businessEntityAttributes':
                    propertyName = 'businessEntity';
                    attrName = 'Business Entity';
                    resultArr = pushAttrObjToTempArr(propertyName, attrName);
                    $scope.businessEntityAttributes = resultArr;
                    break;
                case '$scope.effectiveDateAttributes':
                    propertyName = 'effectiveDate';
                    attrName = 'Effective Date';
                    resultArr = pushEffectiveDateObj(propertyName, attrName);
                    $scope.effectiveDateAttributes = resultArr;
                    break;
                case '$scope.endDateAttributes':
                    propertyName = 'endDate';
                    attrName = 'End Date';
                    resultArr = pushEndDateObj(propertyName, attrName);
                    $scope.endDateAttributes = resultArr;
                    break;
                case '$scope.createdByAttributes':
                    propertyName = 'createdBy';
                    attrName = 'created By';
                    resultArr = pushAttrObjToTempOwnerArr(propertyName, attrName);
                    $scope.createdByAttributes = resultArr;
                    break;
                case '$scope.planYearAttributes':
                    propertyName = 'templatePlanYear';
                    attrName = 'Plan Year';
                    resultArr = pushPlanYearObj(propertyName, attrName);
                    $scope.planYearAttributes = resultArr;
                    break;
            }
            return resultArr;
        }

        function pushAttrObjToTempArr(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.templateFiltersProperties[propertyName]['enum'], function(arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.templateFiltersProperties[propertyName]['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        /*        function pushProdAttrObjToTempArr(propertyName, attrName) {
                    var objArr = [];
                    angular.forEach($scope.templateFiltersProductProperties[propertyName]['items']['enum'], function(arrVal) {
                        var attrObj = attrName + arrVal;
                        attrObj = {};
                        attrObj['AttributeId'] = $scope.templateFiltersProductProperties[propertyName]['name'];
                        attrObj['AttributeName'] = attrName;
                        attrObj['AttributeValue'] = arrVal;
                        attrObj['DisplayValue'] = arrVal;
                        objArr.push(attrObj);
                    });
                    return objArr;
                }*/

        /*        function pushProvidertiersObj(propertyName, attrName) {
                    var objArr = [];
                    var count = 0;
                    angular.forEach($scope.numProviderTiers['enum'], function(arrVal) {
                        count++;
                        var attrObj = attrName + arrVal;
                        attrObj = {};
                        if (count <= 4) {
                            attrObj['AttributeId'] = $scope.numProviderTiers['name'];
                            attrObj['AttributeName'] = attrName;
                            attrObj['AttributeValue'] = compareNumProvidertiersValues(arrVal);
                            attrObj['DisplayValue'] = compareNumProvidertiersValues(arrVal);
                            objArr.push(attrObj);
                        }
                    });
                    return objArr;
                }*/

        function pushEffectiveDateObj(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.effectiveDate['enum'], function(arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.effectiveDate['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushEndDateObj(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.endDate['enum'], function(arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.endDate['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushPlanYearObj(propertyName, attrName) {
            var objArr = [];
            angular.forEach($scope.planYearArr['enum'], function (arrVal) {
                var attrObj = attrName + arrVal;
                attrObj = {};
                attrObj['AttributeId'] = $scope.planYearArr['name'];
                attrObj['AttributeName'] = attrName;
                attrObj['AttributeValue'] = arrVal;
                attrObj['DisplayValue'] = arrVal;
                objArr.push(attrObj);
            });
            return objArr;
        }

        function pushAttrObjToTempOwnerArr(propertyName, attrName) {
            var objArr = [];
            var arrVal = 'Me';
            var attrObj = attrName + arrVal;
            attrObj = {};
            attrObj['AttributeId'] = $scope.templateFiltersProperties[propertyName]['name'];
            attrObj['AttributeName'] = attrName;
            attrObj['AttributeValue'] = $scope.userInformation.data.user.email;
            attrObj['DisplayValue'] = arrVal;
            objArr.push(attrObj);
            return objArr;
        }

        /*        function compareNumProvidertiersValues(arrVal) {
                    if (arrVal >= 4) {
                        arrVal = '>=4';
                    }
                    return arrVal;
                }*/
    });