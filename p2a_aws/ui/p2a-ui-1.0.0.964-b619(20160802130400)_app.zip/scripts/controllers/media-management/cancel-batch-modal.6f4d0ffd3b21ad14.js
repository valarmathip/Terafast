﻿'use strict';

angular.module('p2AdvanceApp')
  .controller('CancelBatchCtrl', function (
        $scope,
        $modalInstance,
        ModalDialogFactory)
    {

      $scope.confirmCancel = function (toConfirm) {
        ModalDialogFactory.closeDialog(toConfirm);
      };

      $scope.closeCancelBatchModal = function () {
        $modalInstance.dismiss('cancel');
      };

  });
