'use strict';

angular.module('p2AdvanceApp')
    .controller('SelectOfferingPlansCtrl', function (
        $scope,
        offeringPlans,
        ENV,
        PaginationService,
        FilterService,
        uiGridConstants
        ) {
       
        $scope.$parent.selectedState = 'offeringPlans';
        $scope.$parent.selectedTitle = 'Select Plans';
        $scope.$parent.selectedGridOfferingPlans = [];

        $scope.selectAllChecker = false;
        $scope.selectChecker = false;
        $scope.checkList = [];

        var setOrResetCheckList = function (row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };
        var setCheckList = function () {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };

        $scope.toggleSelection = function (row) {
            if (!$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = true;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }

            $scope.$parent.selectedGridOfferingPlans = $scope.gridApi.selection.getSelectedRows();
            $scope.checkList[row.entity.objectId] = $scope.selectChecker;
        };

        $scope.selectAllItems = function () {
            if (!$scope.selectAllChecker) {
                var rows = $scope.gridApi.grid.getVisibleRows();  // select rows on one page of the grid

                angular.forEach(rows, function (row) {
                    row.isSelected = true;
                    row.enableSelection = true;
                    $scope.gridApi.selection.selectRow(row);
                });

                $scope.selectAllChecker = true;

            } else {
                angular.forEach($scope.gridApi.grid.rows, function (row) {
                    row.isSelected = false;
                    row.enableSelection = true;
                });

                $scope.gridApi.selection.clearSelectedRows();
                $scope.selectAllChecker = false;
            }

            $scope.$parent.selectedGridOfferingPlans = $scope.gridApi.selection.getSelectedRows();

            angular.forEach($scope.selectedGridOfferingPlans, function (plan) {
                $scope.checkList[plan.objectId] = $scope.selectAllChecker;
            });
        };

        $scope.gridOfferingPlans = {
            data: offeringPlans,
            'excessRows': 400,
            enableSorting: true,
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: 20,
            multiSelect: true,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            rowHeight: 105, // never put number in "", like "100"
            minRowsToShow: 6,
            useExternalPagination: false,
            useExternalSorting: false,

            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableColumnMenu: false,
                headerCellTemplate: 'views/media-management/template/offering-plans/icon-col-header.html',
                cellTemplate: 'views/media-management/template/offering-plans/icon-col.html',
                width: 60,
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Source Name',
                width: '75%',
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                cellTemplate: 'views/media-management/template/offering-plans/name-col.html'
            }, {
                name: 'Source Type',
                displayName: 'Source Type',
                width: '20%',
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.objectType}}</div>'
            }],

            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
                gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
                gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
            }

        };

        /** Pagination */
        $scope.pageVal = {
            pageNumber: ''
        };

        $scope.navPage = function ($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.currentPage = $scope.gridApi.pagination.getPage();
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        };

        $scope.viewPages = function () {
            return PaginationService.viewPages($scope.gridApi, []);
        };

        $scope.pageSizeChanged = function (ps) { /* jshint ignore:line */
            // If page size changed, start the pages from beginning.
            // In fact, ui-grid can automatically reset the start page
            // if change page size larger and total page number reduced.
            // If you want the offering not start from begin, comment out this line.
            $scope.gridOfferingPlans.paginationCurrentPage = 1;
        };

        $scope.goToPage = function (keyEvent) {
            PaginationService.goToPage(keyEvent, $scope.pageVal, $scope.gridApi);
        };
        /* End of Pagination */

        $scope.loaded = function () {
            if (!PaginationService.getSortColumns()) {
                PaginationService.setSortColumns(null);
            }
            loadData();
            //updateFilterMeta();
        };

        $scope.queryData = function (selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOfferingPlans);
            $scope.currentPage = 1;
            loadData();
        };

        $scope.doSearch = function (keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridOfferingPlans.paginationCurrentPage = 1;
                $scope.currentPage = 1;
                loadData();
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
        };

        $scope.updateSelectIdToObjsMap = function (selectedId, objs) {
            // look if selectedId exists in the map
            var isFound = false;
            angular.forEach($scope.selectedIdToObjsMap, function (selectedIdToObjs) {
                if (selectedIdToObjs.selectedId === selectedId) {
                    selectedIdToObjs.objs = objs;
                    isFound = true;
                }
            });
            if (isFound === false) { // create new selectedId 
                $scope.selectedIdToObjsMap[$scope.selectedIdToObjsMap.length] = {
                    'selectedId': selectedId,
                    'objs': objs
                };
            }
        };

        //get the filtered data by selections
        $scope.queryData = function (selectedId, objs) {
            $scope.updateSelectIdToObjsMap(selectedId, objs);

            $scope.gridOfferingPlans.paginationCurrentPage = 1;
            loadData();
        };

        //initializeOfferingArrays();

        //function initializeOfferingArrays() {
        //    var initArr = PPMFilterMetaSvc.initializeOfferArr();
        //    $scope.filtersGroups = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, offeringProp, aspectDefProp);
        //}
        /* End Filters */
        // load data according to the new criteria (pagination, sort and filter)
        function loadData() {
            // todo check for empty filter load.
            //var queryString = getQueryString();

            //var associationExpansionLevel = 0;
            //ProductPlanMgmtSvc.getOfferintListViaSearchApi(queryString, associationExpansionLevel)
            //    .then(function (offeringData) {
            offeringListLoaded(offeringPlans);
                //});
        }


        function offeringListLoaded(plans) {
            if (plans) {
                //$scope.offeringList = plans.response.docs;
                $scope.gridOfferingPlans.totalItems = plans.length;
            } else {
                //$scope.offeringList = [];
                $scope.gridOfferingPlans.totalItems = 0;
            }
        }

        offeringListLoaded(offeringPlans);


    });