'use strict';

angular.module('p2AdvanceApp')
    .controller('SelectTemplateCtrl', function(
        $scope,
        $filter,
        DocumentDataFactory,
        FilterDataService,
        ModalDialogFactory,
        $log,
        $state,
        $modalInstance,
        ENV,
        templateFiltersMetaData,
        aspectsMetaData,
        templatesPromise,
        isMultiSourceDoc,
        documentType,
        PaginationService,
        FilterService,
        authorizedUserInfo)
    {
        $scope.templates = templatesPromise.response.docs;
        $scope.templatesForPlanOrUnit = []; //need to separate plan templates from unit templates, this is for single source templates
        $scope.templatesForMultiSource = []; //hold multi source templates
        $scope.userInformation = authorizedUserInfo;
        $scope.allFiltersData = [];
        $scope.allFiltersData = FilterDataService.getTemplateFilters(templateFiltersMetaData, aspectsMetaData, templatesPromise.response.docs, $scope.userInformation.data.user.email);
        $scope.docType = documentType;

        $scope.attrYear = {
            field: ''
        };

        $scope.checkList = {};   // grid single selection

        // do not allow template multi-selection
        $scope.toggleSelection = function (row) {
            $scope.gridApi.selection.clearSelectedRows();

            if (!row.isSelected && !$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);                
            } else {
                row.isSelected = false;
                row.enableSelection = false;
                $scope.gridApi.selection.unSelectRow(row);              
            }

            $scope.checkList = {};
            $scope.checkList[row.entity.objectId] = row.isSelected;
            $scope.selectedGridTemplates = $scope.gridApi.selection.getSelectedRows();
        };

        $scope.selectedIdToObjsMap = [];
        var pageSize = 20; // SLQ
        $scope.currentPage = {
            all: 1,
            draft: 1,
            override: 1,
            published: 1
        };

        $scope.gridTemplates = {
            totalItems: templatesPromise.response.numFound,
            data: $scope.templates,
            multiSelect: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 0,
            rowHeight: 70,
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            useExternalPagination: true,
            useExternalSorting: true,
            columnDefs: [{
                name: 'objectId',
                displayName: '',
                enableColumnMenu: false,
                headerCellTemplate: '<input data-hraf-id="modal-select-all-templates-checkbox" type="checkbox" class="grid-checkbox-position">',
                cellTemplate: '<input data-hraf-id="modal-template-{{row.entity.objectId}}-checkbox" type="checkbox" class="grid-checkbox-position"' +
                              'ng-model="grid.appScope.checkList[row.entity.objectId]" ng-checked="grid.appScope.checkList[row.entity.objectId]"' +
                              'ng-click="grid.appScope.toggleSelection(row)"/>',
                width: 60,
                enableHiding: false
            }, {
                name: 'name',
                displayName: 'Template Name',
                enableColumnMenu: false,
                cellTemplate: '<div><span data-hraf-id="modal-template-{{row.entity.objectId}}-name" class="ui-grid-cell-contents cell-visible">{{row.entity.name}}</span>' +
                    '<span data-hraf-id="modal-template-{{row.entity.objectId}}-validity">(Valid: {{row.entity.effectiveDate | amDateFormat:"MMM DD YYYY"}} - {{row.entity.endDate | amDateFormat:"MMM DD YYYY"}})</span>' +
                    '</div>',
                width: '40%'
            }, {
                name: 'description',
                displayName: 'Template Description',
                enableColumnMenu: false,
                cellTemplate: '<div data-hraf-id="modal-template-{{row.entity.objectId}}-description" class="ui-grid-cell-contents cell-visible textar-expression">{{row.entity.description}}</div>',
                type: 'string',
                width: '60%'
            }],

            onRegisterApi: function(gridApi) {
                //set gridApi on scope
                $scope.gridApi = gridApi;
                $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                    if (sortColumns.length === 0) {
                        paginationOptions.sort = null;
                    } else {
                        paginationOptions.sort = sortColumns[0].sort.direction;
                    }
                    loadData();
                });
                gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                    paginationOptions.pageNumber = newPage;
                    paginationOptions.pageSize = pageSize;
                    $scope.gridTemplates.virtualizationThreshold = pageSize;
                    loadData();
                    if (!PaginationService.isGoToPageEnabled) {
                        $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                    }
                    PaginationService.setGoToPageEnabled(false);
                });

            }

        };

        function loadData() {

            $scope.gridTemplates.data = [];

            var templateQueryStr = '';
            var planYear = $scope.attrYear.field;

            if (isMultiSourceDoc) {
                templateQueryStr = 'TYPE:"template" AND templateStatus:"Published" AND NOT numSources:1 AND isUnit:false AND documentType: "' + $scope.docType + '"';
            } else {
                templateQueryStr = 'TYPE:"template" AND templateStatus:"Published" AND numSources:1 AND documentType: "' + $scope.docType + '"'; // removed 'AND isUnit:false AND numSources:"1"', wrong for single source
            }

            if (planYear) {
                templateQueryStr += ' AND =templatePlanYear:"' + planYear + '" ';
            }

            var currentSearchQuery = FilterService.getFilterQueryDocGen($scope.gridApi, $scope.templateNameSearchQuery, $scope.gridTemplates, $scope.selectedIdToObjsMap, templateQueryStr, $scope.matchCase);

            DocumentDataFactory.getAllTemplates(isMultiSourceDoc, true, currentSearchQuery).then(function(data) {
                $scope.gridTemplates.data = data.response.docs;
                $scope.gridTemplates.totalItems = data.response.numFound;

                // if this is for single source templates, need to separate plan templates from unit templates
                if (!isMultiSourceDoc) {
                    var gridDataSource = [];

                    angular.forEach(data.response.docs, function(item) {
                        if (item.isUnit === true) {
                            if (DocumentDataFactory.getIsForUnitTemplates()) {
                                gridDataSource.push(item);
                            }
                        } else {
                            if (!DocumentDataFactory.getIsForUnitTemplates()) {
                                if (item.numSources === 1) {
                                    gridDataSource.push(item);
                                }
                            }
                        }
                    });

                    $scope.gridTemplates.data = gridDataSource;
                }

            });
        }

        $scope.pageVal = {
            pageNumber: ''
        };

        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };

        $scope.isAnyFilters = function() {
            var length = 0;
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                length += selectedIdToObjs.objs.length;
            });
            if (length > 0) {
                return true;
            }
            return false;
        };
        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridTemplates.paginationCurrentPage = 1;
                loadData();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };
        $scope.pageSizeChanged = function() {
            $scope.gridTemplates.paginationCurrentPage = 1;
        };
        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };
        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };
        $scope.loaded = function() {
            loadData();
        };

        $scope.updateSelectIdToObjsMap = function(selectedId, objs) {
            // look if selectedId exists in the map
            var isFound = false;
            angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
                if (selectedIdToObjs.selectedId === selectedId) {
                    selectedIdToObjs.objs = objs;
                    isFound = true;
                }
            });
            if (isFound === false) { // create new selectedId 
                $scope.selectedIdToObjsMap[$scope.selectedIdToObjsMap.length] = {
                    'selectedId': selectedId,
                    'objs': objs
                };
            }
        };

        //get the filtered data by selections
        $scope.queryData = function(selectedId, objs) {
            $scope.updateSelectIdToObjsMap(selectedId, objs);

            $scope.gridTemplates.paginationCurrentPage = 1;
            loadData();
        };

        $scope.ok = function () {
            var templateJSON = null;
            if ($scope.selectedGridTemplates != null) {
                var selectedTemplate = $scope.selectedGridTemplates[0];
                templateJSON = { 'objectId': selectedTemplate.objectId, 'name': selectedTemplate.name, 'description': selectedTemplate.description, 'sources': selectedTemplate.templateSources };
            }

            ModalDialogFactory.closeDialog(templateJSON);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

    });