﻿'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller: AssignPropertiesCtrl
 * @description
 * # AssignPropertiesCtrl
 * Controller of the p2AdvanceApp under Media Management
 */
angular.module('p2AdvanceApp')
    .controller('AssignPropertiesCtrl',
        function ($scope,
            $rootScope,
            $log,
            $modalInstance,
            defineDocumentFieldsMetaData,
            documentProductPropertiesMetaData,
            numProviderTiers,
            isMultiSourceDoc,
            nameExists,
            documentNames) {

            $scope.nameExists = nameExists;
            $scope.defineDocumentProperties = defineDocumentFieldsMetaData && defineDocumentFieldsMetaData[0] ? defineDocumentFieldsMetaData[0].properties : [];
            $scope.defineDocumentProductProp = documentProductPropertiesMetaData && documentProductPropertiesMetaData[0] ? documentProductPropertiesMetaData[0].properties : [];
            $scope.defineDocumentProductProp.numProviderTiers = numProviderTiers;

            $scope.requiredFields = defineDocumentFieldsMetaData[0].required;

            $scope.isMultiSourceDoc = isMultiSourceDoc;
            $scope.metadata = { documentNames: documentNames };

            $scope.documentDetails = {};
            $scope.source = {};
            $scope.source.productClasses = {};
            $scope.source.productTypes = {};
            $scope.source.marketSegments = {};

            $scope.documentDetails[$scope.defineDocumentProperties.effectiveDate.name] = new Date();
            if (!isMultiSourceDoc) {
                $scope.documentDetails[$scope.defineDocumentProperties.docName.name] = documentNames.replace(/.[^.]+$/, '');
            }

            $scope.datePicker = (function () {
                var method = {};
                method.instances = [];

                method.open = function ($event, instance) {
                    $event.preventDefault();
                    $event.stopPropagation();

                    method.instances[instance] = true;
                };

                method.options = {
                    'show-weeks': false,
                    startingDay: 0
                };

                return method;
            }());

            function validateDocument() {
                $scope.documentStatusMissing = !$scope.documentDetails[$scope.defineDocumentProperties.documentStatus.name] || $scope.documentDetails[$scope.defineDocumentProperties.documentStatus.name].length === 0;
                $scope.documentTypeMissing = !$scope.documentDetails[$scope.defineDocumentProperties.documentType.name] || $scope.documentDetails[$scope.defineDocumentProperties.documentType.name].length === 0;
                $scope.businessEntityMissing = !$scope.documentDetails[$scope.defineDocumentProperties.businessEntity.name] || $scope.documentDetails[$scope.defineDocumentProperties.businessEntity.name].length === 0;

                if (!isMultiSourceDoc) {
                    $scope.documentNameMissing = !$scope.documentDetails[$scope.defineDocumentProperties.docName.name] || $scope.documentDetails[$scope.defineDocumentProperties.docName.name] === 0;
                    $scope.documentNameLength = $scope.documentDetails[$scope.defineDocumentProperties.docName.name] !== undefined && $scope.documentDetails[$scope.defineDocumentProperties.docName.name].length > 50;
                }
                $scope.effectiveDateMissing = !$scope.documentDetails[$scope.defineDocumentProperties.effectiveDate.name];

                $scope.effectiveDateCheck = $scope.documentDetails[$scope.defineDocumentProperties.effectiveDate.name] && $scope.documentDetails[$scope.defineDocumentProperties.endDate.name] &&
                                            $scope.documentDetails[$scope.defineDocumentProperties.effectiveDate.name] > $scope.documentDetails[$scope.defineDocumentProperties.endDate.name];

                return !$scope.documentStatusMissing && !$scope.documentTypeMissing && !$scope.businessEntityMissing && !$scope.documentNameMissing &&
                       !$scope.documentNameLength && !$scope.effectiveDateMissing && !$scope.effectiveDateCheck;
            }

            function cleanAndCopyDocumentSources() {
                var multipleSources = ['productClasses', 'productTypes', 'marketSegments'];
                angular.forEach(multipleSources, function (key) {
                    var val = $scope.source[key];
                    if (typeof val !== 'undefined') {
                        if (val !== null) {
                            if (typeof val === 'object') {
                                var cleanedSelection = [];
                                angular.forEach(val, function (objVal, objKey) {
                                    if (objVal) {
                                        cleanedSelection.push(objKey);
                                    }
                                });
                                $scope.documentDetails[key] = cleanedSelection;
                            }
                        }
                    }
                }
            );
        }

            $scope.ok = function () {
                if (validateDocument()) {
                    cleanAndCopyDocumentSources();
                    $modalInstance.close($scope.documentDetails);
                }
            };

            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };

        });
