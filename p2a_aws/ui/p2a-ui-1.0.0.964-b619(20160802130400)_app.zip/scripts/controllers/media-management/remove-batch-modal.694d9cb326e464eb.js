﻿'use strict';

angular.module('p2AdvanceApp')
  .controller('RemoveBatchCtrl', function (
        $scope,
        $modalInstance,
        ModalDialogFactory)
    {

      $scope.confirmRemoval = function (toConfirm) {
        ModalDialogFactory.closeDialog(toConfirm);
      };

      $scope.closeRemoveBatchModal = function () {
        $modalInstance.dismiss('cancel');
      };

  });
