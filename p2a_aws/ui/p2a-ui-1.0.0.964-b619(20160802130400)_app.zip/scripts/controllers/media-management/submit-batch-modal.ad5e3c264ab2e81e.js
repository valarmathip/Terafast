'use strict';

angular.module('p2AdvanceApp')
  .controller('SubmitBatchCtrl', function (
        $scope,
        $modalInstance,
        ModalDialogFactory)
    {

      $scope.confirmSubmit = function (toConfirm) {
        ModalDialogFactory.closeDialog(toConfirm);
      };

      $scope.closeSubmitBatchModal = function () {
        $modalInstance.dismiss('cancel');
      };

  });
