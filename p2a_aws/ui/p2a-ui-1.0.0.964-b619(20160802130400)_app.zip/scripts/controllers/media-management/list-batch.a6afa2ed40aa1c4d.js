﻿'use strict';

angular.module('p2AdvanceApp')
    .controller('listBatchCtrl', function(
        $scope,
        $rootScope,
        $state,
        $stateParams,
        $log,
        $filter,
        PaginationService,
        BatchService,
        FilterDataService,
        FilterService,
        DatePickerFilterService,
        ENV,
        ENV_MEDIA_MANAGEMENT,
        ConfirmationModalFactory,
        uiGridConstants,
        filtersMeta,
        batchList,
        dialogFactorySvc,
        submittedByUsers,
        ModalDialogFactory
    ) {
        $scope.selectAllChecker = false;
        $scope.selectChecker = false;
        $scope.batchList = [];
        $scope.selectedFilters = {};
        $scope.checkList = {};
        $scope.filters = FilterDataService.updateListBatchFilters(filtersMeta, submittedByUsers);
        var preSearchQuery = null;

        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };
        var pageSize = 20;

        var setOrResetCheckList = function(row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
        };

        var setCheckList = function() {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };

        var submitBatch = function(row) {

            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-submit-batch.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            BatchService.integrationWithSubmitBatch(row);
                        }
                    });
        };

        var reSubmitFailedCancelledJobsBatch = function(row) {

            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-resubmit-failed-cancelled-batch-jobs.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            BatchService.integrationWithReSubmitFailedCancelledJobsBatch(row);
                        }
                    });
        };

        var reSubmitAllJobsBatch = function(row) {

            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-resubmit-batch.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            BatchService.integrationWithReSubmitAllBatchJobs(row);
                        }
                    });
        };

        var cancelBatch = function(row) {

            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-batch-cancel.html',
                controller: 'SubmitBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            if (row && row.objectId) {
                                BatchService.getBatchById(row.objectId)
                                    .then(
                                        // Sucess
                                        function(batch) {
                                            if (batch && batch.data &&
                                                (batch.data.batchStatus === 'In progress' ||
                                                    batch.data.batchStatus === 'Submitted')) {
                                                var batchIdsToBeCanceled = [];
                                                batchIdsToBeCanceled.push(row.objectId);
                                                BatchService.cancelBatch(batchIdsToBeCanceled)
                                                    .then(
                                                        // Success    
                                                        function(data) {
                                                            row.status = data[0].value;
                                                            ConfirmationModalFactory.open('Message', 'Cancel Batch is processing.', ENV.modalErrorTimeout);
                                                        },
                                                        // Error
                                                        function(error) {
                                                            $log.error('Error Canceling batch' + error.message);
                                                        });
                                            } else {
                                                ConfirmationModalFactory.open('Error', 'Batch status (' + batch.data.batchStatus + ') is invalid to cancel a Batch.', ENV.modalErrorTimeout);
                                            }
                                        });
                            } else {
                                ConfirmationModalFactory.open('Error', 'Error Submitting batch', ENV.modalErrorTimeout);
                                $log.error('Error Submitting batch');
                            }
                        }
                    });
        };

        var editBatch = function(row) {
            $state.go('home.media-management.generateDocument', {
                'batchObjectId': row.objectId
            });
        };

        var removeBatch = function(row) { // not really delete a batch from CM
            var dialogOptions = {
                templateUrl: 'views/media-management/confirm-batch-removal.html',
                controller: 'RemoveBatchCtrl',
                size: 'md',
                backdrop: false
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            if (row && row.objectId) {
                                BatchService.getBatchById(row.objectId)
                                    .then(
                                        // Sucess
                                        function(batch) {
                                            if (batch && batch.data &&
                                                (batch.data.batchStatus !== 'In progress' &&
                                                    batch.data.batchStatus !== 'Submitted')) {

                                                BatchService.removeBatch(row.objectId)
                                                    .then(
                                                        function() {
                                                            loadData(); //refresh batch list

                                                            var newlyloadedBatchList = [];

                                                            for (var i = 0, j = $scope.loadedBatchList.length; i < j; i++) {
                                                                newlyloadedBatchList.push($scope.loadedBatchList[i].objectId);
                                                            }

                                                            var idx = newlyloadedBatchList.indexOf(row.objectId);

                                                            if (idx > -1) { // search api sometimes doesn't refresh grid well so we have to do some manual work below
                                                                $scope.loadedBatchList.splice(idx, 1);

                                                                $scope.batchList = [];
                                                                angular.forEach($scope.loadedBatchList, function(item) {
                                                                    $scope.batchList.push({
                                                                        name: item.name,
                                                                        batchSubmittedBy: item.batchSubmittedBy,
                                                                        batchSubmittedDate: item.batchSubmittedDate,
                                                                        status: item.batchStatus,
                                                                        objectId: item.objectId,
                                                                        batchStatusDetails: item.batchStatusDetails,
                                                                        batchJobs: item.batchJobs,
                                                                        batchJobsDetail: item.batchJobs,
                                                                        batchJobsObjectIds: batchJobsObject(item.batchJobs)
                                                                    });
                                                                });

                                                            }

                                                            ConfirmationModalFactory.open('Success', 'Batch has been removed successfully.', ENV.modalErrorTimeout);

                                                        },
                                                        function(error) {
                                                            $log.error('Error removing batch' + error.message);
                                                        });
                                            } else {
                                                ConfirmationModalFactory.open('Error', 'Batch status (' + batch.data.batchStatus + ') is invalid to remove a Batch.', ENV.modalErrorTimeout);
                                            }
                                        });
                            } else {
                                $log.error('Error removing batch');
                            }
                        }
                    });
        };

        $scope.gridBatch = {
            //enableColumnResizing: false,
            data: 'batchList',
            'excessRows': 400,
            enablePaginationControls: false,
            useExternalPagination: true,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            useExternalSorting: true,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            rowHeight: 90,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            columnDefs: [{
                displayName: '',
                name: 'X1',
                field: 'element1',
                width: 100,
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: false,
                headerCellTemplate: 'views/media-management/template/batch-list/icon-col-header.html',
                cellTemplate: 'views/media-management/template/batch-list/icon-col.html'
            }, {
                name: 'name',
                displayName: 'Batch Name',
                enableSorting: true,
                cellTemplate: 'views/media-management/template/batch-list/name-col.html',
                type: 'string',
                width: '35%',
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'batchSubmittedBy',
                displayName: 'Submitted By',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.batchSubmittedBy}}</div>',
                type: 'string',
                width: '30%',
                enableHiding: false,
                enableColumnMenu: false
            }, {
                name: 'batchSubmittedDate',
                displayName: 'Submitted On',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.batchSubmittedDate | amDateFormat:"' + ENV.dateFormat + '"}}</div>',
                type: 'string',
                width: '30%',
                enableHiding: false,
                enableColumnMenu: false
            }]
        };
        updateBatchList(batchList);

        $scope.hoverItems = [{
            label: 'Resubmit All Jobs',
            icon: 'fa-retweet',
            isShown: function(row) {
                return (row.batchJobs && row.batchJobs.length > 0) && (row.status === 'Cancelled' ||
                    row.status === 'Failed' ||
                    row.status === 'Partially Successful' ||
                    row.status === 'Successful');
            },
            action: reSubmitAllJobsBatch,
            permission: '|all.update,|all.create,|document.create,|document.update'
        }, {
            label: 'Resubmit Failed/Cancelled Jobs',
            icon: 'fa-retweet',
            isShown: function(row) {
                return (row.batchJobs && row.batchJobs.length > 0) && (row.status === 'Cancelled' ||
                    row.status === 'Failed' ||
                    row.status === 'Partially Successful');
            },
            action: reSubmitFailedCancelledJobsBatch,
            permission: '|all.update,|all.create,|document.create,|document.update'
        }, {
            label: 'Submit Batch',
            icon: 'fa-share',
            isShown: function(row) {
                return row.batchJobs && row.batchJobs.length > 0 && row.status === 'Draft';
            },
            action: submitBatch,
            permission: '|all.update,|all.create,|document.create,|document.update'
        }, {
            label: 'Edit Batch',
            icon: 'fa-pencil',
            isShown: function(row) {
                return row.status === 'Cancelled' ||
                    row.status === 'Failed' ||
                    row.status === 'Partially Successful' ||
                    row.status === 'Successful' ||
                    row.status === 'Draft';
            },
            action: editBatch,
            permission: '|all.update,|all.create,|document.create,|document.update'
        }, {
            label: 'Cancel Batch',
            icon: 'fa-times-circle-o',
            isShown: function(row) {
                return row.status === 'In progress' ||
                    row.status === 'Submitted';
            },
            action: cancelBatch,
            permission: '|all.update,|all.create,|document.create,|document.update'
        }, {
            label: 'Remove Batch',
            icon: 'fa-trash',
            isShown: function(row) {
                return row.status !== 'In progress' &&
                    row.status !== 'Submitted';
            },
            action: removeBatch,
            permission: '|all.update,|all.create,|document.create,|document.update'
        }];

        // context menu actions
        $scope.contextMenu = {
            resubmit: {
                id: 'resubmit',
                action: function(guid) {
                    $log.info('guid = ' + guid);
                },
                enabled: true
            },
            submit: {
                id: 'submit',
                action: function(guid) {
                    $log.info('guid = ' + guid);
                },
                enabled: true
            },
            edit: {
                id: 'edit',
                action: function(guid) {
                    $log.info('guid = ' + guid);
                },
                enabled: true
            }
        };

        //filterId should be added on adding date widget to a filter
        $scope.datePicker = {
            fromDate: {
                batchSubmittedDate: []
            },
            toDate: {
                batchSubmittedDate: []
            }
        };
        $scope.attrYear = {
            field: ''
        };
        $scope.dateOptions = {
            showWeeks: false
        };

        function updateBatchList(data) {
            $scope.batchList = [];
            $scope.loadedBatchList = [];
            $scope.gridBatch.totalItems = data.response.numFound;
            $scope.loadedBatchList = data.response.docs;
            angular.forEach($scope.loadedBatchList, function(item) {
                $scope.batchList.push({
                    name: item.name,
                    batchSubmittedBy: item.batchSubmittedBy,
                    batchSubmittedDate: item.batchSubmittedDate,
                    status: item.batchStatus,
                    objectId: item.objectId,
                    batchStatusDetails: item.batchStatusDetails,
                    //batchJobs: batchJobsObject(item.batchJobs),
                    batchJobs: item.batchJobs, // need the full expansion of batchJob to get to taskDocument's property batchJobTaskDocumentIsMultiSource
                    batchJobsDetail: item.batchJobs,
                    batchJobsObjectIds: batchJobsObject(item.batchJobs) // Using this for batch summary module
                });
            });
        }

        function batchJobsObject(jobArray) {
            var object = '';
            var length = 1;
            angular.forEach(jobArray, function(item) {
                object += item.objectId;
                if (jobArray.length !== length) {
                    object += ',';
                }
                length = length + 1;
            });
            return object;
        }

        $scope.gridBatch.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                loadData();
            });
            $scope.gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                loadData();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
            $scope.gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            $scope.gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
        };

        loadData();

        function loadData() {
            //var filterQuery = '?q=TYPE:"batch" AND batchArchived: false ';
            var filterQuery = '?q=TYPE:"batch" ';   // MarkLogic doesn't have batchArchived false as default value anymore, we'll find another solution ASAP
            var currentSearchQuery = FilterService.getFilterQuery($scope.gridApi, $scope.batchSearchQuery, $scope.gridBatch, $scope.selectedFilters, filterQuery, 'name', $scope.matchCase, 'batchSubmittedDate',
                $scope.datePicker.fromDate, $scope.datePicker.toDate, -1);
            currentSearchQuery += PaginationService.getSortQuery();

            //var currentSearchQuery = FilterService.getFilterQuery($scope.gridApi, $scope.batchSearchQuery, $scope.gridBatch, $scope.selectedFilters, filterQuery, 'name', $scope.matchCase);
            if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                return;
            }
            preSearchQuery = currentSearchQuery;
            BatchService.getPaginationAPI(currentSearchQuery).then(function(data) {
                updateBatchList(data.data);
            });
        }

        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };

        $scope.pageSizeChanged = function() {
            $scope.gridBatch.paginationCurrentPage = 1;
        };


        $scope.queryData = function(selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridBatch);
            loadData();
        };
        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridBatch.paginationCurrentPage = 1;
                loadData();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };

        $scope.openCalendar = function($event, $index, effectiveDate) {
            $scope.calendarOpened = {};
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[effectiveDate]) {
                $scope.calendarOpened[effectiveDate] = [];
            }

            $scope.calendarOpened[effectiveDate][$index] = true;
        };
        $scope.clearAll = function() {
            $rootScope.$broadcast('clearAllSelected');
        };
        $scope.loaded = function() {
            PaginationService.setSortColumns(null);
            if ($scope.datePicker.fromDate !== '' && $scope.datePicker.toDate !== '') {
                loadData();
            }

        };
        $scope.selectCell = function(row) {
            if (!$scope.selectChecker) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = false;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }
            $scope.checkList[row.entity.objectId] = $scope.selectChecker;

        };

        $scope.selectAllCell = function() {
            if (!$scope.selectAllChecker) {
                $scope.gridApi.grid.rows = enableOrDisableSelection($scope.gridApi.grid.rows, true);
                $scope.gridApi.selection.selectAllRows();
                $scope.selectAllChecker = true;
            } else {
                $scope.gridApi.grid.rows = enableOrDisableSelection($scope.gridApi.grid.rows, false);
                $scope.gridApi.selection.clearSelectedRows();
                $scope.selectAllChecker = false;
            }
            angular.forEach($scope.batchList, function(row) {
                $scope.checkList[row.objectId] = $scope.selectAllChecker;
            });
        };

        function enableOrDisableSelection(loadedOptions, bool) {
            angular.forEach(loadedOptions, function(row) {
                row.enableSelection = bool;
                row.isSelected = bool;
            });
            return loadedOptions;
        }

        $scope.setTextClass = function(value) {
            if (value === 'Successful') {
                return {
                    'text-success': true
                };
            } else if (value === 'Failed' || value === 'Cancelled') {
                return {
                    'text-danger': true
                };
            } else if (value === 'Partially Successful') {
                return {
                    'text-warning': true
                };
            } else if (value === 'Draft' || value === 'In progress' || value === 'Submitted') {
                return {
                    'text-gray': true
                };
            }
        };

        $scope.showBatchListingDialog = function(batchObject) {
            var dlgUrl = 'views/media-management/batch-summary.html';
            var controller = 'batchSummaryCtrl';
            var data = {
                batchObject: function() {
                    return batchObject;
                }
            };
            var options = {
                size: 'lg'
            };
            $('html').css('overflow', '');
            dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
        };


        $scope.setDatePickerAttrId = function(rangeAttr) {
            $scope.selectedFilters = DatePickerFilterService.pushDatePickerAttr(rangeAttr, $scope.selectedFilters);
        };
    });