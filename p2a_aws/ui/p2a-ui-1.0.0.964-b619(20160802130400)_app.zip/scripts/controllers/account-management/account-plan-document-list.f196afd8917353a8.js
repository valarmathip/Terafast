'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ExpandableAccountPlanDocumentListCtrl
 * @description
 * # ExpandableAccountPlanDocumentListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ExpandableAccountPlanDocumentListCtrl', function($scope, ENV, uiGridConstants, $timeout, $log) {
        var pageSize = 20;

        var gridOptionsDocument = {
            'excessRows': 400,
            //'scrollThreshold': 4,
            //"excessColumns": 4,
            enableSorting: true,
            // pagination
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.NEVER,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.NEVER,
            // height of row,Fixing DOGVT-196 QA- Height of the table row should be 105px.
            rowHeight: 70, // never put number in "", like "100"
            headerRowHeight: 35, // default 30 // seems not work
            minRowsToShow: 6,
            rowTemplate: 'views/account-management/template/account-list/plan-list/row.html',
            enableRowHeaderSelection: false, // disable the head selection
            useExternalPagination: true,
            useExternalSorting: true,
            /**
            //  * Following for expandable ui grid
            //  */
            // expandableRowTemplate: 'views/account-management/template/account-list/expandableRow.html',
            // expandableRowHeight: 150, // keep the same value as .ppm-expandable-row
            // //expandableRowHeaderWidth: 40,
            enableExpandableRowHeader: false
        };

        gridOptionsDocument.columnDefs = [{
            displayName: '',
            name: 'X1',
            field: 'element1',
            width: '15%',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: false,
            cellTemplate: 'views/account-management/template/account-list/plan-list/document-list/icon-col.html'
        }, {
            displayName: 'Document Name',
            name: 'name',
            width: '85%',
            field: 'name',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/plan-list/document-list/name-col.html'
        }];


        $scope.gridOption = gridOptionsDocument;
        $scope.gridOption.data = 'documentList';

        gridOptionsDocument.onRegisterApi = function(gridApi) {
            // do not use the same name as the in account constroller 
            $scope.gridApi = gridApi;
        };

        $scope.toggleRowSelection = function(event, row) {
            event.stopPropagation();
            $log.log('toggle the row selection');
            $scope.gridApi.selection.toggleRowSelection(row.entity);
        };

        $scope.toggleAllRowSelection = function(event) {
            event.stopPropagation();
            if (event.currentTarget.checked) {
                $scope.gridApi.selection.selectAllRows();
            } else {
                $scope.gridApi.selection.clearSelectedRows();
            }
        };

        $timeout(function() {
            try {
                $log.log('associate row id = ' + $scope.subGridAdapter.rowEntity.associatedId);
                $log.log('associate row name = ' + $scope.subGridAdapter.rowEntity.associatedName);
            } catch (e) {}
            $scope.documentList = [{
                name: 'document1'
            }, {
                name: 'document2'
            }, {
                name: 'document3'
            }, {
                name: 'document4'
            }, {
                name: 'document5'
            }];

            $scope.gridOption.totalItems = 2;

            // $timeout(function() {
            // $scope.$emit('slq.internal.level1.data.loaded', $scope.expandableLevel);
            $scope.$emit('ppm.sub.grid.resize');
            // });

        }, 500);



    });