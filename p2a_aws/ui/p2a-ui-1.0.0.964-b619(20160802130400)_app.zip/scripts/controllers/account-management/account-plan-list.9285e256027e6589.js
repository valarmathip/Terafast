'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ExpandableAccountPlanListCtrl
 * @description
 * # ExpandableAccountPlanListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ExpandableAccountPlanListCtrl', function($scope, ENV, uiGridConstants, $timeout, AccountMgmtSvc,
        OfferingListHoverMenuSvc, PpmOfferingSummaryDialogSvc, $log) {
        var pageSize = 20;

        $scope.scopeName = 'account-plan-list';

        var gridOptionsPlan = {
            'excessRows': 400,
            //'scrollThreshold': 4,
            //"excessColumns": 4,
            enableSorting: true,
            // pagination
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.NEVER,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.NEVER,
            rowHeight: 70, // never put number in "", like "100"
            headerRowHeight: 35, // default 30 // seems not work
            minRowsToShow: 6,
            rowTemplate: 'views/account-management/template/account-list/plan-list/row.html',
            enableRowHeaderSelection: false, // disable the head selection
            useExternalPagination: true,
            useExternalSorting: true,
            /**
             * Following for expandable ui grid
             */
            expandableRowTemplate: 'views/account-management/template/account-list/plan-list/expandable-row.html',
            expandableRowHeight: 150, // keep the same value as .ppm-expandable-row
            //expandableRowHeaderWidth: 40,
            enableExpandableRowHeader: false
        };

        gridOptionsPlan.columnDefs = [{
            displayName: '',
            name: 'X1',
            field: 'element1',
            width: '10%',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: false,
            headerCellTemplate: 'views/account-management/template/account-list/plan-list/icon-col-header.html',
            cellTemplate: 'views/account-management/template/account-list/plan-list/icon-col.html'
        }, {
            displayName: 'Offering Name',
            name: 'name',
            width: '35%',
            field: 'name',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/plan-list/name-col.html'
        }, {
            displayName: 'Offering Start Date',
            name: 'planStartDate',
            width: '15%',
            field: 'planStartDate',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/plan-list/plan-start-date-col.html'
        }, {
            displayName: 'Offering End Date',
            name: 'planEndtDate',
            width: '15%',
            field: 'planEndDate',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/plan-list/plan-end-date-col.html'
        }, {
            displayName: 'Sales Status',
            name: 'salesStatus',
            width: '10%',
            field: 'salesStatus',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/plan-list/sales-status-col.html'
        }, {
            displayName: 'Benefit Period',
            name: 'benefitPeriod',
            width: '15%',
            field: 'benefitPeriod',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/plan-list/benefit-period-col.html'
        }];

        $scope.gridOption = gridOptionsPlan;
        $scope.gridOption.data = 'planList';

        gridOptionsPlan.onRegisterApi = function(gridApi) {
            // do not use the same name as the in account constroller
            $scope.gridApi = gridApi;

            gridApi.expandable.on.rowExpandedStateChanged($scope, function(row) {
                if (row.isExpanded) {
                    row.entity.subGridOptions = {
                        showHeader: false,
                        columnDefs: [{
                            name: 'name',
                            cellTemplate: 'views/account-management/template/account-list/plan-list/expandable-cell.html',
                            enableHiding: false
                        }]
                    };


                    // SLQ need a general api
                    row.entity.subGridOptions.data = [{
                        name: 'slq'
                    }];
                } else {
                    row.entity.subGridOptions = {};
                    $scope.$emit('ppm.sub.grid.resize');
                }
            });
        };

        $scope.toggleRowSelection = function(event, row) {
            event.stopPropagation();
            $log.log('toggle the row selection');
            $scope.gridApi.selection.toggleRowSelection(row.entity);
        };

        $scope.toggleAllRowSelection = function(event) {
            event.stopPropagation();
            if (event.currentTarget.checked) {
                $scope.gridApi.selection.selectAllRows();
            } else {
                $scope.gridApi.selection.clearSelectedRows();
            }
        };

        /**
         * Row Expansion
         */
        $scope.toggleRowExpansion = function(rowEntity) {
            $log.log('toggle the expandable grid');
            $scope.gridApi.expandable.toggleRowExpansion(rowEntity);
        };
        /* End of row Expansion*/

        function changeOfferingPlansToPlansOffering(offering) {
            var offeringList = [];

            if (!offering || !offering.offerings || offering.offerings.length === 0) {
                return offeringList;
            }

            offeringList = offering.offerings;
            // To remove cycle reference
            delete offering.offerings;
            // Current we do not care about the documents
            // Also document should be associated to plan, not account.
            //delete offering.documents;

            angular.forEach(offeringList, function(listedOffering, index) { /*jshint ignore:line*/
                listedOffering.offering = offering;
            });

            return offeringList;
        }

        function parseAccountForPlanList(account) {
            var offeringList = [];

            if (!account.accountofferings || account.accountofferings.length === 0) {
                return offeringList;
            }

            angular.forEach(account.accountofferings, function(offering, index) { /*jshint ignore:line*/
                offeringList = offeringList.concat(changeOfferingPlansToPlansOffering(offering));
            });

            return offeringList;
        }

        // return promise, containing plan list that associated to this account
        function getPlanListByAccountId(accountId, objectType) {
            var associationExpansionLevel = 2;

            return AccountMgmtSvc.getAccountById(accountId, associationExpansionLevel, objectType)
                .then(function(account) {
                    return parseAccountForPlanList(account);
                });
        }

        // Hover Menu
        function findPlanFromPlanListById(planId) {
            for (var i = 0; i < $scope.planList.length; i++) {
                if (planId === $scope.planList[i].objectId) {
                    return $scope.planList[i];
                }
            }

            return null;
        }

        function refreshLockStatus(lockStatus, planId) {
            var plan = findPlanFromPlanListById(planId);
            if (plan) {
                if (lockStatus === null) {
                    delete plan.isLocked; // = undefined;
                    delete plan.lockedBy; // = undefined;
                    delete plan.lockedAt; // = undefined;

                } else {
                    plan.isLocked = lockStatus.isLocked;
                    plan.lockedBy = lockStatus.lockedBy;
                    plan.lockedAt = lockStatus.lockedAt; // This could be a little difference between backend really lock time
                }
            }
        }

        function updatePlanStatusInViewList(planViewList, planId, status) {
            angular.forEach(planViewList, function(plan) {
                if (plan.objectId === planId) {
                    plan.planStatus = status;
                }
            });
        }


        $scope.$on('ppm.plan.list.hover.menu.lock.status.changed', function(event, lockStatus, planId) {
            event.stopPropagation();
            refreshLockStatus(lockStatus, planId);
        });

        $scope.$on('ppm.plan.list.hover.menu.plan.status.changed', function(event, planId, status) {
            event.stopPropagation();
            updatePlanStatusInViewList($scope.planList, planId, status);
        });

        $scope.hoverItems = OfferingListHoverMenuSvc.getHoverMenu($scope);
        // End of Hover Menu

        $scope.showOfferingSummaryDialog = PpmOfferingSummaryDialogSvc.showOfferingSummaryDialog;


        (function loadData() {
            $log.log('associate row id = ' + $scope.subGridAdapter.rowEntity.associatedId);
            $log.log('associate row name = ' + $scope.subGridAdapter.rowEntity.associatedName);
            $log.log('associate row objectType = ' + $scope.subGridAdapter.rowEntity.objectType);

            getPlanListByAccountId($scope.subGridAdapter.rowEntity.associatedId, $scope.subGridAdapter.rowEntity.objectType)
                .then(function(planList) {
                    $log.log(angular.toJson(planList, true));
                    $scope.planList = planList;
                    // notify the root ui-grid to adjust the height of all its sub-ui-grid
                    $scope.$emit('ppm.sub.grid.resize');
                });
        })();
    });
