'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:AccountListCtrl
 * @description
 * # AccountListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('AccountListCtrl', function(
        $rootScope, $filter, $scope, uiGridConstants, $state, $timeout, ENV, $stateParams, ProductPlanSearch, $log,
        dialogFactorySvc, PaginationService, PPMFilterMetaSvc, FilterService, plansFieldsMeta, DatePickerFilterService,
        plansAspectDefs, authorizedUserInfo, accountListData, AccountMgmtSvc, ppmUtils) {

        $scope.debugMode = (ENV.name === 'local');

        $scope.scopeName = 'account-list';

        $scope.searchQuery = $stateParams.searchquery;
        $scope.userInformation = authorizedUserInfo; // SLQ should be already available from $auth service, do not need to call the backend again

        // Filter UI Setup
        $scope.filtersGroups = [];
        $scope.selectedFilters = {};

        var planProp = plansFieldsMeta[0].properties;
        var aspectDefProp = plansAspectDefs[0].properties;

        $scope.tabUrl = 'views/account-management/template/account-list/ui-grid.html';

        var pageSize = 20;
        $scope.currentPage = 1;
        $scope.currentPageSize = pageSize;

        var gridOptionsTpl = {
            'excessRows': 400,
            //'scrollThreshold': 4,
            //"excessColumns": 4,
            enableSorting: true,
            // pagination
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            // height of row,Fixing DOGVT-196 QA- Height of the table row should be 105px.
            rowHeight: 105, // never put number in "", like "100"
            headerRowHeight: 35, // default 30 // seems not work
            minRowsToShow: 6,
            rowTemplate: 'views/account-management/template/account-list/row.html',
            enableRowHeaderSelection: false, // disable the head selection
            useExternalPagination: true,
            useExternalSorting: true,
            /**
             * Following for expandable ui grid
             */
            expandableRowTemplate: 'views/account-management/template/account-list/expandableRow.html',
            expandableRowHeight: 150, // keep the same value as .ppm-expandable-row
            //expandableRowHeaderWidth: 40,
            enableExpandableRowHeader: false
        };
        $scope.pageVal = {
            pageNumber: ''
        };
        // Not used now
        // var paginationOptions = {
        //     pageNumber: 1,
        //     pageSize: 20,
        //     sort: null
        // };
        // var preSearchQuery = null;

        gridOptionsTpl.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
            // Not used by now
            // $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
            //     if (sortColumns.length >= 0) {
            //         PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
            //     }
            //     loadData();
            // });
            // gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
            //     paginationOptions.pageNumber = newPage;
            //     paginationOptions.pageSize = pageSize;
            //     loadData();
            //     if (!PaginationService.isGoToPageEnabled) {
            //         $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            //     }
            //     PaginationService.setGoToPageEnabled(false);
            // });
            gridApi.expandable.on.rowExpandedStateChanged($scope, function(row) {
                if (row.isExpanded) {
                    row.entity.subGridOptions = {
                        showHeader: false,
                        columnDefs: [{
                            name: 'name',
                            cellTemplate: 'views/account-management/template/account-list/expandableCell.html',
                            enableHiding: false
                        }]
                    };

                    // $http.get('https://cdn.rawgit.com/angular-ui/ui-grid.info/gh-pages/data/100.json')
                    //     .success(function(data) {
                    //         row.entity.subGridOptions.data = data;
                    //     });
                    row.entity.subGridOptions.data = [{
                        associatedId: row.entity.objectId,
                        associatedName: row.entity.accountName,
                        objectType: row.entity.objectType
                    }];
                } else {
                    row.entity.subGridOptions = {};
                    // $scope.$emit('ppm.sub.grid.resize');
                    $scope.$broadcast('ppm.sub.grid.resize');
                }
            });
        };

        // $scope.selectall = true;
        gridOptionsTpl.columnDefs = [{
            displayName: '',
            name: 'X1',
            field: 'element1',
            width: '10%',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: false,
            headerCellTemplate: 'views/account-management/template/account-list/icon-col-header.html',
            cellTemplate: 'views/account-management/template/account-list/icon-col.html'
        }, {
            displayName: 'Account/Group Name',
            name: 'name',
            width: '90%',
            field: 'accountName',
            enableColumnMenu: false,
            enableHiding: false,
            enableSorting: true,
            cellTemplate: 'views/account-management/template/account-list/name-col.html'
        }];

        var plainAccountList = getPlainAccountGroupList(accountListData.response.docs);


        $scope.accountList = plainAccountList; // SLQ we are exactly call ppm/accounts to get all list, not call search api, so the '.data.response.docs' is not

        $scope.gridOptions = gridOptionsTpl;
        $scope.gridOptions.data = 'accountList';

        $scope.gridOptions.totalItems = $scope.accountList.length; //plainAccountList.length; // Temp Treatment, current api does not support the pagination

        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.currentPage = $scope.gridApi.pagination.getPage();
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };

        $scope.pageSizeChanged = function(ps) {
            $scope.gridOptions.paginationCurrentPage = 1;
            $scope.currentPage = 1;
            $scope.currentPageSize = ps;
        };

        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject.pageVal, $scope.gridApi);
            $scope.currentPage = $scope.gridApi.pagination.getPage();
        };

        $scope.loaded = function() {
            if (!PaginationService.getSortColumns()) {
                PaginationService.setSortColumns(null);
            }
            loadData();
        };

        /** Custom selection */
        $scope.toggleRowSelection = function(event, row) {
            $log.log('toggle the row selection');
            $scope.gridApi.selection.toggleRowSelection(row.entity);
        };

        $scope.toggleAllRowSelection = function(event) {
            if (event.currentTarget.checked) {
                $scope.gridApi.selection.selectAllRows();
            } else {
                $scope.gridApi.selection.clearSelectedRows();
            }
        };
        /** End of Custom selection */

        /**
         * Row Expansion
         */
        $scope.toggleRowExpansion = function(rowEntity) {
            $log.log('toggle the expandable grid');
            $scope.gridApi.expandable.toggleRowExpansion(rowEntity);
        };
        /* End of row Expansion*/

        $scope.$on('$includeContentLoaded', function() {});

        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridOptions.paginationCurrentPage = 1;
                $scope.currentPage = 1;
                loadData();
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
        };

        // Currently not search available, and this part is commented out
        // function loadData() {
        //     if ($scope.searchQuery === undefined) {
        //         var currentSearchQuery = ''; //getFilterQuery();

        //         //Do not call API with same search query, which was in prvious API call
        //         if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
        //             return;
        //         }
        //         // Load data goes here
        //         preSearchQuery = currentSearchQuery;
        //         // AccountMgmtSvc.getAccountListViaSearchApi(currentSearchQuery).then(function(data) {
        //         //     $scope.gridOptions.totalItems = data.data.response.numFound;
        //         //     $scope.accountList = data.data.response.docs;

        //         //     angular.forEach($scope.accountList, function(row) {
        //         //         $scope.checkList[row.objectId] = false;
        //         //     });
        //         // }).then(function() {
        //         //     // Need to find a event to reset the current page value; Do not like to use timer
        //         //     // Think about use $q again, because it is call in next loop
        //         //     $timeout(function() {
        //         //         if ($scope.currentPage) {
        //         //             $scope.gridOptions.paginationCurrentPage = $scope.currentPage;
        //         //         }
        //         //     }, 50);
        //         // });
        //     } else { // SLQ do we really need this part // This part is get called from plan-search.js, not sure it still be used by now
        //         //$scope.searchQuery = '/searchPlans?query='+$scope.searchQuery;
        //         ProductPlanSearch.getSearchList($scope.searchQuery).then(function(accountList) {
        //             $scope.accountList = accountList;
        //         }).then(function() {
        //             // Need to find a event to reset the current page value; Do not like to use timer
        //             // Think about use $q again, because it is call in next loop
        //             $timeout(function() {
        //                 if ($scope.currentPage) {
        //                     $scope.gridOptions.paginationCurrentPage = $scope.currentPage;
        //                 }
        //             }, 50);
        //         });
        //     }
        // }

        $scope.getNamePath = function(account) {
            return account.pathDsp.join(' | ');
        };

        $scope.showAccountSummaryDialog = function(id, objectType) {
            var dlgUrl = 'views/account-management/account-summary.html';
            var controller = 'AccountSummaryDialogCtrl';
            var data = {
                accountDetails: function() {
                    var associationExpansionLevel = 1;
                    return AccountMgmtSvc.getAccountById(id, associationExpansionLevel, objectType);
                }
            };
            var options = {
                size: 'md'
            };
            dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
        };

        function getPlainAccountGroupList(accountList) {
            var plainAccountList = [];

            planAccountGroupRcsv(accountList, [], plainAccountList);

            return plainAccountList;
        }

        function planAccountGroupRcsv(accountList, path, planList) {
            angular.forEach(accountList, function(account) {
                if (!ppmUtils.isUuid(account)) {

                    var currentPath = path.concat([account.accountName]);
                    account.pathDsp = currentPath;
                    planList.push(account);

                    if (account.groups && account.groups.length > 0) {
                        planAccountGroupRcsv(account.groups, currentPath, planList);
                    }
                // } else {
                //     $log.error('Maybe you not load all level of your subgroup!');
                }
            });
        }

        /* Start Filters */
        /** Start filter query generation **/
        $scope.queryData = function(selectedId, objs) {
          $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOptions);
          $scope.currentPage = 1;
          loadData();
        };

        $scope.doSearch = function(keyEvent) {
          if (keyEvent.which === 13) {
              $scope.gridOptions.pagionationCurrentPage = 1;
              $scope.currentPage = 1;
              loadData();
              $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
          }
        };

        // filterId should be added on adding date widget to filter
        $scope.datePicker = {
          fromDate: {
            lastModificationDate: [],
            renewalStartDate: [],
            renewalEndDate: []
          },
          toDate: {
            lastModificationDate: [],
            renewalStartDate: [],
            renewalEndDate: []
          }
        };

        $scope.attrYear = {
          field: ''
        };

        $scope.setDatePickerAttrId = function(rangeAttr) {
          $scope.selectedFilters = DatePickerFilterService.pushDatePickerAttr(rangeAttr, $scope.selectedFilters);
        };

        function getDatePickerValues() {
          var allDateCollection = [];
          var fromDateObjs = $scope.datePicker.fromDate;
          var toDateObjs = $scope.datePicker.toDate;
          allDateCollection = DatePickerFilterService.getAllDateCollection(allDateCollection, fromDateObjs, toDateObjs);
          return allDateCollection;
        }

        $scope.getFilterParams = function() {
          var fromToDateCollection = getDatePickerValues();
          var filterQuery = 'TYPE:"account"';
          var isNOTRangeFilterValue = false;
          var filterIdClone;
          var accountName = $scope.accountSearchQuery;

          angular.forEach($scope.selectedFilters, function(filterValues, filterId) {
            var isFirstfilterValue = true;
            var isRangeExist = false;
            isNOTRangeFilterValue = false;
            filterIdClone = filterId;
            filterQuery += ' AND ';
            if (filterValues) {
              filterQuery += ' ( ';
              angular.forEach(filterValues, function(filterValue) {
                if (filterValue.toString().toLowerCase() !== 'date range') {
                  filterValue = FilterService.calculateDate(filterValue);
                  filterValue = FilterService.calculateYear(filterValue);
                  filterValue = FilterService.calculateDay(filterValue);
                  filterValue = FilterService.calculateWeek(filterValue);
                  if (isFirstfilterValue) {
                    filterQuery = determineFilterQueryForSingleFilter(filterValue, isFirstfilterValue, filterId, filterQuery);
                    isFirstfilterValue = false;
                    isNOTRangeFilterValue = true;
                  } else {
                    filterQuery = determineFilterQueryForMultipleFilters(filterValue, isNOTRangeFilterValue, filterId, filterQuery);
                    isNOTRangeFilterValue = true;
                  }
                } else if (!isRangeExist) {
                  filterQuery = FilterService.getFilterQueryForRange(filterQuery, isNOTRangeFilterValue, filterIdClone, fromToDateCollection);
                  isRangeExist = true;
                  isFirstfilterValue = false;
                }
              });
              filterQuery += ' ) ';
            }
          });
          filterQuery += FilterService.getSearchQueryForName(accountName, $scope.matchCase, 'accountName');

          return {
            q: filterQuery
          };
        };

        function determineFilterQueryForSingleFilter(filterValue, isFirstfilterValue, filterId, filterQuery) {
          if (filterId === 'renewalStartDate' || filterId === 'renewalEndDate' || filterId === 'lastModificationdate') {
            filterQuery  += filterId + ': ' + filterValue;
          } else if (filterId === 'lastModifiedBy' || filterId === 'createdBy') {
            filterValue = $scope.userInformation.data.user.email;
            filterQuery += filterId + ': "' + filterValue + '"';
          } else if (filterId === 'accountMarketSegment' && filterValue === 'No') {
            filterValue = false;
            filterQuery += filterId + ': "' + filterValue + '"';
          } else {
            filterQuery += filterId + ': "' + filterValue + '"';
          }
          return filterQuery;
        }

        function determineFilterQueryForMultipleFilters(filterValue, isFirstfilterValue, filterId, filterQuery) {
          if (filterId === 'renewalStartDate' || filterId === 'renewalEndDate' || filterId === 'lastModificationdate') {
            filterQuery  += ' OR ' + filterId + ': ' + filterValue;
          } else if (filterId === 'lastModifiedBy' || filterId === 'createdBy') {
            filterValue = $scope.userInformation.data.user.email;
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
          } else if (filterId === 'accountMarketSegment' && filterValue === 'No') {
            filterValue = false;
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
          } else {
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
          }
          return filterQuery;
        }
        /* End Filter query generation */

        /* Calendar Function */

        $scope.openCalendar = function($event, $index, effectiveDate) {
          $scope.calendarOpened = {};
          $event.preventDefault();
          $event.stopPropagation();
          if (!$scope.calendarOpened[effectiveDate]) {
            $scope.calendarOpened[effectiveDate] = [];
          }
          $scope.calendarOpened[effectiveDate][$index] = true;
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
          return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        // Disable week number labels in UI
        $scope.dateOptions = {
            showWeeks: false
        };

        $scope.getSelectedChecks = function(checkList) {
            var selectedChecks = [];
            angular.forEach(checkList, function(checkValue, planId) {
                if (checkValue) {
                    selectedChecks.push(planId);
                }
            });
            return selectedChecks;
        };

        // Init filter ui
        initializeAccountArrays();

        function initializeAccountArrays(){
          var initArr = PPMFilterMetaSvc.initializeAccountArr();
          $scope.filtersGroups = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, planProp, aspectDefProp);
        }

        /* End Fitlers */

        function loadData() {
          var queryString = getQueryString();

          queryString += '&' + ppmUtils.paramSerializer({
            properties: 'name, groups, groupParentId, accountName, renewalStartDate, renewalEndDate, accountStatus, marketSegment, lastModificationDate, lastModifiedBy, createdBy'
          });

          var associationExpansionLevel = -1;

          AccountMgmtSvc.getAccountListViaSearchApi(queryString, associationExpansionLevel, true)
            .then(function(accountsData) {
                accountListLoaded(accountsData);
            });
        }

        function getQueryString() {
          var queryParams = {};

          angular.extend(queryParams, $scope.getFilterParams());

          // pagination
          var curPage = ($scope.gridApi) ? $scope.gridApi.pagination.getPage() : 1;
          var pageSize = $scope.gridOptions.paginationPageSize;
          var startIndex = (curPage === 1) ? 0 : (curPage - 1) * pageSize;
          angular.extend(queryParams, {
              start: startIndex,
              rows: pageSize
          });

          // sorting
          angular.extend(queryParams, PaginationService.getSortParam('accountName asc'));

          var queryString = ppmUtils.paramSerializer(queryParams);

          return queryString;
        }

        function accountListLoaded(accountsData) {
          if (accountsData) {
              $scope.accountList = getPlainAccountGroupList(accountsData.response.docs);
              $scope.gridOptions.totalItems = $scope.accountList.length;
          } else {
              $scope.accountList = [];
              $scope.gridOptions.totalItems = 0;
          }
        }
    });
