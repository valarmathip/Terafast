'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:AccountSummaryDialogCtrl
 * @description
 * # AccountSummaryDialogCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('AccountSummaryDialogCtrl', function($scope, $modalInstance, accountDetails) {
        $scope.accountDetails = accountDetails;

        $scope.close = function() {
            $modalInstance.dismiss('cancel');
        };
    });