'use strict';

angular.module('p2AdvanceApp').controller('MenuCtrl',
    function($scope, $state, ConfirmationModalFactory, ModalDialogFactory, ENV, $aside) {

         $scope.asideState = {
          open: false
        };

        $scope.checked = false; // This will be binded using the ps-open attribute
    
        $scope.openAside = function(position, backdrop) {
          $scope.asideState = {
            open: true,
            position: position
          };
          
          function postClose() {
            $scope.asideState.open = false;
          }
          
          $aside.open({
            templateUrl: 'views/ui-framework/aside.html',
            placement: position,
            size: '',
            backdrop: backdrop,
            controller: function($scope, $modalInstance) {
              $scope.ok = function(e) {
                $modalInstance.close();
                e.stopPropagation();
              };
              $scope.cancel = function(e) {
                $modalInstance.dismiss();
                e.stopPropagation();
              };
            }
          }).result.then(postClose, postClose);
        };

        // Sample rows
        $scope.rows = [{
            name: 'Row 1',
            enable: true
        }, {
            name: 'Row 2',
            enable: false
        }, {
            name: 'Row 3',
            enable: false
        }];

        // Sample menu items
        $scope.items = [{
            label: 'Create New Row',
            icon: 'fa-share-square-o',
            isEnabled: true
        }, {
            label: 'Edit Row',
            icon: 'fa-pencil'
                //      isEnabled: true // default value is enabled (true)
        }, {
            label: 'Disabled Menu Item',
            icon: 'fa-refresh',
            isEnabled: false
        }, {
            label: 'No Action Assigned Menu Item',
            icon: 'fa-files-o'
        }];

        $scope.items[0].action = function(row) {
            ConfirmationModalFactory.open('Menu Item "' + this.label + '"clicked.', 'Selected Row: ' + row.name, ENV.modalErrorTimeout);
        };

        $scope.items[1].action = function(row) {
            ConfirmationModalFactory.open('Menu Item "' + this.label + '"clicked.', 'Selected Row: ' + row.name, ENV.modalErrorTimeout);
        };

        //  if the action function is not set, the menu item will be disabled.   
        //	$scope.menus[3].action = function() {
        //		ConfirmationModalFactory.open('Menu Item "' + this.label + '" clicked.', 'Selected Row: ' + row.name, ENV.modalErrorTimeout);
        //  };
        $scope.hoverItems = [{
            label: 'Edit this Rule',
            icon: 'fa-pencil',
            isEnabled: true
        }, {
            label: 'Inactivate with a long name that overlaps the next cell',
            icon: '',
            isEnabled: true
        }, {
            label: 'Inactivate2',
            icon: '',
            isEnabled: true
        }, {
            label: 'Inactivate3',
            icon: '',
            isEnabled: false
        }];

        $scope.hoverItems[0].action = function() {
            //TODO: need to send a real rule id as param
            $state.go('home.admin.media-management.delete-rule-definition', {
                'ruleId': '1'
            });
        };

        $scope.hoverItems[1].action = function() {
            $state.go('home.admin.media-management.delete-rule-definition', {
                'ruleId': '1'
            });
        };

        $scope.viewRule = function() {
            var dialogOptions = {
                templateUrl: 'views/admin/media-management/view-rule.html',
                controller: 'ViewRuleCtrl',
                size: 'lg',
                resolve: {
                    ruleAvailable: function() {
                        return [{
                            ruleId: '1',
                            name: 'Rule Name A',
                            tagName: 'Lorrem Ipsum 1',
                            contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                            templateName: 'Template A'
                        }];
                    }
                }
            };

            ModalDialogFactory.showDialog(dialogOptions);
        };

        $scope.rules = [{
                ruleId: '1',
                name: 'Rule Name A',
                tagName: 'Lorrem Ipsum 1',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template A'
            },

            {
                ruleId: '2',
                name: 'Rule Name B',
                tagName: 'Lorrem Ipsum 2',
                contentControl: 'Plan.Svc.WellBabyVisit.ServiceLevel3.copay',
                templateName: 'Template B'
            }, {
                ruleId: '3',
                name: 'Rule Name C',
                tagName: 'Lorrem Ipsum 3',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider.ServiceLevel3.copay',
                templateName: 'Template C'
            }, {
                ruleId: '4',
                name: 'Rule Name D',
                tagName: 'Lorrem Ipsum 4',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template D'
            }, {
                ruleId: '5',
                name: 'Rule Name E',
                tagName: 'Lorrem Ipsum 5',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template E'
            }, {
                ruleId: '6',
                name: 'Rule Name F',
                tagName: 'Lorrem Ipsum 6',
                contentControl: 'Plan.Svc.WellBabyVisit.ServiceLevel3.copay',
                templateName: 'Template F'
            }, {
                ruleId: '7',
                name: 'Rule Name G',
                tagName: 'Lorrem Ipsum 7',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider.ServiceLevel3.copay',
                templateName: 'Template G'
            }, {
                ruleId: '8',
                name: 'Rule Name H',
                tagName: 'Lorrem Ipsum 8',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template H'
            }, {
                ruleId: '11',
                name: 'Rule Name J',
                tagName: 'Lorrem Ipsum 1',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template A'
            }, {
                ruleId: '12',
                name: 'Rule Name K',
                tagName: 'Lorrem Ipsum 2',
                contentControl: 'Plan.Svc.WellBabyVisit.ServiceLevel3.copay',
                templateName: 'Template B'
            }, {
                ruleId: '13',
                name: 'Rule Name L',
                tagName: 'Lorrem Ipsum 3',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider.ServiceLevel3.copay',
                templateName: 'Template C'
            }, {
                ruleId: '14',
                name: 'Rule Name M',
                tagName: 'Lorrem Ipsum 4',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template D'
            }, {
                ruleId: '15',
                name: 'Rule Name N',
                tagName: 'Lorrem Ipsum 5',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template E'
            }, {
                ruleId: '16',
                name: 'Rule Name P',
                tagName: 'Lorrem Ipsum 6',
                contentControl: 'Plan.Svc.WellBabyVisit.ServiceLevel3.copay',
                templateName: 'Template F'
            }, {
                ruleId: '17',
                name: 'Rule Name Q',
                tagName: 'Lorrem Ipsum 7',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider.ServiceLevel3.copay',
                templateName: 'Template G'
            }, {
                ruleId: '18',
                name: 'Rule Name R',
                tagName: 'Lorrem Ipsum 8',
                contentControl: 'Plan.Svc.WellBabyVisit.Participatingprovider',
                templateName: 'Template H'
            }

        ];

        //used by advanced grid
        $scope.gridRules = {
            data: $scope.rules,
            enableColumnResizing: false,
            enableFiltering: false,
            enableGridMenu: false,
            enableCellEdit: false,
            showGridFooter: true,
            showColumnFooter: false,
            enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
            enableVerticalScrollbar: 1,
            rowHeight: 70,
            paginationPageSizes: [5, 10, 15],
            columnDefs: [{
                name: 'ruleId',
                displayName: '',
                enableSorting: false,
                enableColumnMenu: false,
                cellTemplate: '<div class="ui-grid-cell-contents">' +
                    '<span><a class="fa fa-eye" href="" ng-click="grid.appScope.viewRule(row.entity.ruleId)"></a></span> ' +
                    '</div>',
                width: '5%'
            }, {
                name: 'name',
                displayName: 'Rule Name',
                enableSorting: true,
                // cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.ruleName}}</div>',
                cellTemplate: '<div class="ui-grid-cell-contents"><hr-hover-menu-widget context="row.entity" items="grid.appScope.hoverItems" grid-options="grid.appScope.gridRules"></hr-hover-menu-widget></div>',
                width: '25%'
            }, {
                name: 'tagName',
                displayName: 'Fields',
                enableSorting: true,
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.tagName}}</div>',
                width: '15%'
            }, {
                name: 'contentControll',
                displayName: 'Path',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.contentControl}}</div>',
                width: '35%'
            }, {
                name: 'templateName',
                displayName: 'Templates',
                cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.templateName}}</div>',
                type: 'string',
                width: '25%'
            }]
        };

    });