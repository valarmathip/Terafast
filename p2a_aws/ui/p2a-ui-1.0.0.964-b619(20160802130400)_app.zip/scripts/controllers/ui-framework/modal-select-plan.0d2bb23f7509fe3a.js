'use strict';

angular.module('p2AdvanceApp')
    .controller('ModalSelectPlanCtrl', function($scope, $modalInstance) {
        $scope.selectPlanType = function(planType) {
            $modalInstance.close(planType);
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

    });