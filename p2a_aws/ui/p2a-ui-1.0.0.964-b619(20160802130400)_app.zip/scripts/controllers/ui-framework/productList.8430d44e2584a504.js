'use strict';

angular.module('p2AdvanceApp')
    .controller('ProductListDemoCtrl', function($scope, $modal, $http, uiGridConstants) {

        // definition options to which grid is attached to
        $scope.gridOptions = {
            selectionRowHeaderWidth: 0,
            columnDefs: []
        };
        //  array of grid options for each level. main gridOptions is reloaded with related on drill down
        $scope.gridOptionsPerLevel = [{}, {}, {}];
        // array to store selected row on each level from which you go drill down
        $scope.currentRowEntityByLevel = [];
        // flags which levels are expanded (drilled down) - controls the visibility of selected header elements
        $scope.LevelsExpanded = [false, false, false];
        // Sets grid data and columns to selected level. Changes visibility of selected headers
        $scope.resetToLevel = function(level) {
            var i;
            for (i = level; i < $scope.LevelsExpanded.length; i++) {
                $scope.LevelsExpanded[i] = false;
            }
            $scope.setGridOptions($scope.gridOptionsPerLevel[level]);
            $scope.gridOptions.data = $scope.gridOptionsPerLevel[level].data;
        };

        $scope.anyRowExpanded = function() {
            var expanded = false;
            for (var i = 0; i < $scope.LevelsExpanded.length; i++) {
                expanded = expanded || $scope.LevelsExpanded[i];
            }
            return expanded;
        };
        // just simple example of click on action icon
        $scope.clickAlert = function(row, col, me) {
            alert('you are at row=' + row.grid.rowHashMap.get(row.entity).i + '\ncolumn = ' + col.name + ', column index = ' + me.colRenderIndex);
        };


        // drill down from clicked row. active level is defined in each gridOptions.level. Resets grid with child level data. Shows current level selected header element
        $scope.expandRow = function(row) {
            $http.get(encodeURI('data/' + row.entity.children.type + row.entity.id + '.json'))
                .success(function(data) {
                    var gopl = row.grid.options.level;
                    $scope.currentRowEntityByLevel[gopl] = row.entity;
                    $scope.LevelsExpanded[gopl] = true;
                    $scope.setGridOptions($scope.gridOptionsPerLevel[gopl + 1]);
                    $scope.gridOptionsPerLevel[gopl + 1].data = data;
                    $scope.gridOptions.data = data;
                    row.grid.api.dataChange(uiGridConstants.ALL);
                });
        };

        // check if current level has children elements
        $scope.hasChildren = function(rowEntity) {
            return rowEntity.children && rowEntity.children.count > 0;
        };


        // resets level, rowHeight and columnDefs of gridOptions per level
        $scope.setGridOptions = function(setTo) {
            $scope.gridOptions.level = setTo.level;
            $scope.gridOptions.rowHeight = setTo.rowHeight;
            angular.copy(setTo.columnDefs, $scope.gridOptions.columnDefs);
        };

        // options for level 0 grid (Products)
        $scope.gridOptionsPerLevel[0] = {
            rowHeight: 135,
            selectionRowHeaderWidth: 0,
            level: 0,
            selectedHeader: 'Product', // used in rowHeaderTemplate
            rowHeaderTemplate: 'views/ui-framework/templates/productHeaderTemplate.html', // template to use on header div for after this grid drill down
            columnDefs: [{
                name: 'selector',
                enableColumnMenu: false,
                enableFiltering: false,
                enableSorting: false,
                enableHiding: false,
                headerCellTemplate: '<div></div>',
                width: 8,
                cellTemplate: '<input type="checkbox" ng-model="row.selected" ng-change="row.setSelected(row.selected)">'
            }, {
                name: 'test',
                enableColumnMenu: false,
                enableFiltering: false,
                enableSorting: false,
                enableHiding: false,
                headerCellTemplate: '<div></div>',
                width: 70,
                cellTemplate: 'views/ui-framework/templates/actionColumnTemplate.html'
            }, {
                name: 'Product Name',
                field: 'name',
                width: '50%',
                cellTemplate: 'views/ui-framework/templates/productNameTemplate.html',
                enableFiltering: false,
                enableHiding: false
            }, {
                name: 'Global Cost Share',
                cellTemplate: 'views/ui-framework/templates/globalCostShareTemplate.html',
                width: '25%',
                enableFiltering: false,
                enableHiding: false
            }, {
                name: 'Plan Family',
                field: 'planFamily',
                cellTemplate: '<div class="ui-grid-cell-contents"><span ng-repeat="planFamily in row.entity.planFamily">{{planFamily}}<span ng-if="!$last">, </span></span> </div>',
                width: '25%',
                enableFiltering: false,
                enableHiding: false
            }],
            onRegisterApi: function(gridApi) {
                $scope.gridApi = gridApi;
            }
        };

        // set initial options to level 1
        $scope.setGridOptions($scope.gridOptionsPerLevel[0]);

        $http.get('data/products.json')
            .success(function(data) {
                $scope.gridOptionsPerLevel[0].data = data;
                $scope.gridOptions.data = data;
            });

        $scope.gridOptionsPerLevel[1] = {
            rowHeight: 75,
            level: 1,
            selectedHeader: 'Plan',
            rowHeaderTemplate: 'views/ui-framework/templates/productHeaderTemplate.html',
            columnDefs: [{
                name: 'selector',
                enableColumnMenu: false,
                enableFiltering: false,
                enableSorting: false,
                enableHiding: false,
                headerCellTemplate: '<div></div>',
                width: 10,
                cellTemplate: '<input type="checkbox" ng-model="row.selected" ng-change="row.setSelected(row.selected)">'
            }, {
                name: 'test',
                enableColumnMenu: false,
                enableFiltering: false,
                enableSorting: false,
                enableHiding: false,
                headerCellTemplate: '<div></div>',
                width: 70,
                cellTemplate: 'views/ui-framework/templates/actionColumnTemplate.html'
            }, {
                name: 'Plan Name',
                field: 'name',
                cellTemplate: 'views/ui-framework/templates/productNameTemplate.html'
            }, {
                name: 'Created On',
                field: 'createdOn',
                enableFiltering: false,
                enableHiding: false,
                cellFilter: 'date'
            }]
        };

        $scope.gridOptionsPerLevel[2] = {
            rowHeight: 75,
            rowHeaderTemplate: 'views/ui-framework/templates/productHeaderTemplate.html',
            columnDefs: [{
                name: 'selector',
                enableColumnMenu: false,
                enableFiltering: false,
                enableSorting: false,
                enableHiding: false,
                headerCellTemplate: '<div></div>',
                width: 10,
                cellTemplate: '<input type="checkbox" ng-model="row.selected" ng-change="row.setSelected(row.selected)">'
            }, {
                name: 'test',
                enableColumnMenu: false,
                enableFiltering: false,
                enableSorting: false,
                enableHiding: false,
                headerCellTemplate: '<div></div>',
                width: 70,
                cellTemplate: 'views/ui-framework/templates/actionColumnTemplate.html'
            }, {
                name: 'Document Name',
                field: 'name',
                cellTemplate: 'views/ui-framework/templates/productNameTemplate.html'
            }, {
                name: 'Generated On',
                field: 'generatedOn',
                enableFiltering: false,
                enableHiding: false,
                cellFilter: 'date'
            }],
            level: 2
        };
    }).directive('hrSelectedRowHeader', function() { // directive to get template for selected header when drilled down
        return {
            restrict: 'A',
            scope: {
                options: '=',
                row: '='
            },
            template: '<ng-include src="getTemplateUrl()"/>',
            controller:['$scope', function($scope) {
                $scope.getTemplateUrl = function() {
                    return $scope.options.rowHeaderTemplate;
                };
            }]
        };
    });