'use strict';

angular.module('p2AdvanceApp')
    .controller('I18nCtrl', ['$scope', '$translate', function($scope, $translate) {
        $scope.changeLanguage = function(langKey) {
            $translate.use(langKey);
        };
    }]);