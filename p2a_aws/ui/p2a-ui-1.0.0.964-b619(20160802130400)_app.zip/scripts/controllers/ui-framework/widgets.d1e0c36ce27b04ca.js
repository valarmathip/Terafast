'use strict';

angular.module('p2AdvanceApp')
    .controller('WidgetsCtrl', function($scope, $rootScope, $modal, $http, uiGridConstants, $interval, $timeout, ConfirmationModalFactory, ENV, $upload) {

        $scope.myDate = new Date();

        $scope.sections = [{
            badgetInfoNum: 4,
            badgetErrorNum: 0,
            locationPath: '/ui-framework/widgets/subnavbar/1',
            name: 'Plan Details',
            routerState: 'subnavbar({ sectionId: 1})'
        }, {
            badgetInfoNum: 11,
            badgetErrorNum: 0,
            locationPath: '/ui-framework/widgets/subnavbar/2',
            name: 'SBC Benefit Data',
            routerState: 'subnavbar({ sectionId: 2})'
        }, {
            badgetInfoNum: 16,
            badgetErrorNum: 3,
            locationPath: '/ui-framework/widgets/subnavbar/3',
            name: 'Important Questions',
            routerState: 'subnavbar({ sectionId: 3})'
        }, {
            badgetInfoNum: 0,
            badgetErrorNum: 0,
            locationPath: '/ui-framework/widgets/subnavbar/4',
            name: 'Common Medical Event',
            routerState: 'subnavbar({ sectionId: 4})'
        }, {
            badgetInfoNum: 16,
            badgetErrorNum: 5,
            locationPath: '/ui-framework/widgets/subnavbar/5',
            name: 'Excluded Services & Other Covered Services',
            routerState: 'subnavbar({ sectionId: 5})'
        }, {
            badgetInfoNum: 3,
            badgetErrorNum: 0,
            locationPath: '/ui-framework/widgets/subnavbar/6',
            name: 'Your Rights to Continue Coverage / Your Grievance and Appeals Rights',
            routerState: 'subnavbar({ sectionId: 6})'
        }, {
            badgetInfoNum: 4,
            badgetErrorNum: 0,
            locationPath: '/ui-framework/widgets/subnavbar/7',
            name: 'Language Access Services',
            routerState: 'subnavbar({ sectionId: 7})'
        }];


        $scope.showModal = function() {
            ConfirmationModalFactory.open('This is the title', 'And this is the message.', ENV.modalErrorTimeout);
        };

        $scope.showModalExample = function() {
            var modalInstance = $modal.open({
                templateUrl: 'views/ui-framework/modal-select-plan.html',
                controller: 'ModalSelectPlanCtrl',
                backdrop: 'static'
            });
            modalInstance.result.then(
                function() {
                    // do something, make $http call, update $scope variables, etc
                    alert('The modal will close after the code is executed.');
                }
            );
        };
        $scope.value1 = '50';
        $scope.value2 = '460';
        $scope.value3 = '1.34';
        $scope.value4 = '700';

        $scope.options = {
            from: 0,
            to: 100,
            step: 5,
            scale: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
            format: '%',
            realtime: true,
            callback: function(value, released) {
                if (released) {
                    console.log(value + ' ' + released);
                }
            },
            value: $scope.value
        };

        $scope.options2 = {
            from: 100,
            to: 900,
            min: 300,
            max: 500,
            step: 5,
            scale: [100, 200, 300, 400, 500, 600, 700, 800, 900],
            format: '$',
            realtime: true
        };

        $scope.options3 = {
            from: 0,
            to: 2,
            step: 0.05,
            round: 2,
            scale: [0, '|', '|', '|', '|', 0.5, '|', '|', '|', '|', 1, '|', '|', '|', '|', 1.5, '|', '|', '|', '|', 2],
            realtime: true
        };
        $scope.testSlider = function() {
            var message = 'Your value is within range.';
            if ($scope.value2 > $scope.options2.max || $scope.value2 < $scope.options2.min) {
                message = 'You cannot proceed. Your value of ' + $scope.value2 + ' is out of range (' + $scope.options2.min + ', ' + $scope.options2.max + ').';
            }
            ConfirmationModalFactory.open('Slider Result:', message, ENV.modalErrorTimeout);
        };

        $scope.uploader = {
            isHTML5: true,
            progress: 0,
            fileSuccess: false
        };

        $scope.$watch('uploader.files', function() {
            if ($scope.uploader.files) {
                for (var i = 0; i < $scope.uploader.files.length; i++) {
                    var file = $scope.uploader.files[i];
                    if (file.progress === undefined) {
                        file.progress = 0;
                        file.isFile = true;
                        $scope.progressData.push(file);
                    }
                }
            }
        });

        $scope.uploadAll = function() {
            $scope.upload($scope.progressData);
        };

        $scope.getFileSize = function(fileSize) {
            var size = ((fileSize / 1024) / 1024);
            return size.toFixed(1);
        };

        var completedFiles = 0;
        $scope.upload = function(files) {
            if (files && files.length) {
                for (var i = 0; i < files.length; i++) {
                    // var item = files[i];
                    if (files[i].progress === 0 && files[i].isFile) {
                        var uploadFile = [];
                        uploadFile.push(files[i]);
                        var metadata = JSON.stringify({
                            'properties': {
                                'cmis:objectTypeId': 'D:hr:template',
                                'cmis:name': uploadFile[0].name,
                                'templateStatus': 'Draft',
                                'documentType': 'SUM',
                                'businessEntity': 'Product',
                                'productClass': 'Medical',
                                'productType': 'HMO',
                                'numProviderTiers': 1,
                                'marketSegment': ['Large (101-150)'],
                                'fundingArrangement': ['Self Funded']
                            }
                        });

                        var blob;

                        try {
                            blob = new Blob([metadata], {
                                type: 'application/json'
                            });
                        } catch (e) {
                            // TypeError old chrome and FF and PhantomJS
                            window.BlobBuilder = window.BlobBuilder ||
                                window.WebKitBlobBuilder ||
                                window.MozBlobBuilder ||
                                window.MSBlobBuilder;
                            if (e.name === 'TypeError' && window.BlobBuilder) {
                                var bb = new BlobBuilder();
                                bb.append([
                                    [metadata].buffer
                                ]);
                                blob = bb.getBlob('application/json');
                            } else if (e.name === 'InvalidStateError') {
                                // InvalidStateError (tested on FF13 WinXP)
                                blob = new Blob([
                                    [metadata].buffer
                                ], {
                                    type: 'application/json'
                                });
                            }
                        }


                        uploadFile.push(blob);

                        $upload.upload({
                            url: 'http://192.168.2.114:8181/cm/templates?tenantFolder=tulip_tree.com',
                            headers: {
                                'Content-Type': undefined
                            },
                            fileName: [uploadFile[0].name, 'metadata'],
                            fileFormDataName: ['file', 'metadata'],
                            file: uploadFile
                        }).progress(function (evt) {
                            var progressPercentage = parseInt(100.0 * evt.loaded / evt.total, 10);
                            if (progressPercentage === 100) {
                                completedFiles++;
                                $scope.uploader.progress = completedFiles / $scope.uploader.files.length * 100;
                            }
                            evt.config.file[0].progress = progressPercentage;
                            console.log('progress: ' + progressPercentage + '% ' +
                                evt.config.file.name);
                        }).success(function (data, status, headers, config) {
                            $scope.uploader.fileSuccess = true;
                            console.log('file ' + config.file.name + 'uploaded. Response: ' +
                                JSON.stringify(data));
                        }).error(function (data, status, headers, config) {
                            config.file[0].failed = true;
                            ConfirmationModalFactory.open('Template Uploader', 'Uploading Error! Status: ' + status, ENV.modalErrorTimeout);
                        });
                    }

                }
            }
        };

        $scope.progVal = 0;

        $scope.changeValue = function() {
            if ($scope.progVal === 0) {
                increaseValue();
            } else {
                decreaseValue();
            }
        };
        var decreaseValue = function() {
            $interval(function() {
                if ($scope.progVal >= 0) {
                    $scope.progVal--;
                }
            }, 50, 100);
        };
        var increaseValue = function() {
            $interval(function() {
                if ($scope.progVal <= 99) {
                    $scope.progVal++;
                }
            }, 50, 100);
        };

        $scope.productDetails = {};

        // Status of opened calendar, internal use only
        $scope.calendarOpened = {};

        // Calendar function
        $scope.openCalendar = function($event, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId] = true;
        };

        $scope.dateOptions = {
            showWeeks: false
        };

        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };
    });