'use strict';

angular.module('p2AdvanceApp')
    .controller('UiFrameworkCtrl', function() {});