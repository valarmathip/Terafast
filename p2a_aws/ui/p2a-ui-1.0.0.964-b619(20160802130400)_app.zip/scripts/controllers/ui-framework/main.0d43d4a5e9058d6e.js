'use strict';

angular.module('p2AdvanceApp')
    .controller('MainCtrl', function($scope, $rootScope, $window, $auth, localStorageService, $state, $q, $log) { /* jshint ignore:line */

        $scope.srv = {
            name: 'Test Server',
            time: new Date(),
            year: '2015',
            build: 'R19.5.10.1'
        };

        $scope.email = $auth.getUserEmail();

        $scope.companyLogo = $auth.getUserCompanyLogoUrl();

        $scope.userFullName = $auth.getUserFullName();

        $scope.cleanupHook = {
            // This function should return a promise
            // execute: function() {}
            execute: null
        };

        window.slqscope = $scope;

        $scope.shouldShow = function(state, name) {
            return state.current.name.indexOf(name) === 0;
        };

        $scope.isActive = function(state, name) {
            return state.current.name.indexOf(name) === 0;
        };

        $scope.logout = function() {
            /*
             * Distribution Logout
             */
            distributionLogout();

            cleanup()['finally'](function() {
                $auth.redirectToIdpLogout();
            });
        };

        function distributionLogout() {
            var frame = document.getElementById('distFrame');
            if (frame != null) {
                console.log(frame);
                frame.contentWindow.postMessage('logout', '*');
                console.log('Distribution module logged out.');
            }
        }

        /**
            DOGHR-1975 The same function is already implemented by detecting state changing. But its not
            suitable here, because the single page application will be unloaded.
            If there are too many clean up in the future, we do not have to re-implement here. maybe we can
            create temp logout page in app, and from that logout do real rediection.
         */
        // return a promise
        function cleanup() {
            if (angular.isDefined($scope.cleanupHook.execute) && angular.isFunction($scope.cleanupHook.execute)) {
                return $scope.cleanupHook.execute();
            }

            return $q.when();
        }

        $scope.submitTicket = function() {
            $window.open('https://ticket.teamsupport.com/HighRoadsInc', '_blank');
        };

        $scope.$watch(function() {
            return localStorageService.get('apiToken');
        }, function(newValue, oldValue) {
            if (_.isNull(oldValue) && newValue) {
                // First time set the credential
                return false;
            } else if (newValue === oldValue) {
                // First time set the credential
                return false;
            } else if (!$auth.isProcessing()) {
                // something has change in the API token, (user manipulation)
                $rootScope.$emit('auth:invalidateCredentials');
            } else {
                return false;
            }
        });

        var adjustHeightAndPadding = function() {

            var navDiv = $window.document.getElementById('navDiv');
            var dropdown = $('.hr-main-dropdown');
            var links = dropdown.find('a');
            for (var i = 0; i < links.length; i++) {
                if (navDiv.clientWidth > 970) {
                    links[i].style.width = '320px';
                } else {
                    links[i].style.minWidth = '0px';
                    links[i].style.width = '193px';
                }
            }

            var progressSpan = $window.document.getElementById('progressWidgetId');
            if (progressSpan) {
                var progressLeft = navDiv.clientWidth - progressSpan.clientWidth - 15;
                progressSpan.style.left = progressLeft + 'px';
            }

            var midDiv = $window.document.getElementById('midDiv');
            if (midDiv) {
                var defaultNavHeight = 40;
                var navHeight = navDiv.offsetHeight;
                var footerHeight = $window.document.getElementById('footerDiv').offsetHeight;
                var calculatedBodyHeight;
                var topPadding = navHeight - defaultNavHeight;
                if (topPadding > 0) { // window is smaller than large
                    midDiv.style.paddingTop = topPadding + 'px';
                    calculatedBodyHeight = $window.innerHeight - footerHeight - defaultNavHeight;
                } else {
                    midDiv.style.paddingTop = '';
                    calculatedBodyHeight = w.height() - footerHeight - navHeight;
                }
                midDiv.style.minHeight = calculatedBodyHeight + 'px';
                $window.document.getElementById('bodyTag').style.paddingBottom = footerHeight + 'px';
            }

            $rootScope.$broadcast('Main.AdjustHeightAndPadding');
        };

        var w = angular.element($window);

        w.bind('resize', function() {
            adjustHeightAndPadding();
        });

        $scope.$on('$viewContentLoaded', function() {
            adjustHeightAndPadding();
        });

        $scope.isProgressOpen = false;

        $scope.mainActionFunction = function(rowData, action) {
            alert('document: ' + rowData.name + '\naction: ' + action);
        };
        $scope.progressData = [];

    });