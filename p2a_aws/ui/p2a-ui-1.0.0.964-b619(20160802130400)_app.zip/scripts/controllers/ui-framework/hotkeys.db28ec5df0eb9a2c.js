'use strict';

angular.module('p2AdvanceApp')
    .controller('HotkeysCtrl', function($scope, hotkeys, ConfirmationModalFactory, ENV) {
        $scope.volume = 40;
        $scope.message = '';

        // You can pass it an object.  This hotkey will not be unbound unless manually removed
        // using the hotkeys.del() method
        hotkeys.add({
            combo: 'ctrl+up',
            description: 'Hotkeys test: Increase volume ',
            callback: function() {
                $scope.volume += 10;
                if ($scope.volume > 100) {
                    $scope.volume = 100;
                }
            }
        });

        hotkeys.add({
            combo: 'ctrl+down',
            description: 'Hotkeys test: decrease volume',
            callback: function() {
                $scope.volume -= 10;
                if ($scope.volume < 0) {
                    $scope.volume = 0;
                }
            }
        });

        // when you bind it to the controller's scope, it will automatically unbind
        // the hotkey when the scope is destroyed (due to ng-if or something that changes the DOM)
        hotkeys.bindTo($scope)
            .add({
                combo: 'ctrl+alt+s',
                description: 'Hotkeys test: "ctrl+alt+s" pressed',
                callback: function() {
                    $scope.message = '"ctrl + alt + s" keys pressed. Press "Delete" key to delete this message.';
                    ConfirmationModalFactory.open('Hotkeys Test', '"ctrl + alt + s" pressed.', ENV.modalErrorTimeout);
                }
            })
            .add({
                combo: 'del',
                description: 'Hotkeys test: "del" pressed',
                callback: function() {
                    $scope.message = '';
                }
            });

    });