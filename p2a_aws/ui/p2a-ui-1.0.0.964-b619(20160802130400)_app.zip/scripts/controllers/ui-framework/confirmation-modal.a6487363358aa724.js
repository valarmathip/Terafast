'use strict';

angular.module('p2AdvanceApp')
    .controller('ConfirmationModalCtrl', function() {});