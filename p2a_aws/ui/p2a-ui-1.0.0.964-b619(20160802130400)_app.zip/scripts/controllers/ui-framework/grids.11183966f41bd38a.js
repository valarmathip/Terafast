'use strict';

angular.module('p2AdvanceApp')
    .controller('GridsCtrl', function($scope, $modal, $http, uiGridConstants) {

        // function to apply filter entered into genderFilter input on "gender" column of the grid.
        // Initially column filtering was disabled, so no default inputs are shown in the header
        $scope.filterGender = function() {
            // get available columns from grid using GridApi
            var genderColumn = $scope.getGenderColumn($scope.grid1Api.grid.columns);
            // set filter value to "term" from genderFilter
            genderColumn.filter = {
                term: $scope.genderFilter
            };
            // notify grid on changed data or definitions using core api function
            $scope.grid1Api.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);

        };
        $scope.getGenderColumn = function(columns) {
            return columns.filter(
                function(obj) {
                    return obj.field === 'gender';
                })[0];
        };
        $scope.gridOptions1 = {
            enableFiltering: true,
            onRegisterApi: function(gridApi) {
                $scope.grid1Api = gridApi;
            }
        };

        // gridOptions2 are used by advanced grid example
        $scope.gridOptions2 = {
            enableColumnResizing: true,
            enableFiltering: true,
            enableGridMenu: true,
            showGridFooter: true,
            showColumnFooter: true,
            exporterCsvFilename: 'myFile.csv',
            exporterPdfDefaultStyle: {
                fontSize: 9
            },
            exporterPdfTableStyle: {
                margin: [30, 30, 30, 30]
            },
            exporterPdfTableHeaderStyle: {
                fontSize: 10,
                bold: true,
                italics: true,
                color: 'red'
            },
            exporterPdfHeader: {
                text: 'My Header',
                style: 'headerStyle'
            },
            exporterPdfFooter: function(currentPage, pageCount) {
                return {
                    text: currentPage.toString() + ' of ' + pageCount.toString(),
                    style: 'footerStyle'
                };
            },
            exporterPdfCustomFormatter: function(docDefinition) {
                docDefinition.styles.headerStyle = {
                    fontSize: 22,
                    bold: true
                };
                docDefinition.styles.footerStyle = {
                    fontSize: 10,
                    bold: true
                };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll('.custom-csv-link-location')),
            paginationPageSizes: [25, 50, 75],
            paginationPageSize: 25

        };

        $scope.gridOptions2.rowIdentity = function(row) {
            return row.id;
        };
        $scope.gridOptions2.getRowIdentity = function(row) {
            return row.id;
        };

        $scope.gridOptions2.columnDefs = [{
            name: 'id',
            width: 50
        }, {
            name: 'name',
            width: 100
        }, {
            name: 'age',
            width: 100,
            enableCellEdit: true,
            aggregationType: uiGridConstants.aggregationTypes.avg,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Age:{{COL_FIELD}}</span></div>'
        }, {
            name: 'address.street',
            width: 150,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Street:{{COL_FIELD}}</span></div>'
        }, {
            name: 'address.city',
            width: 150,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>City:{{COL_FIELD}}</span></div>'
        }, {
            name: 'address.state',
            width: 50,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>State:{{COL_FIELD}}</span></div>'
        }, {
            name: 'address.zip',
            width: 50,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Zip:{{COL_FIELD}}</span></div>'
        }, {
            name: 'company',
            width: 100,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Company:{{COL_FIELD}}</span></div>'
        }, {
            name: 'email',
            width: 100,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Email:{{COL_FIELD}}</span></div>'
        }, {
            name: 'phone',
            width: 200,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Phone:{{COL_FIELD}}</span></div>'
        }, {
            name: 'about',
            width: 300,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>AAbout:{{COL_FIELD}}</span></div>'
        }, {
            name: 'friends[0].name',
            displayName: '1st friend',
            width: 150,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Friend0:{{COL_FIELD}}</span></div>'
        }, {
            name: 'friends[1].name',
            displayName: '2nd friend',
            width: 150,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Friend1:{{COL_FIELD}}</span></div>'
        }, {
            name: 'friends[2].name',
            displayName: '3rd friend',
            width: 150,
            enableCellEdit: true,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Friend2:{{COL_FIELD}}</span></div>'
        }, {
            name: 'agetemplate',
            field: 'age',
            width: 150,
            cellTemplate: '<div class="ui-grid-cell-contents"><span>Age 2:{{COL_FIELD}}</span></div>'
        }];


        // Product Grid - possible implementation of Product Plan Document Listing page

        $scope.myVar = 'test 111';
        $scope.clickAlert = function(row, col, me) {
            alert('you are at row=' + row.grid.rowHashMap.get(row.entity).i + '\ncolumn = ' + col.name + ', column index = ' + me.colRenderIndex);
        };
        $scope.expandRow = function(row) {
            row.grid.api.expandable.toggleRowExpansion(row.entity);
        };
        $scope.hasChildren = function(rowEntity) {
            return rowEntity.children && rowEntity.children.count > 0;
        };

        // definition for highest level Product Grid
        $scope.productsOptions = {
            expandableRowTemplate: 'views/ui-framework/templates/planListTemplate.html',
            expandableRowHeight: 435,
            rowHeight: 135,
            enableExpandableRowHeader: false,
            selectionRowHeaderWidth: 0,
            onRegisterApi: function(gridApi) {
                gridApi.expandable.on.rowExpandedStateChanged($scope, function(row) {
                    if (row.isExpanded) {
                        // define Plan level sub grid per product row
                        row.entity.subGridOptions = {
                            expandableRowTemplate: 'views/ui-framework/templates/documentListTemplate.html',
                            expandableRowHeight: 320,
                            enableExpandableRowHeader: false,
                            selectionRowHeaderWidth: 0,
                            appScopeProvider: $scope,
                            rowHeight: 75,
                            onRegisterApi: function(gridApi) {
                                gridApi.expandable.on.rowExpandedStateChanged($scope, function(row) {
                                    if (row.isExpanded) {
                                        row.entity.subGridOptions = {
                                            expandableRowTemplate: 'views/ui-framework/templates/documentListTemplate.html',
                                            expandableRowHeight: 255,
                                            enableExpandableRowHeader: false,
                                            selectionRowHeaderWidth: 0,
                                            appScopeProvider: $scope,
                                            rowHeight: 75,
                                            columnDefs: [{
                                                name: 'selector',
                                                enableColumnMenu: false,
                                                enableFiltering: false,
                                                enableSorting: false,
                                                enableHiding: false,
                                                headerCellTemplate: '<div></div>',
                                                width: 10,
                                                cellTemplate: '<input type="checkbox" ng-model="row.selected" ng-change="row.setSelected(row.selected)">'
                                            }, {
                                                name: 'test',
                                                enableColumnMenu: false,
                                                enableFiltering: false,
                                                enableSorting: false,
                                                enableHiding: false,
                                                headerCellTemplate: '<div></div>',
                                                width: 70,
                                                cellTemplate: 'views/ui-framework/templates/actionColumnTemplate.html'
                                            }, {
                                                name: 'Document Name',
                                                field: 'name',
                                                cellTemplate: 'views/ui-framework/templates/productNameTemplate.html',
                                                enableHiding: false
                                            }, {
                                                name: 'Generated On',
                                                field: 'generatedOn',
                                                enableFiltering: false,
                                                enableHiding: false,
                                                cellFilter: 'date'
                                            }]
                                        };

                                        $http.get(encodeURI('data/' + row.entity.children.type + row.entity.id + '.json'))
                                            .success(function(data) {
                                                row.entity.subGridOptions.data = data;
                                            });
                                    }
                                });
                            },

                            columnDefs: [{
                                name: 'selector',
                                enableColumnMenu: false,
                                enableFiltering: false,
                                enableSorting: false,
                                enableHiding: false,
                                headerCellTemplate: '<div></div>',
                                width: 10,
                                cellTemplate: '<input type="checkbox" ng-model="row.selected" ng-change="row.setSelected(row.selected)">'
                            }, {
                                name: 'test',
                                enableColumnMenu: false,
                                enableFiltering: false,
                                enableSorting: false,
                                enableHiding: false,
                                headerCellTemplate: '<div></div>',
                                width: 70,
                                cellTemplate: 'views/ui-framework/templates/actionColumnTemplate.html'
                            }, {
                                name: 'Plan Name',
                                field: 'name',
                                cellTemplate: 'views/ui-framework/templates/productNameTemplate.html',
                                enableHiding: false
                            }, {
                                name: 'Generated On',
                                field: 'createdOn',
                                enableFiltering: false,
                                enableHiding: false,
                                cellFilter: 'date'
                            }]
                        };

                        $http.get(encodeURI('data/' + row.entity.children.type + row.entity.id + '.json'))
                            .success(function(data) {
                                row.entity.subGridOptions.data = data;
                            });
                    }
                });
            }
        };
        $scope.productsOptions.columnDefs = [{
            name: 'selector',
            enableColumnMenu: false,
            enableFiltering: false,
            enableSorting: false,
            enableHiding: false,
            headerCellTemplate: '<div></div>',
            width: 10,
            cellTemplate: '<input type="checkbox" ng-model="row.selected" ng-change="row.setSelected(row.selected)">'
        }, {
            name: 'test',
            enableColumnMenu: false,
            enableFiltering: false,
            enableSorting: false,
            enableHiding: false,
            headerCellTemplate: '<div></div>',
            width: 70,
            cellTemplate: 'views/ui-framework/templates/actionColumnTemplate.html'
        }, {
            name: 'Product Name',
            field: 'name',
            cellTemplate: 'views/ui-framework/templates/productNameTemplate.html',
            enableFiltering: false,
            enableHiding: false
        }, {
            name: 'Global Cost Share',
            cellTemplate: 'views/ui-framework/templates/globalCostShareTemplate.html',
            enableFiltering: false,
            enableHiding: false
        }, {
            name: 'Plan Family',
            field: 'planFamily',
            cellTemplate: '<div class="ui-grid-cell-contents"><span ng-repeat="planFamily in row.entity.planFamily">{{planFamily}}' + '<span ng-if="!$last">, </span></span> </div>',
            enableFiltering: false,
            enableHiding: false
        }];

        $http.get('data/products.json')
            .success(function(data) {
                $scope.productsOptions.data = data;
            });

        $http.get('data/gridDemo.json')
            .success(function(data) {
                $scope.gridOptions2.data = data;
            });

        $http.get('data/gridOptions.json')
            .success(function(data) {
                //merge received gridDefinition into scope defined using jQuery extend
                $.extend(true, $scope.gridOptions1, data);
                $http.get('data/gridDemo2.json')
                    .success(function(data) {
                        $scope.gridOptions1.data = data;
                    });
            });

    });