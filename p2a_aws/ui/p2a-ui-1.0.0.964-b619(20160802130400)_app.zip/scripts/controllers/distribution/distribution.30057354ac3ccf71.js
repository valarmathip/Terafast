'use strict';

angular.module('p2AdvanceApp')
    .controller('distributionController', function($scope, $state, $sce, $stateParams, localStorageService, ENV_DISTRIBUTION) {

    var frame = document.getElementById('distFrame');
    var origApiToken = localStorageService.get('apiToken').replace('Bearer','');
    var escapedApiToken = encodeURIComponent(origApiToken.trim()); // encoded token is required to pass in as frame src
    frame.contentWindow.postMessage(origApiToken, '*');

    /*
     * Main Distribution page
     */
    $scope.getIframeSrc = function () {
      frame.contentWindow.postMessage(origApiToken, '*');
      console.log('origApiToken: '+origApiToken);
      console.log('escapedApiToken: '+escapedApiToken);
      var url = ENV_DISTRIBUTION.hostName+ENV_DISTRIBUTION.tokenParameter+escapedApiToken;
      console.log(url);
      // return $sce.trustAsResourceUrl(url);
      frame.contentWindow.postMessage(origApiToken, '*');
      $state.go('home.draft');
    };

    /*
     * Sent Distribution page
     */
    $scope.getSentIframeSrc = function () {
      var url = ENV_DISTRIBUTION.hostNameSent+ENV_DISTRIBUTION.tokenParameter+escapedApiToken;
      console.log('Sent page url: '+url);
      return $sce.trustAsResourceUrl(url);
    };

    /*
     * Draft Distribution page
     */
    $scope.getDraftIframeSrc = function () {
      var url = ENV_DISTRIBUTION.hostNameDraft+ENV_DISTRIBUTION.tokenParameter+escapedApiToken;
      console.log('Draft page url: '+url);
      return $sce.trustAsResourceUrl(url);
    };

    /*
     * Distribution Administration page
     */
    $scope.getAdminIframeSrc = function () {
      var url = ENV_DISTRIBUTION.hostNameAdmin+'&t='+escapedApiToken;
      console.log('Admin page url: '+url);
      return $sce.trustAsResourceUrl(url);
    };
});
