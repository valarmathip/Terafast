(function() {
    'use strict';

    angular
        .module('p2AdvanceApp')
        .controller('TaskDynamicFormCtrl', TaskDynamicFormCtrl);

    TaskDynamicFormCtrl.$inject = ['$scope', 'TaskDetails'];

    /* @ngInject */
    function TaskDynamicFormCtrl($scope, TaskDetails) {
        $scope.taskDetails = TaskDetails;
        $scope.formError = false;

        $scope.formMockup = {
            'formActions': [{
                'action': 'reject',
                'label': 'Reject',
                'value': 'Overrideplan rejected'
            }, {
                'action': 'accept',
                'label': 'Accept',
                'value': 'Overrideplan approved'
            }, {
                'action': 'somethingElse',
                'label': 'Some other Action',
                'value': 'Overrideplan approved'
            }],
            'dynamicFields': {
                'schema': {
                    'type': 'object',
                    'properties': {
                        'datePickerField': {
                            'type': 'string',
                            'format': 'p2aDatepicker'
                        },
                        'datePickerFieldRange': {
                            'type': 'string',
                            'format': 'p2aDatepickerRange'
                        },
                        'textInput': {
                            'type': 'string',
                            'format': 'p2aTextInput'
                        },
                        'textArea': {
                            'type': 'string',
                            'format': 'p2aTextArea'
                        },
                        'checkbox': {
                            'type': 'string',
                            'format': 'p2aBooleanCheckbox'
                        },
                        'multipleCheckbox': {
                            'type': 'string',
                            'format': 'p2aMultipleCheckboxes'
                        },
                        'radioButtons': {
                            'type': 'string',
                            'format': 'p2aRadioButtons'
                        },
                        'dropdown': {
                            'type': 'string',
                            'format': 'p2aDropdownSelection'
                        },
                        'asyncDropdown': {
                            'type': 'string',
                            'format': 'p2aDropdownSelection'
                        },
                        'requiredLabel': {
                            'type': 'string',
                            'format': 'p2aRequiredFieldsLabel'
                        }
                    }
                },
                'form': [{
                    'key': 'datePickerField',
                    'title': 'Date Requested',
                    'required': false,
                    'description': 'Some Description',
                    'dateFormat': 'dd-MMMM-yyyy',
                    'dateOptions': {}
                }, {
                    'key': 'datePickerFieldRange',
                    'title': 'Date Requested Range',
                    'required': true,
                    'descriptionStartDate': 'Some Description',
                    'descriptionEndDate': 'Some Description',
                    'dateFormat': 'dd-MMMM-yyyy',
                    'dateOptions': {}
                }, {
                    'key': 'textInput',
                    'title': 'Text input',
                    'required': false,
                    'description': 'Some Description',
                    'placeholder': 'Some placeholder'
                }, {
                    'key': 'textArea',
                    'title': 'Text Area',
                    'required': false,
                    'description': 'Some Description',
                    'placeholder': 'Some placeholder'
                }, {
                    'key': 'checkbox',
                    'title': 'Check if true or false',
                    'required': false,
                    'description': 'Some description'

                }, {
                    'key': 'multipleCheckbox',
                    'title': 'Select one or more',
                    'required': true,
                    'description': 'Some Description',
                    'defaultSelection': 'Selection3',
                    'selections': [
                        'Selection1',
                        'Selection2',
                        'Selection3',
                        'Selection4',
                        'Selection5',
                        'Selection6'
                    ]
                }, {
                    'key': 'radioButtons',
                    'title': 'Select one',
                    'required': false,
                    'description': 'Some Description',
                    'defaultSelection': 'Selection2',
                    'selections': [
                        'Selection1',
                        'Selection2',
                        'Selection3'
                    ]
                }, {
                    'key': 'asyncDropdown',
                    'title': 'Select one of the async data',
                    'required': true,
                    'description': 'Some Description',
                    'placeholder': 'Some placeholder',
                    'multipleSelection': false,
                    'asynchronousSelection': true,
                    'selectionsUrl': '/tasks/filters'
                }, {
                    'key': 'dropdown',
                    'title': 'Select one',
                    'required': true,
                    'description': 'Some Description',
                    'placeholder': 'Some placeholder',
                    'multipleSelection': false,
                    'asynchronousSelection': false,
                    'selections': [
                        'Selection1',
                        'Selection2',
                        'Selection3'
                    ]
                }, {
                    'key': 'requiredLabel'
                }]
            },
            'widgets': {
                'previousAttachments': {
                    'config': {
                        'available': true
                    }
                },
                'uploadAttachments': {
                    'config': {
                        'available': true
                    }
                }
            }
        };

        $scope.formModel = {};
        $scope.formModel.dynamicFieldsModel = {};


        $scope.submitForm = function(form, formAction) {
            // First we broadcast an event so all fields validate themselves
            $scope.$broadcast('schemaFormValidate');
            console.log(formAction);
            // Then we check if the form is valid
            if (form.$valid) {
                $scope.formError = false;
            } else {
                $scope.formError = true;
            }
        };

        $scope.clear = function(form) {
            $scope.formError = false;
            $scope.formModel = {};
            $scope.formModel.dynamicFieldsModel = {};
            form.$setPristine();
            $scope.$broadcast('schemaFormRedraw');
            $scope.$broadcast('uploadAttachmentsWidget.clearQueue');
        };

    }
})();
