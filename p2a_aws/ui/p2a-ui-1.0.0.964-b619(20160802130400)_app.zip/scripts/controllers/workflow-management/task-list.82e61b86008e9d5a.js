'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:TaskListCtrl
 * @description
 * # TaskListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')

.controller('TaskListCtrl', function($filter, $scope, uiGridConstants, $http, $state, $timeout, ENV, ppmUtils, $stateParams, WorkflowDataFactory,
    ModalDialogFactory, $log, FilterService, WorkflowService, WorkflowFilterService, filtersGroupsMeta, PaginationService, ProductPlanMgmtSvc, ConfirmationModalFactory, userAuthorizationManager) {
    $scope.debugMode = (ENV.name === 'local');
    $scope.searchQuery = $stateParams.searchquery;
    $scope.filters = filtersGroupsMeta;
    $scope.selectedFilters = {};

    var pageSize = 20;

    var gridOptions = $scope.gridOptions = {
        'excessRows': 400, // SLQ need to more investigation
        //"scrollThreshold": 4,
        //"excessColumns": 4,
        enableSorting: true,
        // pagination
        enablePaginationControls: false,

        enableFiltering: true,

        paginationPageSizes: ENV.settings.paginationPageSizes,

        //ENV.settings.paginationPageSizes, TODO Can't change value in 'Gruntfile.js' temporarily (Change will break other screens)

        paginationPageSize: pageSize,
        // scroll bar
        enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
        rowHeight: 85,
        minRowsToShow: 6,
        multiSelect: false,
        rowTemplate: 'views/workflow-management/template/task/task-list-row.html',
        useExternalPagination: true,
        useExternalSorting: true,
        enableRowHeaderSelection: false
    };

    var paginationOptions = {
        pageNumber: 1,
        pageSize: 20,
        sort: null
    };
    $scope.pageVal = {
        pageNumber: ''
    };
    //var preSearchQuery = null;

    function hasViewOthersPermission() {
        // NOTE: Current only the 'OrganizationAdmin' role has this permission, so we use this
        // permission to determine if user is organization admin user
        var hasPerm = userAuthorizationManager.hasPermission('entity.unlock'); // do not to check criteria
        // HRSuperAdmin has the all.create permisison
        hasPerm = hasPerm || userAuthorizationManager.hasPermission('all.create'); // do not to check criteria

        return hasPerm;
    }

    var applyFilter = {};
    if (hasViewOthersPermission()) {
        applyFilter = { term: '' };
    } else {
        applyFilter = { term: $scope.email };
    }

    gridOptions.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
            if (sortColumns.length >= 0) {
                PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
            }
            $scope.loadData();
        });
        $scope.gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
            paginationOptions.pageNumber = newPage;
            paginationOptions.pageSize = pageSize;
            $scope.queryData(); //$scope.loadData();
            if (!PaginationService.isGoToPageEnabled) {
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
            PaginationService.setGoToPageEnabled(false);
        });
    };
    //
    gridOptions.rowIdentity = function(row) {
        return row.id;
    };
    gridOptions.getRowIdentity = function(row) {
        return row.id;
    };

    gridOptions.columnDefs = [{
        displayName: '',
        name: 'X1',
        field: 'element1',
        width: 50,
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: false,
        cellTemplate: 'views/workflow-management/template/task/task-list-icon-col.html'
    }, {
        displayName: 'My Tasks',
        name: 'name',
        field: 'name',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/task/task-list-name-col.html'
    }, {
        displayName: 'Process',
        name: 'processDefinitionUrl',
        field: 'processDefinitionUrl',
        width: 180,
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/task/task-list-process-col.html'
    }, {
        displayName: 'Case ID',
        name: 'caseId',
        field: 'caseId',
        width: 70,
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/task/task-list-id-col.html'
    }, {
        displayName: 'Due Date',
        name: 'dueDate',
        field: 'dueDate',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        width: '170',
        cellTemplate: 'views/workflow-management/template/task/task-list-due-date-col.html'
    }, {
        displayName: 'Assigned On',
        name: 'createTime',
        field: 'createTime',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        width: '170',
        cellTemplate: 'views/workflow-management/template/task/task-list-assigned-on-col.html'
    }, {
        displayName: 'Assignee',
        name: 'assignee',
        field: 'assignee',
        width: 150,
        enableColumnMenu: false,
        enableColumnMenus: false,
        filter: applyFilter,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/task/task-list-assignee-col.html'
    }];

    $scope.taskList = [];
    $scope.gridOptions.data = 'taskList';

    $scope.doSearch = function(keyEvent) {
        if (keyEvent.which === 13) {
            $scope.gridDocuments.paginationCurrentPage = 1;
            $scope.queryData();
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        }
    };

    $scope.loadData = function(query) {
        WorkflowDataFactory.getTasks(query).then(function(data) {
            $scope.gridOptions.totalItems = data.response.numFound;
            $scope.taskList = data.response.docs;
        });
    };

    function getPlanId(taskId) {
        var planId;
        for (var i = 0, j = $scope.taskList.length; i < j; i++) {
            var task = $scope.taskList[i];
            if (task.id === taskId) {
                for (var p = 0, k = task.variables.length; p < k; p++) {
                    if (task.variables[p].name === 'pm_planid') {
                        planId = task.variables[p].value;
                        break;
                    }
                }
            }
        }
        return planId;
    }

    $scope.showTaskSummaryDialog = function(taskId) {

        var dialogOptions = {
            templateUrl: 'views/workflow-management/task-summary.html',
            controller: 'TaskSummaryDialogCtrl',
            resolve: {
                planId: function() {
                    return getPlanId(taskId);
                },
                taskDetails: function() {
                    return WorkflowDataFactory.getTaskDetails(taskId).then(function(data) {
                        return data.data;
                    });
                }
            },
            size: 'md'
        };

        ModalDialogFactory.showDialog(dialogOptions).then(function(result) {
            var auditLogData = {
                'auditCategory': 'Validation',
                'auditSubCategory': 'Plan',
                'eventDetails': '{\"comments\":[\"' + result.comments + '\"]}',
                'objectRef': result.planId //'(plan ID contained in the task object)'
            };

            // Execute complete task service
            if (result.action === 'accept') {
                auditLogData.event = 'Override Approved';

                if (result.task.taskDefinitionKey === 'L3_Task') {
                    ProductPlanMgmtSvc.updatePlan({ 'planStatus': auditLogData.event }, auditLogData.objectRef)
                        .then(function() {
                            $log.log('Validation Plan --> Set plan status approved');
                            ConfirmationModalFactory.open('Validation Plan', 'Set plan status approved', ENV.modalErrorTimeout);
                        }, function() {
                            $log.log('Failed --> setting plan status to Override Approved ');
                        });
                }

                ProductPlanMgmtSvc.sendAuditLog(auditLogData)
                    .then(function() {
                        $log.log('Validation Plan --> Workflow Task Accepted');
                        WorkflowService.acceptTask(result.task.processInstanceId, taskId).then(function() {
                            $scope.loadData();
                        });
                    }, function() {
                        $log.log('Fail to update audit log');
                    });

            } else if (result.action === 'reject') {
                auditLogData.event = 'Override Rejected';

                ProductPlanMgmtSvc.updatePlan({ 'planStatus': auditLogData.event }, auditLogData.objectRef)
                    .then(function() {
                        $log.log('Validation Plan --> Set plan status rejected');
                        ConfirmationModalFactory.open('Validation Plan', 'Set plan status rejected', ENV.modalErrorTimeout);
                    }, function() {
                        $log.log('Failed --> setting plan status to Override Rejected');
                    });

                ProductPlanMgmtSvc.sendAuditLog(auditLogData).then(function() {
                    $log.log('Validation Plan --> Workflow Task Rejected');
                    WorkflowService.rejectTask(result.task.processInstanceId, taskId).then(function() {
                        $scope.loadData();
                    });
                }, function() {
                    var msg = 'Fail to update audit log';
                    $log.log('Failed --> ' + msg);
                });

            } else if (result.action === 'routeToL1') {
                WorkflowService.routeToL1(result.task.processInstanceId, taskId).then(function() {
                    $scope.loadData();
                });

            } else if (result.action === 'routeToL2') {
                WorkflowService.routeToL2(result.task.processInstanceId, taskId).then(function() {
                    $scope.loadData();
                });

            }

        });
    };

    //get passed data to filter the grid
    $scope.queryData = function queryData(selectedId, objs) {
        $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOptions);
         $scope.query = WorkflowFilterService.getTaskFilterQuery($scope.taskSearchQuery, $scope.selectedFilters);
        $scope.loadData($scope.query);
    };

    // Initial data load
    $scope.loadData();

});
