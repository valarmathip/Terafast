'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:TaskSummaryDialogCtrl
 * @description
 * # TaskSummaryDialogCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('TaskSummaryDialogCtrl', function($state, $scope, $modalInstance, ModalDialogFactory, taskDetails, planId) {
        $scope.taskDetails = taskDetails;
        $scope.close = function() {
            $modalInstance.dismiss('cancel');
        };

        $scope.data = {};
        $scope.data.comments = '';

        //prepare config for modal directive

        //all details for selected task
        $scope.taskDetails = taskDetails;
        //id of current task
        $scope.taskId = taskDetails.id;
        //parent case of selected task
        $scope.caseId = taskDetails.processInstanceId;
        //form properties for selected task


        // $scope.acceptTask = function() {
        //     ModalDialogFactory.closeDialog({
        //         action: 'accept',
        //         comments: $scope.data.comments,
        //         task: $scope.taskDetails,
        //         planId: planId
        //     });
        // };

        // $scope.rejectTask = function() {
        //     ModalDialogFactory.closeDialog({
        //         action: 'reject',
        //         comments: $scope.data.comments,
        //         task: $scope.taskDetails,
        //         planId: planId
        //     });
        // };

        //prepare config for modal directive
        $scope.config = {};
        $scope.config.taskDetails = taskDetails;
        $scope.config.taskId = taskDetails.id;
        $scope.config.caseId = taskDetails.processInstanceId;
        $scope.config.formType = taskDetails.formKey;
        $scope.config.$modalInstance = $modalInstance;
        $scope.config.formDetails = [];



        $scope.viewPlanDetails = function() {
            $modalInstance.dismiss('cancel');
            $state.go('home.ppm.plan.edit.plan-details', {
                planId: planId

                // ,
                // type: 'plan',
                // action: 'edit'
            });
        };

    });