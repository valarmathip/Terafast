'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:CaseSummaryDailogCtrl
 * @description
 * # CaseSummaryDailogCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
  .controller('CaseSummaryDialogCtrl', function ($filter, $scope, $modalInstance, caseDetails, WorkflowDataFactory) {
    
    $scope.caseDetails = caseDetails;
    $scope.tasks = caseDetails.tasks;
    
    for (var i = 0; i < caseDetails.variables.length; i++) {
      if(caseDetails.variables[i].name === 'pm_plan_name') {
        $scope.pmPlanName = caseDetails.variables[i].value;
      }
    }

    /**
     * Return the progress diagram image URL for the case
     */
    WorkflowDataFactory.getCaseProcessDiagram($scope.caseDetails.id).then(function(response){
      $scope.processDiagramUrl =  response;
    });

    $scope.close = function () {
      $modalInstance.dismiss('cancel');
    };

  });
