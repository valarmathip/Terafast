'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:TaskListCtrl
 * @description
 * # CaseListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')

  .controller('CaseListCtrl', function ($filter, $scope, uiGridConstants, $http, $state, $timeout, ENV, ppmUtils, $stateParams, WorkflowDataFactory,
                                        dialogFactorySvc, FilterService, WorkflowFilterService, filtersGroupsMeta, PaginationService) {
    $scope.debugMode = (ENV.name === 'local');
    $scope.searchQuery = $stateParams.searchquery;
    $scope.filters = filtersGroupsMeta;
    $scope.selectedFilters = {};

    var pageSize = 20;

    var gridOptions = $scope.gridOptions = {
      'excessRows': 400, // SLQ need to more investigation
      //"scrollThreshold": 4,
      //"excessColumns": 4,
      enableSorting: true,
      // pagination
      enablePaginationControls: false,

      paginationPageSizes: ENV.settings.paginationPageSizes,

      //ENV.settings.paginationPageSizes, TODO Can't change value in 'Gruntfile.js' temporarily (Change will break other screens)

      paginationPageSize: pageSize,
      // scroll bar
      enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
      enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
      rowHeight: 85,
      minRowsToShow: 6,
      multiSelect: false,
      rowTemplate: 'views/workflow-management/template/case/case-list-row.html',
      useExternalPagination: true,
      useExternalSorting: true,
      enableRowHeaderSelection: false
    };

    var paginationOptions = {
      pageNumber: 1,
      pageSize: 20,
      sort: null
    };
    $scope.pageVal = {
      pageNumber: ''
    };
    //var preSearchQuery = null;

    gridOptions.onRegisterApi = function (gridApi) {
      $scope.gridApi = gridApi;
      $scope.gridApi.core.on.sortChanged($scope, function (grid, sortColumns) {
        if (sortColumns.length >= 0) {
          PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
        }
        $scope.loadData();
      });
      $scope.gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
        paginationOptions.pageNumber = newPage;
        paginationOptions.pageSize = pageSize;
        $scope.queryData();//loadData();
        if (!PaginationService.isGoToPageEnabled) {
          $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        }
        PaginationService.setGoToPageEnabled(false);
      });
    };
    //
    gridOptions.rowIdentity = function (row) {
      return row.id;
    };
    gridOptions.getRowIdentity = function (row) {
      return row.id;
    };

    gridOptions.columnDefs = [
      {
        displayName: '',
        name: 'X1',
        field: 'element1',
        width: 50,
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: false,
        cellTemplate: 'views/workflow-management/template/case/case-list-icon-col.html'
      },
      {
        displayName: 'Case ID',
        name: 'caseId',
        field: 'caseId',
        width: 70,
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/case/case-list-id-col.html'
      },
      {
        displayName: 'Instance Name',
        name: 'name',
        field: 'name',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/case/case-list-name-col.html'
      }, {
        displayName: 'Process',
        name: 'processName',
        field: 'processName',
        width: 210,
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        cellTemplate: 'views/workflow-management/template/case/case-list-process-col.html'
      }, {
        displayName: 'Due Date',
        name: 'caseDueDate',
        field: 'caseDueDate',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        width: 170,
        cellTemplate: 'views/workflow-management/template/case/case-list-due-date-col.html'
      }, {
        displayName: 'Created On',
        name: 'creationDate',
        field: 'creationDate',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        width: 170,
        cellTemplate: 'views/workflow-management/template/case/case-list-created-on-col.html'
      }
    ];

    $scope.caseList = [];
    $scope.gridOptions.data = 'caseList';

    $scope.doSearch = function (keyEvent) {
      if (keyEvent.which === 13) {
        $scope.gridDocuments.paginationCurrentPage = 1;
        $scope.queryData();
        $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
      }
    };

    $scope.loadData = function(query) {
      WorkflowDataFactory.getCases(query).then(function (data) {
        $scope.gridOptions.totalItems = data.response.numFound;
        $scope.caseList = data.response.docs;
      });
    };


    $scope.showCaseSummaryDialog = function (caseId) {
      var dlgUrl = 'views/workflow-management/case-summary.html';
      var controller = 'CaseSummaryDialogCtrl';
      var data = {
        caseDetails: function() {
          return WorkflowDataFactory.getCaseDetails(caseId).then(function(data) {
            return data.data;
          });
        }
      };
      var options = {
        size: 'lg'
      };
      dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
    };

    //get passed data to filter the grid
    $scope.queryData = function queryData(selectedId, objs) {
      $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOptions);
      $scope.query = WorkflowFilterService.getCaseFilterQuery($scope.caseSearchQuery, $scope.selectedFilters);
      $scope.loadData($scope.query);
    };

    // Initial data load
    $scope.loadData();

  });
