'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:WorkflowManagementCtrl
 * @description
 * # WorkflowManagementCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
  .controller('WorkflowManagementCtrl', function () {
  });
