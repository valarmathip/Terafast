'use strict';

angular.module('p2AdvanceApp')
    .controller('LandingPageCtrl', function($scope) {
        $scope.modules = [
        // PONHR- 1036
        // {
        //     name: 'Account Management',
        //     icon: 'fa-users',
        //     disabled: true,
        //     sref: 'home.landing-page'
        // }, 
        {
            name: 'Admin',
            icon: 'fa-key',
            //disabled: true,
            sref: 'home.admin.landing-page'
        }, 
        // PONHR- 1036
        // {
        //     name: 'Distribution',
        //     icon: 'fa-share-alt',
        //     disabled: true,
        //     sref: 'home.landing-page'
        // }, 
        {
            name: 'Media Management',
            icon: 'fa-file-text-o',
            sref: 'home.media-management.documents'
        }, 
        {
            name: 'Product/Plan Management',
            icon: 'fa-file-text-o',
            sref: 'home.ppm.plan.plan-list' // DOGHR-1091
        },
        {
            name: 'Workflow',
            icon: 'fa-sitemap',
            sref: 'home.workflow.tasks' // DOGHR-1091
        },
        {
                               
            name: 'Offerings',
            icon: 'fa-folder',
            sref: 'home.ppm.offering.offering-list'  //DOGHR-2364
        }
        ];
        $scope.something='';
    });