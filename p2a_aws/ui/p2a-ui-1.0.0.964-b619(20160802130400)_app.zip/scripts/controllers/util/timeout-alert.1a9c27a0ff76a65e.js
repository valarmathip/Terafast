'use strict';

angular.module('p2AdvanceApp')
    .controller('TimeOutAlertCtrl', function (
        $scope,
        $modalInstance,
        $timeout,
        $auth
        ) {

        var noAnswer = function() {
            $timeout.cancel(noAnswerPromise);
            $modalInstance.dismiss('signOut');
        };

        $scope.userLogoutWaitingTimeSeconds = $auth.getUserLogoutWaitingTimeSeconds();

        var noAnswerPromise = $timeout(noAnswer, $auth.getUserLogoutWaitingTime());

        $scope.keepSignedIn = function () {
            $timeout.cancel(noAnswerPromise);
            $modalInstance.close('keepSignedIn');
        };

        $scope.signOut = function () {
            $timeout.cancel(noAnswerPromise);
            $modalInstance.close('signOut');
        };

        $scope.cancel = function () {
            $timeout.cancel(noAnswerPromise);
            $modalInstance.dismiss('cancel');
        };

    });

