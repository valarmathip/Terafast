'use strict';

angular.module('p2AdvanceApp').
controller('FileSelectCtrl', function($window, $scope, DocumentDataFactory, $stateParams, ConfirmationModalFactory, ENV, $log) {

    $scope.objects = [];
    $scope.objectsPerPage = [];
    $scope.itemsPerPage = 20;
    $scope.currentPage = 1;
    $scope.selectedObjects = [];
    $scope.selectedPlanObjectIds = [];
    $scope.selectedPlanObjectTypes = [];
    $scope.selectedPlanNames = [];
    $scope.mainObj = {};
    $scope.listOfSelectedObjects = [];
    $scope.fileSelectorType = $stateParams.objectType;
    $scope.setInitialData = function(fileSelectorType){
    if (fileSelectorType !== undefined && fileSelectorType.toLowerCase() === 'document') {
        $scope.title = 'List of Documents';
        DocumentDataFactory.getDocuments().then(function(data) {
               $scope.setData(data);
            },
            function(reason) {
                $log.error(reason);
                ConfirmationModalFactory.open('Error Message', 'Error occured when loading a list of available documents.', ENV.modalErrorTimeout);
            });
    } else if (fileSelectorType !== undefined && fileSelectorType.toLowerCase() === 'plan') {
        $scope.title = 'List of Plans';
        DocumentDataFactory.getPlans().then(function(data) {
                $scope.setData(data);
            },
            function(reason) {
                $log.error(reason);
                ConfirmationModalFactory.open('Error Message', 'Error occured when loading a list of available plans.', ENV.modalErrorTimeout);
            });
    } else if (fileSelectorType !== undefined && fileSelectorType.toLowerCase() === 'product') {
        $scope.title = 'List of Products';
        DocumentDataFactory.getProducts().then(function(data) {
                $scope.setData(data);
            },
            function(reason) {
                $log.error(reason);
                ConfirmationModalFactory.open('Error Message', 'Error occured when loading a list of available products.', ENV.modalErrorTimeout);
            });
    }
    };
    $scope.setData = function(data){
        $scope.objects = data;
        $scope.objectsLength = $scope.objects.length;
        $scope.loaded();
    };
    $scope.setInitialData($scope.fileSelectorType);

    $scope.loaded = function() {
        $scope.splitNewArrayForPagination(0, 20);
    };
    //initial pagination
    $scope.splitNewArrayForPagination = function(startPoint, endPoint) {
        if ($scope.objectsLength > endPoint) {
            $scope.objectsPerPage = $scope.objects.slice(startPoint, endPoint);
        } else {
            $scope.objectsPerPage = $scope.objects;
        }
    };
    $scope.toggleSelection = function(objectId, objectType, name) {
        var idx = $scope.selectedPlanObjectIds.indexOf(objectId);
        if (idx > -1) {
            $scope.selectedPlanObjectIds.splice(idx, 1);
            $scope.selectedPlanObjectTypes.splice(idx, 1);
            $scope.selectedPlanNames.splice(idx, 1);
            $scope.listOfSelectedObjects.splice(idx, 1);

        }
        // is newly selected
        else {
            $scope.selectedPlanObjectIds.push(objectId);
            $scope.selectedPlanObjectTypes.push(objectType);
            $scope.selectedPlanNames.push(name);
            $scope.selectedObject = {};
            $scope.selectedObject['objectId'] = objectId;
            $scope.selectedObject['objectType'] = objectType;
            $scope.selectedObject['name'] = name;
            $scope.listOfSelectedObjects.push($scope.selectedObject);
            $scope.mainObj['selectedObjects'] = $scope.listOfSelectedObjects;

        }

    };

    //page navigation, change the page to view other references
    $scope.changePage = function(pageNumber) {
        var endPoint = pageNumber * 20;
        var startPoint = endPoint - 20;
        if ($scope.objectsLength >= endPoint) {
            $scope.objectsPerPage = $scope.objects.slice(startPoint, endPoint);
        } else {
            $scope.objectsPerPage = $scope.objects.slice(startPoint, $scope.objectsLength);
        }
    };

    $scope.ok = function() {
        $log.log(JSON.stringify($scope.mainObj, null, 3));
        return JSON.stringify($scope.mainObj, null, 3);
    };

});