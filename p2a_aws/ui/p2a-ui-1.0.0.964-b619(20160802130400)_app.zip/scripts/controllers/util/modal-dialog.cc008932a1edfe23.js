'use strict';

angular.module('p2AdvanceApp').
controller('ModalDailogCtrl', function ($scope, $filter, DocumentDataFactory, $http, $log, ModalDialogFactory, $modalInstance, fileSelectorType, fieldSelectorOption, ConfirmationModalFactory, ENV, ppmUtils, ProductPlanMgmtSvc,
    PaginationService,
    FilterService,
    authorizedUserInfo) {

    var selectorType = fileSelectorType;
    $scope.fileSelectoroption = fieldSelectorOption;
    $scope.objects = [];
    $scope.objectsPerPage = [];
    $scope.filterFieldOptions = {};
    $scope.currentPage = 1;
    $scope.selectedObjects = [];
    $scope.selectedPlanObjectIds = [];
    $scope.selectedPlanObjects = [];
    $scope.selectedPlanObjectTypes = [];
    $scope.selectedPlanNames = [];
    $scope.mainObj = {};
    $scope.listOfSelectedObjects = [];
    $scope.filteredRecords = [];
    $scope.recordsPerPage = [10, 20, 40, 60, 80, 100];
    //stores checkboxes selected attribute values, could come from multiple filters
    $scope.filterOptions = [];
    // stores multiple filter options
    $scope.selectedIdToObjsMap = [];
    $scope.userInformation = authorizedUserInfo;

    $scope.selectAllChecker = false;
    $scope.selectChecker = false;
    $scope.checkList = [];

    //var setOrResetCheckList = function (row) {
    //    $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
    //};
    //var setCheckList = function () {
    //    $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
    //};

    $scope.toggleSelected = function (row) {
        if ($scope.fileSelectoroption === 'single') {
            $scope.gridApi.selection.clearSelectedRows();

            if (!row.isSelected && !$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = false;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }

            $scope.checkList = [];

        } else if ($scope.fileSelectoroption === 'multiple') {
            if (!$scope.checkList[row.entity.objectId]) {
                row.isSelected = true;
                row.enableSelection = true;
                $scope.gridApi.selection.selectRow(row);
                $scope.selectChecker = true;
            } else {
                row.isSelected = false;
                row.enableSelection = true;
                $scope.gridApi.selection.unSelectRow(row);
                $scope.selectChecker = false;
            }
        }

        $scope.selectedPlanObjects = $scope.gridApi.selection.getSelectedRows();
        $scope.checkList[row.entity.objectId] = $scope.selectChecker;
    };

    $scope.selectAllItems = function () {
        if ($scope.fileSelectoroption === 'single') {   // no multi selection if it is 'single' from calling page
            return;
        }

        if (!$scope.selectAllChecker) {
            angular.forEach($scope.gridApi.grid.rows, function (row) {
                row.isSelected = true;
                row.enableSelection = true;
            });

            $scope.gridApi.selection.selectAllRows();
            $scope.selectAllChecker = true;
        } else {
            angular.forEach($scope.gridApi.grid.rows, function (row) {
                row.isSelected = false;
                row.enableSelection = true;
            });

            $scope.gridApi.selection.clearSelectedRows();
            $scope.selectAllChecker = false;
        }

        $scope.selectedPlanObjects = $scope.gridApi.selection.getSelectedRows();

        angular.forEach($scope.selectedPlanObjects, function (obj) {
            $scope.checkList[obj.objectId] = $scope.selectAllChecker;
        });
    };

    $scope.gridOptions = {
        data: $scope.objects,
        enableRowSelection: false,
        enableRowHeaderSelection: false,
        multiSelect: false,
        enableHorizontalScrollbar: 0, //never show the horizontal scroll bar
        enableVerticalScrollbar: 2,
        rowHeight: 35,
        enablePaginationControls: false,
        paginationPageSizes: ENV.settings.paginationPageSizes,
        paginationPageSize: 20,
        useExternalPagination: true,
        useExternalSorting: true,
        columnDefs: [{
            name: 'objectId',
            displayName: '',
            enableColumnMenu: false,
            headerCellTemplate: '<input data-hraf-id="select-all-plans-checkbox" type="checkbox" class="grid-checkbox-position" ng-model="grid.appScope.master" ng-click="grid.appScope.selectAllItems()">',
            cellTemplate: '<input data-hraf-id="plan-{{row.entity.objectId}}-checkbox" type="checkbox" class="grid-checkbox-position"' +
                          'ng-model="grid.appScope.checkList[row.entity.objectId]" ng-checked="grid.appScope.master && grid.appScope.checkList[row.entity.objectId]"' +
                          'ng-click="grid.appScope.toggleSelected(row)"/>',
            width: 60,
            enableHiding: false
        }, {
            name: 'name',
            displayName: 'Plan Name',
            enableColumnMenu: false,
            cellTemplate: '<div data-hraf-id="plan-{{row.entity.objectId}}-name" class="ui-grid-cell-contents">{{row.entity.name}} </div>',
            enableHiding: false
        }],

        onRegisterApi: function(gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;
            $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                if (sortColumns.length === 0) {
                    paginationOptions.sort = null;
                } else {
                    paginationOptions.sort = sortColumns[0].sort.direction;
                }
                loadData();
            });
            gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                $scope.gridOptions.virtualizationThreshold = pageSize;
                loadData();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });

            gridApi.selection.on.rowSelectionChanged($scope, function() {
                //var selectedPlan = $scope.gridApi.selection.getSelectedRows()[0];
                //$scope.toggleSelection(selectedPlan.objectId, selectedPlan.objectType, selectedPlan.name, selectedPlan.planYear, 'single');
                $scope.selectedPlanObjects = $scope.gridApi.selection.getSelectedRows();
            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function() {
                $scope.selectedPlanObjects = $scope.gridApi.selection.getSelectedRows();
            });

            //gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            //gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
        }

    };
    $scope.viewPages = function() {
        var ps = [];
        ps = PaginationService.viewPages($scope.gridApi, ps);
        return ps;
    };
    $scope.doSearch = function(keyEvent) {
        if (keyEvent.which === 13) {
            $scope.gridOptions.paginationCurrentPage = 1;
            loadData();
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        }
    };
    $scope.pageSizeChanged = function() {
        $scope.gridOptions.paginationCurrentPage = 1;
    };
    $scope.goToPage = function(keyEvent, pageNumberObject) {
        PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);

    };
    $scope.navPage = function($event, delta) {

        PaginationService.navPage($event, delta, $scope.gridApi);
        $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);

    };
    $scope.loaded = function() {
        loadData();
    };
    var paginationOptions = {
        pageNumber: 1,
        pageSize: 20,
        sort: null
    };


    function loadData() {
        var currentSearchQuery = FilterService.getFilterQueryDocGen($scope.gridApi, $scope.planSearchQuery, $scope.gridOptions, $scope.selectedIdToObjsMap, 'TYPE:"plan"', $scope.matchCase);
        currentSearchQuery += '&properties=objectId,objectType,name';
        $scope.objects = [];
        $scope.gridOptions.data = [];
        DocumentDataFactory.getPlans(currentSearchQuery).then(function(data) {
                $scope.objects = data.response.docs;
                $scope.gridOptions.totalItems = data.response.numFound;
                $scope.gridOptions.data = $scope.objects;
                $scope.objectList = $scope.objects;
                $scope.objectsPagination = $scope.objects;
                $scope.objectsLength = $scope.objects.length;
                //$scope.dataPerPage = 20;
                $scope.itemsPerPage = $scope.recordsPerPage[0];
                if ($scope.objectsLength > $scope.itemsPerPage) {
                    $scope.splitNewArrayForPagination(0, $scope.itemsPerPage);
                } else {
                    $scope.objectList = $scope.objects;
                    $scope.objectsPerPage = $scope.objects;
                }
            },
            function() {
                $log.error('Error occured when loading a list of available plans.');
            });
    }

    function updateFilterTypeObj(filterTypeObj) {
        angular.forEach(filterTypeObj, function(attrVal, attrKey) {
            if (attrKey === 'AttributeValue') {
                filterTypeObj[attrKey] = $scope.userInformation.data.user.email;
            }
        });
    }

    function updatePlanOwnerAttr() {
        var ModifiedByArr = $scope.filtersGroups[2]['User Information Filters'][0]['Modified By'];
        var createdByArr = $scope.filtersGroups[2]['User Information Filters'][1]['Created By'];
        updateFilterTypeObj(ModifiedByArr[0]);
        updateFilterTypeObj(createdByArr[0]);
    }

    $scope.setInitialData = function(selectorType) {
        if (selectorType !== 'undefined' && selectorType.toLowerCase() === 'document') {
            if ($scope.fileSelectoroption === 'single') {
                $scope.title = 'List Of Documents For Generating Summary Of Benefits';
            } else {
                $scope.title = 'List of Documents';
            }
            ProductPlanMgmtSvc.getDocumentFilterMeta().then(function(data) {
                $scope.filtersGroups = data;
            });
            DocumentDataFactory.getDocuments().then(function(data) {
                    $scope.objects = data;
                    $scope.objectList = $scope.objects;
                    $scope.objectsPagination = $scope.objects;
                    $scope.objectsLength = $scope.objects.length;
                    $scope.itemsPerPage = $scope.recordsPerPage[0];
                    if ($scope.objectsLength > $scope.itemsPerPage) {
                        $scope.splitNewArrayForPagination(0, $scope.itemsPerPage);
                    } else {
                        $scope.objectList = $scope.objects;
                        $scope.objectsPerPage = $scope.objects;
                    }
                },
                function() {
                    ConfirmationModalFactory.open('Error Message', 'Error occured when loading a list of available documents.', ENV.modalErrorTimeout);
                });

        } else if (selectorType !== 'undefined' && selectorType.toLowerCase() === 'plan') {
            if ($scope.fileSelectoroption === 'single') {
                $scope.title = 'List Of Plans For Generating Summary Of Benefits';
                $scope.gridOptions.multiSelect = false;
            } else {
                $scope.title = 'List of Plans';
                $scope.gridOptions.multiSelect = true; //enable multi selection for batch
            }
            ProductPlanMgmtSvc.getPlanListFilterMeta().then(function(data) {
                $scope.filtersGroups = data;
                updatePlanOwnerAttr();
            });

            DocumentDataFactory.getPlans().then(function(data) {
                    $scope.objects = data.response.docs;
                    $scope.gridOptions.totalItems = data.response.numFound;
                    $scope.gridOptions.data = $scope.objects;
                    $scope.objectList = $scope.objects;
                    $scope.objectsPagination = $scope.objects;
                    $scope.objectsLength = $scope.objects.length;
                    //$scope.dataPerPage = 20;
                    $scope.itemsPerPage = $scope.recordsPerPage[0];
                    if ($scope.objectsLength > $scope.itemsPerPage) {
                        $scope.splitNewArrayForPagination(0, $scope.itemsPerPage);
                    } else {
                        $scope.objectList = $scope.objects;
                        $scope.objectsPerPage = $scope.objects;
                    }
                },
                function() {
                    ConfirmationModalFactory.open('Error Message', 'Error occured when loading a list of available plans.', ENV.modalErrorTimeout);
                });
        } else if (selectorType !== 'undefined' && selectorType.toLowerCase() === 'product') {
            if ($scope.fileSelectoroption === 'single') {
                $scope.title = 'List Of Products For Generating Summary Of Benefits';
            } else {
                $scope.title = 'List of Products';
            }
            ProductPlanMgmtSvc.getPlanListFilterMeta().then(function(data) {
                $scope.filtersGroups = data;
            });
            DocumentDataFactory.getProducts().then(function(data) {
                    $scope.objects = data;
                    $scope.objectList = $scope.objects;
                    $scope.objectsPagination = $scope.objects;
                    $scope.objectsLength = $scope.objects.length;
                    $scope.itemsPerPage = $scope.recordsPerPage[0];
                    if ($scope.objectsLength > $scope.itemsPerPage) {
                        $scope.splitNewArrayForPagination(0, $scope.itemsPerPage);
                    } else {
                        $scope.objectList = $scope.objects;
                        $scope.objectsPerPage = $scope.objects;
                    }
                },
                function() {
                    ConfirmationModalFactory.open('Error Message', 'Error occured when loading a list of available products.', ENV.modalErrorTimeout);
                });
        }

    };
    $scope.setInitialData(selectorType);


    //recordsPerPAge
    $scope.changeRecords = function() {
        $scope.splitNewArrayForPagination(0, $scope.itemsPerPage);
    };
    //initial pagination
    $scope.splitNewArrayForPagination = function(startPoint, endPoint) {
        if ($scope.objectsLength > endPoint) {
            $scope.objectsPerPage = $scope.objectList.slice(startPoint, endPoint);
        } else {
            $scope.objectsPerPage = $scope.objectList;
        }
        $scope.currentPage = 1;
    };
    $scope.toggleSelection = function(objectId, objectType, name, plnYear, toggleOption) {
        if (toggleOption === 'single') {
            $scope.selectedPlanObjectIds = [];
            //$scope.selectedPlanObjectTypes = [];
            //$scope.selectedPlanNames = [];
            $scope.listOfSelectedObjects = [];
        }
        var idx = $scope.selectedPlanObjectIds.indexOf(objectId);
        if (idx > -1) {
            $scope.selectedPlanObjectIds.splice(idx, 1);
            // $scope.selectedPlanObjectTypes.splice(idx, 1);
            // $scope.selectedPlanNames.splice(idx, 1);
            $scope.listOfSelectedObjects.splice(idx, 1);
        }
        // is newly selected
        else {
            $scope.selectedPlanObjectIds.push(objectId);
            //$scope.selectedPlanObjectTypes.push(objectType);
            // $scope.selectedPlanNames.push(name);
            $scope.selectedObject = {};
            $scope.selectedObject['objectId'] = objectId;
            $scope.selectedObject['objectType'] = objectType;
            $scope.selectedObject['name'] = name;
            $scope.selectedObject['planYear'] = plnYear;
            $scope.listOfSelectedObjects.push($scope.selectedObject);
            $scope.mainObj['selectedObjects'] = $scope.listOfSelectedObjects;
        }
    };
    //page navigation, change the page to view other references
    $scope.changePage = function(pageNumber) {
        var endPoint = pageNumber * $scope.itemsPerPage;
        var startPoint = endPoint - $scope.itemsPerPage;
        if ($scope.objectsLength >= endPoint) {
            $scope.objectsPerPage = $scope.objectsPagination.slice(startPoint, endPoint);
        } else {
            $scope.objectsPerPage = $scope.objectsPagination.slice(startPoint, $scope.objectsLength);
        }
    };
    $scope.ok = function() {
        $scope.mainObj['selectedObjects'] = [];
        angular.forEach($scope.selectedPlanObjects, function(selectedPlan) {
            var tempObj = {
                'objectId': selectedPlan.objectId,
                'objectType': selectedPlan.objectType,
                'name': selectedPlan.name,
                'planYear': selectedPlan.planYear
            };
            $scope.mainObj['selectedObjects'].push(tempObj);
        });

        $modalInstance.close(JSON.stringify($scope.mainObj, null, 3));
    };
    $scope.cancel = function() {
        $modalInstance.dismiss('cancel');
    };

    /*Filters*/

    //get passed data to filter
    $scope.filterData = function(selectedId, objs) {
        $scope.updateSelectIdToObjsMap(selectedId, objs);
        $scope.gridOptions.paginationCurrentPage = 1;
        loadData();
    };

    $scope.isAnyFilters = function() {
        var length = 0;
        angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
            length += selectedIdToObjs.objs.length;
        });
        if (length > 0) {
            return true;
        }
        return false;
    };

    $scope.updateSelectIdToObjsMap = function(selectedId, objs) {
        // look if selectedId exists in the map
        var isFound = false;
        angular.forEach($scope.selectedIdToObjsMap, function(selectedIdToObjs) {
            if (selectedIdToObjs.selectedId === selectedId) {
                selectedIdToObjs.objs = objs;
                isFound = true;
            }
        });
        if (isFound === false) { // create new selectedId
            $scope.selectedIdToObjsMap[$scope.selectedIdToObjsMap.length] = {
                'selectedId': selectedId,
                'objs': objs
            };
        }
    };



});