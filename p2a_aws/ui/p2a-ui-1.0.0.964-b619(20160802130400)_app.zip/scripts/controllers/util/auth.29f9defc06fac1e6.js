'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:AuthCtrl
 * @description
 * # AuthCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
  .controller('AuthCtrl', function ($rootScope, $log, $auth, apiToken) {

    $log.info('api token ' + apiToken);


  });
