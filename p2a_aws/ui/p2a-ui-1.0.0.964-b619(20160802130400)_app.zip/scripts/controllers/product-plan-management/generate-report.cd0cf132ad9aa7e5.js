'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:GenerateReportCtrl
 * @description
 * # GenerateReportCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('GenerateReportCtrl', function($scope, $filter, $modalInstance, selectedPlanIds,
        reportTemplatesList, $log, ProductPlanMgmtSvc, $rootScope, Common, ENV) {

        $scope.selectedPlanIds = selectedPlanIds;
        $scope.reportTemplatesList = reportTemplatesList;
        $scope.showTemplates = true;
        $scope.selectedTemplates = [];


        $scope.toggleSelection = function(template) {
            var element = angular.element(document.getElementsByClassName('table-responsive'));
            element.remove();
            $scope.selectedTemplates = [];
            $scope.selectedTemplates.push(template.objectId);
            $scope.templateName = template.name;
            $scope.reportLayoutType = template.reportLayout;
            if ($scope.reportLayoutType === 'QHP Rx') {
                $scope.showReportLayout4 = true;
            } else {
                $scope.showReportLayout4 = false;
            }
        };
        angular.forEach($scope.reportTemplatesList, function(item) {
            if (item.reportLayout === 'Plan Comparison') {
                $scope.reportTemplatesList.splice($scope.reportTemplatesList.indexOf(item), 1);
            }
        });


        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

        $scope.generateReport = function() {
            var timezone = $scope.getTimeZone();
            ProductPlanMgmtSvc.getReportPlanDetails($scope.selectedPlanIds.toString(), $scope.selectedTemplates.toString(), timezone).then(function(data) {
                $scope.reportPlanDetails = data;
                $scope.allPlans = $scope.reportPlanDetails.plansToShow;
                $scope.showTemplates = false;
                initGenerateReport();
                if ($scope.reportLayoutType === 'QHP Rx') {
                    $rootScope.$broadcast('bindDataForLayout4');
                } else if ($scope.reportLayoutType === 'QHP Medical') {
                    $rootScope.$broadcast('bindData');
                } else if ($scope.reportLayoutType === 'Medical Runner') {
                    $rootScope.$broadcast('bindDataForLayout2');
                } else if ($scope.reportLayoutType === 'Rx Runner') {
                    $rootScope.$broadcast('bindDataForLayout3');
                }
            });
        };

        $scope.goToTemplatesPage = function() {
            $scope.showTemplates = true;
        };

        $scope.buildPropertiesAndPlanDetailsInfoMap = function() {
            $scope.planDetailsInfo = {};
            $scope.serviceProperties = {};
            var planCount = 0;
            iteratePlans(planCount);
        };

        $scope.constructAllPlanPropertiesMap = function(planSections) {
            angular.forEach(planSections, function(plansection) {
                angular.forEach(plansection, function(plansectionObj, plansectionkey) {
                    if (!$scope[plansectionkey]) {
                        $scope[plansectionkey] = {};
                    }
                    angular.forEach(plansectionObj, function(planPropObj) {
                        var i = 0;
                        var nwTiers = [];
                        angular.forEach(planPropObj, function(networkTiersVal) {
                            nwTiers[i] = networkTiersVal;
                            i++;
                        });
                        $scope[plansectionkey] = nwTiers;
                    });
                });
            });
        };

        $scope.constructAllPlansHeadersArray = function() {
            $scope.allPlansHeaders = [];
            var planheaderCount = 0;
            angular.forEach($scope.allPlans, function(plan) {
                angular.forEach(plan, function(planPropVal, planPropKey) {
                    if (planPropKey === 'planHeaders') {
                        angular.forEach(planPropVal, function(planheader) {
                            if ($scope.reportLayoutType === 'Medical Runner' || $scope.reportLayoutType === 'Rx Runner' || $scope.reportLayoutType === 'QHP Rx') {
                                if ($scope.allPlansHeaders.length === 0) {
                                    $scope.allPlansHeaders.push(planheader);
                                } else {
                                    if ($scope.allPlansHeaders.indexOf(planheader) === -1) {
                                        $scope.allPlansHeaders.push(planheader);
                                    }
                                }
                            } else {
                                $scope.allPlansHeaders[planheaderCount] = planheader;
                                planheaderCount++;
                            }
                        });
                    } else if (planPropKey === 'sections') {
                        $scope.constructAllPlanPropertiesMap(planPropVal);
                    }
                });
            });
            if ($scope.reportLayoutType === 'Medical Runner' || $scope.reportLayoutType === 'Rx Runner' || $scope.reportLayoutType === 'QHP Rx') {
                $scope.sortedHeaders($scope.allPlansHeaders);
            }
        };


        $scope.sortedHeaders = function(allPlansHeaders) {
            $scope.sortedAllPlanHeaders = [];
            var defaultOrder = ['Preferred Network 1', 'Preferred Network 2', 'Preferred Network 3', 'In Network', 'Out of Network', 'Out of Area', 'Out of Country', 'Coverage'];
            angular.forEach(defaultOrder, function(item) {
                angular.forEach(allPlansHeaders, function(header) {
                    if (item === header) {
                        $scope.sortedAllPlanHeaders.push(header);
                    }

                });
            });
            $scope.allPlansHeaders = $scope.sortedAllPlanHeaders;
            return $scope.allPlansHeaders;
        };

        $scope.exportExcel = function() {
            var timezone = $scope.getTimeZone();
            var fieldurl = ENV.apiGatewayEndpoint + '/gateway/reports/exportExcel?planIds=' + $scope.selectedPlanIds.toString() + '&reportTemplateId=' + $scope.selectedTemplates.toString() + '&timeZone=' + timezone;
            var name = $scope.reportLayoutType + '_' + ($filter('date')(new Date(), 'sss_ss_mm_HH_MM_dd_yyyy')).toString();
            Common.downloadAndNotify(fieldurl, name, 'xlsx');
        };

        function getServicePropObj(servicePropObj, value) {
            angular.forEach(value, function(serviceProp) {
                if (typeof serviceProp === 'object' && Object.keys(serviceProp).length) {
                    servicePropObj = angular.copy(serviceProp);
                }
            });
            return servicePropObj;
        }

        function iterateSectionProperties(plan, sectionProperty, sectionName, serviceName, serviceSectionName) {
            angular.forEach(sectionProperty, function(serviceProperty, servicePropertyName) {
                if (sectionName === 'Plan Service') {
                    if ($scope.reportLayoutType === 'Rx Runner') {
                        setIteratedPropertiesForRxRunner(sectionName, serviceName, serviceProperty, servicePropertyName, serviceSectionName);
                        $scope.planDetailsInfo[plan.planName][sectionName][serviceSectionName][serviceName][servicePropertyName] = serviceProperty;
                    } else {
                        setIteratedProperties(sectionName, serviceName, serviceProperty, servicePropertyName);
                        $scope.planDetailsInfo[plan.planName][sectionName][serviceName][servicePropertyName] = serviceProperty;
                    }
                } else if (sectionName !== 'unAssociatedServices') {
                    if ($scope.reportLayoutType === 'Medical Runner') {
                        $scope.properties[servicePropertyName] = {};
                        $scope.planDetailsInfo[plan.planName][servicePropertyName] = serviceProperty;
                    } else {
                        $scope.properties[sectionName][servicePropertyName] = {};
                        $scope.planDetailsInfo[plan.planName][sectionName][servicePropertyName] = serviceProperty;
                    }
                } else if (sectionName === 'unAssociatedServices') {
                    var servicePropObj = null;
                    servicePropObj = getServicePropObj(servicePropObj, sectionProperty);
                    $scope.properties[sectionName][servicePropertyName] = {};
                    $scope.properties[sectionName][servicePropertyName] = servicePropObj;
                    $scope.planDetailsInfo[plan.planName][sectionName][servicePropertyName] = servicePropObj;
                }
            });
        }

        function iterateSections(plan, planCount) {
            angular.forEach(plan.sections, function(planSection) {
                angular.forEach(planSection, function(sectionProperty, sectionName) {

                    if ($scope.reportLayoutType === 'Medical Runner') {
                        if (sectionName === 'Plan Service') {
                            $scope.planDetailsInfo[plan.planName][sectionName] = {};
                            if (planCount === 1) {
                                $scope.properties[sectionName] = {};
                            }
                        }
                    } else if ($scope.reportLayoutType !== 'Medical Runner') {
                        $scope.planDetailsInfo[plan.planName][sectionName] = {};
                        if (planCount === 1) {
                            $scope.properties[sectionName] = {};
                        }
                    }
                    if ($scope.reportLayoutType === 'Rx Runner' && sectionName === 'Plan Service') {
                        angular.forEach(sectionProperty, function(serviceSectionObject, serviceSectionName) {
                            if (!$scope.properties[sectionName].hasOwnProperty(serviceSectionName)) {
                                $scope.properties[sectionName][serviceSectionName] = {};
                            }
                            $scope.planDetailsInfo[plan.planName][sectionName][serviceSectionName] = {};
                            angular.forEach(serviceSectionObject, function(serviceObject, serviceName) {
                                if (!$scope.properties[sectionName][serviceSectionName].hasOwnProperty(serviceName)) {
                                    $scope.properties[sectionName][serviceSectionName][serviceName] = {};
                                }

                                $scope.planDetailsInfo[plan.planName][sectionName][serviceSectionName][serviceName] = {};
                                iterateSectionProperties(plan, serviceObject, sectionName, serviceName, serviceSectionName);
                            });
                        });
                    } else if ($scope.reportLayoutType !== 'Rx Runner' && sectionName === 'Plan Service') {
                        iterateServiceProperty(plan, sectionProperty, sectionName);
                    } else {
                        iterateSectionProperties(plan, sectionProperty, sectionName, '', '');
                    }
                });
            });
        }

        function iteratePlans(planCount) {
            angular.forEach($scope.reportPlanDetails.plansToShow, function(plan) {
                planCount++;
                $scope.planDetailsInfo[plan.planName] = {};
                if (planCount === 1) {
                    $scope.properties = {};
                }
                iterateSections(plan, planCount);
            });
        }

        function initGenerateReport() {
            $scope.buildPropertiesAndPlanDetailsInfoMap();
            $scope.constructAllPlansHeadersArray();
        }

        $scope.getTimeZone = function() {
            var date = new Date().toString().match(/([A-Z]+[\+-][0-9]+)/)[1];
            return encodeURIComponent(date);
        };

        function iterateServiceProperty(plan, sectionProperty, sectionName) {
            angular.forEach(sectionProperty, function(serviceObject, serviceName) {
                if (!$scope.properties[sectionName].hasOwnProperty(serviceName)) {
                    $scope.properties[sectionName][serviceName] = {};
                }

                $scope.planDetailsInfo[plan.planName][sectionName][serviceName] = {};
                iterateSectionProperties(plan, serviceObject, sectionName, serviceName, '');
            });
        }

        function setIteratedProperties(sectionName, serviceName, serviceProperty, servicePropertyName) {
            if (!$scope.properties[sectionName][serviceName].hasOwnProperty(servicePropertyName)) {
                $scope.properties[sectionName][serviceName][servicePropertyName] = {};
            }

            angular.forEach(serviceProperty, function(serviceObject, serviceObjectName) {
                if (!$scope.properties[sectionName][serviceName][servicePropertyName].hasOwnProperty(serviceObjectName)) {
                    $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName] = {};
                }
                angular.forEach(serviceObject, function(serviceProperties, servicePropertiesName) {
                    if (!$scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName].hasOwnProperty(servicePropertiesName)) {
                        $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName] = serviceProperties;
                    }
                    if (serviceObjectName === 'Plan Service Cost Shares') {
                        angular.forEach(serviceProperties, function(servicePropValue, servicePropKey) {
                            if (!$scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName].hasOwnProperty(servicePropKey)) {
                                $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey] = {};
                            }
                            angular.forEach(servicePropValue, function(costShareValue, costShareName) {
                                if (!$scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey].hasOwnProperty(costShareName)) {
                                    $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey][costShareName] = {};
                                    $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey][costShareName] = costShareValue;
                                }
                            });
                        });
                    }
                });
            });
        }

        function setIteratedPropertiesForRxRunner(sectionName, serviceName, serviceProperty, servicePropertyName, serviceSectionName) {
            if (!$scope.properties[sectionName][serviceSectionName][serviceName].hasOwnProperty(servicePropertyName)) {
                $scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName] = {};
            }

            angular.forEach(serviceProperty, function(serviceObject, serviceObjectName) {
                if (!$scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName].hasOwnProperty(serviceObjectName)) {
                    $scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName] = {};
                }
                angular.forEach(serviceObject, function(serviceProperties, servicePropertiesName) {
                    if (!$scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName].hasOwnProperty(servicePropertiesName)) {
                        $scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName] = serviceProperties;
                    }
                    if (serviceObjectName === 'Plan Service Cost Shares') {
                        angular.forEach(serviceProperties, function(servicePropValue, servicePropKey) {
                            if (!$scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName].hasOwnProperty(servicePropKey)) {
                                $scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey] = {};
                            }
                            angular.forEach(servicePropValue, function(costShareValue, costShareName) {
                                if (!$scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey].hasOwnProperty(costShareName)) {
                                    $scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey][costShareName] = {};
                                    $scope.properties[sectionName][serviceSectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey][costShareName] = costShareValue;
                                }
                            });
                        });
                    }
                });
            });
        }

        $log.log('selected plans list------------------->' + JSON.stringify($scope.selectedPlanIds));
        $log.log('reportTemplatesList------------------->' + JSON.stringify($scope.reportTemplatesList));
        $log.log('selectedTemplates------------------->' + JSON.stringify($scope.selectedTemplates));
    });