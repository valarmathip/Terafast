'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:WarningModalDialogCtrl
 * @description
 * # WarningModalDialogCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('WarningModalDialogCtrl', function($scope, $modalInstance, Title, Message, Icon, DialogType, ContentTplUrl) {
        $scope.message = Message;
        $scope.title = Title;
        $scope.icon = Icon;
        $scope.dialogType = DialogType; // ppm-modal-dialog-default, ppm-modal-dialog-warning, ppm-modal-dialog-error
        $scope.contentTplUrl = ContentTplUrl;

        $scope.ok = function() {
            $modalInstance.close();
        };
        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };
    });