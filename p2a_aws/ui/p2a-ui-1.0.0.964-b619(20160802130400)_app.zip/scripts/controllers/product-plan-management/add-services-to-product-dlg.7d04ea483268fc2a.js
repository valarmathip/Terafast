'use strict';

angular.module('p2AdvanceApp')
    .controller('AddServiceToProductDlgCtrl', function($rootScope, $filter, $scope, $modalInstance, filtersMeta, associatedServiceMap, /*serviceList,*/ ENV,
        uiGridConstants, ppmUtils, PPMFilterSvc, $log, ProductPlanMgmtSvc, FilterService, PaginationService, PPMFilterMetaSvc, $timeout, QueryDialog) {


        /** Grid Setting **/
        var pageSize = 20;
        var preSearchQuery = null;
        $scope.checkList = {};
        $scope.filters = PPMFilterMetaSvc.updateFilterMetaData(filtersMeta);
        $scope.gridOption = {
            'excessRows': 20, // SLQ need to more investigation
            enableSorting: true,
            // pagination
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            rowHeight: 105, // never put number in "", like "100"
            minRowsToShow: 6,
            useExternalPagination: true,
            enableHorizontalScrollbar: 0,
            useExternalSorting: true,
            rowTemplate: 'views/product-plan-management/template/service-list/row.html',
            selectionRowHeaderWidth: 0 // hide row head by setting it width to 0 
        };

        $scope.gridOption.columnDefs = [{
            displayName: '',
            name: 'X1',
            field: 'element1',
            width: 70,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/service-list/add-services-to-plan-icon-col.html',
            headerCellTemplate: 'views/product-plan-management/template/service-list/icon-header.html'
        }, {
            displayName: 'Service Name',
            name: 'name',
            field: 'name',
            width: 450,
            enableColumnMenu: false,
            enableColumnMenus: false,
            cellTemplate: 'views/product-plan-management/template/service-list/add-services-to-plan-name-col.html'
        }, {
            displayName: 'Category',
            field: 'category',
            width: '14%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/service-list/category-col.html'
        }, {
            displayName: 'Sub-Category',
            field: 'subCategory',
            width: '14%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/service-list/location-col.html'
        }, {
            displayName: 'Level',
            field: 'level',
            width: '14%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/service-list/level-col.html'
        }];


        $scope.selectedServiceList = [];
        $scope.selectedFilters = {};
        $scope.selectedRows = [];
        $scope.gridOption.data = 'serviceList';
        loadData();
        var paginationOptions = {
            pageNumber: 1,
            pageSize: 20,
            sort: null
        };

        $scope.gridOption.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
            $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
                if (sortColumns.length >= 0) {
                    PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                }
                loadData();
            });
            $scope.gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
                paginationOptions.pageNumber = newPage;
                paginationOptions.pageSize = pageSize;
                loadData();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
            $scope.gridApi.grid.registerDataChangeCallback(function(data) {
                data.selection.selectAll = false;
            }, [uiGridConstants.dataChange.ROW]);


            gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);

        };
        var setOrResetCheckList = function(row) {
            $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);

        };
        var setCheckList = function() {
            $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
        };
        $scope.loaded = function() {
            PaginationService.setSortColumns(null);
        };

        function loadData() {
            var queryParams = {}; // ?q=

            var filterQuery = 'TYPE:"service"';
            // Following sort function specify the add new service default sort order and it will be override when collumn sort is enabled
            var currentSearchParams = FilterService.getFilterParams($scope.gridApi, $scope.planSearchQuery, $scope.gridOption, $scope.selectedFilters, filterQuery, 'name', $scope.matchCase1);
            angular.extend(queryParams, currentSearchParams);
            angular.extend(queryParams, PaginationService.getSortQuery('name asc'));

            var currentSearchQuery = '?' + ppmUtils.paramSerializer(queryParams);
            if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                return;
            }
            preSearchQuery = currentSearchQuery;
            ProductPlanMgmtSvc.getAdditionalServiceList((currentSearchQuery)).then(function(data) {
                $scope.gridOption.totalItems = data.response.numFound;
                $scope.loadedServiceList = transferInput(data.response.docs);
                $scope.selectedRows = $scope.selectedRows.concat($scope.loadedServiceList);
                $scope.refreshGridData();
            }, function() {
                var msg = 'Error occured when loading available Plans.';
                QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
            });
        }

        /** Custom selection */
        $scope.toggleRowSelection = function(event, row) {
            $log.log('toggle the row selection');
            $scope.gridApi.selection.toggleRowSelection(row.entity);
        };

        $scope.toggleAllRowSelection = function(event) {
            if (event.currentTarget.checked) {
                $scope.gridApi.selection.selectAllRows();
            } else {
                $scope.gridApi.selection.clearSelectedRows();
            }
        };
        /** End of Custom selection */

        $scope.refreshGridData = function() {
            $scope.serviceList = [];
            angular.forEach($scope.loadedServiceList, function(item) {
                $scope.serviceList.push({
                    objectId: item.objectId,
                    level: item.level,
                    serviceName: item.serviceName,
                    name: item.name,
                    effectiveDate: item.effectiveDate,
                    endDate: item.endDate,
                    // location: item.location,
                    subCategory: item.subCategory,
                    category: item.category,
                    productStatus: item.productStatus,
                    lastModificationDate: item.lastModificationDate,
                    isServiceIncluded: isServiceIncluded(item.objectId),
                    isServiceCovered: isServiceCovered(item.objectId)
                });
            });
            $scope.count = 0;
            $timeout(function() {
                angular.forEach($scope.checkList, function(value, key) {
                    angular.forEach($scope.serviceList, function(item) {
                        if (item.objectId === key && value === true) {
                            $scope.gridApi.selection.selectRow(item, true);
                            $scope.count++;
                        }
                    });
                });
                if ($scope.count !== 'undefined' && $scope.count === paginationOptions.pageSize) {
                    $scope.gridApi.selection.selectAllRows();
                }
            });
        };

        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject, $scope.gridApi);
        };
        $scope.pageSizeChanged = function() {
            $scope.gridOption.paginationCurrentPage = 1;
        };
        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.gridOption.paginationCurrentPage = 1;
                loadData();
                $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
            }
        };
        /** End of Grid Setting **/

        /** Pagenation Function **/
        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.gridApi);
            $scope.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageNumber);
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.gridApi, ps);
            return ps;
        };
        /** End of Pagenation Function **/

        /** Done and Cancel Button **/
        $scope.ok = function() {
            $scope.selectedServiceList = [];
            angular.forEach($scope.checkList, function(value, key) {
                for (var count = 0; count < $scope.selectedRows.length; count++) {
                    if (key === $scope.selectedRows[count].objectId && value === true) {
                        $scope.selectedServiceList.push($scope.selectedRows[count]);
                        break;
                    }
                }
            });
            $modalInstance.close($scope.selectedServiceList);
        };

        $scope.enableOrDisableDone = function() {
            if (Object.keys($scope.checkList).length === 0) {
                return true;
            }
            if (Object.keys($scope.checkList).length > 0) {
                var counter = Object.keys($scope.checkList).length;
                angular.forEach($scope.checkList, function(value) {
                    if (value === true) {
                        counter++;
                    }
                });
                if (counter !== Object.keys($scope.checkList).length) {
                    return false;
                } else {
                    return true;
                }
            }

        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };


        $scope.queryData = function(selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOption);
            loadData();
        };

        // This is duplicated in the service-list.js and need to move them in a separated service
        /*** Transfer function ***/
        function transferInput(data) {
            var transferedData = [];

            angular.forEach(data, function(item /*, index*/ ) {
                var transferedItem = {};
                angular.forEach(item, function(value, key) {
                    // if (key === 'subCategory') {
                    //     transferedItem['location'] = angular.copy(value);
                    // } else {
                    transferedItem[key] = angular.copy(value); // TODO: if it is really flated data, no deep copy necessary.
                    // }
                });

                transferedData.push(transferedItem);
            });

            return transferedData;
        }
        $scope.clearAll = function() {
            $rootScope.$broadcast('clearAllSelected');
        };

        function isServiceIncluded(serviceId) {
            if (associatedServiceMap[serviceId] !== undefined) {
                return true;
            } else {
                return false;
            }
        }

        function isServiceCovered(serviceId) {
            return !!associatedServiceMap[serviceId];
        }
    });