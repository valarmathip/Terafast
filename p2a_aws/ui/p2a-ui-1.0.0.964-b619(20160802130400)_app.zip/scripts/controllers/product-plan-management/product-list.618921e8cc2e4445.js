'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductListCtrl
 * @description
 * # ProductListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')

.controller('ProductListCtrl', function($filter, $scope, uiGridConstants, $http, ProductPlanMgmtSvc, $state, $timeout, ENV,
    ppmUtils, $stateParams, ProductPlanSearch, FilterService, PaginationService, $auth, $log, filtersGroupsMeta, PPMFilterMetaSvc, DatePickerFilterService, $rootScope, ProductListHoverMenuSvc) {
    $scope.debugMode = (ENV.name === 'local');
    $scope.searchQuery = $stateParams.searchquery;
    $scope.tabUrl = {
        all: 'views/product-plan-management/template/product-list-ui-grid.html',
        draft: '',
        denied: ''
    };
    $scope.userInformation = $auth.getUserEmail();
    // $scope.publishedUrl = '';  // SLQ seems no one use this
    var selectedTab = 'all';
    $scope.selectedFilters = {};


    var pageSize = 20;
    $scope.currentPage = {
        all: 1,
        draft: 1,
        denied: 1
    };
    $scope.currentPageSize = {};
    $scope.currentPageSize['all'] = $scope.currentPageSize['draft'] = $scope.currentPageSize['denied'] = pageSize;
    $scope.filters = PPMFilterMetaSvc.updateProductListFilters(filtersGroupsMeta[0].properties);

    var gridOptionsTpl = {
        'excessRows': 400, // SLQ need to more investigation
        //"scrollThreshold": 4,
        //"excessColumns": 4,
        enableSorting: true,
        // pagination
        enablePaginationControls: false,

        paginationPageSizes: ENV.settings.paginationPageSizes,

        //ENV.settings.paginationPageSizes, TODO Can't change value in 'Gruntfile.js' temporarily (Change will break other screens)

        paginationPageSize: pageSize,
        // scroll bar
        enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
        // height of row
        rowHeight: 160, // never put number in "", like "100"
        minRowsToShow: 6,
        rowTemplate: 'views/product-plan-management/template/product-list-row.html',
        useExternalPagination: true,
        useExternalSorting: true,
        enableRowHeaderSelection: false,
        enableRowSelection: false
    };

    var paginationOptions = {
        pageNumber: 1,
        pageSize: 20,
        sort: null
    };
    $scope.pageVal = {
        pageNumber: ''
    };
    var preSearchQuery = null;

    gridOptionsTpl.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
            if (sortColumns.length >= 0) {
                PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
            }
            executeLoadData();
        });
        $scope.gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
            paginationOptions.pageNumber = newPage;
            paginationOptions.pageSize = pageSize;
            executeLoadData();
            if (!PaginationService.isGoToPageEnabled) {
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
            PaginationService.setGoToPageEnabled(false);
        });

    };

    gridOptionsTpl.rowIdentity = function(row) {
        return row.id;
    };
    gridOptionsTpl.getRowIdentity = function(row) {
        return row.id;
    };

    gridOptionsTpl.columnDefs = [
        // {
        //     displayName: '',
        //     name: 'X1',
        //     field: 'element1',
        //     width: 100,
        //     enableColumnMenu: false,
        //     enableColumnMenus: false,
        //     enableSorting: false,
        //     //headerCellTemplate: 'views/product-plan-management/template/plan-list/icon-col-header.html',
        //     cellTemplate: 'views/product-plan-management/template/product-list-icon-col.html'

        // },
        {
            displayName: 'Product Name',
            name: 'name',
            field: 'name',
            width: 387,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/product-list-name-col.html'
        }, {
            displayName: 'Product Family',
            field: 'productFamilies',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/product-list-plan-family-col.html'
        }, {
            displayName: 'Last Modified',
            field: 'lastModificationDate',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            width: '15%',
            cellTemplate: 'views/product-plan-management/template/product-list-last-modified-on-col.html'
        }, {
            displayName: 'Modified By',
            field: 'lastModifiedBy',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            width: 187,
            cellTemplate: 'views/product-plan-management/template/product-list-last-modified-by-col.html'
        }
    ];

    $scope.productList = [];
    $scope.gridOptions = gridOptionsTpl;
    $scope.gridOptions.data = 'productList';

    $scope.navPage = function($event, delta) {
        PaginationService.navPage($event, delta, $scope.gridApi);
        $scope.currentPage[selectedTab] = $scope.gridApi.pagination.getPage();
        $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
    };

    $scope.hoverItems = ProductListHoverMenuSvc.getHoverMenu($scope);

    $scope.$on('ppm.product.list.hover.menu.lock.status.changed', function(event, lockStatus, productId) {
        event.stopPropagation();
        refreshLockStatus(lockStatus, productId);
    });

    $scope.$on('ppm.product.list.hover.menu.product.status.changed', function(event, productId, status) {
        event.stopPropagation();
        updateProductStatusInViewList($scope.productList, productId, status);
    });

    $scope.createNew = function() {
        $state.go('home.ppm.product.edit.product-details', {
            productId: ''
        });
    };

    function updateProductStatusInViewList(productViewList, productId, status) {
        angular.forEach(productViewList, function(product) {
            if (product.objectId === productId) {
                product.productStatus = status;
            }
        });
    }

    function refreshLockStatus(lockStatus, productId) {
        var product = findProductFromProductListById(productId);
        if (product) {
            if (lockStatus === null) {
                delete product.isLocked; // = undefined;
                delete product.lockedBy; // = undefined;
                delete product.lockedAt; // = undefined;

            } else {
                product.isLocked = lockStatus.isLocked;
                product.lockedBy = lockStatus.lockedBy;
                product.lockedAt = lockStatus.lockedAt; // This could be a little difference between backend really lock time
            }
        }
    }

    function findProductFromProductListById(productId) {
        for (var i = 0; i < $scope.productList.length; i++) {
            if (productId === $scope.productList[i].objectId) {
                return $scope.productList[i];
            }
        }

        return null;
    }

    $scope.viewPages = function() {
        var ps = [];
        ps = PaginationService.viewPages($scope.gridApi, ps);
        return ps;
    };

    $scope.tabSelected = function(tabName) {
        selectedTab = tabName;
        $scope.tabUrl[selectedTab] = 'views/product-plan-management/template/product-list-ui-grid.html';

        if ($scope.currentPageSize[selectedTab]) {
            var num = $scope.currentPageSize[selectedTab];
            $scope.gridOptions.paginationPageSize = num;
        }
    };

    $scope.datePicker = {
        fromDate: {
            productDueDate: [],
            lastModificationDate: [],
            productRegulatoryDate: [],
            effectiveDate: [],
            endDate: []
        },
        toDate: {
            productDueDate: [],
            lastModificationDate: [],
            productRegulatoryDate: [],
            effectiveDate: [],
            endDate: []
        }
    };
    $scope.openCalendar = function($event, $index, effectiveDate) {
        $scope.calendarOpened = {};
        $event.preventDefault();
        $event.stopPropagation();

        if (!$scope.calendarOpened[effectiveDate]) {
            $scope.calendarOpened[effectiveDate] = [];
        }

        $scope.calendarOpened[effectiveDate][$index] = true;
    };

    $scope.setDatePickerAttrId = function(rangeAttr) {
        $scope.selectedFilters = DatePickerFilterService.pushDatePickerAttr(rangeAttr, $scope.selectedFilters);
    };



    $scope.tabDeselected = function(tabName) {
        $scope.tabUrl[tabName] = '';
    };

    $scope.pageSizeChanged = function(ps) {
        $scope.gridOptions.paginationCurrentPage = 1;
        $scope.currentPage[selectedTab] = 1;
        $scope.currentPageSize[selectedTab] = ps;
    };

    $scope.loaded = function() {
        PaginationService.setSortColumns(null);
        loadData();
    };

    $scope.$on('$includeContentLoaded', function() {
        console.log('template loaded');
    });

    // context menu
    $scope.contextMenu = {
        edit: {
            id: 'edit',
            action: function(guid) {
                //console.log("guid = " + guid);
                $state.go('home.ppm.product.edit.product-details', {
                    objectId: guid
                });
            },
            enabled: true
        },
        newPlan: {
            id: 'newPlan',
            action: function(guid) {
                //console.log("guid = " + guid);
                var planData = {};
                ProductPlanMgmtSvc.createPlanFromProduct(planData, guid)
                    .then(function(planId) {
                        $log.log('Edit plan planId = ' + planId);
                        $state.go('home.ppm.plan.edit.plan-details', {
                            planId: planId
                        });
                    });
            }
        },
        other: {
            id: 'other',
            action: function(para) {
                console.log('para = ' + para);
            },
            enable: true
        }
    };


    // private function

    /**
     * Get the list has given status: published, or draft
     */
    function filter(data, status) {
        var result = [];

        angular.forEach(data, function(item) {
            if (!item.productStatus && status.toLowerCase() === 'draft') {
                result.push(item);
            } else if (item.productStatus && item.productStatus.toLowerCase() === status.toLowerCase()) {
                result.push(item);
            }
        });

        return result;
    }

    function loadData() {
        if (!$scope.productList || $scope.productList.length === 0) {
            $timeout(function() {
                executeLoadData();
            }, 500); // wait the ui-grid to steady, otherwise it will only show last one repeatly; This only occurs when first load the product list. Do not like to use time
        } else {
            executeLoadData();
        }
    }
    $scope.doSearch = function(keyEvent) {
        if (keyEvent.which === 13) {
            $scope.gridOptions.paginationCurrentPage = 1;
            $scope.currentPage[selectedTab] = 1;
            executeLoadData();
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        }
    };
    $scope.goToPage = function(keyEvent, pageNumberObject) {
        PaginationService.goToPage(keyEvent, pageNumberObject.pageVal, $scope.gridApi);
        $scope.currentPage[selectedTab] = $scope.gridApi.pagination.getPage();
    };

    $scope.clearAll = function() {
        $rootScope.$broadcast('clearAllSelected');
    };

    $scope.queryData = function(selectedId, objs) {
        $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOptions);
        executeLoadData();
    };


    function executeLoadData() {

        if ($scope.searchQuery === undefined) {
            var queryParams = {}; // ?q=

            var productStatus = (selectedTab === 'all') ? null : (selectedTab === 'draft') ? 'Draft' : 'Denied';
            var filterQuery = 'TYPE:"product"';
            if (productStatus) {
                filterQuery += ' AND productStatus:"' + productStatus + '" ';
            }
            var currentSearchParams = FilterService.getFilterParams($scope.gridApi,
                $scope.productSearchQuery,
                $scope.gridOptions,
                $scope.selectedFilters, filterQuery, 'name',
                $scope.matchCase, '',
                $scope.datePicker.fromDate,
                $scope.datePicker.toDate, '0', undefined,
                $scope.userInformation);

            angular.extend(queryParams, currentSearchParams);
            angular.extend(queryParams, PaginationService.getSortParam());

            var currentSearchQuery = '?' + ppmUtils.paramSerializer(queryParams);

            if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                return;
            }
            $scope.productList = [];
            preSearchQuery = currentSearchQuery;

            ProductPlanMgmtSvc.getProductList(currentSearchQuery).then(function(data) {
                $scope.gridOptions.totalItems = data.response.numFound;
                var result = transformInput(data.response.docs);

                angular.forEach(result, function(item) {
                    this.push(item);
                }, $scope.productList);

            }).then(function() {
                // Need to find a event to reset the current page value; Do not like to use timer
                $timeout(function() {
                    if ($scope.currentPage[selectedTab]) {
                        $scope.gridOptions.paginationCurrentPage = $scope.currentPage[selectedTab];
                    }
                }, 50);
            });
        } else {
            //$scope.searchQuery = 'searchProducts?productQuery='+$scope.searchQuery;
            ProductPlanSearch.getSearchList($scope.searchQuery).then(function(productList) {
                var result = (selectedTab === 'all') ? productList : filter(productList, selectedTab);
                angular.forEach(result, function(item) {
                    this.push(item);
                }, $scope.productList);
            }).then(function() {
                // Need to find a event to reset the current page value; Do not like to use timer
                // Think about use $q again, because it is call in next loop
                $timeout(function() {
                    if ($scope.currentPage[selectedTab]) {
                        $scope.gridOptions.paginationCurrentPage = $scope.currentPage[selectedTab];
                    }
                }, 50);
            });
        }
    }
    /*DOGVT-247 Refactor product listing UI due to PPM service API change*/
    function transformInput(productList) { // array of plans
        var result = [];
        var mapping = {
            'effectiveDate': 'effectiveDates',
            'endDate': 'effectiveDates'
        };
        angular.forEach(productList, function(product) {
            var temp = {
                'effectiveDates': {}
            };
            angular.forEach(product, function(productValue, productAttribute) {
                var found = false;
                angular.forEach(mapping, function(mappingValue, mappingAttribute) {
                    if (productAttribute === mappingAttribute) {
                        temp[mappingValue][productAttribute] = productValue;
                        found = true;
                    }
                });
                if (!found) {
                    temp[productAttribute] = productValue;

                }
            });
            result.push(temp);

        });
        return result;
    }


});