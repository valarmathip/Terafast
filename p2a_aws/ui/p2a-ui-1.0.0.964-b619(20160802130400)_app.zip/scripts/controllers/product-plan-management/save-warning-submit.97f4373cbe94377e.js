'use strict';

angular.module('p2AdvanceApp')
    .controller('SaveProductWarningCtrl', function(
        $scope,
        $modalInstance,
        ModalDialogFactory) {

        $scope.confirmSubmit = function(toConfirm) {
            ModalDialogFactory.closeDialog(toConfirm);
        };

    });