'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:OfferingDetailsCtrl
 * @description
 * # OfferingDetailsCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('OfferingDetailsCtrl', function($scope, ENV, $log, $state, $stateParams, $timeout, $q, $parse,
        uiGridConstants,
        offeringDetailFieldsMetaData, offeringDetails, FileSelectFactory, QueryDialog,
        PpmFullEqual, ProductPlanMgmtSvc, ConfirmationModalFactory, ppmUtils, PlanLockSvc) {

        function init() {
            $scope.debugMode = (ENV.name === 'local');
            $scope.offeringDetails = {};
            $scope.offeringDetailsOri = {};
            $scope.offeringFieldsMetaData = offeringDetailFieldsMetaData.offeringFieldsMetaData;
            $scope.selectedTab = 'sdf';
            $scope.calendarOpened = {};

            setupModel();
            loadData();
        }

        $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
            // leaving edit state
            if (fromState.name.indexOf('home.ppm.offering.edit') === 0) {
                if (toState.name.indexOf('home.ppm.offering.edit') === -1) {
                    if (ppmUtils.isUuid($stateParams.offeringId)) {
                        askIfUserNeedToUnlockPlan = askIfUserNeedToUnlockPlan(event, toState, toParams, fromState, fromParams);
                    }
                }
            }
        });

        function saveBeforeLeave() {
            return QueryDialog.open('Save Offering', '<p>Do you want to save the offering?</p>', 'question', 'ppm-modal-dialog-question')
                .result.then(function() {
                        $log.log('save offering');
                        return $scope.saveClick();
                    },
                    function(reason) {
                        $log.log('canceled');
                        return reason;
                    });
        }

        // setup the cleanupHook (clearupHook is defined in MainCtrl, main.js)
        $scope.cleanupHook.execute = function() {
            return saveBeforeLeave()
                .then(function() {
                    var objectType = 'offering';
                    return PlanLockSvc.queryIfUserNeedToUnlockEntity($stateParams.offeringId, objectType);
                });
        };
        // remove cleanupHook
        $scope.$on('$destroy', function() {
            $scope.cleanupHook.execute = null;
        });

        var askIfUserNeedToUnlockPlan = function(event, toState, toParams, fromState, fromParams) { /* jshint ignore:line */
            event.preventDefault();

            $scope.cleanupHook.execute()['finally'](function() {
                $state.go(toState.name, {});
            });

            return angular.noop;
        };

        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId][$index] = true;

            $log.log('$scope.calendarOpened[nameId][$index] = ' + $scope.calendarOpened[nameId][$index]);
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function

        var offeringId = '';

        function loadData() {
            offeringId = $stateParams.offeringId;
            if (isNullOrUndefined(offeringId) || offeringId === 'new') {
                offeringId = '';
            }

            if (offeringId !== '') {
                transformInputOfferingDetails(offeringDetails);
            }

            if (!$scope.offeringDetails.objectId) {
                $scope.offeringDetails.objectId = offeringId;
            }

            // Currently we load offering at level 1 to including offeringplans, in the future,
            // if there is an api we can load offeringplans directly, we may load directly.
            SynchronizeOfferingPlanList($scope.offeringDetails.offeringplans);

            getLatestOfferingToOri();
        }

        function transformInputOfferingDetails(offeringDetail) {
            var mapping = {
                'effectiveDate': 'effectiveDates',
                'endDate': 'effectiveDates'
            };
            angular.forEach(offeringDetail, function(offeringValue, offeringKey) {
                var found = false;

                // Effective Dates
                angular.forEach(mapping, function(item, key) {
                    if (offeringKey === key) {
                        $scope.offeringDetails[item][offeringKey] = offeringValue;
                        found = true;
                    }
                });

                angular.forEach($scope.offeringFieldsMetaData, function(metadata) {
                    if (metadata.nameId === offeringKey) {
                        // Multi-selection checkbox
                        if (metadata.type === 'checkbox' && angular.isArray(offeringValue)) {
                            var temp = {};
                            angular.forEach(offeringValue, function(item) {
                                temp[item] = true;
                            });
                            $scope.offeringDetails[offeringKey] = temp;
                            found = true;
                        }
                        // Radio Button
                        if (metadata.type === 'radioButton') {
                            if (offeringValue === true) {
                                $scope.offeringDetails[offeringKey] = 'Yes';
                            } else if (offeringValue === false) {
                                $scope.offeringDetails[offeringKey] = 'No';
                            } else {
                                $scope.offeringDetails[offeringKey] = offeringValue;
                            }
                            found = true;
                        }
                    }
                });

                if (!found) {
                    if (offeringValue !== null) { // Note: no matter single or multiple, backend only returns null value. No empty array.
                        // null value returned should not overwirte the initial setup value, which will cause problem.
                        $scope.offeringDetails[offeringKey] = offeringValue;
                    }
                }

            });
        }
        // End of transformInputPlanDetail function

        $scope.tabClicked = function($event, tabName) {
            $event.preventDefault();
            setTab(tabName);
        };

        function setTab(tabName) {
            $log.log($scope.selectedTab + ' ---> ' + tabName);
            $scope.selectedTab = tabName;

            $state.go('home.ppm.offering.edit.content', {
                tabName: $scope.selectedTab
            });
        }

        $scope.saveClick = function() {
            // verify manadatory field
            if (containAllMandatoryFields()) {
                $scope.hasError = false;
            } else {
                $scope.hasError = true;
            }
            if ($scope.hasError) {
                $log.log('Mandatory fields check not passed.');

                return;
            }

            // check if there is any changes
            var nonEqualStrs = {};
            if (!isSaving(nonEqualStrs)) {
                return;
            }

            $scope.hasError = false;
            saveOrUpdateOffering(nonEqualStrs, true);
        };

        function containAllMandatoryFields() {
            function isInvalidString(data) {
                if (isNullOrUndefined(data)) {
                    return true;
                } else if (data === '') {
                    return true;
                } else {
                    return false;
                }
            }

            function isInvalidArray(data) {
                if (isNullOrUndefined(data)) {
                    return true;
                } else if (data.length < 1) {
                    return true;
                } else {
                    return false;
                }
            }

            function isCheckboxValueUnselected(data) {
                var allFalseValues = true;
                angular.forEach(data, function(value) {
                    if (value) {
                        allFalseValues = false;
                    }
                });
                return (allFalseValues);
            }

            function containInvalidValue(metadata) {
                var foundInvalidFields = false;
                angular.forEach(metadata, function(field) {
                    if (field.requiredField) {
                        if (field.multiple) { // drop down. dateRange, checkbox, text
                            if ((field.type === 'dateRange') && (field.nameId === 'effectiveDates')) {
                                if (isInvalidString($scope.offeringDetails[field.nameId]['endDate']) || isInvalidString($scope.offeringDetails[field.nameId]['effectiveDate'])) {
                                    foundInvalidFields = true;
                                }
                            } else if (field.type === 'checkbox') {
                                foundInvalidFields = isCheckboxValueUnselected($scope.offeringDetails[field.nameId]) || foundInvalidFields;
                            } else {
                                foundInvalidFields = isInvalidArray($scope.offeringDetails[field.nameId]) || foundInvalidFields;
                            }
                        } else { // text, radioButton, date
                            foundInvalidFields = isInvalidString($scope.offeringDetails[field.nameId]) || foundInvalidFields;
                        }
                    }
                });

                return foundInvalidFields;
            }

            var foundInvalidFields = containInvalidValue($scope.offeringFieldsMetaData);

            return (!foundInvalidFields);
        }

        function isNullOrUndefined(value) {
            if ((value === undefined) || (value === null)) {
                return true;
            } else {
                return false;
            }
        }

        function isSaving(result) {
            var config = {};

            var equalSvc = new PpmFullEqual(config);
            var currentValue = angular.copy(transformOutput($scope.offeringDetails));
            currentValue.offeringplans = getOfferingPlanIdList($scope.offeringDetails.offeringplans); // only id list/order could be change, we did not edit plan properties
            $log.log(angular.toJson(currentValue, true));
            var isSame = equalSvc.equals(currentValue, $scope.offeringDetailsOri, result);

            return !isSame;
        }

        function transformOutput() {
            var data = {};

            angular.forEach($scope.offeringDetails, function(offeringValue, offeringKey) {
                var found = false;
                angular.forEach($scope.offeringFieldsMetaData, function(metadata) {
                    if (metadata.nameId === offeringKey) {
                        var value = doOutputUnitTransform(offeringValue, metadata);
                        if (value != null) {
                            found = true;
                            if (metadata.type === 'dateRange') {
                                angular.forEach(value, function(item, key) {
                                    data[key] = item;
                                });
                            } else {
                                data[offeringKey] = value;
                            }
                        } else {
                            if (metadata.type === 'radio') {
                                data[offeringKey] = offeringValue;
                            } else if (metadata.type === 'radioButton') {
                                data[offeringKey] = null;
                            }
                            found = true;
                        }
                    }
                });
                if (!found) {
                    if (offeringValue === '') {
                        offeringValue = null;
                    }
                    data[offeringKey] = offeringValue;
                }
            });

            return data;
        }
        // End of transformOutput function

        function doOutputUnitTransform(originValue, metaDataField) {
            function getRadioButtonValue(originValue) {
                var value = originValue;
                if (originValue.toString().toLowerCase() === 'yes') {
                    value = true;
                } else if (originValue.toString().toLowerCase() === 'no') {
                    value = false;
                }
                return value;
            }

            var value = originValue;
            switch (metaDataField.type) {
                case 'checkbox':
                    value = [];
                    angular.forEach(originValue, function(item, key) {
                        if (item === true) {
                            value.push(key);
                        }
                    });
                    break;
                case 'radioButton':
                    if (isNullOrUndefined(originValue)) {
                        value = null;
                    } else {
                        value = getRadioButtonValue(originValue);
                    }
                    break;
                case 'dropdown':
                    value = originValue;
                    break;
            }
            return value;
        }

        function saveOrUpdateOffering(nonEqualStrs, showMessage) {
            // unregister watch offeringDetails, because after save or validation, offering details could be updated
            unregisterOfferingChangedListener();

            var offeringName = $scope.offeringDetails['name'];
            if (offeringName == null) {
                offeringName = '';
            }
            var dataConverted = transformOutput();
            $log.log('non simplified submit data = ' + angular.toJson(dataConverted, true));
            dataConverted = getSimplifiedPostData(dataConverted, nonEqualStrs);
            $log.log('submit data = ' + angular.toJson(dataConverted, true));

            if (offeringId && offeringId.toString().length > 0) { // edit existing offering
                return ProductPlanMgmtSvc.updateOffering(dataConverted, offeringId).then(function(data) {
                    if (showMessage) {
                        var msgtitle;
                        var msg;
                        msgtitle = '';
                        msg = offeringName + ' updated successfully';
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }

                    getLatestOfferingToOri();

                    return data; // it is offering objectId
                }, function(reason) {
                    $log.log(reason);
                    return $q.reject(reason);
                })['finally'](function() { // same as .finally()
                    registerOfferingChangedListener();
                });
            } else { // save new
                ProductPlanMgmtSvc.createOffering(dataConverted).then(function(data) {
                    if (showMessage) {
                        var msgtitle;
                        var msg;
                        msgtitle = '';
                        msg = offeringName + ' created successfully';
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }

                    $state.go('home.ppm.offering.edit', {
                        offeringId: data
                    });

                    // return data; // it is offering objectId
                }, function(reason) {
                    $log.log(reason);
                    return $q.reject(reason);
                });
            }
        }

        var unregisterOfferingChangedListenerFn = null;

        function registerOfferingChangedListener() {
            $timeout(function() {
                // $log.log('>>>>> registerOfferingChangedListener');
                if (!unregisterOfferingChangedListenerFn) { // make sure only one listener registered
                    unregisterOfferingChangedListenerFn = $scope.$watch('offeringDetails', function(newValue, oldValue) {
                        if (!newValue || !oldValue || newValue === oldValue) {
                            return;
                        }
                    }, true);
                }
            }, 500);
        }

        function unregisterOfferingChangedListener() {
            if (unregisterOfferingChangedListenerFn) {
                // $log.log('>>>>> unregisterOfferingChangedListener');
                unregisterOfferingChangedListenerFn();
                unregisterOfferingChangedListenerFn = null;
            }
        }

        registerOfferingChangedListener();

        function getSimplifiedPostData(postData, nonEqualPropertyStrs) {

            return generatePostData(postData, nonEqualPropertyStrs);

            /*
            1. if only plan properties changes, send the simple plan
            2. if plan cost share changed (add/remove), send composite plan with cost shares,
               could combine with plan properties that changed.
            */
            function generatePostData(postData, nonEqualPropertyStrs) {
                $log.log('==============================');
                var retValue = {};
                var offering = generateOfferingPropertiesData(postData, nonEqualPropertyStrs);
                var offeringplanIdList = generateOferingPlanIdList(postData.offeringplans, nonEqualPropertyStrs); // only id list/order could be change, we did not edit plan properties

                retValue.offering = offering;
                if (!retValue.offering) {
                    retValue.offering = {};
                }
                if (offeringplanIdList && offeringplanIdList.length > 0) {
                    retValue.offering.offeringplans = offeringplanIdList;
                }

                delete retValue.offering.objectId;

                //$log.log('changed part: ' + angular.toJson(retValue.offering, true));

                return retValue.offering;
            }

            function generateOfferingPropertiesData(postData, nonEqualPropertyStrs) {
                var p = /^(value\.[^\[\]\.]+).*$/;
                var p2 = /^(value\.offeringplans[\.\[]?).*$/;
                var obj = {};
                angular.forEach(nonEqualPropertyStrs, function(value, propertyStr) {
                    if (!p2.test(propertyStr)) {
                        var groups = p.exec(propertyStr);
                        if (groups) {
                            var propertyStrArray = groups[1]; // if simple property is array, use array as property, if not, it is still the property
                            copyValueFromSource(propertyStrArray, postData, obj);
                        }
                    }
                });
                // copy objectId
                if (!angular.equals(obj, {})) {
                    copyValueFromSource('value.objectId', postData, obj);
                }
                return obj.value;
            }

            function copyValueFromSource(propertyPath, source, dest) {
                var newValue = $parse(propertyPath)({
                    value: source
                });
                ppmUtils.transferPathToObject(propertyPath, newValue, dest);
            }

            function generateOferingPlanIdList(planList, nonEqualPropertyStrs) {
                var p = /^(value\.offeringplans[\.\[]?).*$/;
                var offeringPlansChanged = false;
                angular.forEach(nonEqualPropertyStrs, function(value, propertyStr) {
                    if (p.test(propertyStr)) {
                        offeringPlansChanged = true;
                    }
                });

                if (offeringPlansChanged) {
                    return getOfferingPlanIdList($scope.offeringDetails.offeringplans);
                } else {
                    return null;
                }
            }
        } // end of getSimplePostData

        function getLatestOfferingToOri() {
            $timeout(function() {
                $scope.offeringDetailsOri = angular.copy(transformOutput());
                $scope.offeringDetailsOri.offeringplans = getOfferingPlanIdList($scope.offeringDetails.offeringplans); // only id list/order could be change, we did not edit plan properties
            }, 200); // leave some time for system steady
        }

        function setupModel() {
            angular.forEach($scope.offeringFieldsMetaData, function(metadata) { // fieldsMetaData is array, and value is object
                if (!metadata.multiple) {
                    if (!$scope.offeringDetails[metadata.nameId]) {
                        $scope.offeringDetails[metadata.nameId] = null;
                    }
                } else {
                    if (!$scope.offeringDetails[metadata.nameId]) {
                        $scope.offeringDetails[metadata.nameId] = {};
                    }
                    if (metadata.type === 'dropdown') {
                        $scope.offeringDetails[metadata.nameId] = [];
                    }
                }
            });
            setTab('sdf');
        }

        /////////////////////////////////////////////////////////////////////////////////
        // Plan/Rider UI Grid
        /////////////////////////////////////////////////////////////////////////////////
        $scope.gridOptions = {
            'excessRows': 400, // SLQ need to more investigation
            enableSorting: true,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
            // height of row
            rowHeight: 105, // never put number in "", like "100"
            minRowsToShow: 6,
            rowTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/row.html',
            enableRowHeaderSelection: false // disable the head selection
        };

        $scope.gridOptions.columnDefs = [{
            displayName: '',
            field: 'element1', // required, but element1 dose not exist.
            width: '2%',
            minWidth: 30,
            maxWidth: 30,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/icon-col.html'
        }, {
            displayName: 'Order',
            name: 'order',
            field: 'order',
            width: '8%',
            minWidth: 90,
            maxWidth: 90,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/order-col.html',
            sort: { // default sort by service name asc.
                direction: uiGridConstants.ASC,
                priority: 0
            }
        }, {
            displayName: 'Plan/Rider Name',
            name: 'name',
            field: 'name',
            width: '60%', // I know the total percentage is less than 100% (95% exactly)
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/name-col.html'
        }, {
            displayName: 'Source Type',
            field: 'sourcetype',
            width: '10%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/source-type-col.html'
        }, {
            displayName: 'Version',
            field: 'version',
            width: '10%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/version-col.html'
        }, {
            displayName: '',
            field: 'element2', // filed property is requred, but element2 dose not exist.
            width: '5%',
            maxWidth: 35,
            minWidth: 35,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-details/plan-rider-list/plan-type-col.html'
        }];

        $scope.gridOptions.data = 'offeringDetails.offeringplans';

        $scope.gridOptions.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
        };

        $scope.browsePlans = function() {
            var selectorType = 'multiple';
            var objectType = 'plan';
            FileSelectFactory.openModalDialog(objectType, selectorType)
                .then(function(jsonStr) {
                    var currentPlanMap = {};
                    var alreadyExistPlanMap = {};
                    var newPlanMap = {};

                    angular.forEach($scope.offeringDetails.offeringplans, function(planRider) {
                        currentPlanMap[planRider.objectId] = true;
                    });
                    var selectedPlanList = angular.fromJson(jsonStr).selectedObjects;
                    angular.forEach(selectedPlanList, function(plan) {
                        if (currentPlanMap[plan.objectId]) {
                            alreadyExistPlanMap[plan.objectId] = plan.name;
                        } else {
                            newPlanMap[plan.objectId] = plan.objectId;
                        }
                    });

                    showAlreadyExistWarning(alreadyExistPlanMap);

                    // update ui offeringplans
                    if (!angular.equals(newPlanMap, {})) {
                        var promises = [];
                        $scope.offeringDetails.offeringplans = $scope.offeringDetails.offeringplans || [];
                        angular.forEach(newPlanMap, function(planId /*, key*/ ) {
                            promises.push(ProductPlanMgmtSvc.getEntityViaPpm(planId, 'plan', 0, ''));
                        });
                        $q.all(promises)
                            .then(function(planList) {
                                angular.forEach(planList, function(plan) {
                                    $scope.offeringDetails.offeringplans.push(plan);
                                });
                                SynchronizeOfferingPlanList($scope.offeringDetails.offeringplans);
                            });
                    }
                });
        };

        // Note this function will change the value in the list
        // And we suppose the list send from backend is sorted by order when 
        // we load the offering at level 1
        function addOrderIntoOfferingPlanList(list) {
            var order = 0;
            angular.forEach(list, function(planRider /*, key*/ ) {
                planRider.order = ++order;
            });

            return list ? list : [];
        }

        function SynchronizeOfferingPlanList(list) {
            $scope.offeringDetails.offeringplans = addOrderIntoOfferingPlanList(list);
        }

        function showAlreadyExistWarning(alreadyExistPlanMap) {
            if (!angular.equals(alreadyExistPlanMap, {})) {
                var msg = 'You have already added this Plan(s) to the Offering: <ul>';
                angular.forEach(alreadyExistPlanMap, function(item /*, key*/ ) {
                    msg += '<li>' + item + '</li>';
                });
                msg += '</ul>';
                QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
            }
        }

        $scope.disableRemoveButton = function(entity) {
            if (entity.objectType !== 'plan') { // only the last plan have to be kept
                return false;
            }

            var planNumber = $scope.offeringDetails.offeringplans.reduce(function(total, entity) {
                if (entity.objectType === 'plan') {
                    ++total;
                }
                return total;
            }, 0);

            return planNumber === 1;
        };

        function getOfferingPlanIdList(offeringPlanList) {
            if (!offeringPlanList) {
                return [];
            }

            var planIdList = $.map(offeringPlanList, function(item /*, key*/ ) {
                return item.objectId;
            });

            return planIdList;
        }

        $scope.removePlan = function(plan) {
            // update ui offeringplans
            for (var i = $scope.offeringDetails.offeringplans.length - 1; i >= 0; --i) {
                if ($scope.offeringDetails.offeringplans[i].objectId === plan.objectId) {
                    $scope.offeringDetails.offeringplans.splice(i, 1);
                    break;
                }
            }
            SynchronizeOfferingPlanList($scope.offeringDetails.offeringplans);
        };

        $scope.canChangeOrder = function() {
            var sort = getOrderSort();
            return sort.priority === 0 && (sort.direction === 'asc' || sort.direction === 'desc');
        };

        function getOrderSort() {
            var orderColumnIndex = 1;
            var sort = $scope.gridApi.grid.columns[orderColumnIndex].sort;
            return sort;
        }

        $scope.hideArrow = function(planRider, arrowDir) {
            var isShown = $scope.canChangeOrder();
            var sort = getOrderSort();

            var planList = $scope.offeringDetails.offeringplans;

            if (sort.direction === 'asc') {
                if (arrowDir === 'up') {
                    return isShown && planRider.objectId === planList[0].objectId;
                } else {
                    return isShown && planRider.objectId === planList[planList.length - 1].objectId;
                }
            } else {
                if (arrowDir === 'down') {
                    return isShown && planRider.objectId === planList[0].objectId;
                } else {
                    return isShown && planRider.objectId === planList[planList.length - 1].objectId;
                }
            }
        };

        function getIndexForGivenPlanRider(planRider, list) {
            var index = -1;
            for (var i = 0, n = list.length; i < n; i++) {
                if (planRider.objectId === list[i].objectId) {
                    index = i;
                    break;
                }
            }

            return index;
        }

        function increaseOrder(planRider) {
            var index = getIndexForGivenPlanRider(planRider, $scope.offeringDetails.offeringplans);
            if (index > 0) {
                var tmpOrder = $scope.offeringDetails.offeringplans[index].order;
                $scope.offeringDetails.offeringplans[index].order = $scope.offeringDetails.offeringplans[index - 1].order;
                $scope.offeringDetails.offeringplans[index - 1].order = tmpOrder;

                var planRiderIncrease = $scope.offeringDetails.offeringplans.splice(index, 1); // note: splice return array
                $scope.offeringDetails.offeringplans.splice(index - 1, 0, planRiderIncrease[0]);
            }
        }

        function decreaseOrder(planRider) {
            var index = getIndexForGivenPlanRider(planRider, $scope.offeringDetails.offeringplans);
            if (index < $scope.offeringDetails.offeringplans.length - 1) {
                var tmpOrder = $scope.offeringDetails.offeringplans[index].order;
                $scope.offeringDetails.offeringplans[index].order = $scope.offeringDetails.offeringplans[index + 1].order;
                $scope.offeringDetails.offeringplans[index + 1].order = tmpOrder;

                var planRiderIncrease = $scope.offeringDetails.offeringplans.splice(index, 1); // note: splice return array
                $scope.offeringDetails.offeringplans.splice(index + 1, 0, planRiderIncrease[0]);
            }
        }

        $scope.planMoveUp = function(planRider) {
            var sort = getOrderSort();
            if (sort.direction === 'asc') {
                increaseOrder(planRider);
            } else {
                decreaseOrder(planRider);
            }
        };

        $scope.planMoveDown = function(planRider) {
            var sort = getOrderSort();
            if (sort.direction === 'asc') {
                decreaseOrder(planRider);
            } else {
                increaseOrder(planRider);
            }
        };
        // End of Plan/Rider UI Grid
        /////////////////////////////////////////////////////////////////////////////////

        init();
    });