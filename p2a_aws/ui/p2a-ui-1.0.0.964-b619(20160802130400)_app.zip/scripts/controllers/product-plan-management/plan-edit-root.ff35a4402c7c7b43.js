'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:PlanEditRootCtrl
 * @description
 * # PlanEditRootCtrl
 * Controller of the p2AdvanceApp
 *
 * This controller is just used as plan, plan service and plan cost share 
 * value shares, should no logic in side.
 */
angular.module('p2AdvanceApp')
    .controller('PlanEditRootCtrl', function($scope, $log, $stateParams, $state, CostShareFacadeSvc, PlanLockSvc, QueryDialog) {
        $scope.ppmName = 'editroot';

        $log.log('edit root $state = ' + $state);
        $log.log('edit root $state = ' + $stateParams);

        /*
        If put this at plan details, the event cannot be detected if return from service list to plan detail
        */
        $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
            // $log.log('---------------------------------------------------------------------');
            // $log.log(toState.name + ' <-- ' + fromState.name);
            // $log.log(toState.url + ' <-- ' + fromState.url);
            // $log.log(angular.toJson(toParams, true));
            // $log.log(angular.toJson(fromParams, true)); 
            angular.noop(event, toState, toParams, fromState, fromParams); // this do nothing, just remove the jsHint error

            if (toState.name.indexOf('home.ppm.plan.edit.plan-details') === 0) {
                if (fromState.name.indexOf('home.ppm.plan.edit.service-list') === 0) {
                    // NOTE: Seems this is not necessary (by Mar 23, 2016):
                    // 1. plan detail use planId now, not objectId
                    // 2. even it is set here, in the plan details, it still cannot visible
                    toParams.objectId = CostShareFacadeSvc.PlanExpandable3().objectId; // SLQ when back from service list to plan detail, it seems that planId already set
                }
            }

            // leaving edit state
            if (fromState.name.indexOf('home.ppm.plan.edit') === 0) {
                if (toState.name.indexOf('home.ppm.plan.edit') === -1) {
                    // $log.log('>>>>>>>>> $stateParams.planId = ' + $stateParams.planId);
                    if ($stateParams.planId) {
                        askIfUserNeedToUnlockPlan = askIfUserNeedToUnlockPlan(event, toState, toParams, fromState, fromParams);
                    }
                }
            }
        });

        $scope.savingHook = {
            // this function return promise;
            action: null
        };

        // return promise
        function saveBeforeLeave() {
            return QueryDialog.open('Save Plan', '<p>Do you want to save the plan?</p>', 'question', 'ppm-modal-dialog-question')
                .result.then(function() {
                        $log.log('save plan');
                        return angular.isFunction($scope.savingHook.action) ? $scope.savingHook.action() : null;
                    },
                    function(reason) {
                        $log.log('canceled');
                        return reason;
                    });
        }

        // setup the cleanupHook (clearupHook is defined in MainCtrl, main.js)
        $scope.cleanupHook.execute = function() {
            return saveBeforeLeave() // 1. query save
                .then(function() {
                    return PlanLockSvc.queryIfUserNeedToUnlockPlan($stateParams.planId); // 2. query unlock
                });
        };
        // remove the cleanupHook
        $scope.$on('$destroy', function() {
            $scope.cleanupHook.execute = null;
        });

        var askIfUserNeedToUnlockPlan = function(event, toState, toParams, fromState, fromParams) { /* jshint ignore:line */
            event.preventDefault();

            $scope.cleanupHook.execute()['finally'](function() {
                $state.go(toState.name, {});
            });

            return angular.noop;
        };

        // Dev Test code  
        // $scope.$on('zhiyisheng', function() {
        //     $log.log('MyCtrl scope: ' + $scope.$id + ' zhiyisheng, timestamp ' + (new Date()).getTime());
        //     $log.log('      - path: ' + getPath($scope));
        // });

        // function getPath(scope) {
        //     if (!scope.$parent) {
        //         return scope.$id;
        //     } else {
        //         return scope.$id + ' ' + getPath(scope.$parent);
        //     }
        // }
        // end of Dev Test Code

    });