'use strict';
/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:PlanSearchCtrl
 * @description
 * # PlanSearchCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('PlanSearchCtrl', function($filter, $scope, $log, ProductPlanMgmtSvc, planDetailFieldsMetaData, ProductPlanSearch, ENV, $state, QueryDialog) {
        $scope.planSearch = true;
        $scope.planSearchLable = true;
        $scope.statusList = ['Published', 'Approved', 'Override Approved'];
        $scope.searchQuery = '';
        $scope.errorMsg = '';
        $scope.planDetails = {};
        $scope.gloableDetails = {};
        $scope.planList = {};
        $scope.plantSearchResult = [];
        //$scope.dataConverted={};
        $scope.requiredFields = [];
        $scope.planstatusDetails = [];
        $scope.optionMetaData = [{
            'optionNameId': 'min',
            'label': 'min'
        }, {
            'optionNameId': 'max',
            'label': 'max'
        }];
        $scope.debugMode = (ENV.name === 'development');
        angular.element('#planNavBar').addClass('active-bar');
        $scope.calendarOpened = {};
        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();
            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }
            $scope.calendarOpened[nameId][$index] = true;
        };
        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };
        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function
        $scope.GloableCostMetaData = planDetailFieldsMetaData.productFieldsMetaData;
        angular.forEach($scope.GloableCostMetaData, function(item) {
            if (item.type === 'slider') {
                item['optionMetaData'] = $scope.optionMetaData;
            }
        });
        $scope.fieldsMetaData = $scope.GloableCostMetaData;
        $scope.init = function(data) {
            $scope.planDetails = data;
            setupModel();
        };
        $scope.init({});
        $scope.saveClick = function() {
            $scope.searchQuery = $scope.transformStringOutput();
            if ($scope.searchQuery !== '') {
                $scope.searchQuery = 'TYPE:"plan" AND ' + $scope.searchQuery;
            } else {
                $scope.searchQuery = 'TYPE:"plan"';
            }
            $log.log('search query:' + $scope.searchQuery);
            $state.go('home.ppm.plan.plan-list-search', {
                'searchquery': $scope.searchQuery
            });
        };

        $scope.transformStringOutput = function() {
            var StringDataSet = '';
            var itemTypeMap = {};
            angular.forEach($scope.fieldsMetaData, function(field) {
                if (field.type !== 'text' || (field.multiple)) {
                    itemTypeMap[field.nameId] = field.type;
                } else {
                    itemTypeMap[field.nameId] = 'radio';
                }

            });
            angular.forEach($scope.planDetails, function(value, attribute) {
                var querySegment = getQuerySegment(value, attribute, itemTypeMap[attribute]);
                if (querySegment !== '') {
                    if (StringDataSet === '') {
                        StringDataSet = querySegment;
                    } else {
                        StringDataSet = StringDataSet + ' AND ' + querySegment;
                    }
                }
            });
            return StringDataSet;
        };
        $scope.CheckBoxFields = function(value, attribute, tempQuery) {
            var singleValue = true;
            tempQuery = '';
            angular.forEach(value, function(isChecked, optionValue) {
                if (isChecked) {
                    if (tempQuery !== '') {
                        tempQuery = tempQuery + ' OR ' + attribute + ':"' + optionValue + '"';
                        singleValue = false;
                    } else if (optionValue !== '' && optionValue !== null) {
                        tempQuery = attribute + ':"' + optionValue + '"';
                    }
                }
            });
            if (singleValue) {
                return tempQuery;
            }
            return '(' + tempQuery + ')';
        };
        $scope.dateRangeFields = function(value, attribute, tempQuery) {
            var tempDateRange = '';
            tempQuery = '';
            angular.forEach(value, function(selectedDate) {
                if (value !== undefined && value !== '' && tempDateRange !== '') {
                    tempDateRange = tempDateRange + ' TO "' + $filter('date')(selectedDate, 'yyyy-MM-dd') + '"';
                } else if (value !== undefined && value !== '') {
                    tempDateRange = '"' + $filter('date')(selectedDate, 'yyyy-MM-dd') + '"';
                }
            });
            if (tempDateRange !== '') {
                tempQuery = attribute + ': [' + tempDateRange + ']';
            }
            return tempQuery;
        };
        $scope.dropdownFields = function(value, attribute, tempQuery) {
            value = value + '';
            tempQuery = '';
            var tempVal = value.split(',');
            angular.forEach(tempVal, function(item3) {
                if (tempQuery !== '') {
                    tempQuery = tempQuery + ' OR ' + attribute + ':"' + item3 + '"';
                } else if (item3 !== '[object Object]' && item3 !== '') {
                    tempQuery = attribute + ':"' + item3 + '"';
                }
            });
            return tempQuery;
        };
        $scope.dateFields = function(value, attribute, tempQuery) {
            tempQuery = '';
            if (value !== undefined && value !== '' && value !== null) {
                tempQuery = attribute + ': "' + $filter('date')(value, 'yyyy-MM-dd') + '"';
            }
            return tempQuery;
        };
        $scope.defaultFields = function(value, attribute, tempQuery) {
            tempQuery = '';
            if (attribute === 'numProviderTiers' && value.tiersNumber !== '' && value.tiersNumber !== undefined) {
                tempQuery = attribute + ': "' + value.tiersNumber + '"';
            } else if (value !== null && value !== '' && JSON.stringify(value) !== '{}' && (attribute !== 'numProviderTiers')) {
                tempQuery = attribute + ': "' + value + '"';
            }
            return tempQuery;
        };
        $scope.radioFields = function(value, attribute, tempQuery) {
            tempQuery = '';
            if (value !== null && value !== '') {
                tempQuery = attribute + ': "' + value + '"';
            }
            return tempQuery;
        };

        function getQuerySegment(value, attribute, type) {
            var tempQuery = '';
            switch (type) {
                case 'text':
                case 'checkbox':
                    tempQuery = $scope.CheckBoxFields(value, attribute, tempQuery);
                    break;
                case 'dateRange':
                    tempQuery = $scope.dateRangeFields(value, attribute, tempQuery);
                    break;
                case 'date':
                    tempQuery = tempQuery = $scope.dateFields(value, attribute, tempQuery);
                    break;
                case 'ties':
                case 'radio':
                    tempQuery = $scope.radioFields(value, attribute, tempQuery);
                    break;
                case 'dropdown':
                    tempQuery = $scope.dropdownFields(value, attribute, tempQuery);
                    break;
                default:
                    tempQuery = $scope.defaultFields(value, attribute, tempQuery);
                    break;
            }
            return tempQuery;
        }

        $scope.saveGloableCost = function() {
            $scope.errorMsg = '';
            $scope.errorField = [];
            $scope.gloablesearchQuery = '';
            if ($scope.searchQuery !== '') {
                $scope.searchQuery = 'TYPE:"plan" AND ' + $scope.searchQuery;
            } else {
                $scope.searchQuery = 'TYPE:"plan"';
            }
            angular.forEach($scope.gloableDetails, function(item, key) {
                if ((item['min'] !== '' && item['max'] !== '') && (parseInt(item['min'], 10) >= parseInt(item['max'], 10))) {
                    $scope.errorField.push(item['displayName']);
                }
                if (parseInt(item['min'], 10) < parseInt(item['max'], 10)) {
                    if (item['min'] !== '' && item['max'] !== '') {
                        if ($scope.gloablesearchQuery !== '') {
                            $scope.gloablesearchQuery = $scope.gloablesearchQuery + ' AND ' + key + ': [' + item['min'] + ' TO ' + item['max'] + ']';
                        } else {
                            $scope.gloablesearchQuery = key + ': [' + item['min'] + ' TO ' + item['max'] + ']';
                        }
                    }
                }
            });
            if ($scope.errorField.length > 0) {
                $scope.errorMsg = 'Max values should be more than Min values for all field(s).';
            }
            if ($scope.errorMsg === '') {
                $scope.combinedQuery = '';
                if ($scope.gloablesearchQuery !== '') {
                    $scope.combinedQuery = $scope.searchQuery + ' AND ' + $scope.gloablesearchQuery;
                } else {
                    $scope.combinedQuery = $scope.searchQuery;
                }
                $log.log('Search Query' + $scope.combinedQuery);
                $state.go('home.ppm.plan.plan-list-search', {
                    'searchquery': $scope.combinedQuery
                });
            } else {
                QueryDialog.open('Error', $scope.errorMsg, 'minus', 'ppm-modal-dialog-error');
            }
        };

        $scope.loadProcessPage = function(pageType) {
            if (pageType === 'GloableCost') {
                $scope.planSearch = false;
                $scope.planSearchLable = false;
                $scope.searchQuery = $scope.transformStringOutput();
                var tempGloableCostShare = [];
                angular.element('#GloableCostNavBar').removeClass('deactive-bar');
                angular.element('#planNavBar').removeClass('active-bar');
                angular.element('#GloableCostNavBar').addClass('active-bar'); //;
                angular.element('#planNavBar').addClass('deactive-bar');
                angular.forEach($scope.GloableCostMetaData, function(item) {
                    if (item.type === 'slider') {
                        var arrayData = {};
                        angular.forEach(item.optionMetaData, function(item1) {
                            arrayData[item1.label] = '';
                        });
                        arrayData['displayName'] = item.displayName;
                        $scope.gloableDetails[item.nameId] = arrayData;
                        tempGloableCostShare.push(item);
                    }
                });
                $scope.fieldsMetaData = tempGloableCostShare;
            } else {
                angular.element('#planNavBar').removeClass('deactive-bar');
                angular.element('#GloableCostNavBar').removeClass('active-bar');
                angular.element('#planNavBar').addClass('active-bar');
                angular.element('#GloableCostNavBar').addClass('deactive-bar');
                $scope.planSearch = true;
                $scope.planSearchLable = true;
                $scope.fieldsMetaData = $scope.GloableCostMetaData;
            }
        };

        function setupModel() {
            angular.forEach($scope.fieldsMetaData, function(item) { // fieldsMetaData is array, and value is object
                if (item.type !== 'slider') {
                    if (item.requiredField) {
                        $scope.requiredFields.push(item.nameId);
                    }
                    if (!item.multiple) {
                        if (!$scope.planDetails[item.nameId]) {
                            $scope.planDetails[item.nameId] = '';
                        }
                    } else {
                        if (!$scope.planDetails[item.nameId]) {
                            $scope.planDetails[item.nameId] = {};
                        }
                    }
                }
            });
        }
    });