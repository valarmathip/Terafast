'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:DocumentSearchCtrl
 * @description
 * # DocumentSearchCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('DocumentSearchCtrl', function($filter, $scope, documentDetailFieldsMetaData, ENV, $log) {
        $scope.documentSearch = true;
        $scope.statusList = ['Final', 'Draft', 'Outdated'];
        $scope.documentDetails = {};
        $scope.gloableDetails = {};
        $scope.dataConverted = {};
        $scope.requiredFields = [];
        $scope.optionMetaData = [{
            'optionNameId': 'min',
            'label': 'min'
        }, {
            'optionNameId': 'max',
            'label': 'max'
        }];
        $scope.debugMode = (ENV.name === 'development');
        angular.element('#documentNavBar').addClass('active-bar');
        $scope.calendarOpened = {};
        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }
            $scope.calendarOpened[nameId][$index] = true;
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function
        $scope.documentFieldsMetaData = documentDetailFieldsMetaData.documentFieldsMetaData;
        angular.forEach($scope.documentFieldsMetaData, function(item) {
            if (item.type === 'slider') {
                item['optionMetaData'] = $scope.optionMetaData;
            }
        });
        $scope.fieldsMetaData = $scope.documentFieldsMetaData;
        init({});

        function init(data) {
            $scope.documentDetails = data;
            setupModel();
        }

        $scope.transformOutput = function() {
            var data = {};

            angular.forEach($scope.documentDetails, function(item, key) {
                var found = false;
                angular.forEach($scope.fieldsMetaData, function(item2) {
                    if (item2.nameId === key) {
                        var value;
                        if (item2.type === 'checkbox') {
                            value = [];
                            angular.forEach(item, function(item3, key3) {
                                if (item3 === true) {
                                    value.push(key3);
                                }
                            });
                            data[key] = value;
                            found = true;
                        } else if (item2.type === 'dateRange') {
                            value = {};
                            angular.forEach(item, function(item3, key3) {
                                value[key3] = $scope.formatDate(item3);
                            });
                            data[key] = value;
                            found = true;
                        } else if (item2.type === 'date') {
                            data[key] = $scope.formatDate(item);
                            found = true;
                        } else if (item2.type === 'dropdown' || item2.type === 'ties' || item2.type === 'radio' || item2.type === 'radioButton' || item2.type === 'numberInput') {
                            var tempItem = $scope.nullChecker(item);
							data[key] = tempItem;
                            found = true;
                        }

                    }
                });
                if (!found) {
                    data[key] = item;
                }
            });
            $scope.outPut = data;
            return data;
        };
        $scope.formatDate = function(item) {
            if (item !== '') {
                return $filter('date')(item, 'yyyy-MM-dd');
            } else {
                return '';
            }

        };
		$scope.nullChecker = function(item) {
            if (item !== null && item !== undefined) {
                return item;
            } else {
                return '';
            }

        };
        $scope.saveClick = function() {
        $scope.dataConverted = $scope.transformOutput();
            $log.log(JSON.stringify($scope.dataConverted));

        };
        $scope.saveGloableCost = function() {
            $scope.errorMsg = '';
            angular.forEach($scope.dataConverted, function() {
                angular.forEach($scope.gloableDetails, function(item, key) {
                    if (item['min'] > item['max']) {
                        $scope.errorMsg = 'Max value should be more than MIN value.';
                    }
                    $scope.dataConverted[key] = item;
                });
            });
            $log.log(JSON.stringify($scope.dataConverted));
        };
        $scope.loadProcessPage = function(pageType) {
            if (pageType === 'GloableCost') {
                $scope.documentSearch = false;
                $scope.dataConverted = $scope.transformOutput();
                var tempGloableCostShare = [];
                angular.element('#GloableCostNavBar').removeClass('deactive-bar');
                angular.element('#documentNavBar').removeClass('active-bar');
                angular.element('#GloableCostNavBar').addClass('active-bar'); //;
                angular.element('#documentNavBar').addClass('deactive-bar');
                angular.forEach($scope.documentFieldsMetaData, function(item) {
                    if (item.type === 'slider') {
                        var arrayData = {};
                        angular.forEach(item.optionMetaData, function(item1) {
                            arrayData[item1.label] = '';
                        });
                        $scope.gloableDetails[item.nameId] = arrayData;
                        tempGloableCostShare.push(item);
                    }
                });
                $scope.fieldsMetaData = tempGloableCostShare;
            } else if (pageType === 'documentPage') {
                angular.element('#documentNavBar').removeClass('deactive-bar');
                angular.element('#GloableCostNavBar').removeClass('active-bar');
                angular.element('#documentNavBar').addClass('active-bar'); //;
                angular.element('#GloableCostNavBar').addClass('deactive-bar');
                $scope.documentSearch = true;
                $scope.fieldsMetaData = $scope.documentFieldsMetaData;
            }
        };

        function setupModel() {
            angular.forEach($scope.fieldsMetaData, function(item) { // fieldsMetaData is array, and value is object
                if (item.type !== 'slider') {
                    if (item.requiredField) {
                        $scope.requiredFields.push(item.nameId);
                    }
                    if (!item.multiple) {
                        if (!$scope.documentDetails[item.nameId]) {
                            $scope.documentDetails[item.nameId] = '';
                        }
                    } else {
                        if (!$scope.documentDetails[item.nameId]) {
                            $scope.documentDetails[item.nameId] = {};
                        }

                    }
                }
            });
        }
    });