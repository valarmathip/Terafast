'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductPlanManagementCtrl
 * @description
 * # ProductPlanManagementCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ProductPlanManagementCtrl', function($scope, $rootScope, dialogFactorySvc, ProductPlanMgmtSvc, ValidationReportPageslideSvc, ValidationReportAsideSvc, QueryDialog, $log) {
        $scope.buildInfo = null;
        $scope.uiBuildInfo = {
            uiInfo: null
        };

        $scope.showDialog = function() {
            var dlgUrl = 'views/product-plan-management/default-modal-dialog.html';
            var controller = 'ServiceDefinitionCtrl';
            var data = {
                serviceDefinitionFieldsMetaData: function() {
                    return ProductPlanMgmtSvc.getServiceDefinitionFieldMetaInfo();
                }
            };
            var options = {
                size: 'lg'
            };
            dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
        };

        var reportData = {
            'warnings': ['Warning: Plan Year is not between the range 6', 'Warning: Plan Year is not between the range 5',
                'Warning: Plan Year is not between the range 6', 'Warning: Plan Year is not between the range 5',
                'Warning: Plan Year is not between the range 4', 'Warning: Plan Year is not between the range 3',
                'Warning: Plan Year is not between the range 2', 'Warning: Plan Year is not between the range 1',
                'Warning: Plan Year 1980\' is \"not\" between, aka among, the range: 1; try agian!'
            ],
            'planId': 'fb509e39-b2ec-4404-b038-ae6a428d1e09',
            'planName': 'Test Plan',
            'validatedDate': new Date(),
            'errors': ['Error: Plan Year is not between the range 6', 'Error: Plan Year is not between the range 5',
                'Error: Plan Year is not between the range 4', 'Error: Plan Year is not between the range 3',
                'Error: Plan Year is not between the range 4', 'Error: Plan Year is not between the range 3',
                'Error: Plan Year is not between the range 2', 'Error: Plan Year is not between the range 1'
            ]
        };

        $scope.showAside = function() {
            ValidationReportAsideSvc.openAside('left', reportData);
        };

        $scope.showPageslide = function() {
            ValidationReportPageslideSvc.openPageslide('left', reportData, $scope)
                .then(function(data) {
                    $log.log(data);
                }, function(reason) {
                    $log.log(reason);
                });
        };

        ProductPlanMgmtSvc.uiBuildInfo().then(function(data) {
            $scope.uiBuildInfo.uiInfo = data;
        });

        ProductPlanMgmtSvc.getPpmVersion().then(function(data) {
            $scope.buildInfo = data;
            // $scope.buildInfo.ppmServerUrlBase = PPMENV.getPpmApiEndpoint();
        });

        $scope.testClicked = function() {
            var errorData = [{
                'httpStatus': 'BAD_REQUEST (400)',
                'errorCode': 'bad.request',
                'errorMessage': 'The request cannot be fulfilled due to bad syntax',
                'errorId': '9cac1876-2934-40f1-9f4b-7fb03a45c2a3',
                'errorDetails': 'Invalid search query parameter - q: \'TYPE:\"role\"'
            }, {
                'httpStatus': 'UNAUTHORIZED (401)',
                'errorCode': 'unauthorized',
                'errorMessage': 'You are unauthorized to make this call',
                'errorId': '7ddd3cdc-527d-4c78-8e9e-8cdda263b145',
                'errorDetails': null
            }];

            var index = Math.floor(Math.random() * errorData.length);

            return QueryDialog.open(errorData[index].httpStatus, errorData[index], 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
        };

        $scope.filterData = {
            'productClasses': {
                'type': 'string',
                'facetValues': [{
                    'name': 'Medical',
                    'count': 4
                }]
            },
            'lastModifiedBy': {
                'type': 'string',
                'facetValues': [{
                    'name': 'admin@upmc.com',
                    'count': 3
                }, {
                    'name': 'admin@tenant.test.1456956581743',
                    'count': 1
                }]
            },
            'creationDate': {
                'type': 'dateRange',
                'facetValues': [{
                    'name': 'Previous 12 months',
                    'count': 4
                }, {
                    'name': 'Previous 6 months',
                    'count': 4
                }]
            },
            '_AnameReallyDoesNotExistReallyDoesNotExistIHaveToldYouAlreadyAndLongName': {
                'type': 'string',
                'facetValues': [{
                    'name': 'canNotFindName123456789123456789123456789AndLongName',
                    'count': 4
                }]
            },
            '_AdateRangeNameReallyDoesNotExistReallyDoesNotExistIHaveToldYouAlreadyAndLongName': {
                'type': 'dateRange',
                'facetValues': [{
                    'name': 'dateRangeCanNotFindName123456789123456789123456789AndLongName',
                    'count': 4
                }]
            }
        };

        $scope.hrMetadata = [{
            nameId: 'creationDate',
            displayName: 'Creation Date',
            otherProperties: 'Other properties'
        }, {
            nameId: 'lastModifiedBy',
            displayName: 'Last Modified By',
            otherProperties: 'Other properties'
        }, {
            nameId: 'productClasses',
            displayName: 'Product Classes',
            otherProperties: 'Other properties'
        }];

        $scope.facetsChanged = function(queryString) {
            $log.log(queryString);
        };

        $scope.$on('hrRefineFacets.internal.facetsChanged', function() {
            $log.log('hrRefineFacets.internal.facetsChanged in product-plan-management.js');
        });

        $scope.open = function($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened = true;
        };
    });