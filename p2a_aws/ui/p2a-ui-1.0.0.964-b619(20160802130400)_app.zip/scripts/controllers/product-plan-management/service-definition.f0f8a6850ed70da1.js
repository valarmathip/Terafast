'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ServiceDefinitionCtrl
 * @description
 * # ServiceDefinitionCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ServiceDefinitionCtrl', function($scope, $timeout, $filter, $q, $modalInstance, ProductPlanMgmtSvc, serviceDefinitionFieldsMetaData, ConfirmationModalFactory, ENV) {

        $scope.debugMode = (ENV.name === 'local');
        $scope.serviceDefinition = {};
        // Status of opened calendar, internal use only
        $scope.calendarOpened = {};

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };


        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId][$index] = true;
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };

        // End of Calendar function
        $scope.fieldsMetaData = serviceDefinitionFieldsMetaData.fieldsMetaData;
        $scope.optionsMetaData = serviceDefinitionFieldsMetaData.optionsMetaData;

        function findDependantComponents(root, nameId, result) {
            angular.forEach(root, function(item) {
                if (item.parentId && item.parentId === nameId) {
                    // check if result array already contains the item
                    var addToArray = true;
                    angular.forEach(result, function(item2) {
                        if (item2.nameId === item.nameId) {
                            addToArray = false;
                        }
                    });
                    if (addToArray) {
                        result.push(item);
                    }
                }
                if (!isUndefinedOrNull(item.children)) {
                    if (item.children.length > 0) {
                        findDependantComponents(item.children, nameId, result);
                    }
                }
            });
        }

        $scope.checkboxChanged = function(field, selectedValues, metaData, target) {
            if (target === 'all') { // click on all
                if (selectedValues.all === true) {
                    angular.forEach(field.options, function(item) {
                        if (item.optionNameId !== 'all') {
                            $scope.serviceDefinition[field.nameId][item.optionNameId] = true;
                        }
                    });
                } else {
                    angular.forEach(field.options, function(item) {
                        if (item.optionNameId !== 'all') {
                            delete $scope.serviceDefinition[field.nameId][item.optionNameId];
                        }
                    });
                }
            } else {
                var hasAllOption = false;
                var originalLength = field.options.length;
                angular.forEach(field.options, function(item) {
                    if (item.optionNameId === 'all') {
                        hasAllOption = true;
                    }
                });
                if (hasAllOption) {
                    originalLength--;
                    var selectedLength = 0;
                    angular.forEach(selectedValues, function(item, key) {
                        if (item === true && key !== 'all') {
                            selectedLength++;
                        }
                    });
                    if (selectedLength === originalLength) {
                        selectedValues['all'] = true;
                    } else {
                        selectedValues['all'] = false;
                    }
                }
            }

            var result = [];
            findAllDependantComponents(metaData, field.nameId, result);

            var selected = [];
            angular.forEach(selectedValues, function(item, key) {
                if (item === true && key !== 'all') {
                    selected.push(key);
                }
            });

            angular.forEach(result, function(item) {
                var options = [];
                angular.forEach(selected, function(item2) {
                    if (item.parentId === field.nameId) { // child
                        var id = item.nameId;
                        options = options.concat($scope.optionsMetaData[id][item2]);
                    } else {
                        options = [];
                    }
                });
                item.options = options;
                if (!item.multiple) {
                    $scope.serviceDefinition[item.nameId] = null;
                } else {
                    $scope.serviceDefinition[item.nameId] = {};
                }
            });
        };

        $scope.radioChanged = function(field, selectedValue, metaData) {
            var result = [];
            findAllDependantComponents(metaData, field.nameId, result);
            angular.forEach(result, function(item) {
                if (item.parentId === field.nameId) { // child    
                    var id = item.nameId;
                    item.options = $scope.optionsMetaData[id][selectedValue];
                    if (!item.multiple) {
                        $scope.serviceDefinition[item.nameId] = null;
                    } else {
                        $scope.serviceDefinition[item.nameId] = {};
                    }
                } else { // grandchild    
                    item.options = [];
                    if (!item.multiple) {
                        $scope.serviceDefinition[item.nameId] = null;
                    } else {
                        $scope.serviceDefinition[item.nameId] = {};
                    }
                }
            });
        };

        function findAllDependantComponents(root, nameId, result) {
            var size = 0;
            findDependantComponents(root, nameId, result);

            while (size < result.length) {
                size = result.length;
                angular.forEach(result, function(item) {
                    findDependantComponents(root, item.nameId, result);
                });
            }
        }

        function isUndefinedOrNull(val) {
            return (val === undefined) || (val === null);
        }

        function transformOutput(data) {
            var result = {};
            angular.forEach(data, function(item, key) {
                if (angular.isObject(item)) { // array
                    var found = false;
                    angular.forEach($scope.fieldsMetaData, function( /*item2*/ ) {
                        // We changed to user UTC datetime format, so there is no need to transfer the datetime. 
                        // Important: Current the product is not editable, so this is not tested 
                        // if (key === item2.nameId && item2.type === 'dateRange') {
                        //     angular.forEach(item, function(item3, key3) {
                        //         result[key3] = $filter('date')(item3, 'yyyy-MM-dd');
                        //     });
                        //     found = true;
                        // }
                    });
                    if (!found) {
                        var value = [];
                        angular.forEach(item, function(item3, key3) {
                            if (item3 === true) {
                                value.push(key3);
                            }
                        });
                        result[key] = value;
                    }
                } else { // string
                    if (item === '') {
                        result[key] = null;
                    } else {
                        result[key] = item;
                    }
                }
            });
            return result;
        }

        function replaceIdWithLabel(data) {
            var result = {};
            angular.forEach(data, function(item, key) {
                if (angular.isObject(item)) { // array
                    var value = {};
                    var options = [];
                    var isDateRange = false;
                    angular.forEach($scope.fieldsMetaData, function(item2) {
                        if (item2.nameId === key) {
                            if (item2.type === 'dateRange') {
                                result[key] = item;
                                isDateRange = true;
                            } else {
                                options = item2.options;
                            }
                        }
                        angular.forEach(item2.children, function(item3) {
                            if (item3.nameId === key) {
                                options = item3.options;
                            }
                        });
                    });
                    if (!isDateRange) {
                        angular.forEach(item, function(item2, key2) {
                            angular.forEach(options, function(item3) {
                                if (item3.optionNameId === key2) {
                                    value[item3.label] = item2;
                                }
                            });
                        });
                        result[key] = value;
                    }
                } else { // string - serviceName, note. and single selection
                    var found = false;
                    angular.forEach($scope.fieldsMetaData, function(item2) {
                        if (item2.nameId === key) {
                            angular.forEach(item2.options, function(item3) {
                                if (item === item3.optionNameId) {
                                    result[key] = item3.label;
                                    found = true;
                                }
                            });
                        }
                    });
                    if (!found) {
                        result[key] = item;
                    }
                }
            });
            return result;
        }

        $scope.saveClick = function() {
            var dataConverted = transformOutput(replaceIdWithLabel($scope.serviceDefinition));
            ProductPlanMgmtSvc.createService(dataConverted).then(function(data) {
                ConfirmationModalFactory.open('Create new service', 'Create new service successed. New service id: ' + data, ENV.modalErrorTimeout);
            }, function(reason) {
                console.log(reason);
            });
        };

        function setupModel() {
            angular.forEach($scope.fieldsMetaData, function(item) { // fieldsMetaData is array, and value is object
                if (isUndefinedOrNull(item.children)) {
                    if (item.multiple) {
                        $scope.serviceDefinition[item.nameId] = {};
                    } else {
                        $scope.serviceDefinition[item.nameId] = null;
                    }
                } else {
                    for (var i = 0; i < item.children.length; i++) {
                        if (item.children[i].multiple) {
                            $scope.serviceDefinition[item.children[i].nameId] = {};
                        } else {
                            $scope.serviceDefinition[item.children[i].nameId] = null;
                        }
                    }
                }

                // add service name and notes
                $scope.serviceDefinition['serviceName'] = null;
                $scope.serviceDefinition['note'] = null;

            });
        }
        setupModel();
    });