'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductDetailsCtrl
 * @description
 * # ProductDetailsCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ProductDetailsCtrl', function($scope, $timeout, $q, $log, ppmUtils, $filter, $parse, ProductPlanMgmtSvc, productDetailFieldsMetaData,
        ProductL3, PpmFullEqual, ModalDialogFactory, ConfirmationModalFactory, QueryDialog, ENV, $stateParams, $state, ProductCostShareFacadeSvc) {
        $scope.debugMode = (ENV.name === 'local');

        // This is the parent control indicating whether to show the related cost share sliders or not
        var costShareParentId = 'applicableCoverageTiers',
            isIncludeSecondaryMoop = 'isIncludeSecondaryMoop',
            product = 'productClasses';

        $scope.productId = ProductL3 != null ? ProductL3.objectId : null;

        $scope.isZeroAllowed = false;
        $scope.isEnforced = false;
        $scope.isWarningEnabled = false;
        $scope.isErrorEnabled = false;
        $scope.editedTierNameValid = false;
        $scope.productEditStatus = false;

        // It is better to move this to a angular constant in future
        var providerTierNamesOrder = [
            'In Network',
            'Out of Network',
            'Out of Area',
            'Out of Country',
            'Preferred Network 1',
            'Preferred Network 2',
            'Preferred Network 3',
            'Coverage'
        ];
        $scope.componentStatus = {
            isValidationEnabled: true,
            isSaveEnabled: true
        };
        $scope.fieldsErrorStatus = {};
        $scope.providerTierNamesOrder = providerTierNamesOrder;


        var productId = '';

        function init() {
            $scope.debugMode = (ENV.name === 'local');

            $scope.productDetails = {}; // $scope.editPlan.screens.productDetails;
            $scope.productDetailsOri = {};
            $scope.productDetails['enableOrDisable'] = false;
            $scope.productCostSharesOriginal = undefined;


            // Sameple data format should be: {'maximumIndividualDeductible': {'selected': true, 'displayName': 'Individual Deductible'}}
            $scope.costShares = {};

            $scope.selectedTab = 'sdf';

            // Status of opened calendar, internal use only
            $scope.calendarOpened = {};

            $scope.productFieldsMetaData = productDetailFieldsMetaData.productFieldsMetaData;
            $scope.costSharesMapping = productDetailFieldsMetaData.coverageTiersMapping;
            $scope.productFieldsMetaDataMappedByNameId = getMetaInfoMappedByNameId($scope.productFieldsMetaData);

            $scope.hasError = false;
            $scope.isIncludeSecondaryMoopInitValueChanged = false;

            setupModel();
            loadData();
        }

        // Status of opened calendar, internal use only
        $scope.calendarOpened = {};

        $scope.isArray = function(data) {
            return angular.isArray(data);
        };

        $scope.savingHook.action = function() {
            $scope.saveClick();
        };
        // before destory the scope, make sure the hooker is removed so that this memory can be released
        $scope.$on('$destroy', function() {
            $scope.savingHook.action = null;
        });

        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId][$index] = true;

            $log.log('$scope.calendarOpened[nameId][$index] = ' + $scope.calendarOpened[nameId][$index]);
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function

        $scope.tabClicked = function($event, tabName) {
            $event.preventDefault();
            setTab(tabName);
        };

        $scope.validationMsgFunction = function() {
            $scope.validationMsgTracker = {};
            $scope.foundError = false;
            angular.forEach($scope.productDetails.globalcostshares, function(item) {
                $scope.validationMsgTracker[item.costShareType] = {};
                $scope.validationMsgTracker[item.costShareType]['showError'] = false;
                if (item.from === null || item.min === null || item.max === null || item.to === null || item.step === null || item.scale === null || item['default'] === null) {
                    $scope.validationMsgTracker[item.costShareType]['showError'] = true;
                    $scope.foundError = true;
                }
            });
        };

        $scope.saveClick = function() {
            // verify manadatory field
            if ($scope.productDetails.enableOrDisable === true) {
                $log.log('Invalid Range Values');
                return;
            }
            $scope.validationMsgFunction();
            if ($scope.foundError === true) {
                $log.log('Range values not entered');
                return;
            }

            if (containAllMandatoryFields()) {
                $scope.hasError = false;
            } else {
                $scope.hasError = true;
            }
            if ($scope.hasError) {
                $log.log('Mandatory fields check not passed.');
                return;
            }
            if (!validateAllCostShares()) {
                $log.log('split cost share value check not passed.');
                return;
            }

            // check if there is any changes
            var nonEqualStrs = {};
            if (!isSaving(nonEqualStrs)) {
                $scope.componentStatus.isValidationEnabled = true;
                return;
            }

            $scope.hasError = false;
            $scope.validstatussave = $scope.areTierNamesValid($scope.editedTierNameValid);
            if (!$scope.validstatussave) {
                return;
            }

            saveOrUpdateProduct(nonEqualStrs, true);
        };

        $scope.nextClick = function() {
            if ($scope.productDetails.enableOrDisable === true) {
                $log.log('Invalid Range Values');
                return;
            }
            $scope.validationMsgFunction();
            if ($scope.foundError === true) {
                $log.log('Range values not entered');
                return;
            }
            var nonEqualStrs = {};

            function doSave() {
                // setDefaultPlanYearValue();
                saveOrUpdateProduct(nonEqualStrs, false, true);
            }

            if (containAllMandatoryFields()) {
                $scope.hasError = false;
            } else {
                $scope.hasError = true;
                $log.log('Mandatory fields check not passed.');
                return;
            }
            $scope.validstatusnext = $scope.areTierNamesValid($scope.editedTierNameValid);

            if (!$scope.validstatusnext) {
                return;
            }
            // check if there is any changes
            $q.when(isSaving(nonEqualStrs))
                .then(function(savingIt) {
                    if (savingIt) {
                        return doSave();
                    }
                })
                .then(function() {
                    if ($scope.productId !== null && angular.isDefined($scope.productId)) {
                        $state.go('home.ppm.product.edit.service-list', {
                            productId: $scope.productId
                        });
                    }
                });
        };

        $scope.displayCostShareErrorMsgFlag = function(csName) {
            var flag = false;


            // check global cost shares 
            if (flag || !$scope.productFieldsMetaDataMappedByNameId[csName].show) {
                return flag;
            }
            var globalValue = parseFloat($scope.productDetails[csName]);
            if (globalValue < 0) {
                flag = true;
            } else if (globalValue > 100 && csName === 'coinsurance') {
                flag = true;
            }
            return flag;
        };

        $scope.providerTierChanged = function(nameId, label) {

            if (!$scope.productEditStatus) {
                return;
            }

            if ($scope.productDetails['productTiers']['providerTierNamesforDisplay'][nameId]) {
                return;
            }

            var title = 'Warning';
            var warningMessage = '<p>Deselecting provider tier(s) will delete the provider tier(s) and all associated cost share information from the product. </p><p>Do you want to save this change to the product?</p>';

            var modalInstance = QueryDialog.open(title, warningMessage, 'question', 'ppm-modal-dialog-question');


            modalInstance.result.then(function() {
                $log.log('Provider tier removed:' + label);
            }, function() {
                $scope.productDetails['productTiers']['providerTierNamesforDisplay'][nameId] = true;
                $log.log('Warning modal dismissed for provider tier removal: ' + label);
            });
        };

        $scope.tiersNameChanged = function() {
            $log.log('tiersNameChanged');
            refreshTiersChanges($scope.productDetails.productTiers.providerTierNamesforDisplay);
        };

        $scope.tiersNameValid = function(btnNameId, btnNameLabel) {
            $log.log('tiersNameValid: ' + btnNameId + ' --> ' + btnNameLabel + '.');

            var tierNameOptions = $scope.productFieldsMetaDataMappedByNameId['productTiers'].options;
            var valid = true;
            var msg;

            if (btnNameLabel.trim().length > 65) {
                valid = false;
                msg = 'Tier Name should be less than or equal to 65. The current length is ' + btnNameLabel.length + '.';
            } else if (btnNameLabel.trim().length < 3) {
                valid = false;
                msg = 'Tier Name should be greater than or equal to 3. The current length is ' + btnNameLabel.length + '.';
            } else { // make sure the name is unique
                angular.forEach(tierNameOptions, function(option) {
                    if (option.optionNameId !== btnNameId && option.label.toLowerCase() === btnNameLabel.toLowerCase()) {
                        valid = false;
                        msg = 'Tier Name should be unique (Case Insensitive).';
                    }
                });
            }

            if (!valid) {
                QueryDialog.open('Tier Name Invalid', msg, 'minus', 'ppm-modal-dialog-error');
                $scope.editedTierNameValid = true;
            } else {
                $scope.editedTierNameValid = false;
            }
            return valid;
        };

        $scope.areTierNamesValid = function(validstatus) {
            if (validstatus) {
                var validationmsg = 'Tier Name should be unique (Case Insensitive).';
                QueryDialog.open('Tier Name Invalid', validationmsg, 'minus', 'ppm-modal-dialog-error');
                return false;
            } else {
                return true;
            }
        };

        $scope.$on('ppm.input.validation.error', function(event, args) {
            event.stopPropagation();
            if (args.hasError) {
                $scope.fieldsErrorStatus[args.id] = true;
            } else {
                delete $scope.fieldsErrorStatus[args.id];
            }
            $scope.componentStatus.isSaveEnabled = angular.equals($scope.fieldsErrorStatus, {});
        });

        // Update split cost share names automatically
        $scope.$watchCollection('productDetails.productTiers.providerTierNames', function( /*newNames, oldNames*/ ) {
            $log.log('productDetails.productTiers.providerTierNames changed');

            angular.forEach($scope.productFieldsMetaData, function(field) {

                if (field.type === 'slider') {
                    angular.forEach($scope.costShares, function(csValue, csNameId) {

                        if ((csValue.selected) && (field.nameId === csNameId)) {

                            var id = genCostShareSplitId(field.nameId);
                            var tierNameIndex = (function indexOfTierNameInSplit(searchedSplitValues) {
                                var indexMap = {};
                                angular.forEach(searchedSplitValues, function(splitValue, idx) {
                                    indexMap[splitValue['tierName']] = idx;
                                });

                                return indexMap;
                            })($scope.productDetails[id]);

                            var count = 0;
                            field.children = [];
                            var newSplitValues = [];
                            angular.forEach($scope.productDetails['productTiers']['providerTierNames'], function(tierName) {
                                var child = {};
                                child['id'] = count.toString();
                                child['displayName'] = tierName;
                                child['parentId'] = field.nameId;
                                child['requiredField'] = false;
                                field.children.push(child);
                                // update user enter value (remove removed and add new with value as 0)
                                var index = tierNameIndex[tierName];
                                if (index >= 0) { // means that tier still exist
                                    newSplitValues.push($scope.productDetails[id][index]); // add it into new array
                                } else { // mean this is a new one
                                    newSplitValues.push({
                                        'tierName': tierName,
                                        'tierValue': 0
                                    });
                                }
                                count++;
                            });
                            $scope.productDetails[id] = newSplitValues;
                        }
                    });
                }
            });
        });
        // End of tier name change watch

        $scope.$watchCollection('productDetails.productTiers.providerTierNamesforDisplay', function(newValue, oldValue) {
            // if (newValue === oldValue) { // now the init is go first and when first init listener call, the newValue and oldValue are the same
            //     return;
            // } 

            if (numOfSelectedTierNames(newValue) === 0) {
                if (productId && productId.toString().length > 0) {
                    var msg = 'User must select at least one provider tier';
                    QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
                    $scope.productDetails.productTiers.providerTierNamesforDisplay = oldValue;
                }

            } else {
                refreshTiersChanges(newValue);
            }

        });

        function numOfSelectedTierNames(tierNames) {
            var num = 0;
            angular.forEach(tierNames, function(selectedValue) {
                if (selectedValue) {
                    num++;
                }
            });

            return num;
        }

        function refreshTiersChanges(selectedTiersForDisplay) {
            var fieldMetaInfo = $scope.productFieldsMetaDataMappedByNameId['productTiers'];
            var availableOptions = fieldMetaInfo.options;

            $scope.productDetails.productTiers.providerTierNames = [];
            $scope.productDetails.productTiers.providerTierDisplayNames = [];
            angular.forEach(availableOptions, function(option) {
                if (selectedTiersForDisplay[option.optionNameId]) {
                    $scope.productDetails.productTiers.providerTierNames.push(option.optionNameId);
                    $scope.productDetails.productTiers.providerTierDisplayNames.push(option.label);
                }
            });
        }

        function containAllMandatoryFields() {
            function isInvalidString(data) {
                if (isNullOrUndefined(data)) {
                    return true;
                } else if (data === '') {
                    return true;
                } else {
                    return false;
                }
            }

            function isInvalidArray(data) {
                if (isNullOrUndefined(data)) {
                    return true;
                } else if (data.length < 1) {
                    return true;
                } else {
                    return false;
                }
            }

            function isCheckboxValueUnselected(data) {
                var allFalseValues = true;
                angular.forEach(data, function(value) {
                    if (value) {
                        allFalseValues = false;
                    }
                });
                return (allFalseValues);
            }

            function checkForOtherRanges(costShares) {
                var isCostShareNotFound = false;
                if (costShares.to === '' || costShares.to === 0 || costShares.to === null) {
                    isCostShareNotFound = true;
                } else if (costShares.scale === '' || costShares.scale === 0 || costShares.scale === null) {
                    isCostShareNotFound = true;
                } else if (costShares.step === '' || costShares.step === 0 || costShares.step === null) {
                    isCostShareNotFound = true;
                }
                return isCostShareNotFound;
            }

            function isGlobalCostShareRangeAvailable(costShares) {
                var isCostShareNotFound = false;
                if (costShares.from === '' || costShares.from === null) {
                    isCostShareNotFound = true;
                } else if (costShares.min === '' || costShares.min === null || (costShares.min === 0 && costShares.from !== 0)) {
                    isCostShareNotFound = true;
                } else if (costShares.max === '' || costShares.max === 0 || costShares.max === null) {
                    isCostShareNotFound = true;
                }
                if (!isCostShareNotFound) {
                    isCostShareNotFound = checkForOtherRanges(costShares);
                }
                return isCostShareNotFound;
            }

            function isSliderValueSelected(foundInvalidFields, field) {
                var costShareValueAvailable = false;
                var copayFound = false;
                var coinsuranceFound = false;
                if (foundInvalidFields) {
                    costShareValueAvailable = true;
                } else {
                    if (angular.isDefined($scope.productDetails.globalcostshares) && $scope.productDetails.globalcostshares.length > 0) {
                        angular.forEach($scope.productDetails.globalcostshares, function(costShares) {
                            if (angular.isDefined(costShares)) {
                                if (costShares.costShareType === field.displayName && !costShareValueAvailable) {
                                    costShareValueAvailable = isGlobalCostShareRangeAvailable(costShares);
                                    if (costShares.costShareType === 'Copay') {
                                        copayFound = true;
                                    } else if (costShares.costShareType === 'Co-insurance') {
                                        coinsuranceFound = true;
                                    }
                                } else if (costShares.costShareType !== field.displayName && !costShareValueAvailable) {
                                    if (costShares.costShareType === 'Copay') {
                                        copayFound = true;
                                    } else if (costShares.costShareType === 'Co-insurance') {
                                        coinsuranceFound = true;
                                    }



                                }

                            } else {
                                costShareValueAvailable = true;
                            }



                        });

                        if (!costShareValueAvailable && (!copayFound || !coinsuranceFound)) {
                            costShareValueAvailable = true;
                        }

                    } else {
                        costShareValueAvailable = true;
                    }
                }
                return costShareValueAvailable;
            }

            function isDateValueAvailable(field) {
                var notValidDate = false;
                if (angular.isDefined($scope.productDetails[field.nameId]) && (isInvalidString($scope.productDetails[field.nameId]['endDate']) || isInvalidString($scope.productDetails[field.nameId]['effectiveDate']))) {
                    notValidDate = true;
                }
                return notValidDate;
            }

            function containInvalidValue(metadata) {
                var foundInvalidFields = false;
                angular.forEach(metadata, function(field) {
                    if (field.requiredField && !foundInvalidFields) {
                        if (field.multiple) { // drop down. dateRange, checkbox, text
                            if ((field.type === 'dateRange') && (field.nameId === 'effectiveDates')) {
                                foundInvalidFields = isDateValueAvailable(field);

                            } else if (field.type === 'checkbox') {
                                foundInvalidFields = isCheckboxValueUnselected($scope.productDetails[field.nameId]) || foundInvalidFields;
                            } else {
                                foundInvalidFields = isInvalidArray($scope.productDetails[field.nameId]) || foundInvalidFields;
                            }
                        } else { // text, radioButton, date  
                            if (field.type === 'slider') {
                                foundInvalidFields = isSliderValueSelected(foundInvalidFields, field);
                            } else {
                                foundInvalidFields = isInvalidString($scope.productDetails[field.nameId]) || foundInvalidFields;
                            }
                        }
                    }
                });

                return foundInvalidFields;
            }

            var foundInvalidFields = containInvalidValue($scope.productFieldsMetaData);
            return (!foundInvalidFields);
        }

        function validateAllCostShares() {
            var isValid = true;
            // check global cost shares
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (isValid && (metadata.type === 'slider') && metadata.show) {
                    isValid = isValid && !$scope.displayCostShareErrorMsgFlag(metadata.nameId);
                }
            });

            if (!isValid) {
                var msg = 'Unable to create the Product because you’ve entered one or more invalid Cost Share amounts. Change any Copay or Deductible amount &lt; $0 and any Coinsurance amount &lt; 0% or &gt; 100%.';
                QueryDialog.open('Create Product', msg, 'minus', 'ppm-modal-dialog-error');
            }
            return isValid;
        }

        function isSaving(result) {
            var config = {};
            var equalSvc = new PpmFullEqual(config);
            var currentValue = transformOutput($scope.productDetails);
            currentValue = extractEffectiveDate(currentValue);
            $log.log(angular.toJson(currentValue, true));
            var isSame = equalSvc.equals(currentValue, $scope.productDetailsOri, result);
            return !isSame;
        }

        // return promise
        function saveOrUpdateProduct(nonEqualStrs, showMessage, fromNext) {
            // unregirest wath productDetails, because after save or validation, plan details could be updated
            unregisterProductChangedListener();
            /* Fixed DOGVT-244 - I get the attached message when I click Next on the Plan Details page */
            // DOGHR-1610 inconsistency error message between the UPMC and Highroads when Save an edited Plan
            // Avoid using length to retrieve certain metadata item, since right now metadata is dynamic after udf introduced
            var productName = $scope.productDetails['name'];
            if (productName == null) {
                productName = '';
            }
            var dataConverted = transformOutput();
            dataConverted = extractEffectiveDate(dataConverted);

            if (!isNullOrUndefined(dataConverted.globalcostshares) && dataConverted.globalcostshares.length === 1 && isNullOrUndefined(dataConverted.globalcostshares[0])) {
                delete dataConverted.globalcostshares;
            }


            $log.log('non simplified submit data = ' + angular.toJson(dataConverted, true));
            dataConverted = getSimplifiedPostData(dataConverted, nonEqualStrs);

            if (productId && productId.toString().length > 0) { // make sure Id is string if test length
                //dataConverted = getSimplifiedPostData(dataConverted, nonEqualStrs);
                //delete dataConverted['globalcostshares'];
                $log.log('submit data = ' + angular.toJson(dataConverted, true));
                return ProductPlanMgmtSvc.updateProduct(dataConverted, productId).then(function(data) {
                    $scope.productDetails.productStatus = 'Draft'; // If the update successfully, the status can be expected to be draft
                    if (showMessage) {
                        var msgtitle;
                        var msg;
                        msgtitle = '';
                        msg = productName + ' updated successfully'; /* Fixed DOGVT-244 - I get the attached message when I click Next on the Plan Details page */
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }

                    getLatestProductToOri();
                    $scope.createProductForm.$setPristine();
                    if ($scope.toCreateNewcreateProductForm === true) {
                        $state.go('home.ppm.product.edit.product-details', {
                            productId: ''
                        });
                    }

                    return data; // it is plan objectId
                }, function(reason) {
                    $log.log(reason);
                    return $q.reject(reason);
                }).then(function(productId) {
                    dataConverted.productStatus = 'Draft';
                    return updateCachedProductL3(productId, dataConverted); // should return a promise
                }).then(function() {
                    loadData();
                    $scope.productDetails.productId = 'Draft';
                })['finally'](function() { // same as .finally()
                    registerProductChangedListener();
                });
            } else { // save  
                dataConverted = extractEffectiveDate(dataConverted);
                /*if(angular.isArray(dataConverted['globalcostshares']) && dataConverted['globalcostshares'].length===1 && dataConverted['globalcostshares'][0]===null){
                    delete dataConverted['globalcostshares'];
                }*/
                //
                ProductPlanMgmtSvc.createProduct(dataConverted).then(function(productId) {
                    $scope.productId = productId;
                    $scope.productDetails.productStatus = 'Draft'; // If the update successfully, the status can be expected to be draft
                    if (showMessage) {
                        var msgtitle;
                        var msg;
                        msgtitle = '';
                        msg = productName + ' created successfully'; /* Fixed DOGVT-244 - I get the attached message when I click Next on the Plan Details page */

                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                        $state.go('home.ppm.product.edit.product-details', {
                            productId: productId
                        });
                    }
                    return productId;
                }).then(function() {
                    if (fromNext !== null && angular.isDefined(fromNext) && fromNext) {
                        $state.go('home.ppm.product.edit.service-list', {
                            productId: $scope.productId
                        });
                    }
                });

                /*$log.error('Product Id must be specified!');
                return $q.reject('Product Id must be specified!');*/
            }
        }
        // End of saveOrUpdateProduct function

        function updateCachedProductL3(productId, simpleSentData) {
            return ProductCostShareFacadeSvc.updateCachedProductL3PropertyAndPlanCostShares(productId, simpleSentData);
        }

        function getSimplifiedPostData(postData, nonEqualPropertyStrs) {

            return generatePostData(postData, nonEqualPropertyStrs);

            function generatePostData(postData, nonEqualPropertyStrs) {
                $log.log('==============================');
                var retValue = {};
                var product = generateProductPropertiesData(postData, nonEqualPropertyStrs);
                var costShares = generateProductCostShareProperties(postData);
                retValue.product = product;
                if (!retValue.product) {
                    retValue.product = {};
                }
                if (costShares && costShares.length > 0) {
                    retValue.product.globalcostshares = costShares;
                }
                delete retValue.product.objectId;
                return retValue.product;
            }

            function generateProductPropertiesData(postData, nonEqualPropertyStrs) {
                var p = /^(value\.[^\[\]\.]+).*$/;
                var p2 = /^(value\.globalcostshares[\.\[]?).*$/;
                var obj = {};
                angular.forEach(nonEqualPropertyStrs, function(value, propertyStr) {
                    if (!p2.test(propertyStr)) {
                        var groups = p.exec(propertyStr);
                        if (groups) {
                            var propertyStrArray = groups[1]; // if simple property is array, use array as property, if not, it is still the property
                            copyValueFromSource(propertyStrArray, postData, obj);
                        }

                    }
                });
                // copy objectId
                if (!angular.equals(obj, {})) {
                    copyValueFromSource('value.objectId', postData, obj);
                }
                // copy providerTierNames, if providerTierDisplayName changed
                if (obj.value && obj.value.providerTierDisplayNames && !obj.value.providerTierNames) {
                    copyValueFromSource('value.providerTierNames', postData, obj);
                }
                return obj.value;
            }

            function generateProductCostShareProperties(postData) {
                return postData.globalcostshares;
            }

            function copyValueFromSource(propertyPath, source, dest) {
                var newValue = $parse(propertyPath)({
                    value: source
                });
                ppmUtils.transferPathToObject(propertyPath, newValue, dest);
            }
        }

        function extractEffectiveDate(dataConverted) {
            var effectiveDates = dataConverted.effectiveDates;

            angular.forEach(effectiveDates, function(dateValue, dateKey) {
                dataConverted[dateKey] = dateValue;
            });
            delete dataConverted.effectiveDates;
            return dataConverted;
        }

        function getMetaInfoMappedByNameId(fieldMetaInfoList) {
            var mapper = {};
            angular.forEach(fieldMetaInfoList, function(fieldMetaInfo) {
                mapper[fieldMetaInfo.nameId] = fieldMetaInfo;
            });

            return mapper;
        }

        function transformOutput() {
            var data = {};

            var costShareShowList = getCostShareShowList(costShareParentId, $scope.costSharesMapping);
            //data.productCostShares = [];
            data.productStatus = $scope.productDetails.productStatus;

            angular.forEach($scope.productDetails, function(prodValue, prodKey) {
                var found = false;
                /*jshint maxcomplexity:12 */
                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.nameId === prodKey) {
                        var value = doOutputUnitTransform(prodValue, metadata, costShareShowList);
                        if (value != null) {
                            found = true;
                            if (metadata.type === 'slider') {
                                $log.log(metadata.nameId);
                                // Removing Round slide setting to preveting sent save it into backend. 
                                // DOGHR-1836
                                // delete value['round'];
                                // if (typeof value.selectedValue === 'string') {
                                //     value.selectedValue = parseFloat(value.selectedValue);
                                // }
                                // data.globalcostshares.push(value);
                            } else if (metadata.type === 'tiers') {
                                angular.forEach(value, function(item, key) {
                                    data[key] = item;
                                });
                            } else if ((metadata.type === 'radioButton') && (metadata.nameId === isIncludeSecondaryMoop)) {
                                if (prodValue === 'Yes') {
                                    data[prodKey] = true;
                                } else {
                                    data[prodKey] = false;
                                }
                            } else {
                                data[prodKey] = value;
                            }
                        } else { // invalid cost share items, need to remove
                            if (metadata.type === 'radio') {
                                data[prodKey] = prodValue;
                            } else if (metadata.type === 'radioButton') {
                                data[prodKey] = null;
                            } else if (metadata.type === 'textInput' || metadata.type === 'textArea') {
                                data[prodKey] = null;
                            }
                            found = true;
                        }
                    }
                });

                if (!found) {
                    if (prodValue === '') {
                        prodValue = null;
                    }
                    data[prodKey] = prodValue;
                }
            });

            if (data['providerTierNamesforDisplay']) {
                delete data['providerTierNamesforDisplay'];
            }
            if (data['productCostShares']) {
                delete data['productCostShares'];
            }
            if (data['productType']) {
                delete data['productType'];
            }
            if (data['warning']) {
                delete data['warning'];
            }
            if (data['error']) {
                delete data['error'];
            }
            return data;
        }
        // End of transformOutput function

        function getCostShareShowList(parent, mapping) {
            var showList = [];
            var hasSingle = false;
            var selected = 0;

            function contains(array, obj) {
                var i = array.length;
                while (i--) {
                    if (array[i] === obj) {
                        return true;
                    }
                }
                return false;
            }

            function containsKey(array, obj) {
                var i = array.length;
                while (i--) {
                    if (array[i].toString().toLowerCase().indexOf(obj) > -1) {
                        return true;
                    }
                }
                return false;
            }

            function getProdId(nameId) {
                var productArr = ['medical', 'dental', 'vision', 'pharmacy'];
                var prodId = '';
                for (var i = 0; i < productArr.length; i++) {
                    if (nameId.indexOf(productArr[i]) > -1) {
                        prodId = nameId.slice(nameId.indexOf(productArr[i]), productArr[i].length);
                    }
                }
                return prodId;
            }

            angular.forEach($scope.productDetails[parent], function(item, key) {
                // DOGHR-1286: Add a check to see if the value exist in product, if not, don't show the corresponding slider
                if (item === true && !isNullOrUndefined($scope.productDetails[parent]) && contains(Object.keys($scope.productDetails[parent]), key)) {
                    selected++;
                    if (key === 'Individual') {
                        hasSingle = true;
                    }
                    angular.forEach(mapping, function(item2, key2) {
                        if (key2 === key) {
                            showList = showList.concat(item2);
                        }
                    });
                }
            });

            if (!hasSingle && selected > 0) {
                showList = showList.concat(mapping.Individual);
            }

            //Secondary Moop check  
            if ($scope.productDetails[isIncludeSecondaryMoop] !== 'Yes') {
                for (var i = showList.length - 1; i >= 0; i--) {
                    if (showList[i].indexOf('SecondaryMoop') > -1) {
                        showList.splice(i, 1);
                    }
                }
            }

            angular.forEach($scope.productDetails[product], function(selected, productName) {
                var selectedValues = Object.keys($scope.productDetails[product]);
                if (selected) {
                    for (var i = showList.length - 1; i >= 0; i--) {
                        if (showList[i].indexOf(productName.toString().toLowerCase()) === -1 && !containsKey(selectedValues, getProdId(showList[i]))) {
                            showList.splice(i, 1);
                        }
                    }
                } else {
                    for (var j = showList.length - 1; j >= 0; j--) {
                        if (showList[j].indexOf(productName.toString().toLowerCase()) !== -1) {
                            showList.splice(j, 1);
                        } else if (showList[j].indexOf(productName.toString().toLowerCase()) === -1 && !containsKey(selectedValues, getProdId(showList[j]))) {
                            showList.splice(j, 1);
                        }
                    }
                }
            });

            if (Object.keys($scope.productDetails[product]).length === 0) {
                showList = [];
            }

            return showList;
        }
        // End of getCostShareShowList function

        // This function has a cyclomatic complexity error! and the  reason is simple, 
        // it has too many if / else paths. The question is why not create small reusable
        // functions instead a huge large function?
        function doOutputUnitTransform(originValue, metaDataField, costShareShowList) {
            var value = originValue;
            switch (metaDataField.type) {
                case 'checkbox':
                    value = [];
                    angular.forEach(originValue, function(item, key) {
                        if (item === true) {
                            value.push(key);
                        }
                    });
                    break;
                    // We changed to user UTC datetime format like '2015-12-25T05:00:00.000Z' or '2016-01-19T09:56:30.543-05:00', 
                    // so there is no need to transfer the datetime. 
                    // case 'dateRange':
                    //     value = {};
                    //     angular.forEach(originValue, function(item, key) {
                    //         value[key] = getDateFilterValue(item);
                    //     });
                    //     break;
                    // case 'date':
                    //     value = getDateFilterValue(originValue);
                    //     break;
                case 'slider':
                    value = getSlideValue(metaDataField, originValue, costShareShowList);
                    break;
                case 'radioButton':
                    if (isNullOrUndefined(originValue)) {
                        value = null;
                    } else {
                        value = getRadioButtonValue(originValue);
                    }
                    break;
                case 'dropdown':
                    value = getDropdownValue(metaDataField, originValue);
                    break;
                case 'textInput':
                case 'textArea':
                    if (value === '') {
                        value = null;
                    }
                    break;
            }
            return value;
        }
        // End of doOutputUnitTransform function

        function getSlideValue(metaDataField, originValue, costShareShowList) {
            var value = null;
            if (showSlider(metaDataField, costShareShowList)) {
                value = angular.copy(metaDataField.options);
                //value.selectedValue = parseInt(originValue, 10);
                value.selectedValue = originValue;
                value.scale = value.scaleOriginal;
                delete value.scaleOriginal;
                if (metaDataField.options.splitByTier === 'true') {
                    value.splitByTier = $scope.costShares[metaDataField.nameId].selected;
                } else {
                    value.splitByTier = false;
                }
            }
            return value;
        }

        function getRadioButtonValue(originValue) {
            var value = originValue;
            if (originValue.toString().toLowerCase() === 'yes') {
                value = true;
            } else if (originValue.toString().toLowerCase() === 'no') {
                value = false;
            }
            return value;
        }

        function getDropdownValue(metaDataField, originValue) {
            var value = originValue;
            if (metaDataField.nameId === 'planYear' && angular.isArray(originValue) && originValue.length === 0) {
                originValue.push('NA'); // Seems that backend use NA, not N/A.
            }
            return value;
        }


        function showSlider(metaDataField, costShareShowList) {
            var show = false;
            if (!metaDataField.parentId) {
                show = true;
            } else {
                show = isNameExist(metaDataField.nameId, costShareShowList);
            }
            return show;
        }

        // Check to show the slider or not
        function isNameExist(name, mapping) {
            var found = false;
            for (var i = 0, j = mapping.length; i < j; i++) {
                if (mapping[i] === name) {
                    found = true;
                    break;
                }
            }
            return found;
        }
        // End of isNameExist function

        function genCostShareSplitId(csId) {
            return csId + '_split';
        }

        function isNullOrUndefined(value) {
            if ((value === undefined) || (value === null)) {
                return true;
            } else {
                return false;
            }
        }

        var unregisterProductChangedListenerFn = null;

        function registerProductChangedListener() {
            $timeout(function() {
                // $log.log('>>>>> registerPlanChangedListener');
                if (!unregisterProductChangedListenerFn) { // make sure only one listener registered
                    unregisterProductChangedListenerFn = $scope.$watch('productDetails', function(newValue, oldValue) {
                        if (!newValue || !oldValue || newValue === oldValue) {
                            return;
                        }
                        $scope.componentStatus.isValidationEnabled = false;
                        $log.log('watchCollection productDetails: $scope.componentStatus.isValidationEnabled = ' + $scope.componentStatus.isValidationEnabled);
                    }, true);
                }
            }, 500);
        }

        function unregisterProductChangedListener() {
            if (unregisterProductChangedListenerFn) {
                // $log.log('>>>>> unregisterPlanChangedListener');
                unregisterProductChangedListenerFn();
                unregisterProductChangedListenerFn = null;
            }
        }

        registerProductChangedListener();

        function setupModel() {
            $scope.productDetails['productStatus'] = 'Draft';
            angular.forEach($scope.productFieldsMetaData, function(metadata) { // fieldsMetaData is array, and value is object
                if (!metadata.multiple) {
                    assignSingleSelectPropertiesToProductDetails(metadata);
                } else {
                    if (!$scope.productDetails[metadata.nameId]) {
                        $scope.productDetails[metadata.nameId] = {};
                    }
                    assignMultipleSelectPropertiesToProductDetails(metadata);
                }
            });

            setTab('sdf');
        }

        function assignSingleSelectPropertiesToProductDetails(metadata) {
            if (!$scope.productDetails[metadata.nameId] && metadata.nameId !== 'productTypes') {
                $scope.productDetails[metadata.nameId] = null;
            }
            if (metadata.type === 'slider') {
                var found = false;
                // how many numbers allowed after comma
                metadata.options.round = 2;
                angular.forEach(metadata.options, function(opt) {
                    if (angular.isDefined(opt) && opt.optionNameId === 'default') {
                        $scope.productDetails[metadata.nameId] = opt.label;
                        found = true;
                    }
                });
                if (!found) {
                    $scope.productDetails[metadata.nameId] = 0;
                }
            }
        }

        function assignMultipleSelectPropertiesToProductDetails(metadata) {
            if (!$scope.productDetails[metadata.nameId] && metadata.nameId === 'productFamilies') {
                $scope.productDetails[metadata.nameId] = [];
            } else if (!$scope.productDetails[metadata.nameId] && metadata.nameId !== 'productFamilies') {
                $scope.productDetails[metadata.nameId] = {};
            }
            //$scope.productDetails[metadata.nameId] = {};

            // For special type:
            if (metadata.type === 'tiers') { // Setup structure to avoid null exception
                if (!$scope.productDetails[metadata.nameId]['providerTierNames']) {
                    $scope.productDetails[metadata.nameId]['providerTierNames'] = [];
                }
                if (!$scope.productDetails[metadata.nameId]['providerTierNamesforDisplay']) {
                    $scope.productDetails[metadata.nameId]['providerTierNamesforDisplay'] = {};
                }
            }
            if (metadata.type === 'text') {
                $scope.productDetails[metadata.nameId] = [];
            }
            if (metadata.type === 'checkbox' && metadata.nameId === 'productTypes') {
                $scope.productDetails['productType'] = [];
            }
        }

        function setTab(tabName) {
            $log.log($scope.selectedTab + ' ---> ' + tabName);
            $scope.selectedTab = tabName;

            $state.go('home.ppm.product.edit.product-details.content', {
                tabName: $scope.selectedTab
            });
        }

        function loadData() {

            productId = $stateParams.productId;
            if (productId !== null) {
                $scope.productEditStatus = true;
            }

            var product = ProductL3;

            if (product === null) {
                angular.forEach($scope.costSharesMapping, function(costShareVal, costShareType) {
                    $scope.productDetails['applicableCoverageTiers'][costShareType] = false;
                });
            }

            $scope.productDetails = product !== null ? mergeProductDetails(product) : $scope.productDetails;

            if (product === null) {
                $scope.productDetails['globalcostshares'] = [];
            }
            updateMetadataSliderInfoWithProduct();
            transformInputMetaData();
            transformInputProductDetail(product);

            if (product) {
                filterProductMetaData(product);
            }

            initFromPlanDetail();

            getLatestProductToOri();
        }

        function filterProductMetaData(referenceData) {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (metadata.type === 'dropdown') {
                    return;
                }
                angular.forEach($scope.productDetails, function(prdValue, prdKey) {
                    if (metadata.nameId === prdKey) {
                        if (angular.isArray(prdValue)) {
                            var options = [];
                            angular.forEach(metadata.options, function(opt) {
                                var found = false;
                                angular.forEach(prdValue, function(item) {
                                    if (opt.label === item) {
                                        found = true;
                                    }
                                });
                                if (found) {
                                    options.push(opt);
                                }
                            });
                            metadata.options = options;
                        }
                    }
                });
            });

            filterProductTiers(referenceData);
        }
        // End of filterProductMetaData

        // setup product provider tier meta data by using the product info
        // This is eaxctly add options to tiers meta data
        function filterProductTiers(referenceData) {
            var tierDisplayNameList = [];
            var tierIdNameList = [];
            var tierNamesMap = {};

            // get product itself value (product could change the prefered network 1, 2, 3 display name)
            angular.forEach(referenceData.providerTierNames, function(tName, index) {
                var displayNameInProduct = referenceData.providerTierDisplayNames ? referenceData.providerTierDisplayNames[index] : tName;
                tierNamesMap[tName] = displayNameInProduct ? displayNameInProduct : tName;
            });

            // generate analysis result
            angular.forEach(providerTierNamesOrder, function(tName /*, index*/ ) {
                if (tierNamesMap[tName]) {
                    tierIdNameList.push(tName);
                    tierDisplayNameList.push(tierNamesMap[tName]);
                } else {
                    tierIdNameList.push(tName);
                    tierDisplayNameList.push(tName);
                }
            });

            var tierMetaInfo = $scope.productFieldsMetaDataMappedByNameId['productTiers'];
            var options = [];
            angular.forEach(tierDisplayNameList, function(displayName, index) {
                options.push({
                    'optionNameId': tierIdNameList[index],
                    'label': displayName
                });
            });

            tierMetaInfo.options = options;
        }

        function getLatestProductToOri() {
            $timeout(function() {
                $scope.productDetailsOri = angular.copy(transformOutput());
            }, 200);
        }

        // Merge multiple product info to get the final combined product details
        function mergeProductDetails(product) {

            $scope.productDetails['globalcostshares'] = [];
            // product cost share

            $scope.productDetails['globalcostshares'] = $scope.productDetails['globalcostshares'].concat(product.globalcostshares);
            if (!angular.isDefined($scope.productDetails['productTiers'])) {
                $scope.productDetails['productTiers'] = {};
            }
            angular.forEach($scope.productDetails['productTiers'], function(tierVal, tierkey) {
                $scope.productDetails['productTiers'][tierkey] = angular.isDefined(product[tierkey]) ? product[tierkey] : product['providerTierDisplayNames'];
            });
            return $scope.productDetails;
        }
        // End mergeProductDetails function

        function updateMetadataSliderInfoWithProduct() {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (metadata.type === 'slider') {
                    var found = false;
                    angular.forEach($scope.productDetails.globalcostshares, function(costshare) {
                        if (angular.isDefined(costshare) && metadata.displayName === costshare.costShareType) {
                            found = true;
                            metadata.options = angular.copy(costshare);
                            // how many numbers allowed after comma
                            metadata.options.round = 2;
                            metadata.options.splitByTier = 'true'; // decide if there's a checkbox
                            metadata.options['scaleOriginal'] = costshare.scale;
                            metadata.options.scale = calculateScaleArray(costshare);
                            delete metadata.options.name;
                            delete metadata.options.objectId;
                            $scope.productDetails[metadata.nameId] = costshare['default'];
                        }
                    });
                    // DOGHR-1286: convert array to object even if there's no global cost share info available in product, 
                    // to avoid next step format error
                    if (!found) {
                        $log.log('Global cost share not found in product: ' + metadata.nameId);
                        if (angular.isDefined(metadata.options[0])) {
                            // var splitByTierValue = metadata.options[0].label;
                            metadata.options = {};
                            metadata.options.splitByTier = 'true';
                        }

                        $scope.productDetails[metadata.nameId] = 0;
                    }
                }
            });
        }
        // End of updateMetadataSliderInfoWithProduct function

        function calculateScaleArray(costshareObj) { // Input is an object
            var scaleArray = [];
            var from = parseInt(costshareObj.from, 10);
            var to = parseInt(costshareObj.to, 10);
            var scale = parseInt(costshareObj.scale, 10);
            if (scale > 0 && from >= 0 && to > 0 && from < to) {
                for (var i = from; i <= to; i = i + scale) {
                    scaleArray.push(i);
                }
            }
            return scaleArray;
        }
        // End of calculateScaleArray function


        // Change slider data to required UI format
        function transformInputMetaData() {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (metadata.type === 'slider') {
                    // init costShares values for split features
                    if (!angular.isArray(metadata.options) && metadata.options.splitByTier === 'true') {
                        $scope.costShares[metadata.nameId] = {
                            'selected': false,
                            'displayName': metadata.placeholder,
                            'isRangeValidationEnforced': false,
                            'severityLevel': 'Warning',
                            'isZeroAllowed': false
                        };
                        $scope.costShares[metadata.nameId].displayName = metadata.displayName;
                    }
                } else if (metadata.type === 'tiers' && metadata.nameId === 'productTiers' && metadata.options.length === 0) {
                    angular.forEach(providerTierNamesOrder, function(tier) {
                        var tierObj = {};
                        tierObj['label'] = tier;
                        tierObj['optionNameId'] = tier;
                        metadata.options.push(tierObj);
                    });
                }
                if (metadata.parentId === '') {
                    if (metadata.nameId === isIncludeSecondaryMoop) { // Secondary moop
                        metadata.show = true;
                    } else {
                        metadata.show = true;
                    }

                } else {
                    metadata.show = false;
                }
            });
        }
        // End of transformInputMetaData function

        function transformInputProductDetail(productDetails) {
            var mapping = {
                'effectiveDate': 'effectiveDates',
                'endDate': 'effectiveDates',
                'numProviderTiers': 'productTiers',
                'providerTierNames': 'productTiers',
                'providerTierDisplayNames': 'productTiers'
            };

            // Multi-selection checkbox
            $scope.productDetails['isIncludeSecondaryMoop'] = 'No';
            angular.forEach(productDetails, function(prodValue, prodKey) {
                var found = false;

                // Effective Dates and ProductTiers
                angular.forEach(mapping, function(mapVal, mapKey) {
                    if (prodKey === mapKey && angular.isDefined($scope.productDetails[mapVal])) {
                        $scope.productDetails[mapVal][prodKey] = prodValue;
                        found = true;
                    }
                });

                // set the selected tier name in the product for display
                var tierNameForDisplay = {};

                if (angular.isDefined($scope.productDetails['productTiers'])) {
                    angular.forEach($scope.productDetails['productTiers']['providerTierNames'], function(tierName) {
                        tierNameForDisplay[tierName] = true;
                    });
                    $scope.productDetails['productTiers']['providerTierNamesforDisplay'] = tierNameForDisplay;
                }

                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.nameId === prodKey) {
                        if (metadata.type === 'checkbox' && angular.isArray(prodValue)) {
                            var temp = {};
                            angular.forEach(prodValue, function(item) {
                                temp[item] = true;
                            });
                            $scope.productDetails[prodKey] = temp;
                            found = true;
                        }
                        // Radio Button
                        else if (metadata.type === 'radioButton') {
                            if (prodValue === true) {
                                $scope.productDetails[prodKey] = 'Yes';
                            } else if (prodValue === false) {
                                $scope.productDetails[prodKey] = 'No';
                            } else {
                                $scope.productDetails[prodKey] = prodValue;
                            }
                            found = true;
                        }
                        //Radio
                        else {
                            if (angular.isDefined(prodValue)) {
                                $scope.productDetails[prodKey] = prodValue;
                            }
                            found = true;
                        }
                    } else if (metadata.nameId === 'effectiveDates' && (prodKey === 'effectiveDate' || prodKey === 'endDate')) {
                        $scope.productDetails[prodKey] = prodValue;
                        found = true;
                    }
                });

                if (!found) {
                    $scope.productDetails[prodKey] = prodValue;
                }
            });
            displayMaxOutOfPocket();
            displayProductSpecificFields();
        }

        $scope.radioButtonClicked = function(event, nameId) {
            if ($scope.previousRadioSelection === event.target.value) {
                $scope.productDetails[nameId] = null;
            } else {
                $scope.productDetails[nameId] = event.target.value;
            }
            displayMaxOutOfPocket();
            displayProductSpecificFields();
            displayCostShares();
        };
        $scope.setPreviousSelectedRadioBtnValue = function(nameId) {
            $scope.previousRadioSelection = $scope.productDetails[nameId];
        };

        function initFromPlanDetail() {
            $scope.checkboxChanged(costShareParentId);
        }
        // End of initFromPlanDetail function

        $scope.checkboxChanged = function(nameId) {
            if (nameId !== costShareParentId && nameId !== product) {
                return;
            }
            displayCostShares();
            displayProductSpecificFields();
        };

        function displayMaxOutOfPocket() {
            //Secondary Moop check  
            if ($scope.productDetails[isIncludeSecondaryMoop] === 'Yes') {
                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.type === 'textArea' && metadata.nameId.indexOf('Secondary') !== -1) {
                        metadata.show = true;
                    }
                });
            } else {
                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.type === 'textArea' && metadata.nameId.indexOf('Secondary') !== -1) {
                        metadata.show = false;
                    }
                });
            }
        }

        function displayProductSpecificFields() {
            if (Object.keys($scope.productDetails[product]).length !== 0) {
                var selectedProducts = getSelectedProducts($scope.productDetails[product]);
                angular.forEach($scope.productDetails[product], function(selected, productName) {
                    if (selected) {
                        angular.forEach($scope.productFieldsMetaData, function(metadata) {
                            if ((metadata.type === 'textArea' || (metadata.nameId.indexOf('Accumulation') !== -1 && metadata.nameId.indexOf('udfproduct_') === -1)) && metadata.nameId.indexOf(productName.toString().toLowerCase()) !== -1) {
                                if ($scope.productDetails[isIncludeSecondaryMoop] === 'Yes') {
                                    metadata.show = true;
                                } else {
                                    if (metadata.nameId.indexOf('Secondary') !== -1) {
                                        metadata.show = false;
                                    } else {
                                        metadata.show = true;
                                    }
                                }
                            } else if ((metadata.type === 'textArea' || (metadata.nameId.indexOf('Accumulation') !== -1 && metadata.nameId.indexOf('udfproduct_') === -1)) &&
                                metadata.nameId.indexOf(productName.toString().toLowerCase()) === -1 && !contains(selectedProducts, getProdId(metadata.nameId))) {
                                metadata.show = false;
                            }
                        });
                    } else {
                        angular.forEach($scope.productFieldsMetaData, function(metadata) {
                            if ((metadata.type === 'textArea' || (metadata.nameId.indexOf('Accumulation') !== -1 && metadata.nameId.indexOf('udfproduct_') === -1)) && metadata.nameId.indexOf(productName.toString().toLowerCase()) !== -1) {
                                metadata.show = false;
                            } else if ((metadata.type === 'textArea' || (metadata.nameId.indexOf('Accumulation') !== -1 && metadata.nameId.indexOf('udfproduct_') === -1)) &&
                                metadata.nameId.indexOf(productName.toString().toLowerCase()) === -1 &&
                                !contains(selectedProducts, getProdId(metadata.nameId)) && metadata.show) {
                                metadata.show = false;
                            }
                        });
                    }
                });
            } else {
                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.type === 'textArea' || (metadata.nameId.indexOf('Accumulation') !== -1 && metadata.nameId.indexOf('udfproduct_') === -1)) {
                        metadata.show = false;
                    }
                });
            }

            function getProdId(nameId) {
                var productArr = ['medical', 'dental', 'vision', 'pharmacy'];
                var prodId = '';
                for (var i = 0; i < productArr.length; i++) {
                    if (nameId.indexOf(productArr[i]) > -1) {
                        prodId = nameId.slice(nameId.indexOf(productArr[i]), productArr[i].length);
                    }
                }
                return prodId;
            }

            function contains(array, obj) {
                var i = array.length;
                while (i--) {
                    if (array[i].toString().toLowerCase() === obj.toString().toLowerCase()) {
                        return true;
                    }
                }
                return false;
            }
        }

        function displayCostShares() {
            // get the list of cost shares(moop and deductible) that should be displayed
            var showList = getCostShareShowList(costShareParentId, $scope.costSharesMapping);
            $log.log('CostShareShowList=' + JSON.stringify(showList));
            angular.forEach($scope.productFieldsMetaData, function(item) {
                var found = false;
                if (item.type === 'slider') {
                    if (!item.parentId) { // copay and co-insurance
                        found = true;
                    } else { // moop and deductible
                        item.show = isNameExist(item.nameId, showList);
                        if (item.show) { // display the cost share
                            found = true;
                        } else { // hide the cost share and remove its splitted children if there's any
                            if (!$scope.costShares[item.nameId]) {
                                $scope.costShares[item.nameId] = {};
                            }
                            $scope.costShares[item.nameId].selected = false;
                        }
                    }
                    if (!found) {
                        item.show = false;
                    }
                }
            });
        }

        function getSelectedProducts(productObj) {
            var selectedProducts = [];
            angular.forEach(productObj, function(selected, productName) {
                if (selected) {
                    selectedProducts.push(productName);
                }
            });
            return selectedProducts;
        }
        $scope.saveFlag = true;
        $scope.createNew = function() {
            if ($scope.createProductForm.$dirty === true) {
                $scope.savewarningalert();
            } else {
                $state.go('home.ppm.product.edit.product-details', {
                    productId: ''
                });
                $state.go('home.ppm.product.edit.product-details.content', {
                    tabName: $scope.selectedTab
                });
                init();
            }


        };

        $scope.savewarningalert = function() {
            var dialogOptions = {
                templateUrl: 'views/product-plan-management/confirm-saveproduct-warning.html',
                size: 'md',
                controller: 'SaveProductWarningCtrl',
                backdrop: true
            };

            ModalDialogFactory.showDialog(dialogOptions)
                .then(
                    // For Yes response
                    function(result) {
                        if (result) {
                            $scope.toCreateNewcreateProductForm = true;
                            $scope.saveClick();
                        } else { // For No response
                            $scope.createProductForm.$setPristine();
                            $scope.createNew();

                        }
                    });
        };

        $scope.charRestrictRegex = function() {
            return /[\"<>\\\/\.\?\:\|\*]/g;
        };

        $scope.isUrlField = function(field) {
            if ((field.type === 'textInput') && (field.nameId.toString().toLowerCase().indexOf('link') !== -1 || field.nameId.toString().toLowerCase().indexOf('website') !== -1) && (field.nameId.toString().toLowerCase().indexOf('phone') === -1)) {
                return true;
            } else {
                return false;
            }
        };

        $scope.isTextField = function(field) {
            if ((field.type === 'textInput') && (field.nameId.toString().toLowerCase().indexOf('link') === -1 && field.nameId.toString().toLowerCase().indexOf('website') === -1 && field.nameId.toString().toLowerCase().indexOf('phone') === -1)) {
                return true;
            } else {
                return false;
            }
        };

        $scope.isPhoneField = function(field) {
            if ((field.type === 'textInput') && (field.nameId.toString().toLowerCase().indexOf('link') === -1 && field.nameId.toString().toLowerCase().indexOf('website') === -1 && field.nameId.toString().toLowerCase().indexOf('phone') !== -1)) {
                return true;
            } else {
                return false;
            }
        };

        init();

    });