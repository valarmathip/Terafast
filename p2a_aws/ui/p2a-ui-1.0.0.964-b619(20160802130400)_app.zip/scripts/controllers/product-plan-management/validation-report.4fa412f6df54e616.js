'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductListCtrl
 * @description
 * # ProductListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')

.controller('ValidationReportCtrl', function($scope, $modalInstance, position, validationResult, ENV) {
    $scope.debugMode = (ENV.name === 'local');
    $scope.position = position;
    $scope.vResult = validationResult;

    $scope.identity = angular.identity; // http://stackoverflow.com/questions/17936078/orderby-array-item-value-in-angular-ng-repeat

    $scope.panel = {
        oneAtATime: false,
        error: {
            open: true
        },
        warning: {
            open: true
        }
    };


    $scope.ok = function(event) {
        $modalInstance.close();
        event.stopPropagation();
    };
    $scope.cancel = function(event) {
        $modalInstance.dismiss('cancel');
        event.stopPropagation();
    };

    $scope.reposition = function(event, position) {
        $modalInstance.dismiss(position);
        event.stopPropagation();
    };

});