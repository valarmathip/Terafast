'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:PlanListCtrl
 * @description
 * # PlanListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')

.controller('PlanListCtrl', function($rootScope, $filter, $scope, uiGridConstants, ProductPlanMgmtSvc, /*jshint ignore: line*/
    $state, $timeout, ConfirmationModalFactory, ENV, ppmUtils, $stateParams, ProductPlanSearch, $log,
    dialogFactorySvc, plansFieldsMeta, plansAspectDefs, PPMFilterMetaSvc, FilterService, PaginationService,
    authorizedUserInfo, DatePickerFilterService, userAuthorizationManager, $auth, PlanLockSvc, QueryDialog,
    PlanListHoverMenuSvc, PpmPlanSummaryDialogSvc, PlanVersioningPageslideSvc) {
    $scope.debugMode = (ENV.name === 'local');
    $scope.searchQuery = $stateParams.searchquery;
    $scope.userInformation = authorizedUserInfo;

    $scope.tabUrl = {
        all: 'views/product-plan-management/template/plan-list/ui-grid.html',
        draft: '',
        override: ''
    };
    $scope.hideCustomReport = false;
    $scope.reportTemplateData = {};
    $scope.publishedUrl = '';
    var selectedTab = 'all';

    var pageSize = 20; // SLQ
    $scope.currentPage = {
        all: 1,
        draft: 1,
        override: 1
    };
    $scope.selectedPlans = [];
    $scope.selectedrows = [];
    $scope.selectAllChecker = false;
    $scope.selectChecker = false;
    $scope.checkList = {};
    $scope.currentPageSize = {};
    $scope.currentPageSize['all'] = $scope.currentPageSize['draft'] = $scope.currentPageSize['override'] = pageSize;
    /*
        Jira Id: DOGVT-193,
        Description: The below function is used for customized select and select all function trigger form grid cell.
        */
    var setOrResetCheckList = function(row) {
        $scope.checkList = PaginationService.setOrResetCheckList(row, $scope.checkList);
    };
    var setCheckList = function() {
        $scope.checkList = PaginationService.setCheckList($scope.gridApi, $scope.checkList);
    };
    var gridOptionsTpl = {
        'excessRows': 400, // SLQ need to more investigation
        //'scrollThreshold': 4,
        //"excessColumns": 4,
        enableSorting: true,
        // pagination
        enablePaginationControls: false,
        paginationPageSizes: ENV.settings.paginationPageSizes,
        paginationPageSize: pageSize,
        enableRowSelection: false,
        // scroll bar
        enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
        // height of row,Fixing DOGVT-196 QA- Height of the table row should be 105px.
        rowHeight: 110, // never put number in "", like "100"
        minRowsToShow: 6,
        rowTemplate: 'views/product-plan-management/template/plan-list/row.html',
        enableRowHeaderSelection: false,
        useExternalPagination: true,
        useExternalSorting: true
    };
    $scope.pageVal = {
        pageNumber: ''
    };
    var paginationOptions = {
        pageNumber: 1,
        pageSize: 20,
        sort: null
    };
    var preSearchQuery = null;

    gridOptionsTpl.onRegisterApi = function(gridApi) {
        $scope.gridApi = gridApi;
        $scope.gridApi.core.on.sortChanged($scope, function(grid, sortColumns) {
            if (sortColumns.length >= 0) {
                PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
            }
            loadData();
        });
        gridApi.pagination.on.paginationChanged($scope, function(newPage, pageSize) {
            paginationOptions.pageNumber = newPage;
            paginationOptions.pageSize = pageSize;
            loadData();
            if (!PaginationService.isGoToPageEnabled) {
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
            }
            PaginationService.setGoToPageEnabled(false);
        });

        $scope.gridApi.grid.registerDataChangeCallback(function(data) {
            data.selection.selectAll = false;
        }, [uiGridConstants.dataChange.ROW]);

        gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
        gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
    };

    $scope.selectall = true;
    gridOptionsTpl.columnDefs = [{
        displayName: '',
        name: 'X1',
        field: 'element1',
        width: 80,
        enableColumnMenu: false,
        enableHiding: false,
        enableSorting: false,
        headerCellTemplate: 'views/product-plan-management/template/plan-list/icon-col-header.html',
        cellTemplate: 'views/product-plan-management/template/plan-list/icon-col.html'
    }, {
        displayName: 'Plan Name',
        name: 'name',
        width: 387,
        field: 'name',
        enableColumnMenu: false,
        enableHiding: false,
        enableSorting: true,
        cellTemplate: 'views/product-plan-management/template/plan-list/name-col.html'
    }, {
        displayName: 'Due Date',
        name: 'planDueDate',
        width: 140,
        field: 'planDueDate',
        enableColumnMenu: false,
        enableHiding: false,
        enableSorting: true,
        cellTemplate: 'views/product-plan-management/template/plan-list/due-date-col.html'
    }, {
        displayName: 'Plan Family',
        field: 'element3',
        width: 120,
        enableColumnMenu: false,
        enableHiding: false,
        enableSorting: false,
        cellTemplate: 'views/product-plan-management/template/plan-list/plan-family-col.html'
    }, {
        displayName: 'Last modified',
        field: 'lastModificationDate',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        width: '15%',
        cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModificationDate | date:"MMM dd y hh:mma"}}</div>'
    }, {
        displayName: 'Modified By',
        field: 'lastModifiedBy',
        enableColumnMenu: false,
        enableColumnMenus: false,
        enableSorting: true,
        width: 187,
        cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.lastModifiedBy}}</div>'
    }];

    // $scope.loadedPlanList = []; // This variable is used to hold all palns when pagination/sort are take place at front end, and it should not be used by now, we will keep the planList only
    $scope.planList = [];
    $scope.gridOptions = gridOptionsTpl;
    $scope.gridOptions.data = 'planList';
    $scope.selectedPlans = [];

    // $scope.gridHeight = 2118;

    // $scope.$watch('gridOptions.totalItems', function() {
    //     var gridDiv = angular.element('div.ui-grid-viewport');

    //     if ($scope.gridHeight < gridDiv.height()) {
    //         $scope.gridHeight = gridDiv.height();
    //         $log.info('new $scope.gridHeight ' + $scope.gridHeight);
    //     }

    //     if ($scope.gridHeight > gridDiv.height()) {
    //         gridDiv.height($scope.gridHeight);
    //         $log.info('updated gridDiv.height ' + $scope.gridHeight);
    //     }

    // });

    /* Filter data and setting */
    $scope.filtersGroups = [];
    $scope.selectedFilters = {};

    var planProp = plansFieldsMeta[0].properties;
    var aspectDefProp = plansAspectDefs[0].properties;

    initializePlanArrays();

    $scope.navPage = function($event, delta) {
        PaginationService.navPage($event, delta, $scope.gridApi);
        $scope.currentPage[selectedTab] = $scope.gridApi.pagination.getPage();
        $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
    };
    /*
        Jira Id: DOGVT-193,
        Description: The below function used for check box selection functions.
        */
    /** Custom selection */
    $scope.toggleRowSelection = function(event, row) {
        $log.log('toggle the row selection');
        $scope.gridApi.selection.toggleRowSelection(row.entity);
        $scope.selectedrows = $scope.gridApi.selection.getSelectedRows();
        if (paginationOptions.pageSize === $scope.selectedrows.length) {
            $scope.gridApi.grid.selection.selectAll = true;
        }
        if (event.currentTarget.checked === true) {
            $scope.selectedPlans.push(row.entity);
        } else {
            for (var key in $scope.selectedPlans) {
                if ($scope.selectedPlans[key].objectId === row.entity.objectId) {
                    $scope.selectedPlans.splice(key, 1);
                }
            }
        }
    };

    $scope.toggleAllRowSelection = function(event) {
        var rows = $scope.gridApi.grid.rows;
        if (event.currentTarget.checked) {
            $scope.gridApi.selection.selectAllRows();
            if ($scope.selectedPlans.length === 0) {
                angular.forEach(rows, function(row) {
                    $scope.selectedPlans.push(row.entity);
                });
            } else {
                angular.forEach($scope.selectedPlans, function(item) {
                    angular.forEach(rows, function(row) {
                        if (item.entity.objectId !== row.entity.objectId) {
                            $scope.selectedPlans.push(row.entity);
                        }
                    });
                });
            }
        } else {
            $scope.gridApi.selection.clearSelectedRows();
            angular.forEach(rows, function(rowone) {
                angular.forEach($scope.selectedPlans, function(row) {
                    if (rowone.entity.objectId === row.objectId) {
                        $scope.selectedPlans.splice($scope.selectedPlans.indexOf(row), 1);
                    }
                });
            });
        }
    };
    /** End of Custom selection */

    $scope.viewPages = function() {
        var ps = [];
        ps = PaginationService.viewPages($scope.gridApi, ps);
        return ps;
    };

    $scope.tabSelected = function(tabName) {
        selectedTab = tabName;
        $scope.tabUrl[selectedTab] = 'views/product-plan-management/template/plan-list/ui-grid.html';

        if ($scope.currentPageSize[selectedTab]) {
            var num = $scope.currentPageSize[selectedTab];
            $scope.gridOptions.paginationPageSize = num;
        }
    };

    $scope.tabDeselected = function(tabName) {
        $scope.tabUrl[tabName] = '';
        $scope.planList = [];
    };

    $scope.pageSizeChanged = function(ps) {
        $scope.gridOptions.paginationCurrentPage = 1;
        $scope.currentPage[selectedTab] = 1;
        $scope.currentPageSize[selectedTab] = ps;
    };

    $scope.loaded = function() {
        if (!PaginationService.getSortColumns()) {
            PaginationService.setSortColumns(null);
        }
        loadData();
        //updateFilterMeta();
    };

    $scope.$on('$includeContentLoaded', function() {});

    $scope.queryData = function(selectedId, objs) {
        $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.gridOptions);
        $scope.currentPage[selectedTab] = 1;
        loadData();
    };

    $scope.doSearch = function(keyEvent) {
        if (keyEvent.which === 13) {
            //$scope.planYear = planYear;
            $scope.gridOptions.paginationCurrentPage = 1;
            $scope.currentPage[selectedTab] = 1;
            loadData();
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.gridApi, $scope.pageVal.pageNumber);
        }
    };

    $scope.goToPage = function(keyEvent, pageNumberObject) {
        PaginationService.goToPage(keyEvent, pageNumberObject.pageVal, $scope.gridApi);
        $scope.currentPage[selectedTab] = $scope.gridApi.pagination.getPage();
    };

    //filterId should be added on adding date widget to a filter
    $scope.datePicker = {
        fromDate: {
            lastModificationDate: [],
            planDueDate: [],
            effectiveDate: []
        },
        toDate: {
            lastModificationDate: [],
            planDueDate: [],
            effectiveDate: []
        }
    };

    $scope.attrYear = {
        field: ''
    };

    $scope.setDatePickerAttrId = function(rangeAttr) {
        $scope.selectedFilters = DatePickerFilterService.pushDatePickerAttr(rangeAttr, $scope.selectedFilters);
    };

    function getDatePickerValues() {
        var allDateCollection = [];
        var fromDateObjs = $scope.datePicker.fromDate;
        var toDateObjs = $scope.datePicker.toDate;
        allDateCollection = DatePickerFilterService.getAllDateCollection(allDateCollection, fromDateObjs, toDateObjs);
        return allDateCollection;
    }

    function getFilterParams() {
        var params = {};

        var curPage = ($scope.gridApi) ? $scope.gridApi.pagination.getPage() : 1;
        var planStatus = null;
        if (selectedTab === 'draft') {
            planStatus = 'Draft';
        } else if (selectedTab === 'override') {
            planStatus = 'Override';
        }

        var planName = $scope.planSearchQuery;
        var planYear = $scope.attrYear.field;

        var fromToDateCollection = getDatePickerValues();

        var startIndex = (curPage === 1) ? 0 : (curPage - 1) * $scope.gridOptions.paginationPageSize;
        var filterQuery = 'TYPE:"plan"';

        var isNOTRangeFilterValue = false;
        var filterIdClone;

        angular.forEach($scope.selectedFilters, function(filterValues, filterId) {
            var isFirstfilterValue = true;
            var isRangeExist = false;
            isNOTRangeFilterValue = false;
            filterIdClone = filterId;
            filterQuery += ' AND ';
            if (filterValues) {
                filterQuery += ' ( ';

                angular.forEach(filterValues, function(filterValue) {

                    if (filterValue.toString().toLowerCase() !== 'date range') {
                        filterValue = FilterService.calculateDate(filterValue);
                        filterValue = FilterService.calculateYear(filterValue);
                        filterValue = FilterService.calculateDay(filterValue);
                        filterValue = FilterService.calculateWeek(filterValue);

                        if (isFirstfilterValue) {
                            filterQuery = determineFilterQueryForSingleFilter(filterValue, isFirstfilterValue, filterId, filterQuery);
                            isFirstfilterValue = false;
                            isNOTRangeFilterValue = true;
                        } else {
                            filterQuery = determineFilterQueryForMultipleFilters(filterValue, isFirstfilterValue, filterId, filterQuery);
                            isNOTRangeFilterValue = true;
                        }
                    } else if (!isRangeExist) {
                        filterQuery = FilterService.getFilterQueryForRange(filterQuery, isNOTRangeFilterValue, filterIdClone, fromToDateCollection);
                        isRangeExist = true;
                        isFirstfilterValue = false;
                    }

                });
                filterQuery += ' ) ';
            }
        });
        if (planStatus) {
            filterQuery += ' AND planStatus:"' + planStatus + '" ';
        }
        if (planYear) {
            filterQuery += ' AND =planYear:"' + planYear + '" ';
        }
        filterQuery += FilterService.getSearchQueryForName(planName, $scope.matchCase, 'name');
        params.q = filterQuery;

        angular.extend(params, {
            associationExpansionLevel: 0,
            start: startIndex,
            rows: $scope.gridOptions.paginationPageSize
        });

        return angular.extend(params, PaginationService.getSortParam());
    }

    function getEncodedFilterQuery() {
        return '?' + ppmUtils.paramSerializer(getFilterParams());
    }

    function determineFilterQueryForSingleFilter(filterValue, isFirstfilterValue, filterId, filterQuery) {

        if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'lastModificationDate' || filterId === 'planDueDate') {
            filterQuery += filterId + ': ' + filterValue;
        } else if (filterId === 'lastModifiedBy' || filterId === 'createdBy') {
            filterValue = $scope.userInformation.data.user.email;
            filterQuery += filterId + ': "' + filterValue + '"';
        } else if (filterId === 'grandfatheredPlan' && filterValue === 'Yes') {
            filterValue = true;
            filterQuery += filterId + ': "' + filterValue + '"';
        } else if (filterId === 'grandfatheredPlan' && filterValue === 'No') {
            filterValue = false;
            filterQuery += filterId + ': "' + filterValue + '"';
        } else {
            filterQuery += filterId + ': "' + filterValue + '"';
        }

        return filterQuery;
    }


    function determineFilterQueryForMultipleFilters(filterValue, isFirstfilterValue, filterId, filterQuery) {
        if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'lastModificationDate' || filterId === 'planDueDate') {
            filterQuery += ' OR ' + filterId + ': ' + filterValue;
        } else if (filterId === 'lastModifiedBy' || filterId === 'createdBy') {
            filterValue = $scope.userInformation.data.user.email;
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
        } else if (filterId === 'grandfatheredPlan' && filterValue === 'Yes') {
            filterValue = true;
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
        } else if (filterId === 'grandfatheredPlan' && filterValue === 'No') {
            filterValue = false;
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
        } else {
            filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
        }

        return filterQuery;
    }

    function loadData() {
        if ($scope.searchQuery === undefined) {
            var currentSearchQuery = getEncodedFilterQuery();
            //Do not call API with same search query, which was in prvious API call
            if (currentSearchQuery && preSearchQuery && (currentSearchQuery.toString() === preSearchQuery.toString())) {
                return;
            }
            // Load data goes here
            preSearchQuery = currentSearchQuery;

            // currentSearchQuery cannot be encodeURI-ed, because some of its component is already encodeURIComponent-ed
            ProductPlanMgmtSvc.getPlanList(currentSearchQuery).then(function(data) {
                $scope.gridOptions.totalItems = data.response.numFound;
                $scope.planList = data.response.docs;
                $scope.count = 0;
                $timeout(function() {
                    angular.forEach($scope.checkList, function(value, key) {
                        angular.forEach($scope.planList, function(item) {
                            if (item.objectId === key && value === true) {
                                $scope.gridApi.selection.selectRow(item, true);
                                $scope.count++;
                            }
                        });
                    });
                    if ($scope.count !== 'undefined' && $scope.count === paginationOptions.pageSize) {
                        $scope.gridApi.selection.selectAllRows();
                    }
                });
                //updateFilterMeta();
            }).then(function() {
                // Need to find a event to reset the current page value; Do not like to use timer
                // Think about use $q again, because it is call in next loop
                $timeout(function() {
                    if ($scope.currentPage[selectedTab]) {
                        $scope.gridOptions.paginationCurrentPage = $scope.currentPage[selectedTab];
                    }
                }, 50);
            });
        } else { // This part is get called from plan-search.js, not sure it still be used by now
            //$scope.searchQuery = '/searchPlans?query='+$scope.searchQuery;
            ProductPlanSearch.getSearchList($scope.searchQuery).then(function(planList) {
                $scope.planList = planList;
            }).then(function() {
                // Need to find a event to reset the current page value; Do not like to use timer
                // Think about use $q again, because it is call in next loop
                $timeout(function() {
                    if ($scope.currentPage[selectedTab]) {
                        $scope.gridOptions.paginationCurrentPage = $scope.currentPage[selectedTab];
                    }
                }, 50);
            });
        }
    }

    function updatePlanStatusInViewList(planViewList, planId, status) {
        angular.forEach(planViewList, function(plan) {
            if (plan.objectId === planId) {
                plan.planStatus = status;
            }
        });
    }

    /*
     * format the JSON data in required format to post
     */
    $scope.formatDataToPost = function() {
        $scope.planDetails.name = $scope.planDetails.name + '_' + Date.now();
        $scope.planDetails.linkedProducts = [];
        $scope.planDetails.linkedProducts.push($scope.planDetails.planPrimaryProductId);
        if ($scope.planDetails.applicableCoverageTiers === null) {
            $scope.planDetails.applicableCoverageTiers = [];
        }
        //PONVT-945(Should reset plan cost share name & service name in order to generate plan from plan)
        if ($scope.planDetails.planCostShares !== null && $scope.planDetails.planCostShares !== undefined) {
            angular.forEach($scope.planDetails.planCostShares, function(costShare) {
                delete costShare.name;
            });
        }
        if ($scope.planDetails.linkedPlanServices !== null && $scope.planDetails.linkedPlanServices !== undefined) {
            $scope.planDetails.linkedPlanServices = resetPlanServices($scope.planDetails.linkedPlanServices);
        }
    };

    function resetPlanServices(linkedPlanServices) {
        var updatedLinkedPlanServices = linkedPlanServices;
        angular.forEach(updatedLinkedPlanServices, function(planService) {
            delete planService.name;
            if (planService.planserviceCostShares !== null && planService.planserviceCostShares !== undefined) {
                angular.forEach(planService.planserviceCostShares, function(planserviceCostShare) {
                    delete planserviceCostShare.name;

                });
            }

        });
        return updatedLinkedPlanServices;
    }


    function initializePlanArrays() {
        var initArr = PPMFilterMetaSvc.initializeArr();
        $scope.filtersGroups = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, planProp, aspectDefProp);
    }

    // hover menu
    function findPlanFromPlanListById(planId) {
        for (var i = 0; i < $scope.planList.length; i++) {
            if (planId === $scope.planList[i].objectId) {
                return $scope.planList[i];
            }
        }

        return null;
    }

    function refreshLockStatus(lockStatus, planId) {
        var plan = findPlanFromPlanListById(planId);
        if (plan) {
            if (lockStatus === null) {
                delete plan.isLocked; // = undefined;
                delete plan.lockedBy; // = undefined;
                delete plan.lockedAt; // = undefined;

            } else {
                plan.isLocked = lockStatus.isLocked;
                plan.lockedBy = lockStatus.lockedBy;
                plan.lockedAt = lockStatus.lockedAt; // This could be a little difference between backend really lock time
            }
        }
    }

    $scope.$on('ppm.plan.list.hover.menu.lock.status.changed', function(event, lockStatus, planId) {
        event.stopPropagation();
        refreshLockStatus(lockStatus, planId);
    });

    $scope.$on('ppm.plan.list.hover.menu.plan.status.changed', function(event, planId, status) {
        event.stopPropagation();
        updatePlanStatusInViewList($scope.planList, planId, status);
    });

    $scope.hoverItems = PlanListHoverMenuSvc.getHoverMenu($scope);
    // end of hover menu

    // DOGHR-999, pending for another issue, save for later
    $scope.showPlanSummaryDialog = PpmPlanSummaryDialogSvc.showPlanSummaryDialog;

    $scope.clearAll = function() {
        $rootScope.$broadcast('clearAllSelected');
    };

    // Calendar function
    $scope.openCalendar = function($event, $index, effectiveDate) {
        $scope.calendarOpened = {};
        $event.preventDefault();
        $event.stopPropagation();

        if (!$scope.calendarOpened[effectiveDate]) {
            $scope.calendarOpened[effectiveDate] = [];
        }

        $scope.calendarOpened[effectiveDate][$index] = true;
    };

    // Disable weekend selection
    $scope.disabled = function(date, mode) {
        return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));

    };

    $scope.dateOptions = {
        showWeeks: false
    };
    // End of Calendar function

    $scope.getSelectedChecks = function(checkList) {
        var selectedChecks = [];
        angular.forEach(checkList, function(checkValue, planId) {
            if (checkValue) {
                selectedChecks.push(planId);
            }
        });
        return selectedChecks;
    }; // End of Calendar function

    $scope.generateReport = function() {
        var dlgUrl = 'views/product-plan-management/generate-report.html';
        var controller = 'GenerateReportCtrl';
        var data = {
            selectedPlanIds: function() {
                return $scope.getSelectedChecks($scope.checkList);
            },
            reportTemplatesList: function() {
                return $scope.reportTemplateData;
            }
        };

        var options = {
            size: 'lg'
        };
        dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
    };

    $scope.planCompare = function() {
        var dlgUrl = 'views/product-plan-management/plan-comparison.html';
        var controller = 'PlanCompareCtrl';
        var data = {
            selectedPlans: function() {
                return $scope.selectedPlans;
            },
            reportTemplatesList: function() {
                return $scope.reportTemplateData;
            }
        };

        var options = {
            size: 'lg'
        };
        dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
    };
    $scope.removeCustomReport = function() {
        ProductPlanMgmtSvc.getReportTemplates().then(function(data) {
            $scope.reportTemplateData = data;
            if (data.length === 1) {
                $scope.hideCustomReport = true;
            }
        });
    };
    $scope.removeCustomReport();

    $scope.showPlanVersioningHistory = function(plan) {
        ProductPlanMgmtSvc.getPlanVersionHistory(plan.objectId).then(function(data) {
            var result = {};
            result.versionHistory = data;
            result.plan = plan;
            angular.forEach(data, function(value) {
                if (value.latest === 'true') {
                    result.latestVersion = value['version-id'];
                }
            });

            PlanVersioningPageslideSvc.openPageslide('left', result, $scope);
        });
    };

}); // End of controller