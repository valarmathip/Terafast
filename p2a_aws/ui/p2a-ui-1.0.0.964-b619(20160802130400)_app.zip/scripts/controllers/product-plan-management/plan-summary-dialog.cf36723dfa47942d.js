'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:PlanSummaryDialogCtrl
 * @description
 * # PlanSummaryDialogCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('PlanSummaryDialogCtrl', function($filter, $scope, $modalInstance, ProductPlanMgmtSvc, planDetails, planDetailFieldsMetaData,
        planServiceFieldsMetaData, $timeout, ENV) {

        function init() {
            $scope.debugMode = (ENV.name === 'local');

            $scope.tabUrl = {
                service: 'views/product-plan-management/template/plan-summary/service-details.html',
                plan: 'views/product-plan-management/template/plan-summary/plan-properties.html'
            };
            // plan properties related
            $scope.planMetaData = planDetailFieldsMetaData.productFieldsMetaData.concat(planDetailFieldsMetaData.planFieldsMetaData);
            $scope.planServiceMetaData = planServiceFieldsMetaData.attributes;
            $scope.transformedPlanMetaData = [];
            $scope.hasPlanUDF = false;
            $scope.transformedPlanDetails = transformPlanProperties(planDetails, $scope.transformedPlanMetaData);
            $scope.planDetailsArray = [planDetails];
            // service related
            $scope.noncategorizedServiceList = [];
            $scope.categorizedServiceList = [];
            $scope.serviceList = {};
            $scope.isexpandAll = false;
            $scope.isunCoveredexpandAll = false;
            $scope.coveredSortDirection = true;
            $scope.noncoveredSortDirection = true;
            $scope.coveredSortColumn = '';
            $scope.coveredPreSortColumn = '';
            $scope.nonCoveredSortColumn = '';
            $scope.nonCoveredPreSortColumn = '';

            transformPlanServiceData();

            $scope.loadedServiceList = [];
            $scope.selectedServiceList = [];
            $scope.subList = {};

            $scope.loadedNoncategorizedServiceList = $scope.noncategorizedServiceList;
            $scope.loadedServiceList = $scope.categorizedServiceList;

            $scope.statusHolder = {
                coveredStatus: {
                    open: true
                },
                nonCoveredStatus: {
                    open: true
                },
                coveredPanelstatus: {
                    open: new Array($scope.loadedServiceList.length)
                },
                nonCoveredPanelstatus: {
                    open: new Array($scope.loadedNoncategorizedServiceList.length)
                }
            };

            initializePanelCollapse('coveredPanelstatus', false);
            initializePanelCollapse('nonCoveredPanelstatus', false);

            loadSummaryData();
        }
        init();

        var selectedTab = 'plan';

        $scope.tabSelected = function(tabName) {
            selectedTab = tabName;
        };

        function transformPlanProperties(plan, newMetaData) {
            var result = {};
            result.planStatus = plan.planStatus;
            // result.lastModificationDate = plan.lastModificationDate;
            result.creationDate = plan.creationDate;
            result.lastModifiedBy = plan.lastModifiedBy;


            var found = false;
            // all plan properties, but not including global cost shares
            angular.forEach($scope.planMetaData, function(metaDataField) {
                found = false;
                // check if there's any plan udf field
                if (!$scope.hasPlanUDF && (metaDataField.nameId.indexOf('udfplan_') !== -1) && plan.hasOwnProperty(metaDataField.nameId)) {
                    $scope.hasPlanUDF = true;
                }
                // effective dates excluded from plan properties tab, moved to the top instead
                if (metaDataField.nameId === 'effectiveDates') {
                    found = false;
                    angular.forEach(metaDataField.options, function(option) {
                        result[option.optionNameId] = plan[option.optionNameId];
                    });
                }
                // global cost shares
                if (metaDataField.type === 'slider') {
                    var csInfo = {
                        'split': {}
                    };
                    angular.forEach(plan.planCostShares, function(globalcostshare) {
                        if (metaDataField.displayName === globalcostshare.costShareType) {
                            found = true;
                            if (globalcostshare.providerTier === 'NA') {
                                if (globalcostshare.costShareType === 'Co-insurance') {
                                    csInfo.globalValue = globalcostshare.selectedValue + globalcostshare.format;
                                } else {
                                    csInfo.globalValue = globalcostshare.format + globalcostshare.selectedValue;
                                }
                            } else { // split cost shares
                                if (globalcostshare.costShareType === 'Co-insurance') {
                                    csInfo.split[globalcostshare.providerTier] = globalcostshare.selectedValue + globalcostshare.format;
                                } else {
                                    csInfo.split[globalcostshare.providerTier] = globalcostshare.format + globalcostshare.selectedValue;
                                }
                            }
                        }
                    });
                    if (found) {
                        result[metaDataField.nameId] = csInfo;
                    }
                }
                // product tiers
                if (metaDataField.type == 'tiers') {
                    found = true;
                    result[metaDataField.nameId] = plan.providerTierDisplayNames.join(', ');
                }
                // other plan properties
                angular.forEach(plan, function(planValue, planKey) {
                    if ((planKey === metaDataField.nameId) && (planValue !== '')) {
                        found = true;
                        if (angular.isArray(planValue)) {
                            result[planKey] = planValue.join(', ');
                        } else {
                            if (metaDataField.type === 'radioButton') {
                                if (planValue === true) {
                                    result[planKey] = 'Yes';
                                } else if (planValue === false) {
                                    result[planKey] = 'No';
                                } else {
                                    result[planKey] = planValue;
                                }
                            } else {
                                result[planKey] = planValue;
                            }
                        }
                    }

                });
                // only push the metadata whose value has been set in plan
                if (found) {
                    newMetaData.push(metaDataField);
                }
            });

            return result;
        }

        function transformPlanServiceData() {
            angular.forEach(planDetails.linkedPlanServices, function(serviceSummary) {
                if ((serviceSummary.linkedService).length > 0) {
                    $scope.serviceList[serviceSummary.linkedService[0].objectId] = [{
                        'costShare': serviceSummary.planserviceCostShares,
                        'showUDF': false,
                        'udf': {},
                        'showProperty': false,
                        'property': {}
                    }];
                    // plan service property
                    var propList = ['isCarvedOut', 'vendorName', 'vendorPhone', 'vendorWebsite'];
                    angular.forEach(propList, function(prop) {
                        if (serviceSummary.hasOwnProperty(prop)) {
                            if (prop === 'isCarvedOut') {
                                if (serviceSummary[prop]) {
                                    $scope.serviceList[serviceSummary.linkedService[0].objectId][0]['property'][prop] = 'Yes';
                                    $scope.serviceList[serviceSummary.linkedService[0].objectId][0].showProperty = true;
                                }
                            } else {
                                if (serviceSummary[prop] !== '') {
                                    $scope.serviceList[serviceSummary.linkedService[0].objectId][0]['property'][prop] = serviceSummary[prop];
                                    $scope.serviceList[serviceSummary.linkedService[0].objectId][0].showProperty = true;
                                }
                            }

                        }
                    });
                    // plan service udf
                    angular.forEach(serviceSummary, function(item, key) {
                        if ((key.indexOf('udfplanservice_') !== -1) && (item !== '')) {
                            if (item === true) {
                                item = 'Yes';
                            } else if (item === false) {
                                item = 'No';
                            }
                            var displayName = getDisplayName(key, $scope.planServiceMetaData);
                            $scope.serviceList[serviceSummary.linkedService[0].objectId][0]['udf'][displayName] = item;
                            $scope.serviceList[serviceSummary.linkedService[0].objectId][0].showUDF = true;
                        }
                    });
                    if (serviceSummary.isServiceCovered) {
                        $scope.categorizedServiceList.push(serviceSummary.linkedService[0]);
                    } else {
                        $scope.noncategorizedServiceList.push(serviceSummary.linkedService[0]);
                    }
                }
            });
        }

        function getDisplayName(nameId, metadata) {
            var result = '';
            angular.forEach(metadata, function(item) {
                if (nameId === item.nameId) {
                    result = item.displayName;
                }
            });
            return result;
        }

        $scope.close = function() {
            $modalInstance.dismiss('cancel');
        };

        function initializePanelCollapse(panelStatus, bool) {
            for (var i = 0; i < $scope.statusHolder[panelStatus].open.length; i++) {
                $scope.statusHolder[panelStatus].open[i] = bool;
            }
        }

        $scope.toggleOpen = function(statusType, panelStatus, idx) {
            $scope.statusHolder[panelStatus].open[idx] = !$scope.statusHolder[panelStatus].open[idx];
            //$scope.statusHolder[statusType].open = !$scope.statusHolder[panelStatus].open[idx];
            $scope.statusHolder[statusType].open = $scope.checkAllPanelStatus(panelStatus);
        };

        $scope.expandOrCollapseAll = function(statusType, panelStatus) {
            $scope.statusHolder[statusType].open = !$scope.statusHolder[statusType].open;
            initializePanelCollapse(panelStatus, !$scope.statusHolder[statusType].open);
        };
        $scope.sortCoveredService = function(columnName, $event) {
            if ($scope.coveredSortColumn === $scope.coveredPreSortColumn) {
                $scope.coveredSortDirection = !$scope.coveredSortDirection;
            } else {
                $scope.coveredSortDirection = true;
            }
            $scope.coveredSortColumn = columnName;
            $scope.loadedServiceList = $filter('orderBy')($scope.loadedServiceList, ($scope.coveredSortDirection) ? '-' + $scope.coveredSortColumn : '+' + $scope.coveredSortColumn);
            $scope.coveredPreSortColumn = $scope.coveredSortColumn;
            $event.currentTarget.parentNode.childNodes[1].childNodes[2].className = 'ui-grid-invisible';
            $event.currentTarget.parentNode.childNodes[2].childNodes[2].className = 'ui-grid-invisible';
            $event.currentTarget.parentNode.childNodes[3].childNodes[2].className = 'ui-grid-invisible';
            $event.currentTarget.parentNode.childNodes[4].childNodes[2].className = 'ui-grid-invisible';
            if ($scope.coveredSortDirection) {
                $event.currentTarget.lastChild.className = 'ui-grid-icon-down-dir';
            } else {
                $event.currentTarget.lastChild.className = 'ui-grid-icon-up-dir';
            }
        };
        $scope.sortNonCoveredService = function(columnName, $event) {

            if ($scope.nonCoveredSortColumn === $scope.nonCoveredSortColumn) {
                $scope.noncoveredSortDirection = !$scope.noncoveredSortDirection;
            } else {
                $scope.noncoveredSortDirection = true;
            }
            $scope.nonCoveredSortColumn = columnName;
            $scope.loadedNoncategorizedServiceList = $filter('orderBy')($scope.loadedNoncategorizedServiceList, ($scope.noncoveredSortDirection) ? '-' + $scope.nonCoveredSortColumn : '+' + $scope.nonCoveredSortColumn);
            $scope.nonCoveredPreSortColumn = $scope.nonCoveredSortColumn;
            $event.currentTarget.parentNode.childNodes[1].childNodes[2].className = 'ui-grid-invisible';
            $event.currentTarget.parentNode.childNodes[2].childNodes[2].className = 'ui-grid-invisible';
            $event.currentTarget.parentNode.childNodes[3].childNodes[2].className = 'ui-grid-invisible';
            $event.currentTarget.parentNode.childNodes[4].childNodes[2].className = 'ui-grid-invisible';
            if ($scope.noncoveredSortDirection) {
                $event.currentTarget.lastChild.className = 'ui-grid-icon-down-dir';
            } else {
                $event.currentTarget.lastChild.className = 'ui-grid-icon-up-dir';
            }
        };

        $scope.checkAllPanelStatus = function(panelStatus) {
            var isPanelStatusFalsy = false;
            for (var panel = 0; panel < $scope.statusHolder[panelStatus].open.length; panel++) {
                if (!$scope.statusHolder[panelStatus].open[panel]) {
                    isPanelStatusFalsy = true;
                    break;
                }
            }
            return isPanelStatusFalsy;
        };

        function loadSummaryData() {
            angular.forEach($scope.loadedServiceList, function(serviceSummary) {
                $scope.subList[serviceSummary.serviceName] = serviceSummary.Others;
            });
        }

        /* Below code needs to placed at the end of controller to apply directive 'ppm-line-text' css styles on this dialog */
        $timeout(function() {
            $(window).resize();
        });
    }).filter('format', function() {

        return function(str) {
            if (str.match('%')) {
                var x = str.split('%').join('');
                return x + '%';
            } else {
                return str;
            }
        };
    });