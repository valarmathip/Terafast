'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:PlanVersioningHistoryPageslideCtrl
 * @description
 * # PlanVersioningHistoryPageslideCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('PlanVersioningHistoryPageslideCtrl', function($scope, $q, $compile, $templateCache, $filter, ENV, $timeout,
        $state, userAuthorizationManager, $log) {
        $scope.debugMode = (ENV.name === 'local');
        $scope.position = 'right';
        $scope.vResult = null;

        $scope.isPageslideShown = false;

        $scope.identity = angular.identity; // http://stackoverflow.com/questions/17936078/orderby-array-item-value-in-angular-ng-repeat

        var pageSlideCompiledElt;

        /**
         Hover Menu setting
         */
        function hasUpdatePlanPermission(plan) {
            var itemShow = userAuthorizationManager.hasPermission('all.update'); // super user
            itemShow = itemShow || userAuthorizationManager.hasPermissionWithCriteria('plan.update', plan);
            itemShow = itemShow || userAuthorizationManager.hasPermissionWithCriteria('plan.update.custom', plan); // has plan status update permissions

            return itemShow;
        }

        function generatePlanDocuments(planId, versionId) {
            $state.go('home.media-management.generateDocumentByDataSourceId', {
                businessEntity: 'plan',
                dataSourceId: planId + '-' + versionId
            });
        }

        $scope.pageSlideHoverItems = [{ // index: 0
            label: 'Make this current version',
            // icon: 'fa-code-fork',
            isShown: function(context) {
                var isLatest = angular.fromJson(context.verInfo.latest); // verInfo.latest is a string, not boolean value
                return !isLatest && hasUpdatePlanPermission(context.plan);
            },
            action: function( /*row*/ ) {
                // currently do nothing
            }
        }, { // index: 1
            label: 'Generate documents',
            // icon: 'fa-code-fork',
            isShown: function( /*context*/ ) {
                return true;
            },
            action: function(context) {
                generatePlanDocuments(context.plan.objectId, context.verInfo['version-id']);
            },
            permission: '|all.create,|document.create'
        }, { // index: 2
            label: 'Add to an existing offering',
            // icon: 'fa-code-fork',
            isShown: function( /*row*/ ) {
                return true;
            },
            action: function( /*row*/ ) {
                // currently do nothing
            },
            permission: '|all.update,|offering.update'
        }, { // index: 3
            label: 'Add to new offering',
            // icon: 'fa-code-fork',
            isShown: function( /*row*/ ) {
                return true;
            },
            action: function( /*row*/ ) {
                // currently do nothing
            },
            permission: '|all.create,|offering.create'
        }];
        /* end of hover menu setting */

        $scope.showOptions = {
            'showAll': false,
            'versions': true,
            'documentsGenerated': false,
            'accountsSoldTo': false,
            'accountsProposedTo': false
        };
		
		$scope.selectedVersionList = {};

		function loadData() {
			$scope.selectedVersionList = {};
			angular.forEach($scope.vResult.versionHistory, function(item) {
				var versionId = item['version-id'];
				$scope.selectedVersionList[versionId] = false;
			});
			console.log('>>>>>>>>>>>>>>>' + JSON.stringify($scope.selectedVersionList));
		}

		$scope.selectedVesionChanged = function(versionId) {
			console.log('>>>>>>>>>>>>>>>' + versionId + '-' + JSON.stringify($scope.selectedVersionList));    
		};

        // return promise
		$scope.open = function() {
			$scope.defer = $q.defer();

			compilePageslideAndShow();
			loadData();
			return $scope.defer.promise;
		};

        $scope.ok = function(event) {
            event.stopPropagation();
            cleanManualThing();
            close();
            $scope.defer.resolve('close');
        };

        $scope.cancel = function(event) {
            event.stopPropagation();
            cleanManualThing();
            close();
            $scope.defer.reject('dismiss');
        };

        function cleanManualThing() {
            $scope.manualScope.$destroy();
            $scope.manualElement.remove();
        }

        function close() {
            $scope.isPageslideShown = false;
            $timeout(function() {
                removeOldSlideElement();
            }, 250);
        }

        $scope.reposition = function(event, position) {
            event.stopPropagation();
            $scope.isPageslideShown = false;
            $scope.position = position;
            compilePageslideAndShow();
        };

        // When context scope is destroyed, all is descendant will be destroyed, and this event will be triggered
        $scope.$on('$destroy', function() {
            close();
            $scope.manualElement.remove(); // note scope destroy is already triggered
        });

        function removeOldSlideElement() {
            var oldPageslideElement = angular.element('div.ng-pageslide'); // please note that this element attached scope is root scope but it sub-element attached scope is the desendant of this controller's scope
            if (oldPageslideElement.length) {
                if (pageSlideCompiledElt) {
                    pageSlideCompiledElt.remove();
                }
                oldPageslideElement.remove();
            }
        }

        function compilePageslideAndShow() {
            $log.log('compilePageslideAndShow');
            removeOldSlideElement();

            var pageslideTmpl = $templateCache.get('views/product-plan-management/plan-versioning-history.html');

            pageSlideCompiledElt = $compile(pageslideTmpl)($scope);

            $timeout(function() {
                var divElt = angular.element('div.ng-pageslide');
                divElt.css({
                    'overflow-y': 'auto'
                });
                $scope.isPageslideShown = true;
            }, 100);
        }

        $scope.showAll = function() {
            if ($scope.showOptions.showAll) {
                $scope.showOptions.versions = true;
                $scope.showOptions.documentsGenerated = true;
                $scope.showOptions.accountsSoldTo = true;
                $scope.showOptions.accountsProposedTo = true;

            } else {
                $scope.showOptions.versions = false;
                $scope.showOptions.documentsGenerated = false;
                $scope.showOptions.accountsSoldTo = false;
                $scope.showOptions.accountsProposedTo = false;
            }
        };
        $scope.showVersions = function() {
            console.log('>>>>>>showVersions');
            setShowAll();
        };
        $scope.showDocumentsGenerated = function() {
            console.log('>>>>>>showDocumentsGenerated');
            setShowAll();
        };
        $scope.showAccountsSoldTo = function() {
            console.log('>>>>>>showAccountsSoldTo');
            setShowAll();
        };
        $scope.showAccountsProposedTo = function() {
            console.log('>>>>>>showAccountsProposedTo');
            setShowAll();
        };

        function setShowAll() {
            if ($scope.showOptions.versions && $scope.showOptions.documentsGenerated &&
                $scope.showOptions.accountsSoldTo && $scope.showOptions.accountsProposedTo) {
                $scope.showOptions.showAll = true;
            } else {
                $scope.showOptions.showAll = false;
            }
        }

    });
