'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductSearchCtrl
 * @description
 * # ProductSearchCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
   .controller('ProductSearchCtrl',  function($filter,$scope,$log,$http,productDetailFieldsMetaData,ENV,ProductPlanSearch,ProductPlanMgmtSvc,$state){
	$scope.statusList=['Published','Approved'];
	$scope.debugMode = (ENV.name === 'development');
    $scope.productDetails = {};
	$scope.searchQuery = '';
	$scope.productSearchResult = [];
	angular.element('#planNavBar').addClass('active-bar');
    // Status of opened calendar, internal use only
    $scope.calendarOpened = {};
    // Calendar function
    $scope.openCalendar = function($event, $index, nameId) {
		$event.preventDefault();
		$event.stopPropagation();
		if (!$scope.calendarOpened[nameId]) {
			$scope.calendarOpened[nameId] = [];
		}
		$scope.calendarOpened[nameId][$index] = true;
	};
	// Disable weekend selection
	$scope.disabled = function(date, mode) {
		return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
	};
	$scope.dateOptions = {
		showWeeks: false
	};
	// End of Calendar function
	$scope.fieldsMetaData = productDetailFieldsMetaData;
	$scope.init = function(data) {
		$scope.productDetails = data;
		setupModel();
	};
	$scope.init({});
	$scope.saveClick = function() {
		//$scope.dataConverted = $scope.transformOutput();
		$scope.searchQuery = $scope.transformStringOutput();
		if($scope.searchQuery !== ''){
			$scope.searchQuery = 'TYPE:"product" AND ' + $scope.searchQuery;
		}else{
			$scope.searchQuery = 'TYPE:"product"';
		}		
		$log.log('search query:'+ $scope.searchQuery);
		$state.go('home.ppm.product.product-list-search',{'searchquery':$scope.searchQuery});
	};
	
	$scope.transformStringOutput = function() {
		var StringDataSet = '';
		var itemTypeMap={};
		angular.forEach($scope.fieldsMetaData, function(field) {
			itemTypeMap[field.nameId] = field.type;
		});
		angular.forEach($scope.productDetails, function(value, attribute) {
			var querySegment  = getQuerySegment(value, attribute,itemTypeMap[attribute]);
			if(querySegment !== ''){
				if(StringDataSet === ''){
					StringDataSet = querySegment;
				}else{
					StringDataSet = StringDataSet+' AND '+querySegment;
				}
			}
		});
		return StringDataSet;
	};
	$scope.CheckBoxFields = function(value,attribute,tempQuery){
		var singleValue = true;
		tempQuery = '';
		angular.forEach(value, function(isChecked, optionValue) {
			if (isChecked) {
				if(tempQuery !== ''){
					tempQuery = tempQuery+' OR '+attribute+':"'+optionValue+'"';
					singleValue = false;
				}else if(optionValue !== '' && optionValue !== null){
					tempQuery = attribute+':"'+optionValue+'"';
				}
			}
		});
		if(singleValue){
			return tempQuery;
		}		
		return '('+tempQuery+')';
	};
	$scope.dateRangeFields = function(value,attribute,tempQuery){
		var tempDateRange = '';
		tempQuery = '';
		var notCorrectDate = false;
		angular.forEach(value, function(selectedDate) {
			if(selectedDate !== undefined && selectedDate!=null && selectedDate !== '' && tempDateRange !== ''){
				tempDateRange = tempDateRange + ' TO "'+$filter('date')(selectedDate, 'yyyy-MM-dd')+'"';
				notCorrectDate = true;
			}else if(selectedDate !== undefined && selectedDate !== '' && selectedDate!=null){
				tempDateRange = '"'+$filter('date')(selectedDate, 'yyyy-MM-dd')+'"';
			}
		});
		if(tempDateRange !== '' && tempDateRange!== null && tempDateRange!=='"null" TO "null"' && notCorrectDate){
			tempQuery = attribute+': ['+tempDateRange+']';
			return tempQuery;
		}
		return tempQuery;
	};
	$scope.dropdownFields = function(value,attribute,tempQuery){
		value = value+'';
		tempQuery = '';
		var singleValue = true;
		var tempVal = value.split(',');
		angular.forEach(tempVal, function(item3) {
			if(tempQuery !== ''){
				tempQuery = tempQuery+' OR '+attribute+':"'+item3+'"';
				singleValue = false;
			}else if(item3 !== '[object Object]' && item3 !== ''){
				tempQuery = attribute+':"'+item3+'"';
			}
		}); 
		if(singleValue){
			return tempQuery;
		}		
		return '('+tempQuery+')';
	};
	$scope.dateFields = function(value,attribute,tempQuery){
		tempQuery = '';
		if( value !== undefined && value !== '' && value !== null){
			tempQuery = attribute+': "'+$filter('date')(value, 'yyyy-MM-dd')+'"';
		}
		return tempQuery;
	};
	$scope.defaultFields = function(value,attribute,tempQuery){
		tempQuery = '';
		if(attribute ==='productTiers' && value.tiersNumber !== '' && value.tiersNumber !== undefined){
			tempQuery = attribute+': "'+value.tiersNumber+'"';	
		}else if(value!==null && value !== '' && JSON.stringify(value)!=='{}' && (attribute !=='productTiers')){
			tempQuery = attribute+': "'+value+'"';
		}
		return tempQuery;
	};
	$scope.radioFields = function(value,attribute,tempQuery){
		tempQuery = '';
		if(value !== null && value !== ''){
			tempQuery = attribute+': "'+value+'"';
		}
		return tempQuery;
	};
	function getQuerySegment(value, attribute, type){
		var tempQuery = '';
		switch(type){
			case 'text':
			case 'checkbox':
				tempQuery = $scope.CheckBoxFields(value,attribute,tempQuery);
				break;
			case 'dateRange':
				tempQuery = $scope.dateRangeFields(value,attribute,tempQuery);
				break;
			case 'date':
				tempQuery = $scope.dateFields(value,attribute,tempQuery);
				break;
			case 'ties':
			case 'radio':	
				tempQuery = $scope.radioFields(value,attribute,tempQuery);
				break;
			case 'dropdown':
				tempQuery = $scope.dropdownFields(value,attribute,tempQuery);
				break;
			default :
				tempQuery = $scope.defaultFields(value,attribute,tempQuery);
				break;
		}
		return tempQuery;
	}
	// private function
	function setupModel() {
		angular.forEach($scope.fieldsMetaData, function(item) { // fieldsMetaData is array, and value is object
			if (!item.multiple) {
				if (!$scope.productDetails[item.nameId]) {
					$scope.productDetails[item.nameId] = '';
				}
			} else {
				if (!$scope.productDetails[item.nameId]) {
					$scope.productDetails[item.nameId] = {};
				}
			}
		});
	}
});