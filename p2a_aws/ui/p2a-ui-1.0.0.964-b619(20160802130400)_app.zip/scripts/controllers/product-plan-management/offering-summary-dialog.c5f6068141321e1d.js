'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:OfferingSummaryDialogCtrl
 * @description
 * # OfferingSummaryDialogCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('OfferingSummaryDialogCtrl', function($scope, $modalInstance, offeringDetailFieldsMetaData, offeringDetails, uiGridConstants) {

        $scope.offeringFieldsMetaData = offeringDetailFieldsMetaData.offeringFieldsMetaData;
        $scope.offeringPlanRiderList = angular.copy(offeringDetails.offeringplans);
        $scope.offeringDetails = transferInput(offeringDetails);

        $scope.close = function() {
            $modalInstance.dismiss('cancel');
        };

        function transferInput(data) {
            var result = {};

            angular.forEach(data, function(value, key) {
                var found = false;
                angular.forEach($scope.offeringFieldsMetaData, function(metadata) {
                    if (metadata.nameId === key) {
                        found = true;
                        if (angular.isArray(value)) {
                            result[key] = value.join(', ');
                        } else if (metadata.type === 'radioButton') {
                            if (value === true) {
                                result[key] = 'Yes';
                            } else if (value === false) {
                                result[key] = 'No';
                            } else {
                                result[key] = value;
                            }
                        } else {
                            result[key] = value;
                        }
                    }
                });
                if (!found) {
                    result[key] = value;
                }

            });
            return result;
        }

        function addOrderIdToPlanList() {
            angular.forEach($scope.offeringPlanRiderList, function(value, key) {
                value.orderId = key + 1;
            });
        }

        function loadData() {
            addOrderIdToPlanList();
        }

        loadData();

        /////////////////////////////////////////////////////////////////////////////////
        // Plan/Rider UI Grid
        /////////////////////////////////////////////////////////////////////////////////
        $scope.gridOptions = {
            'excessRows': 400, // SLQ need to more investigation
            enableSorting: true,
            enableRowSelection: false,
            // scroll bar
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
            // height of row
            rowHeight: 105, // never put number in "", like "100"
            minRowsToShow: 6,
            rowTemplate: 'views/product-plan-management/template/offering-summary/row.html',
            enableRowHeaderSelection: false // disable the head selection
        };

        $scope.gridOptions.columnDefs = [{
            displayName: 'Order',
            name: 'order',
            field: 'order',
            width: '5%',
            minWidth: 90,
            maxWidth: 90,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/offering-summary/order-col.html'
        }, {
            displayName: 'Plan/Rider Name',
            name: 'name',
            field: 'name',
            width: '65%', // I know the total percentage is less than 100% (95% exactly)
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: true,
            cellTemplate: 'views/product-plan-management/template/offering-summary/name-col.html'
        }, {
            displayName: 'Source Type',
            field: 'sourcetype',
            width: '10%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/offering-summary/source-type-col.html'
        }, {
            displayName: 'Version',
            field: 'version',
            width: '10%',
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/offering-summary/version-col.html'
        }, {
            displayName: '',
            field: 'element2', // filed property is requred, but element2 dose not exist.
            width: '5%',
            maxWidth: 35,
            minWidth: 35,
            enableColumnMenu: false,
            enableColumnMenus: false,
            enableSorting: false,
            cellTemplate: 'views/product-plan-management/template/offering-summary/plan-type-col.html'
        }];

        $scope.gridOptions.data = 'offeringPlanRiderList';

        $scope.gridOptions.onRegisterApi = function(gridApi) {
            $scope.gridApi = gridApi;
        };

        // End of Plan/Rider UI Grid
        /////////////////////////////////////////////////////////////////////////////////

    });