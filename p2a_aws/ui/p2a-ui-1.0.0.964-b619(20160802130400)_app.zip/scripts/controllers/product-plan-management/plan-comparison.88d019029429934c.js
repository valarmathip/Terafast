'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:GenerateReportCtrl
 * @description
 * # GenerateReportCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('PlanCompareCtrl', function($scope, $filter, $log, $rootScope, $modalInstance, ProductPlanMgmtSvc, selectedPlans, PlanComparisonService, reportTemplatesList, ENV, Common) {
        $scope.plansToCompare = selectedPlans;
        $scope.showPlans = true;
        $scope.basePlan = null;
        $scope.plansToBeCompared = [];
        $scope.enableGenerateBtn = false;

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };

        $scope.selectPlan = function(row) {
            if (!row.isSelected) {
                row.isSelected = true;
                $scope.plansToBeCompared.push(row.objectId);
            } else {
                row.isSelected = false;
                for (var key in $scope.plansToBeCompared) {
                    if ($scope.plansToBeCompared[key] === row.objectId) {
                        $scope.plansToBeCompared.splice(key, 1);
                    }
                }
            }
        };
        $scope.setBasePlan = function(baseplan) {
            $scope.enableGenerateBtn = true;
            $scope.basePlan = baseplan;
        };

        angular.forEach(reportTemplatesList, function(reportTemplateObject) {
            if (reportTemplateObject.reportLayout === 'Plan Comparison') {
                $scope.selectedTemplates = reportTemplateObject.objectId;
                $scope.reportLayoutType = reportTemplateObject.reportLayout;
            }
        });


        $scope.goToSeletectPlans = function() {
            $scope.showPlans = true;
        };

        $scope.generateComparisonReport = function() {

            $scope.planIdJson = PlanComparisonService.constructPlanComparisonJson($scope.basePlan, $scope.plansToCompare, $scope.selectedTemplates);
            ProductPlanMgmtSvc.getPlanComparisonReportDetails($scope.planIdJson).then(function(data) {
                $scope.reportPlanDetails = data;
                $scope.allPlans = $scope.reportPlanDetails.plansToShow;
                $scope.showPlans = false;
                initGenerateReport();
                $rootScope.$broadcast('comaparisonplansdatabind');
            });

        };

        $scope.buildPropertiesAndPlanDetailsInfoMap = function() {
            $scope.planDetailsInfo = {};
            $scope.serviceProperties = {};
            var planCount = 0;
            iteratePlans(planCount);
        };

        $scope.constructAllPlanPropertiesMap = function(planSections) {
            angular.forEach(planSections, function(plansection) {
                angular.forEach(plansection, function(plansectionObj, plansectionkey) {
                    if (!$scope[plansectionkey]) {
                        $scope[plansectionkey] = {};
                    }
                    angular.forEach(plansectionObj, function(planPropObj) {
                        var i = 0;
                        var nwTiers = [];
                        angular.forEach(planPropObj, function(networkTiersVal) {
                            nwTiers[i] = networkTiersVal;
                            i++;
                        });
                        $scope[plansectionkey] = nwTiers;
                    });
                });
            });
        };

        $scope.constructAllPlansHeadersArray = function() {
            $scope.allPlansHeaders = [];
            var planheaderCount = 0;
            angular.forEach($scope.allPlans, function(plan) {
                angular.forEach(plan, function(planPropVal, planPropKey) {
                    if (planPropKey === 'planHeaders') {
                        angular.forEach(planPropVal, function(planheader) {
                            $scope.allPlansHeaders[planheaderCount] = planheader;
                            planheaderCount++;
                        });
                    } else if (planPropKey === 'sections') {
                        $scope.constructAllPlanPropertiesMap(planPropVal);
                    }
                });
            });

        };

        function iterateSectionProperties(plan, sectionProperty, sectionName, serviceName) {
            angular.forEach(sectionProperty, function(serviceProperty, servicePropertyName) {
                if (sectionName === 'Plan Service') {

                    setIteratedProperties(sectionName, serviceName, serviceProperty, servicePropertyName);
                    $scope.planDetailsInfo[plan.planName][sectionName][serviceName][servicePropertyName] = serviceProperty;


                } else if (sectionName !== 'unAssociatedServices') {

                    $scope.properties[sectionName][servicePropertyName] = {};
                    $scope.planDetailsInfo[plan.planName][sectionName][servicePropertyName] = serviceProperty;

                } else if (sectionName === 'unAssociatedServices') {
                    var servicePropObj = null;
                    servicePropObj = PlanComparisonService.getServicePropObj(servicePropObj, sectionProperty);
                    $scope.properties[sectionName][servicePropertyName] = {};
                    $scope.properties[sectionName][servicePropertyName] = servicePropObj;
                    $scope.planDetailsInfo[plan.planName][sectionName][servicePropertyName] = servicePropObj;
                }
            });
        }

        function iterateSections(plan, planCount) {
            angular.forEach(plan.sections, function(planSection) {
                angular.forEach(planSection, function(sectionProperty, sectionName) {
                    $scope.planDetailsInfo[plan.planName][sectionName] = {};
                    if (planCount === 1) {
                        $scope.properties[sectionName] = {};
                    }

                    if (sectionName === 'Plan Service') {
                        angular.forEach(sectionProperty, function(serviceObject, serviceName) {
                            if (!$scope.properties[sectionName].hasOwnProperty(serviceName)) {
                                $scope.properties[sectionName][serviceName] = {};
                            }

                            $scope.planDetailsInfo[plan.planName][sectionName][serviceName] = {};
                            iterateSectionProperties(plan, serviceObject, sectionName, serviceName);
                        });
                    } else {
                        iterateSectionProperties(plan, sectionProperty, sectionName, '');
                    }


                });
            });
        }

        function iteratePlans(planCount) {
            angular.forEach($scope.reportPlanDetails.plansToShow, function(plan) {
                planCount++;
                $scope.planDetailsInfo[plan.planName] = {};
                if (planCount === 1) {
                    $scope.properties = {};
                }
                iterateSections(plan, planCount);
            });
        }
        $scope.exportExcel = function() {
            var timezone = PlanComparisonService.getTimeZone();
            var parameterValue = 'planIds=' + $scope.planIdJson.planIds.toString() + '&reportTemplateId=' + $scope.selectedTemplates.toString() + '&basePlanId=' + $scope.planIdJson.basePlanId + '&timeZone=' + timezone;
            var fieldurl = ENV.apiGatewayEndpoint + '/gateway/reports/planComparisonExcel?' + parameterValue;
            var name = $scope.reportLayoutType + '_' + ($filter('date')(new Date(), 'sss_ss_mm_HH_MM_dd_yyyy')).toString();
            Common.download(fieldurl, name, 'xlsx').then(function(data) {
                $log.info('File download Successful' + data);
            }, function(response) {
                $log.info('File download Failed' + response);
            });
        };

        function initGenerateReport() {
            $scope.buildPropertiesAndPlanDetailsInfoMap();
            $scope.constructAllPlansHeadersArray();
        }

        function setIteratedProperties(sectionName, serviceName, serviceProperty, servicePropertyName) {
            if (!$scope.properties[sectionName][serviceName].hasOwnProperty(servicePropertyName)) {
                $scope.properties[sectionName][serviceName][servicePropertyName] = {};
            }

            angular.forEach(serviceProperty, function(serviceObject, serviceObjectName) {
                if (!$scope.properties[sectionName][serviceName][servicePropertyName].hasOwnProperty(serviceObjectName)) {
                    $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName] = {};
                }
                angular.forEach(serviceObject, function(serviceProperties, servicePropertiesName) {
                    if (!$scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName].hasOwnProperty(servicePropertiesName)) {
                        $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName] = serviceProperties;
                    }
                    if (serviceObjectName === 'Plan Service Cost Shares') {
                        angular.forEach(serviceProperties, function(servicePropValue, servicePropKey) {
                            if (!$scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName].hasOwnProperty(servicePropKey)) {
                                $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey] = {};
                            }
                            angular.forEach(servicePropValue, function(costShareValue, costShareName) {
                                if (!$scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey].hasOwnProperty(costShareName)) {
                                    $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey][costShareName] = {};
                                    $scope.properties[sectionName][serviceName][servicePropertyName][serviceObjectName][servicePropertiesName][servicePropKey][costShareName] = costShareValue;
                                }
                            });
                        });
                    }
                });
            });
        }
        $log.log('selected plans list------------------->' + JSON.stringify($scope.plansIds));

    });
