'use strict';

angular.module('p2AdvanceApp')
    .controller('ProductEditRootCtrl', function($scope, $log, $stateParams, $state, PlanLockSvc, QueryDialog) {
        $log.log('edit root $state = ' + $state);
        $log.log('edit root $state = ' + $stateParams);

        $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
            angular.noop(event, toState, toParams, fromState, fromParams); // this do nothing, just remove the jsHint error

            if (fromState.name.indexOf('home.ppm.product.edit') === 0) {
                if (toState.name.indexOf('home.ppm.product.edit') === -1) {
                    $scope.createNewProduct = false;
                    if ($stateParams.productId) {
                        askIfUserNeedToUnlockProduct = askIfUserNeedToUnlockProduct(event, toState, toParams, fromState, fromParams, $scope.createNewProduct);
                    }
                } else if (fromState.name.indexOf('home.ppm.product.edit.product-details.content') === 0) {
                    if (toState.name.indexOf('home.ppm.product.edit.product-details') === 0) {
                        if (fromState.templateUrl !== toState.templateUrl) {
                            $scope.createNewProduct = true;
                            if ($stateParams.productId) {
                                askIfUserNeedToUnlockProduct = askIfUserNeedToUnlockProduct(event, toState, toParams, fromState, fromParams, $scope.createNewProduct);
                            }
                        }
                    }
                }
            }
        });

        function saveBeforeLeave() {
            return QueryDialog.open('Save Product', '<p>Would you like to save any unsaved changes?</p>', 'question', 'ppm-modal-dialog-question')
                .result.then(function() {
                        return angular.isFunction($scope.savingHook.action) ? $scope.savingHook.action() : null;
                    },
                    function(reason) {
                        return reason;
                    });
        }

        $scope.savingHook = {
            // this function return promise;
            action: null
        };

        // setup cleanupHook (clearupHook is defined in MainCtrl, main.js)
        $scope.cleanupHook.execute = function() {
            return saveBeforeLeave()
                .then(function() {
                    return PlanLockSvc.queryIfUserNeedToUnlockEntity($stateParams.productId, 'product');
                });
        };
        // remove the cleanupHook
    $scope.$on('$destroy', function() {
            $scope.cleanupHook.execute = null;
        });


        var askIfUserNeedToUnlockProduct = function(event, toState, toParams, fromState, fromParams, topage) {
            angular.noop(event, toState, toParams, fromState, fromParams); // this do nothing, just remove the jsHint error
            event.preventDefault();

            if (topage === true) {
                $scope.goToNextPage(event, toState, toParams, fromState, fromParams, $scope.createNewProduct);
            } else {

                saveBeforeLeave().then(function() {
                    $scope.goToNextPage(event, toState, toParams, fromState, fromParams, $scope.createNewProduct);
                });
                return angular.noop;
            }
        };

        $scope.goToNextPage = function(event, toState, toParams, fromState, fromParams, topage) {
            PlanLockSvc.queryIfUserNeedToUnlockEntity($stateParams.productId, 'product')['finally'](function() {
                if (topage === true) {
                    $state.go('home.ppm.product.edit.product-details', {
                        productId: ''
                    });
                } else {
                    $state.go(toState.name, {});
                }
            });
        };
    });