'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:PlanDetailsCtrl
 * @description
 * # PlanDetailsCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('PlanDetailsCtrl', function($scope, $timeout, $q, $log, $filter, $parse, planDetailFieldsMetaData,
        ProductPlanMgmtSvc, ConfirmationModalFactory, ENV, $stateParams, $state, ValidationReportPageslideSvc,
        PpmFullEqual, ppmUtils, CostShareFacadeSvc, PlanL3, /*ProductL3,*/ QueryDialog, planPreviewSvc, userAuthorizationManager) {

        function init() {
            $scope.debugMode = (ENV.name === 'local');

            $scope.planDetails = {}; // $scope.editPlan.screens.planDetails;
            $scope.planDetailsOri = angular.copy(transformOutput()); // backup for the check changes
            $scope.productDetails = {};
            $scope.productDetailsOri = {};
            $scope.planCostSharesOriginal = undefined;
            $scope.editedTierNameValid = false;

            // Sameple data format should be: {'maximumIndividualDeductible': {'selected': true, 'displayName': 'Individual Deductible'}}
            $scope.costShares = {};

            $scope.selectedTab = 'sdf';

            // Status of opened calendar, internal use only
            $scope.calendarOpened = {};

            $scope.productFieldsMetaData = planDetailFieldsMetaData.productFieldsMetaData;
            $scope.planFieldsMetaData = planDetailFieldsMetaData.planFieldsMetaData;
            $scope.costSharesMapping = planDetailFieldsMetaData.coverageTiersMapping;
            $scope.productFieldsMetaDataMappedByNameId = getMetaInfoMappedByNameId($scope.productFieldsMetaData);
            $scope.planFieldsMetaDataMappedByNameId = getMetaInfoMappedByNameId($scope.planFieldsMetaData);
            $scope.hasError = false;
            $scope.isIncludeSecondaryMoopInitValueChanged = false;
            $scope.componentStatus = {
                isValidationEnabled: true
            };
            copyUnchangedValueforJsonpath(PlanL3);

            setupModel();
            loadData();


        }

        // currently the show/hide based on 4 properties, and one of the value "planType" 
        // is changeable and set a listener on it.
        function copyUnchangedValueforJsonpath(plan) {
            var unchangedProperties = ['productClasses', 'productTypes', 'lineOfBusiness', 'planType'];

            var simplePlan = {};

            angular.forEach(unchangedProperties, function(prop) {
                simplePlan[prop] = angular.copy(plan[prop]);
            });

            $scope.planDetailsBEfmt = [simplePlan];

            $scope.$watch('planDetails.planType', function(newValue /*, oldValue*/ ) {
                // $log.log('planDetails.planType changed.');
                if (newValue === null) {
                    return;
                }
                $scope.planDetailsBEfmt[0].planType = angular.copy(newValue); // in the future, this planType maybe need some transfermation
            });
        }


        $scope.savingHook.action = function() {
            $scope.saveClick();
        };
        // before destory the scope, make sure the hooker is removed so that this memory can be released
        $scope.$on('$destroy', function() {
            $scope.savingHook.action = null;
        });
        $scope.charRestrictRegex = function(id) {
            if (id === 'name') {
                return /[\"<>\\\/\.\?\:\|\*]/g;
            }
        };

        // $scope.getDateRangeBoundary = function(nameId, index, maxOrMin) {
        //     var fieldMetaInfo = $scope.planFieldsMetaDataMappedByNameId[nameId];
        //     var options = fieldMetaInfo.options;

        //     var otherOptionNameId;
        //     if (index === 0 && maxOrMin === 'max') {
        //         otherOptionNameId = options[1].optionNameId;
        //         return $scope.planDetails[nameId][otherOptionNameId];
        //     } else if (index === 1 && maxOrMin === 'min') {
        //         otherOptionNameId = options[0].optionNameId;
        //         return $scope.planDetails[nameId][otherOptionNameId];
        //     }

        //     return null;
        // };

        // This is the parent control indicating whether to show the related cost share sliders or not
        var costShareParentId = 'applicableCoverageTiers',
            isIncludeSecondaryMoop = 'isIncludeSecondaryMoop';

        // It is better to move this to a angular constant in future
        var providerTierNamesOrder = [
            'In Network',
            'Out of Network',
            'Out of Area',
            'Out of Country',
            'Preferred Network 1',
            'Preferred Network 2',
            'Preferred Network 3',
            'Coverage'
        ];

        var planId = '',
            productIds = [];
        // associationExpansionLevel;

        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId][$index] = true;

            $log.log('$scope.calendarOpened[nameId][$index] = ' + $scope.calendarOpened[nameId][$index]);
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function

        function genCostShareSplitId(csId) {
            return csId + '_split';
        }

        function getMetaInfoMappedByNameId(fieldMetaInfoList) {
            var mapper = {};
            angular.forEach(fieldMetaInfoList, function(fieldMetaInfo) {
                mapper[fieldMetaInfo.nameId] = fieldMetaInfo;
            });

            return mapper;
        }


        /* Fixed DOGVT-245 - Plan Year Default value is not set to "N/A" if user doesn't enter a Plan Year */
        function setDefaultPlanYearValue() {
            if ((($scope.planDetails['planYear'] === null) || ($scope.planDetails['planYear'] === '' || !$scope.planDetails['planYear'].length)) && ($scope.planFieldsMetaDataMappedByNameId['planYear'].options.length !== 0)) {
                $scope.planDetails['planYear'] = [$scope.planFieldsMetaDataMappedByNameId['planYear'].options[0].label];
            }
        }

        $scope.printArray = function(str) {
            return str.join(', ');
        };

        // global cost share list is depends on the product applicationCoverageTiers.
        function getCostShareShowList(parent, mapping) {
            var showList = [];
            var hasSingle = false;
            var selected = 0;

            function contains(array, obj) {
                var i = array.length;
                while (i--) {
                    if (array[i] === obj) {
                        return true;
                    }
                }
                return false;
            }

            // Check if the product part has the applicableCoverageTiers exist, if not plan part should not include.
            // Since plan applicableCoverageTiers will automatically updated, so for the mapping, we maybe do not need to refere product ones.
            angular.forEach($scope.planDetails[parent], function(item, key) {
                // DOGHR-1286: Add a check to see if the value exist in product, if not, don't show the corresponding slider
                if (item === true && !isNullOrUndefined($scope.productDetails[parent]) && contains($scope.productDetails[parent], key)) {
                    selected++;
                    if (key === 'Individual') {
                        hasSingle = true;
                    }
                    angular.forEach(mapping, function(item2, key2) {
                        if (key2 === key) {
                            showList = showList.concat(item2);
                        }
                    });
                }
            });

            // always has individual of any of individual + others exist.
            if (!hasSingle && selected > 0) {
                showList = showList.concat(mapping.Individual);
            }

            // remove secondary moop
            //Secondary Moop check  
            if ($scope.planDetails[isIncludeSecondaryMoop] !== 'Yes') {
                for (var i = showList.length - 1; i >= 0; i--) {
                    if (showList[i].indexOf('SecondaryMoop') > -1) {
                        showList.splice(i, 1);
                    }
                }
            }

            return showList;
        }
        // End of getCostShareShowList function

        // Check to show the slider or not
        function isNameExist(name, mapping) {
            var found = false;
            for (var i = 0, j = mapping.length; i < j; i++) {
                if (mapping[i] === name) {
                    found = true;
                    break;
                }
            }
            return found;
        }
        // End of isNameExist function
        function isCostShareInProduct(costShareType, product) {
            var found = false;
            angular.forEach(product[0].globalcostshares, function(item) {
                if (item.costShareType === costShareType) {
                    found = true;
                }
            });
            return found;
        }
        $scope.checkboxChanged = function(nameId) {
            if (nameId !== costShareParentId) {
                return;
            }
            displayCostShares();
        };
        // End of checkboxChanged function
        $scope.setPreviousSelectedRadioBtnValue = function(nameId) {
            $scope.previousRadioSelection = $scope.planDetails[nameId];
        };

        $scope.radioButtonClicked = function(event, nameId) {
            function showWarning(planType) {
                var msg = 'You don’t have the necessary permissions to create a "' + planType + '" plan';
                QueryDialog.open('Warning', msg, 'warning', 'ppm-modal-dialog-warning');
            }
            if (nameId === isIncludeSecondaryMoop) {
                $scope.planDetails[nameId] = event.target.value;
                displayCostShares();
            } else if (nameId === 'planType') { // verify if user has permission to make this change and prompt a warning if user do not have permission
                // if user has plan.update or update.all, return
                if (userAuthorizationManager.hasPermission('plan.update') || // has all plan permission
                    userAuthorizationManager.hasPermission('all.update')) {
                    $scope.planDetails[nameId] = event.target.value;
                    return;
                } else if (userAuthorizationManager.hasPermission('plan.update.custom') && event.target.value === 'Standard') {
                    $timeout(function() {
                        $scope.planDetails[nameId] = 'Custom';
                    });
                    showWarning('Standard');
                } else if (userAuthorizationManager.hasPermission('plan.update.standard') && event.target.value === 'Custom') { // plan.update.standard is not show in role, but is defined and could be a option in the future (backend requested)
                    $timeout(function() {
                        $scope.planDetails[nameId] = 'Standard';
                    });
                    showWarning('Custom');
                }
            } else {
                if ($scope.previousRadioSelection === event.target.value) {
                    $scope.planDetails[nameId] = null;
                } else {
                    $scope.planDetails[nameId] = event.target.value;
                }
            }
        };

        function displayCostShares() {
            // get the list of cost shares(moop and deductible) that should be displayed
            var showList = getCostShareShowList(costShareParentId, $scope.costSharesMapping);
            $log.log('CostShareShowList=' + JSON.stringify(showList));
            angular.forEach($scope.productFieldsMetaData, function(item) {
                var found = false;
                if (item.type === 'slider') { // in fact, only care about slider/cost shares
                    if (!item.parentId) { // copay and co-insurance
                        found = true;
                    } else { // moop and deductible
                        item.show = isNameExist(item.nameId, showList);
                        if (item.show) { // display the cost share
                            item.show = isCostShareInProduct(item.displayName, $scope.productDetailsOri); // Checkout if the product has the same cost share
                            if (item.show) {
                                found = true;
                            }
                        } else { // hide the cost share and remove its splitted children if there's any
                            // This contains the split information (if the )
                            // SLQ-KEEP this is a kind of clean up, need to keep them somewhere.
                            // This should be listen to the field.show changes
                            if (!$scope.costShares[item.nameId]) {
                                $scope.costShares[item.nameId] = {};
                            }
                            $scope.costShares[item.nameId].selected = false;
                            var splitId = genCostShareSplitId(item.nameId); // return "nameId"_split
                            if (!isNullOrUndefined($scope.planDetails[splitId])) {
                                $scope.splitCostShare(item);
                            }
                        }
                    }
                    if (!found) {
                        item.show = false;
                    }
                }
            });
            checkCostShareExistance();
            setIsDeductibleAmountsCombinedOrSeperated();
        }

        function loadData() {
            planId = $stateParams.planId;
            var plan = PlanL3; // in fact, directly load only level 1

            // init plan from loaded plan
            var productInfo = plan.linkedProducts; // array
            angular.forEach(productInfo, function(item) {
                productIds.push(item.objectId);
            });
            $scope.productDetailsOri = angular.copy(productInfo);
            $scope.planDetails['linkedProducts'] = productIds;
            $scope.productDetails = mergeProductDetails(productInfo);
            updateMetadataSliderInfoWithProduct();

            updateMetadataSliderInfoWithPlan(plan);
            transformInputMetaData();
            transformInputPlanDetail(plan);

            if (!$scope.planDetails.objectId) { // SLQ remove it if back end returned
                $scope.planDetails.objectId = planId;
            }

            filterProductMetaData(plan);
            initFromPlanDetail();

            getLatestPlanToOri($scope.isIncludeSecondaryMoopInitValueChanged);
        }


        // Merge multiple product info to get the final combined product details
        function mergeProductDetails(prdArray) {
            var result = {};
            // For each product metadata, go through each product detail info, 
            // If found the key and the value is an array, combine the values.
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                angular.forEach(prdArray, function(product) { // product Details
                    angular.forEach(product, function(prdValue, prdKey) {
                        if (metadata.nameId === prdKey) {
                            if (metadata.nameId === isIncludeSecondaryMoop) {
                                if (isNullOrUndefined(result[prdKey])) {
                                    result[prdKey] = false;
                                }
                                result[prdKey] = result[prdKey] || prdValue;
                            } else if (angular.isArray(prdValue)) {
                                var options = [];
                                if (result[prdKey] && result[prdKey].length > 0) {
                                    options = result[prdKey];
                                }
                                angular.forEach(prdValue, function(item) {
                                    if (options.indexOf(item) === -1) {
                                        options.push(item);
                                    }
                                });
                                result[prdKey] = options;
                            }
                        }
                    });
                });
            });

            result['globalcostshares'] = [];
            // product cost share
            angular.forEach(prdArray, function(product) { // product Details
                result['globalcostshares'] = result['globalcostshares'].concat(product.globalcostshares);
            });
            return result;
        }
        // End mergeProductDetails function

        function initFromPlanDetail() {
            $scope.checkboxChanged(costShareParentId);
        }
        // End of initFromPlanDetail function

        function transformInputPlanDetail(plnDetail) {
            var mapping = {
                'effectiveDate': 'effectiveDates',
                'endDate': 'effectiveDates',
                'numProviderTiers': 'productTiers',
                'providerTierNames': 'productTiers',
                'providerTierDisplayNames': 'productTiers'
            };
            angular.forEach(plnDetail, function(plnValue, plnKey) {
                var found = false;

                // Effective Dates and ProductTiers
                angular.forEach(mapping, function(item, key) {
                    if (plnKey === key) {
                        $scope.planDetails[item][plnKey] = plnValue;
                        found = true;
                    }
                });

                // set the selected tier name in the product for display
                var tierNameForDisplay = {};
                angular.forEach($scope.planDetails['productTiers']['providerTierNames'], function(tierName) {
                    tierNameForDisplay[tierName] = true;
                });
                $scope.planDetails['productTiers']['providerTierNamesforDisplay'] = tierNameForDisplay;

                // Multi-selection checkbox
                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.nameId === plnKey) {
                        if (metadata.type === 'checkbox' && angular.isArray(plnValue)) {
                            var temp = {};
                            angular.forEach(plnValue, function(item) {
                                temp[item] = true;
                            });
                            $scope.planDetails[plnKey] = temp;
                            found = true;
                        }
                        // Radio Button
                        if (metadata.type === 'radioButton') {
                            if (plnValue === true) {
                                $scope.planDetails[plnKey] = 'Yes';
                            } else if (plnValue === false) {
                                $scope.planDetails[plnKey] = 'No';
                            } else {
                                $scope.planDetails[plnKey] = plnValue;
                            }
                            found = true;
                        }
                    }
                });

                angular.forEach($scope.planFieldsMetaData, function(metadata) {
                    if (metadata.nameId === plnKey) {
                        // Multi-selection checkbox
                        if (metadata.type === 'checkbox' && angular.isArray(plnValue)) {
                            var temp = {};
                            angular.forEach(plnValue, function(item) {
                                temp[item] = true;
                            });
                            $scope.planDetails[plnKey] = temp;
                            found = true;
                        }
                        // Radio Button
                        if (metadata.type === 'radioButton') {
                            if (plnValue === true) {
                                $scope.planDetails[plnKey] = 'Yes';
                            } else if (plnValue === false) {
                                $scope.planDetails[plnKey] = 'No';
                            } else {
                                $scope.planDetails[plnKey] = plnValue;
                            }
                            found = true;
                        }
                    }
                });

                /* Fixed DOGVT-245 - Plan Year Default value is not set to "N/A" if user doesn't enter a Plan Year */
                if (!found) {
                    if (plnKey === 'planCostShares') { // save a copy of the original planCostShare to retrieve objectIds
                        $scope.planCostSharesOriginal = plnValue;
                    } else if (plnKey === 'planYear' && (!plnValue || !plnValue.length)) {
                        setDefaultPlanYearValue(); /* Fixed DOGVT-245 - Plan Year Default value is not set to "N/A" if user doesn't enter a Plan Year */
                    } else if (plnValue !== null) { // Note: no matter single or multiple, backend only returns null value. No empty array.
                        // null value returned should not overwirte the initial setup value, which will cause problem.
                        $scope.planDetails[plnKey] = plnValue;
                    }
                }
            });

            if (!$scope.productDetails.isIncludeSecondaryMoop && $scope.planDetails.isIncludeSecondaryMoop && ($scope.planDetails.isIncludeSecondaryMoop === 'Yes')) {
                $log.log('isIncludeSecondaryMoop in product is false, reset the plan value to be false');
                $scope.planDetails.isIncludeSecondaryMoop = 'No';
                $scope.isIncludeSecondaryMoopInitValueChanged = true;
            }

            // plan cost shares
            angular.forEach(plnDetail.planCostShares, function(costShare) {
                angular.forEach($scope.productFieldsMetaData, function(metadata) {

                    if (metadata.type === 'slider' && metadata.displayName === costShare.costShareType) {
                        // cost share - copay, coinsurance, deductible, moop
                        if (isNullOrUndefined(costShare.providerTier) || costShare.providerTier === 'NA') {
                            $scope.planDetails[metadata.nameId] = costShare.selectedValue.toString();
                            if (costShare.splitByTier) { // checkbox checked
                                $scope.costShares[metadata.nameId].selected = true;
                                $scope.splitCostShare(metadata);
                            }
                        } else { // tiers
                            var id = genCostShareSplitId(metadata.nameId);
                            angular.forEach($scope.planDetails[id], function(tierInfo) {
                                if (tierInfo.tierName === costShare.providerTier) {
                                    tierInfo.tierValue = costShare.selectedValue;
                                }
                            });
                        }
                    }
                });
            });
        }
        // End of transformInputPlanDetail function

        // Change slider data to required UI format
        function transformInputMetaData() {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (metadata.type === 'slider') {
                    // init costShares values for split features
                    if (!angular.isArray(metadata.options) && metadata.options.splitByTier === 'true') {
                        $scope.costShares[metadata.nameId] = {
                            'selected': false,
                            'displayName': ''
                        };
                        $scope.costShares[metadata.nameId].displayName = metadata.displayName;
                    }
                }
                if (metadata.parentId === '') {
                    if (metadata.nameId === isIncludeSecondaryMoop) { // Secondary moop
                        if ($scope.productDetails[metadata.nameId]) { // only show when product include secondary moop
                            metadata.show = true; // if product include secondary moop, then plan one will shown
                        } else {
                            metadata.show = false;
                        }
                    } else {
                        metadata.show = true;
                    }

                } else {
                    metadata.show = false;
                }
            });
        }
        // End of transformInputMetaData function

        function transformOutput() {
            var data = {};

            var costShareShowList = getCostShareShowList(costShareParentId, $scope.costSharesMapping);
            data.planCostShares = [];
            data.planStatus = $scope.planDetails.planStatus;

            angular.forEach($scope.planDetails, function(plnValue, plnKey) {
                var found = false;
                /*jshint maxcomplexity:12 */
                angular.forEach($scope.productFieldsMetaData, function(metadata) {
                    if (metadata.nameId === plnKey) {
                        var value = doOutputUnitTransform(plnValue, metadata, costShareShowList);
                        if (value != null) {
                            found = true;
                            if (metadata.type === 'slider') {
                                // Removing Round slide setting to preveting sent save it into backend. 
                                // DOGHR-1836
                                delete value['round'];
                                if (typeof value.selectedValue === 'string') {
                                    value.selectedValue = parseFloat(value.selectedValue);
                                }
                                data.planCostShares.push(value);
                            } else if (metadata.type === 'tiers') {
                                angular.forEach(value, function(item, key) {
                                    data[key] = item;
                                });
                            } else if ((metadata.type === 'radioButton') && (metadata.nameId === isIncludeSecondaryMoop)) {
                                if (plnValue === 'Yes') {
                                    data[plnKey] = true;
                                } else {
                                    data[plnKey] = false;
                                }
                            } else {
                                data[plnKey] = value;
                            }
                        } else { // invalid cost share items, need to remove
                            if (metadata.type === 'radio') {
                                data[plnKey] = plnValue;
                            } else if (metadata.type === 'radioButton') {
                                data[plnKey] = null;
                            } else if (metadata.type === 'textInput' || metadata.type === 'textArea') {
                                data[plnKey] = null;
                            }
                            found = true;
                        }
                    }
                });
                angular.forEach($scope.planFieldsMetaData, function(metadata) {
                    if (metadata.nameId === plnKey) {
                        var value = doOutputUnitTransform(plnValue, metadata, null);
                        if (value != null) {
                            found = true;
                            if (metadata.type === 'dateRange') {
                                angular.forEach(value, function(item, key) {
                                    data[key] = item;
                                });
                            } else {
                                data[plnKey] = value;
                            }
                        } else {
                            if (metadata.type === 'radio') {
                                data[plnKey] = plnValue;
                            } else if (metadata.type === 'radioButton') {
                                data[plnKey] = null;
                            }
                        }
                    }
                });
                if (!found) {
                    if (plnValue === '') {
                        plnValue = null;
                    }
                    data[plnKey] = plnValue;
                }
            });
            // split cost share
            angular.forEach($scope.costShares, function(csValue, csNameId) {
                if (csValue.selected) {
                    var id = genCostShareSplitId(csNameId);
                    angular.forEach($scope.planDetails[id], function(csTierInfo) {
                        var cs = {};
                        cs['costShareType'] = csValue.displayName;
                        cs['providerTier'] = csTierInfo.tierName;
                        cs['selectedValue'] = csTierInfo.tierValue;
                        cs['splitByTier'] = false;
                        cs['objectId'] = retrieveCostShareObjectId(csValue.displayName, csTierInfo.tierName);
                        data.planCostShares.push(cs);
                    });
                    delete data[id];
                }
            });
            // delete data.alternativePlanName;
            // delete data.planStatus;
            if (data['providerTierNamesforDisplay']) {
                delete data['providerTierNamesforDisplay'];
            }
            return data;
        }
        // End of transformOutput function

        // This function has a cyclomatic complexity error! and the  reason is simple, 
        // it has too many if / else paths. The question is why not create small reusable
        // functions instead a huge large function?
        function doOutputUnitTransform(originValue, metaDataField, costShareShowList) {
            var value = originValue;
            switch (metaDataField.type) {
                case 'checkbox':
                    value = [];
                    angular.forEach(originValue, function(item, key) {
                        if (item === true) {
                            value.push(key);
                        }
                    });
                    break;
                    // We changed to user UTC datetime format like '2015-12-25T05:00:00.000Z' or '2016-01-19T09:56:30.543-05:00', 
                    // so there is no need to transfer the datetime. 
                    // case 'dateRange':
                    //     value = {};
                    //     angular.forEach(originValue, function(item, key) {
                    //         value[key] = getDateFilterValue(item);
                    //     });
                    //     break;
                    // case 'date':
                    //     value = getDateFilterValue(originValue);
                    //     break;
                case 'slider':
                    value = getSlideValue(metaDataField, originValue, costShareShowList);
                    break;
                case 'radioButton':
                    if (isNullOrUndefined(originValue)) {
                        value = null;
                    } else {
                        value = getRadioButtonValue(originValue);
                    }
                    break;
                case 'dropdown':
                    value = getDropdownValue(metaDataField, originValue);
                    break;
                case 'textInput':
                case 'textArea':
                    if (value === '') {
                        value = null;
                    }
                    break;
            }
            return value;
        }
        // End of doOutputUnitTransform function

        function getSlideValue(metaDataField, originValue, costShareShowList) {
            var value = null;
            if (showSlider(metaDataField, costShareShowList)) {
                value = angular.copy(metaDataField.options);
                //value.selectedValue = parseInt(originValue, 10);
                value.selectedValue = originValue;
                value.scale = value.scaleOriginal;
                delete value.scaleOriginal;
                if (metaDataField.options.splitByTier === 'true') {
                    value.splitByTier = $scope.costShares[metaDataField.nameId].selected;
                } else {
                    value.splitByTier = false;
                }
                metaDataField.show = true;
            } else {
                metaDataField.show = false;
            }

            checkCostShareExistance();
            setIsDeductibleAmountsCombinedOrSeperated();
            return value;
        }

        function getDropdownValue(metaDataField, originValue) {
            var value = originValue;
            if (metaDataField.nameId === 'planYear' && angular.isArray(originValue) && originValue.length === 0) {
                originValue.push('NA'); // Seems that backend use NA, not N/A.
            }
            return value;
        }

        function showSlider(metaDataField, costShareShowList) {
            var show = false;
            if (!metaDataField.parentId) {
                show = true;
            } else {
                show = isNameExist(metaDataField.nameId, costShareShowList);
                if (show) {
                    show = isCostShareInProduct(metaDataField.displayName, $scope.productDetailsOri);
                }
            }
            return show;
        }

        // We changed to user UTC datetime format like '2015-12-25T05:00:00.000Z' or '2016-01-19T09:56:30.543-05:00', 
        // so there is no need to transfer the datetime. 
        // function getDateFilterValue(originValue) {
        //     return $filter('date')(originValue, 'yyyy-MM-dd');
        // }

        function getRadioButtonValue(originValue) {
            var value = originValue;
            if (originValue.toString().toLowerCase() === 'yes') {
                value = true;
            } else if (originValue.toString().toLowerCase() === 'no') {
                value = false;
            }
            return value;
        }

        // Filter out invalid options according to product details
        function filterProductMetaData(referenceData) {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                angular.forEach($scope.productDetails, function(prdValue, prdKey) {
                    if (metadata.nameId === prdKey) {
                        if (angular.isArray(prdValue)) {
                            var options = [];
                            angular.forEach(metadata.options, function(opt) {
                                var found = false;
                                angular.forEach(prdValue, function(item) {
                                    if (opt.label === item) {
                                        found = true;
                                    }
                                });
                                if (found) {
                                    options.push(opt);
                                }
                            });
                            metadata.options = options;
                        }
                    }
                });
            });

            filterProductTiers(referenceData);
        }
        // End of filterProductMetaData

        // setup plan provider tier meta data by using the product info
        // This is eaxctly add options to tiers meta data
        function filterProductTiers(referenceData) {
            var tierDisplayNameList = [];
            var tierIdNameList = [];

            // get from linked products
            var linkedProducts = referenceData.linkedProducts; // This is product list (could be more than one linked product)
            var tierNamesMap = {};
            // get linked product tiers' name
            angular.forEach(linkedProducts, function(prod) {
                angular.forEach(prod.providerTierNames, function(tName, index) {
                    // if there are 2 linked products and their tier's display name is different, the last one will win.
                    var displayName = prod.providerTierDisplayNames ? prod.providerTierDisplayNames[index] : tName;
                    tierNamesMap[tName] = displayName ? displayName : tName; // prod.providerTierDisplayNames[index] also could be null
                });
            });
            // get plan itself value (plan could change the prefered network 1, 2, 3 display name)
            angular.forEach(referenceData.providerTierNames, function(tName, index) {
                var displayNameInPlan = referenceData.providerTierDisplayNames ? referenceData.providerTierDisplayNames[index] : tName;
                tierNamesMap[tName] = displayNameInPlan ? displayNameInPlan : tName;
            });
            // generate analysis result
            angular.forEach(providerTierNamesOrder, function(tName /*, index*/ ) {
                if (tierNamesMap[tName]) {
                    tierIdNameList.push(tName);
                    tierDisplayNameList.push(tierNamesMap[tName]);
                }
            });

            var tierMetaInfo = $scope.productFieldsMetaDataMappedByNameId['productTiers'];
            var options = [];
            angular.forEach(tierDisplayNameList, function(displayName, index) {
                options.push({
                    'optionNameId': tierIdNameList[index],
                    'label': displayName
                });
            });

            tierMetaInfo.options = options;
        }

        $scope.saveClick = function() {
            // verify manadatory field
            if (containAllMandatoryFields()) {
                $scope.hasError = false;
            } else {
                $scope.hasError = true;
            }
            if ($scope.hasError) {
                $log.log('Mandatory fields check not passed.');
                return;
            }
            if (!validateAllCostShares()) {
                $log.log('split cost share value check not passed.');
                return;
            }

            // check if there is any changes
            var nonEqualStrs = {};
            if (!isSaving(nonEqualStrs)) {
                $scope.componentStatus.isValidationEnabled = true;
                return;
            }

            // following do saving
            setDefaultPlanYearValue(); /* Fixed DOGVT-245 - Plan Year Default value is not set to "N/A" if user doesn't enter a Plan Year */

            $scope.hasError = false;
            $scope.validstatussave = $scope.areTierNamesValid($scope.editedTierNameValid);
            if (!$scope.validstatussave) {
                return;
            }
            saveOrUpdatePlan(nonEqualStrs, true)
                .then(function( /*planId*/ ) {
                    $scope.componentStatus.isValidationEnabled = true;
                });
        };

        function getLatestPlanToOri(isIncludeSecondaryMoopInitValueChanged) {
            $timeout(function() {
                $scope.planDetailsOri = angular.copy(transformOutput());
                // if the init value in product is false, but in plan is true, 
                // we change the value before this function is called for the frist time
                // revert the value for result companrison purpose only.
                // Backend will need this value to modify secondary moop accordingly
                if (isIncludeSecondaryMoopInitValueChanged) {
                    $log.log('revert isIncludeSecondaryMoop in the saved copy to be true, since we reset the init value to be false due the product value changed.');
                    $scope.planDetailsOri.isIncludeSecondaryMoop = true;

                    var msg = 'The option to include a Secondary MOOP has been removed from this Plan’s parent Product. Therefore, Secondary MOOP information has been removed from this Plan';
                    QueryDialog.open('Warning', msg, 'warning', 'ppm-modal-dialog-warning');
                }
            }, 200); // leave some time for system steady
        }

        function isSaving(result) {
            var config = {};

            var equalSvc = new PpmFullEqual(config);
            var currentValue = transformOutput($scope.planDetails);
            $log.log(angular.toJson(currentValue, true));
            var isSame = equalSvc.equals(currentValue, $scope.planDetailsOri, result);

            return !isSame;
        }

        function getSimplifiedPostData(postData, nonEqualPropertyStrs) {

            return generatePostData(postData, nonEqualPropertyStrs);

            /*
            1. if only plan properties changes, send the simple plan
            2. if plan cost share changed (add/remove), send composite plan with cost shares,
               could combine with plan properties that changed.
            */
            function generatePostData(postData, nonEqualPropertyStrs) {
                $log.log('==============================');
                var retValue = {};
                var plan = generatePlanPropertiesData(postData, nonEqualPropertyStrs);
                var costShares = generatePlanCostSharePropertiesDataCostShareLevel(postData);

                retValue.plan = plan;
                if (!retValue.plan) {
                    retValue.plan = {};
                }
                if (costShares && costShares.length > 0) {
                    retValue.plan.planCostShares = costShares;
                }
                delete retValue.plan.objectId;

                //$log.log('changed part: ' + angular.toJson(retValue.plan, true));


                return retValue.plan;
            }

            function generatePlanPropertiesData(postData, nonEqualPropertyStrs) {
                var p = /^(value\.[^\[\]\.]+).*$/;
                var p2 = /^(value\.planCostShares[\.\[]?).*$/;
                var obj = {};
                angular.forEach(nonEqualPropertyStrs, function(value, propertyStr) {
                    if (!p2.test(propertyStr)) {
                        var groups = p.exec(propertyStr);
                        if (groups) {
                            var propertyStrArray = groups[1]; // if simple property is array, use array as property, if not, it is still the property
                            copyValueFromSource(propertyStrArray, postData, obj);
                        }

                    }
                });
                // copy objectId
                if (!angular.equals(obj, {})) {
                    copyValueFromSource('value.objectId', postData, obj);
                }
                // copy providerTierNames, if providerTierDisplayName changed
                if (obj.value && obj.value.providerTierDisplayNames && !obj.value.providerTierNames) {
                    copyValueFromSource('value.providerTierNames', postData, obj);
                }

                return obj.value;
            }

            function generatePlanCostSharePropertiesDataCostShareLevel(postData) {
                var newCostShares = [];
                var removedCostShares = [];
                var map = {};
                var mapOri = {};

                var costShareCur = postData.planCostShares;
                var costShareOri = $scope.planDetailsOri.planCostShares;

                // find new added and possible updated
                angular.forEach(costShareCur, function(costshare1 /*, index*/ ) {
                    if (costshare1.objectId) {
                        map[costshare1.objectId] = costshare1;
                    } else { // this is a new one
                        newCostShares.push(costshare1);
                    }
                });
                // find removed and possible updated from ori
                angular.forEach(costShareOri, function(costshare2 /*, index*/ ) {
                    if (costshare2.objectId in map) { // not removed
                        mapOri[costshare2.objectId] = costshare2;
                    } else {
                        delete map[costshare2.objectId];
                        removedCostShares.push(costshare2);
                    }
                });

                // Special case:
                // There is a case in current situation, new added one has the id, this happen when screen is not loaded
                // if new one id is not in old one, it suppose to be new
                angular.forEach(map, function(costShare6, objectId) {
                    if (!(objectId in mapOri)) { // means also a new one
                        delete costShare6.objectId; // remove it object id
                        newCostShares.push(costShare6);
                        delete map[objectId]; // remove it form map, because it should move to newCostShares
                    }
                });

                // updated cost share array from, for compare
                var updatedNew = [];
                angular.forEach(map, function(costshare3 /*, key*/ ) {
                    updatedNew.push(costshare3);
                });
                // update cost share array from ori, for compare
                var updatedOri = [];
                angular.forEach(mapOri, function(costshare4 /*, key*/ ) {
                    updatedOri.push(costshare4);
                });
                if (updatedNew.length !== updatedOri.length) {
                    $log.error('There is a logic error while call generatePlanCostSharePropertiesDataCostShareLevel()');
                }

                // sorted and compare two array
                var config = {};
                var equalSvc = new PpmFullEqual(config);
                var nonEqualStrs = {};
                updatedNew = angular.copy($filter('orderBy')(updatedNew, ['objectId']));
                updatedOri = angular.copy($filter('orderBy')(updatedOri, ['objectId']));
                var isSame = equalSvc.equals(updatedNew, updatedOri, nonEqualStrs);

                var retValue = [];
                // get changed cost share value and its objectId
                var obj = {};
                obj.value = [];
                if (!isSame) {
                    var p = /^(value\[(\d+)\])\..+/;
                    angular.forEach(nonEqualStrs, function(value, propertyStr) {
                        var groups = p.exec(propertyStr);
                        if (groups) {
                            copyValueFromSource(propertyStr, updatedNew, obj);
                            var thisCostShareProp = groups[1];
                            var changedIndex = Number(groups[2]);
                            if ($parse(thisCostShareProp)(postData) !== null) {
                                copyValueFromSource(thisCostShareProp + '.objectId', updatedNew, obj);
                                delete map[updatedNew[changedIndex].objectId];
                            }
                        }
                    });
                }

                // add new cost share (those without objectId)
                angular.forEach(newCostShares, function(costshare5 /*, index*/ ) {
                    retValue.push(costshare5);
                });
                // remove those null value, that is cause by  element that does not changed element
                angular.forEach(obj.value, function(cs /*, index*/ ) {
                    if (cs != null) {
                        retValue.push(cs);
                    }
                });
                // add those cost share id, that not changed
                if (!isSame || newCostShares.length > 0 || removedCostShares.length > 0) { // there is are value change/cost share add/cost share remove
                    angular.forEach(map, function(cs /*, key*/ ) {
                        retValue.push({
                            'objectId': cs.objectId
                        });
                    });
                }

                return retValue;
            }

            function copyValueFromSource(propertyPath, source, dest) {
                var newValue = $parse(propertyPath)({
                    value: source
                });
                ppmUtils.transferPathToObject(propertyPath, newValue, dest);
            }
        } // end of getSimplePostData

        $scope.tiersNameChanged = function() {
            $log.log('tiersNameChanged');
            refreshTiersChanges($scope.planDetails.productTiers.providerTierNamesforDisplay);
        };

        $scope.tiersNameValid = function(btnNameId, btnNameLabel) {
            $log.log('tiersNameValid: ' + btnNameId + ' --> ' + btnNameLabel + '.');

            var tierNameOptions = $scope.productFieldsMetaDataMappedByNameId['productTiers'].options;
            var valid = true;
            var msg;

            if (btnNameLabel.trim().length > 65) {
                valid = false;
                msg = 'Tier Name should be less than or equal to 65. The current length is ' + btnNameLabel.length + '.';
            } else if (btnNameLabel.trim().length < 3) {
                valid = false;
                msg = 'Tier Name should be greater than or equal to 3. The current length is ' + btnNameLabel.length + '.';
            } else { // make sure the name is unique
                angular.forEach(tierNameOptions, function(option) {
                    if (option.optionNameId !== btnNameId && option.label.toLowerCase() === btnNameLabel.toLowerCase()) {
                        valid = false;
                        msg = 'Tier Name should be unique (Case Insensitive).';
                    }
                });
            }

            if (!valid) {
                QueryDialog.open('Tier Name Invalid', msg, 'minus', 'ppm-modal-dialog-error');
                $scope.editedTierNameValid = true;
            } else {
                $scope.editedTierNameValid = false;
            }
            return valid;
        };

        $scope.areTierNamesValid = function(validstatus) {
            if (validstatus) {
                var validationmsg = 'Tier Name should be unique (Case Insensitive).';
                QueryDialog.open('Tier Name Invalid', validationmsg, 'minus', 'ppm-modal-dialog-error');
                return false;
            } else {
                return true;
            }
        };
        // return promise
        function saveOrUpdatePlan(nonEqualStrs, showMessage) {

            // unregirest wath planDetails, because after save or validation, plan details could be updated
            unregisterPlanChangedListener();
            /* Fixed DOGVT-244 - I get the attached message when I click Next on the Plan Details page */
            // DOGHR-1610 inconsistency error message between the UPMC and Highroads when Save an edited Plan
            // Avoid using length to retrieve certain metadata item, since right now metadata is dynamic after udf introduced
            var planName = $scope.planDetails['name'];
            if (planName == null) {
                planName = '';
            }
            var dataConverted = transformOutput();
            $log.log('non simplified submit data = ' + angular.toJson(dataConverted, true));
            dataConverted = getSimplifiedPostData(dataConverted, nonEqualStrs);
            $log.log('submit data = ' + angular.toJson(dataConverted, true));
            if (planId && planId.toString().length > 0) { // make sure Id is string if test length
                return ProductPlanMgmtSvc.updatePlan(dataConverted, planId).then(function(data) {
                    $scope.planDetails.planStatus = 'Draft'; // If the update successfully, the status can be expected to be draft
                    if (showMessage) {
                        var msgtitle;
                        var msg;
                        msgtitle = '';
                        msg = planName + ' updated successfully'; /* Fixed DOGVT-244 - I get the attached message when I click Next on the Plan Details page */

                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }

                    getLatestPlanToOri(false);

                    return data; // it is plan objectId
                }, function(reason) {
                    $log.log(reason);
                    return $q.reject(reason);
                }).then(function(planId) {
                    dataConverted.planStatus = 'Draft';
                    return updateCachedPlanL3(planId, dataConverted); // should return a promise
                    // updatePlanCostShareId(planId);  // SLQ1626 do not think this is necessary
                    // return planId;
                }).then(function() {
                    loadData();
                    $scope.planDetails.planStatus = 'Draft';
                })['finally'](function() { // same as .finally()
                    registerPlanChangedListener();
                });
            } else { // save  
                $log.error('Plan Id must be specified!');
                return $q.reject('Plan Id must be specified!');
            }
        }
        // End of saveOrUpdatePlan function

        // This one is not used by now
        // need to return promise
        // function updatePlanCostShareId(planId) { // SLQ1626 do not think this is necessary
        //     var associationExpansionLevel = 1;
        //     return ProductPlanMgmtSvc.getPlanDetails(planId, associationExpansionLevel)
        //         .then(function(data) {
        //                 // $scope.editPlan.loadedData.planLevel3 = data; // keep the loaded planDetails
        //                 // CostShareFacadeSvc.PlanExpandable3(data); // not need to put this in cache, also this is a level 1 data
        //                 updateMetadataSliderCostStharIdWithPlan(data); // note could cause slide dead
        //                 updatePlanCostShareOriginal(data);
        //             },
        //             function(reason) {
        //                 $log.log(reason);
        //             });
        // }

        // return a promise
        function updateCachedPlanL3(planId, simpleSentData) {
            return CostShareFacadeSvc.updateCachedPlanL3PropertyAndPlanCostShares(planId, simpleSentData);
        }

        // SLQ need a general place to save those value and then update them through some event automatically
        // After save, it will reload anything from cached plan details
        // function updatePlanCostShareOriginal(data) { 
        //     $scope.planCostSharesOriginal = data.planCostShares;
        // }

        var unregisterPlanChangedListenerFn = null;

        function registerPlanChangedListener() {
            $timeout(function() {
                // $log.log('>>>>> registerPlanChangedListener');
                if (!unregisterPlanChangedListenerFn) { // make sure only one listener registered
                    unregisterPlanChangedListenerFn = $scope.$watch('planDetails', function(newValue, oldValue) {
                        if (!newValue || !oldValue || newValue === oldValue) {
                            return;
                        }
                        $scope.componentStatus.isValidationEnabled = false;
                        $log.log('watchCollection planDetails: $scope.componentStatus.isValidationEnabled = ' + $scope.componentStatus.isValidationEnabled);
                    }, true);
                }
            }, 500);
        }

        function unregisterPlanChangedListener() {
            if (unregisterPlanChangedListenerFn) {
                // $log.log('>>>>> unregisterPlanChangedListener');
                unregisterPlanChangedListenerFn();
                unregisterPlanChangedListenerFn = null;
            }
        }

        registerPlanChangedListener();


        // Update split cost share names automatically
        $scope.$watchCollection('planDetails.productTiers.providerTierNames', function( /*newNames, oldNames*/ ) {
            $log.log('planDetails.productTiers.providerTierNames changed');

            angular.forEach($scope.productFieldsMetaData, function(field) {
                if (field.type === 'slider') {
                    angular.forEach($scope.costShares, function(csValue, csNameId) {
                        if ((csValue.selected) && (field.nameId === csNameId)) {

                            var id = genCostShareSplitId(field.nameId);
                            var tierNameIndex = (function indexOfTierNameInSplit(searchedSplitValues) {
                                var indexMap = {};
                                angular.forEach(searchedSplitValues, function(splitValue, idx) {
                                    indexMap[splitValue['tierName']] = idx;
                                });

                                return indexMap;
                            })($scope.planDetails[id]);

                            var count = 0;
                            field.children = [];
                            var newSplitValues = [];
                            angular.forEach($scope.planDetails['productTiers']['providerTierNames'], function(tierName) {
                                var child = {};
                                child['id'] = count.toString();
                                child['displayName'] = tierName;
                                child['parentId'] = field.nameId;
                                child['requiredField'] = false;
                                field.children.push(child);
                                // update user enter value (remove removed and add new with value as 0)
                                var index = tierNameIndex[tierName];
                                if (index >= 0) { // means that tier still exist
                                    newSplitValues.push($scope.planDetails[id][index]); // add it into new array
                                } else { // mean this is a new one
                                    newSplitValues.push({
                                        'tierName': tierName,
                                        'tierValue': 0
                                    });
                                }
                                count++;
                            });
                            $scope.planDetails[id] = newSplitValues;
                        }
                    });
                }
            });
        });
        // End of tier name change watch

        $scope.$watchCollection('planDetails.productTiers.providerTierNamesforDisplay', function(newValue, oldValue) {
            // if (newValue === oldValue) { // now the init is go first and when first init listener call, the newValue and oldValue are the same
            //     return;
            // } 

            if (numOfSelectedTierNames(newValue) === 0) {
                var msg = 'User must select at least one provider tier';
                QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
                $scope.planDetails.productTiers.providerTierNamesforDisplay = oldValue;
            } else {
                refreshTiersChanges(newValue);
            }
        });


        function refreshTiersChanges(selectedTiersForDisplay) {
            var fieldMetaInfo = $scope.productFieldsMetaDataMappedByNameId['productTiers'];
            var availableOptions = fieldMetaInfo.options;

            $scope.planDetails.productTiers.providerTierNames = [];
            $scope.planDetails.productTiers.providerTierDisplayNames = [];
            angular.forEach(availableOptions, function(option) {
                if (selectedTiersForDisplay[option.optionNameId]) {
                    $scope.planDetails.productTiers.providerTierNames.push(option.optionNameId);
                    $scope.planDetails.productTiers.providerTierDisplayNames.push(option.label);
                }
            });
        }

        function numOfSelectedTierNames(tierNames) {
            var num = 0;
            angular.forEach(tierNames, function(selectedValue) {
                if (selectedValue) {
                    num++;
                }
            });

            return num;
        }

        // add split info in field children and planDetails[xxxxx_split]
        $scope.splitCostShare = function(field) {
            var id = genCostShareSplitId(field.nameId);
            // checkbox is checked, need to show number input for each tier
            if ($scope.costShares[field.nameId].selected) { // $scope.costShares save split cost share name and if it is splitted
                if (isValidProductTiers()) {
                    // DOGHR-2149 if the array xxxxxxxx_split is not empty, the loadData will push duplicated item into this array.
                    $scope.planDetails[id] = [];

                    field.children = [];
                    var count = 0;
                    angular.forEach($scope.planDetails['productTiers']['providerTierNames'], function(tierName) {
                        var child = {};
                        child['id'] = count.toString();
                        child['displayName'] = tierName;
                        child['parentId'] = field.nameId;
                        child['requiredField'] = false;
                        field.children.push(child);
                        var tier = {};
                        tier['tierName'] = tierName;
                        tier['tierValue'] = 0;
                        $scope.planDetails[id].push(tier);
                        count++;
                    });
                } else {
                    var msg = 'Split ' + field.displayName + ' failed: invalid provider tier name(s).';
                    QueryDialog.open('Split Cost Share', msg, 'minus', 'ppm-modal-dialog-error');
                    $scope.costShares[field.nameId].selected = false;
                }
            } else { // checkbox is unchecked. remove all children
                if (!isNullOrUndefined($scope.planDetails[id])) {
                    delete $scope.planDetails[id];
                    field.children = null;
                }
            }
        };
        // End of splitCostShare function

        // product provider Tier name exist, and it name length > 0.
        // Plan provider should not have more tier than product one.
        function isValidProductTiers() {
            if ($scope.planDetails['productTiers']['providerTierNames'].length <= 0) {
                return false;
            } else {
                var valid = true;
                var count = 0;
                angular.forEach($scope.planDetails['productTiers']['providerTierNames'], function(item) {
                    if (item.length <= 0) {
                        valid = false;
                    }
                    count++;
                });
                if (count < $scope.planDetails['productTiers']['providerTierNames'].length) {
                    valid = false;
                }
                return valid;
            }
        }
        // End of isValidProductTiers function

        $scope.validationClick = function() {
            // unregister watch plan details because valudation or save could update plan details
            unregisterPlanChangedListener();

            if (!$scope.componentStatus.isValidationEnabled) {
                $log.log('validation skipped');
                return;
            }

            ProductPlanMgmtSvc.validatePlan($scope.planDetails.objectId).then(function(data) {
                // update plan status
                $scope.planDetails.planStatus = data.plan.planStatus;
                // show result
                var result = {
                    warnings: data.warnings,
                    errors: data.errors,
                    planName: data.plan.name,
                    validatedDate: data.validatedDate ? data.validatedDate : new Date(),
                    planId: data.plan.objectId,
                    planStatus: data.plan.planStatus
                };
                if (result.warnings.length === 0 && result.errors.length === 0) { // no error
                    var msgtitle = 'Success';
                    var msg = 'The plan is validated successfully';
                    ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                } else {
                    ValidationReportPageslideSvc.openPageslide('left', result, $scope)
                        .then(function() {
                            $scope.validationClick();
                        });
                }

            })['finally'](function() { // same as .finally()
                registerPlanChangedListener();
            });
        };

        $scope.nextClick = function() {
            // declairation parts
            var nonEqualStrs = {};

            function doSave() {
                setDefaultPlanYearValue();

                return saveOrUpdatePlan(nonEqualStrs, false);

            }

            function goNextPage() {
                $state.go('home.ppm.plan.edit.service-list', {
                    planId: $scope.planDetails.objectId
                });
            }

            // check mandatory field
            if (containAllMandatoryFields()) {
                $scope.hasError = false;
            } else {
                $scope.hasError = true;
                $log.log('Mandatory fields check not passed.');
                return;
            }
            $scope.validStatusNext = $scope.areTierNamesValid($scope.editedTierNameValid);

            if (!$scope.validStatusNext) {
                return;
            }

            // check if there is any changes
            $q.when(isSaving(nonEqualStrs))
                .then(function(savingIt) {
                    if (savingIt) {
                        return doSave();
                    }
                })
                .then(function() {
                    goNextPage();
                });
        };
        // End of nextClick function

        function updateMetadataSliderInfoWithProduct() {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (metadata.type === 'slider') {
                    var found = false;
                    angular.forEach($scope.productDetails.globalcostshares, function(costshare) {
                        if (metadata.displayName === costshare.costShareType) {
                            found = true;
                            metadata.options = angular.copy(costshare);
                            // how many numbers allowed after comma
                            metadata.options.round = 2;
                            metadata.options.splitByTier = 'true'; // decide if there's a checkbox
                            metadata.options['scaleOriginal'] = costshare.scale;
                            metadata.options.scale = calculateScaleArray(costshare);
                            delete metadata.options.name;
                            delete metadata.options.objectId;
                            $scope.planDetails[metadata.nameId] = costshare['default'];
                        }
                    });
                    // DOGHR-1286: convert array to object even if there's no global cost share info available in product, 
                    // to avoid next step format error
                    if (!found) {
                        $log.log('Global cost share not found in product: ' + metadata.nameId);
                        metadata.options = {};
                        $scope.planDetails[metadata.nameId] = 0;
                    }
                }
            });
        }
        // End of updateMetadataSliderInfoWithProduct function

        function updateMetadataSliderInfoWithPlan(pln) {
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (metadata.type === 'slider') {
                    angular.forEach(pln.planCostShares, function(costshare) {
                        if (metadata.displayName === costshare.costShareType) {
                            if (isNullOrUndefined(costshare.providerTier) || costshare.providerTier === 'NA') {
                                metadata.options = angular.copy(costshare);
                                // how many numbers allowed after comma
                                metadata.options.round = 2;
                                metadata.options.splitByTier = 'true'; // decide if there's a checkbox
                                metadata.options['scaleOriginal'] = costshare.scale;
                                metadata.options.scale = calculateScaleArray(costshare);
                                $scope.planDetails[metadata.nameId] = costshare['default'];
                            }
                        }
                    });
                }
            });
        }

        // This function is mainly to update plan cost share in metadata,
        // now after any saving we reloading whole thing from cached plan details so this one is not necessary 
        // function updateMetadataSliderCostStharIdWithPlan(pln) {
        //     angular.forEach($scope.productFieldsMetaData, function(metadata) {
        //         if (metadata.type === 'slider') {
        //             delete metadata.options.objectId; // delete old cost share object id
        //             angular.forEach(pln.planCostShares, function(costshare) {
        //                 if (metadata.displayName === costshare.costShareType) {
        //                     if (isNullOrUndefined(costshare.providerTier) || costshare.providerTier === 'NA') {

        //                         metadata.options.objectId = costshare.objectId;
        //                     }
        //                 }
        //             });
        //         }
        //     });
        // }
        // End of updateMetadataSliderInfoWithPlan function

        function calculateScaleArray(costshareObj) { // Input is an object
            var scaleArray = [];
            var from = parseInt(costshareObj.from, 10);
            var to = parseInt(costshareObj.to, 10);
            var scale = parseInt(costshareObj.scale, 10);
            if (scale > 0 && from >= 0 && to > 0 && from < to) {
                for (var i = from; i <= to; i = i + scale) {
                    scaleArray.push(i);
                }
            }
            return scaleArray;
        }
        // End of calculateScaleArray function

        $scope.isArray = function(data) {
            return angular.isArray(data);
        };

        function isNullOrUndefined(value) {
            if ((value === undefined) || (value === null)) {
                return true;
            } else {
                return false;
            }
        }

        $scope.tabClicked = function($event, tabName) {
            $event.preventDefault();
            setTab(tabName);
        };

        function setTab(tabName) {
            $log.log($scope.selectedTab + ' ---> ' + tabName);
            $scope.selectedTab = tabName;

            $state.go('home.ppm.plan.edit.plan-details.content', {
                tabName: $scope.selectedTab
            });
        }

        function retrieveCostShareObjectId(csType, providerTier) {
            var id;
            if (!isNullOrUndefined($scope.planCostSharesOriginal)) {
                angular.forEach($scope.planCostSharesOriginal, function(csInfo) {
                    if (csInfo.costShareType === csType && csInfo.providerTier === providerTier) {
                        id = csInfo.objectId;
                    }
                });
            }
            return id;
        }

        function containAllMandatoryFields() {
            function isInvalidString(data) {
                if (isNullOrUndefined(data)) {
                    return true;
                } else if (data === '') {
                    return true;
                } else {
                    return false;
                }
            }

            function isInvalidArray(data) {
                if (isNullOrUndefined(data)) {
                    return true;
                } else if (data.length < 1) {
                    return true;
                } else {
                    return false;
                }
            }

            function isCheckboxValueUnselected(data) {
                var allFalseValues = true;
                angular.forEach(data, function(value) {
                    if (value) {
                        allFalseValues = false;
                    }
                });
                return (allFalseValues);
            }

            function containInvalidValue(metadata) {
                var foundInvalidFields = false;
                angular.forEach(metadata, function(field) {
                    if (field.requiredField) {
                        if (field.multiple) { // drop down. dateRange, checkbox, text
                            if ((field.type === 'dateRange') && (field.nameId === 'effectiveDates')) {
                                if (isInvalidString($scope.planDetails[field.nameId]['endDate']) || isInvalidString($scope.planDetails[field.nameId]['effectiveDate'])) {
                                    foundInvalidFields = true;
                                }
                            } else if (field.type === 'checkbox') {
                                foundInvalidFields = isCheckboxValueUnselected($scope.planDetails[field.nameId]) || foundInvalidFields;
                            } else {
                                foundInvalidFields = isInvalidArray($scope.planDetails[field.nameId]) || foundInvalidFields;
                            }
                        } else { // text, radioButton, date
                            foundInvalidFields = isInvalidString($scope.planDetails[field.nameId]) || foundInvalidFields;
                        }
                    }
                });

                return foundInvalidFields;
            }

            var foundInvalidFields = containInvalidValue($scope.productFieldsMetaData) || containInvalidValue($scope.planFieldsMetaData);

            return (!foundInvalidFields);
        }

        $scope.providerTierChanged = function(nameId, label) {

            if ($scope.planDetails['productTiers']['providerTierNamesforDisplay'][nameId]) {
                return;
            }

            var title = 'Warning';
            var warningMessage = '<p>Deselecting provider tier(s) will delete the provider tier(s) and all associated cost share information from the plan. </p><p>Do you want to continue?</p>';

            var modalInstance = QueryDialog.open(title, warningMessage, 'question', 'ppm-modal-dialog-question');

            modalInstance.result.then(function() {
                $log.log('Provider tier removed:' + label);
            }, function() {
                $scope.planDetails['productTiers']['providerTierNamesforDisplay'][nameId] = true;
                $log.log('Warning modal dismissed for provider tier removal: ' + label);
            });
        };

        $scope.showPlanSummaryDialog = function() {
            planPreviewSvc.previewPlan(planId);
        };

        $scope.viewValidationHistory = function() {
            ProductPlanMgmtSvc.getValidationHistory($scope.planDetails.objectId).then(function(data) {

                angular.forEach(data, function(record) {
                    record.eventDetails = JSON.parse(record.eventDetails);
                    record.show = false; // add to validation history for show/hide
                    record.creationDate = new Date(record.creationDate);
                });

                var result = {};
                result.validationHistory = data;
                result.planName = $scope.planDetails['name'];

                ValidationReportPageslideSvc.openHistoryPageslide('left', result, $scope);
            });
        };

        $scope.displayCostShareErrorMsgFlag = function(csName) {
            var flag = false;
            var splitId = genCostShareSplitId(csName);
            // check splitted values
            angular.forEach($scope.planDetails[splitId], function(item) {
                if (item.tierValue === null) {
                    flag = true;
                }
                if (!flag && (item.tierValue < 0)) {
                    flag = true;
                }
                if (!flag && (item.tierValue > 100) && (csName === 'coinsurance')) {
                    flag = true;
                }
            });

            // check global cost shares 
            if (flag || !$scope.productFieldsMetaDataMappedByNameId[csName].show) {
                return flag;
            }
            var globalValue = parseFloat($scope.planDetails[csName]);
            if (globalValue < 0) {
                flag = true;
            } else if (globalValue > 100 && csName === 'coinsurance') {
                flag = true;
            }
            return flag;
        };

        $scope.displayCostShareErrorMsg = function(csName) {
            var message = '';
            var flag = $scope.displayCostShareErrorMsgFlag(csName);
            if (flag) {
                if (csName === 'copay') {
                    message = 'Copay amount cannot be less than $0';
                } else if (csName === 'coinsurance') {
                    message = 'Coinsurance amount must be greater than or equal 0% and less than or equal 100%';
                } else if (csName.toLowerCase().indexOf('deductible') !== -1) {
                    message = 'Deductible amount cannot be less than $0';
                } else if (csName.toLowerCase().indexOf('moop') !== -1) {
                    message = 'MOOP amount cannot be less than $0';
                }
            }
            return message;
        };

        function validateAllCostShares() {
            var isValid = true;
            // check global cost shares
            angular.forEach($scope.productFieldsMetaData, function(metadata) {
                if (isValid && (metadata.type === 'slider') && metadata.show) {
                    isValid = isValid && !$scope.displayCostShareErrorMsgFlag(metadata.nameId);
                }
            });

            if (!isValid) {
                var msg = 'Unable to create the Plan because you’ve entered one or more invalid Cost Share amounts. Change any Copay or Deductible amount &lt; $0 and any Coinsurance amount &lt; 0% or &gt; 100%.';
                QueryDialog.open('Create Plan', msg, 'minus', 'ppm-modal-dialog-error');
            }
            return isValid;
        }

        // check the cost share exist and set limit/exception and accumulationType
        function checkCostShareExistance() {
            var list = ['pharmacyAnnualMoopLimitsAndExceptions', 'pharmacyAnnualSecondaryMoopLimitsAndExceptions',
                'pharmacyAnnualDeductibleLimitsAndExceptions', 'pharmacyDeductibleAccumulationType',
                'dentalAnnualMoopLimitsAndExceptions', 'dentalAnnualSecondaryMoopLimitsAndExceptions',
                'dentalAnnualDeductibleLimitsAndExceptions', 'dentalDeductibleAccumulationType',
                'visionAnnualMoopLimitsAndExceptions', 'visionAnnualSecondaryMoopLimitsAndExceptions',
                'visionAnnualDeductibleLimitsAndExceptions', 'visionDeductibleAccumulationType',
                'medicalAnnualMoopLimitsAndExceptions', 'medicalAnnualSecondaryMoopLimitsAndExceptions',
                'medicalAnnualDeductibleLimitsAndExceptions', 'medicalDeductibleAccumulationType'
            ];

            var isMetadataMissing = false;
            angular.forEach(list, function(item) {
                if (isNullOrUndefined($scope.productFieldsMetaDataMappedByNameId[item])) {
                    isMetadataMissing = true;
                }
            });

            if (!isMetadataMissing) {

                angular.forEach(list, function(item) {
                    $scope.productFieldsMetaDataMappedByNameId[item].show = false;
                });

                angular.forEach($scope.productFieldsMetaData, function(item) {
                    if (item.type === 'slider' && item.show) {
                        if (item.nameId.indexOf('pharmacy') !== -1) {
                            if (item.nameId.indexOf('Moop') > 0) {
                                $scope.productFieldsMetaDataMappedByNameId['pharmacyAnnualMoopLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['pharmacyAnnualSecondaryMoopLimitsAndExceptions'].show = true;
                            } else {
                                $scope.productFieldsMetaDataMappedByNameId['pharmacyAnnualDeductibleLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['pharmacyDeductibleAccumulationType'].show = true;
                            }
                        } else if (item.nameId.indexOf('dental') !== -1) {
                            if (item.nameId.indexOf('Moop') > 0) {
                                $scope.productFieldsMetaDataMappedByNameId['dentalAnnualMoopLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['dentalAnnualSecondaryMoopLimitsAndExceptions'].show = true;
                            } else {
                                $scope.productFieldsMetaDataMappedByNameId['dentalAnnualDeductibleLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['dentalDeductibleAccumulationType'].show = true;
                            }
                        } else if (item.nameId.indexOf('vision') !== -1) {
                            if (item.nameId.indexOf('Moop') > 0) {
                                $scope.productFieldsMetaDataMappedByNameId['visionAnnualMoopLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['visionAnnualSecondaryMoopLimitsAndExceptions'].show = true;
                            } else {
                                $scope.productFieldsMetaDataMappedByNameId['visionAnnualDeductibleLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['visionDeductibleAccumulationType'].show = true;
                            }
                        } else if (item.nameId.indexOf('medical') !== -1) { // medical
                            if (item.nameId.indexOf('Moop') > 0) {
                                $scope.productFieldsMetaDataMappedByNameId['medicalAnnualMoopLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['medicalAnnualSecondaryMoopLimitsAndExceptions'].show = true;
                            } else {
                                $scope.productFieldsMetaDataMappedByNameId['medicalAnnualDeductibleLimitsAndExceptions'].show = true;
                                $scope.productFieldsMetaDataMappedByNameId['medicalDeductibleAccumulationType'].show = true;
                            }
                        }
                    }
                });

                // set the value to null if it has string value before.
                // maybe we need the modify the show value in the ppm-show directive and watch on that value.
                // or remove them when do a transfer
                angular.forEach(list, function(item) {
                    if (!$scope.productFieldsMetaDataMappedByNameId[item].show) {
                        $scope.planDetails[item] = null;
                    }
                });
            }
        }

        // if 2 of Accumulation Type displayed, then this isDeductibleAmountsCombinedOrSeparate should be displayed
        // one accumulation type mapping to one product classes, but the problem is that product costshare type has also 
        // related if its product has this costshare defined.
        function setIsDeductibleAmountsCombinedOrSeperated() {
            var list = ['pharmacyDeductibleAccumulationType', 'dentalDeductibleAccumulationType',
                'visionDeductibleAccumulationType', 'medicalDeductibleAccumulationType'
            ];
            if (isNullOrUndefined($scope.productFieldsMetaDataMappedByNameId['isDeductibleAmountsCombinedOrSeparate'])) {
                return;
            } else {
                $scope.productFieldsMetaDataMappedByNameId['isDeductibleAmountsCombinedOrSeparate'].show = false;

                var found = 0;
                angular.forEach(list, function(item) {
                    if ($scope.productFieldsMetaDataMappedByNameId[item].show) {
                        found++;
                    }
                });
                if (found >= 2) {
                    $scope.productFieldsMetaDataMappedByNameId['isDeductibleAmountsCombinedOrSeparate'].show = true;
                } else {
                    $scope.planDetails.isDeductibleAmountsCombinedOrSeparate = null;
                }

                // angular.forEach($scope.productFieldsMetaData, function(item) {
                //     if (!found && item.type === 'slider' && item.show && item.nameId.indexOf('Deductible') !== -1) {
                //         found = true;
                //     }
                // });
                // if (found) {
                //     $scope.productFieldsMetaDataMappedByNameId['isDeductibleAmountsCombinedOrSeparate'].show = true;
                // } else {
                //     $scope.planDetails.isDeductibleAmountsCombinedOrSeparate = null;
                // }
            }

        }

        function setupModel() {
            $scope.planDetails['linkedProducts'] = [];
            $scope.planDetails['planStatus'] = 'Draft';
            angular.forEach($scope.productFieldsMetaData, function(metadata) { // fieldsMetaData is array, and value is object
                if (!metadata.multiple) {
                    if (!$scope.planDetails[metadata.nameId]) {
                        $scope.planDetails[metadata.nameId] = null;
                    }
                    if (metadata.type === 'slider') {
                        var found = false;
                        // how many numbers allowed after comma
                        metadata.options.round = 2;
                        angular.forEach(metadata.options, function(opt) {
                            if (opt.optionNameId === 'default') {
                                $scope.planDetails[metadata.nameId] = opt.label;
                                found = true;
                            }
                        });
                        if (!found) {
                            $scope.planDetails[metadata.nameId] = 0;
                        }
                    }
                } else {
                    if (!$scope.planDetails[metadata.nameId]) {
                        $scope.planDetails[metadata.nameId] = {};
                    }
                    // For special type:
                    if (metadata.type === 'tiers') { // Setup structure to avoid null exception
                        if (!$scope.planDetails[metadata.nameId]['providerTierNames']) {
                            $scope.planDetails[metadata.nameId]['providerTierNames'] = [];
                        }
                        if (!$scope.planDetails[metadata.nameId]['providerTierNamesforDisplay']) {
                            $scope.planDetails[metadata.nameId]['providerTierNamesforDisplay'] = {};
                        }
                    }
                    if (metadata.type === 'text') {
                        $scope.planDetails[metadata.nameId] = [];
                    }
                }
            });
            angular.forEach($scope.planFieldsMetaData, function(metadata) { // fieldsMetaData is array, and value is object
                if (!metadata.multiple) {
                    if (!$scope.planDetails[metadata.nameId]) {
                        $scope.planDetails[metadata.nameId] = null;
                    }
                } else {
                    if (!$scope.planDetails[metadata.nameId]) {
                        $scope.planDetails[metadata.nameId] = {};
                    }
                    if (metadata.type === 'dropdown') {
                        $scope.planDetails[metadata.nameId] = [];
                    }
                }
            });
            setTab('sdf');
        }

        init();
    });