'use strict';

angular.module('p2AdvanceApp')
    .controller('ProductCostShareCtrl', function($rootScope, $scope, $state, $stateParams, $window, ENV, localStorageService, productL3, /* jshint ignore:line */
        ProductCostShareFacadeSvc, ConfirmationModalFactory, $timeout, ProductPlanMgmtSvc, ValidationReportPageslideSvc,
        CostShareFieldsMetaData, ValidationCostShareSvc, $q, PpmFullEqual, $location, $log, QueryDialog, $parse, $filter) {

        $scope.debugMode = (ENV.name === 'local');

        $scope.productServiceFieldsMetaData = CostShareFieldsMetaData.attributes;

        $scope.product = angular.copy(productL3);
        $scope.initServiceId = $stateParams.serviceId; // if go through saveAndContinue, this will be undefined. Otherwise, an id.
        $scope.associatedServices = []; // really set value in init() // ProductCostShareFacadeSvc.associatedServices(); // This value is set when switch from service list; 
        $scope.associatedServicesOri = []; //angular.copy($scope.associatedServices);
        $scope.editServiceIndex = 0; // getServiceIndexByInitServiceId(); // actually init in list on event 'ProductCostShareFacadeSvc.associatedServices.changed'
        $scope.selectedTier = 'properties'; // will be updated in init()
        $scope.shownTiersNameOnCostShareTab = []; // initilized in init()
        $scope.tierDisplayNameToName = {}; // initialized in init();
        $scope.costshareTypes = ['Copay', 'Co-insurance', 'Deductible', 'Limits and Exceptions'];
        // This value should be loaded from backend as metadata in the future
        $scope.quantityBasisOptions = ['Per Year', 'Per Confinement', 'Visits Per Year', 'Visits Per Plan Year',
            'Days Supply', 'Per Visit', 'Per Admission', 'Per Day', 'Per Ear', 'Per Emergency Department Visit',
            'Per Inpatient Stay', 'Per Item', 'Per Item, If Applicable', 'Per Outpatient Surgery', 'Minimum', 'Maximum',
            'Per Prescription', 'Per Trip', 'Per Encounter', 'Per Procedure'
        ];
        //  $scope.inputTypes = 'Values';
        $scope.costShareValueInputs = 5;
        $scope.inputValidation = false;
        $scope.inputValuesName = '';
        $scope.rangeValidation = false;
        // It is better to move this to a angular constant in future
        var providerTierNamesOrder = [
            'Preferred Network 1',
            'Preferred Network 2',
            'Preferred Network 3',
            'In Network',
            'Out of Network',
            'Out of Area',
            'Out of Country',
            'Coverage'
        ];

        $scope.savingHook.action = function() {
            $scope.save();
        };
        // before destory the scope, make sure the hooker is removed so that this memory can be released
        $scope.$on('$destroy', function() {
            $scope.savingHook.action = null;
        });

        $scope.componentStatus = {
            isValidationEnabled: true,
            isSaveEnabled: true
        };
        $scope.fieldsErrorStatus = {};

        $scope.isSvcListEmpty = false;

        $scope.previousService = function() {
            $scope.foundError = false;
            validateCostShareValues();
            if ($scope.foundError === true) {
                $log.log('Range values not entered');
                return;
            }

            $q.when(isEqual())
                .then(function(isSame) {
                    if (!isSame) {
                        // save it
                        return doSave();
                    }
                })
                .then(function() {
                    // previous service
                    navService(--$scope.editServiceIndex);
                    ProductCostShareFacadeSvc.populateCurrentProductServiceCostSharesIfNotDoneAllready($scope.associatedServices[$scope.editServiceIndex]);
                });
            //}
        };

        $scope.nextService = function() {
            $scope.foundError = false;
            validateCostShareValues();
            if ($scope.foundError === true) {
                $log.log('Range values not entered');
                return;
            }
            $q.when(isEqual())
                .then(function(isSame) {
                    if (!isSame) {
                        // save it
                        return doSave();
                    }
                }).then(function() {
                    // next service
                    navService(++$scope.editServiceIndex);
                    ProductCostShareFacadeSvc.populateCurrentProductServiceCostSharesIfNotDoneAllready($scope.associatedServices[$scope.editServiceIndex]);
                });
            //}
        };

        /* function displayCostShareErrorMsg() {
             var msg = 'Unable to create the Plan because you’ve entered one or more invalid Cost Share amounts. Change any Copay or Deductible amount &lt; $0 and any Coinsurance amount &lt; 0% or &gt; 100%.';
             QueryDialog.open('Create Plan', msg, 'minus', 'ppm-modal-dialog-error');
         }*/

        function navService(serviceIndex) {
            $scope.editServiceIndex = (serviceIndex + $scope.associatedServices.length) % $scope.associatedServices.length;
            // $scope.selectedTier = 'properties'; // this is updated in the setTab()
            showDefaultTab();
        }

        function doSave() {
            cleanupCostShareInfoBasedOnLevelSelection();
            var associatedServices = $scope.associatedServices[$scope.editServiceIndex];
            var productId = $scope.product.objectId;
            unregisterProductCostShareChangedListener();
            return ProductCostShareFacadeSvc.updateEditProductService(associatedServices, productId, $scope.productServiceFieldsMetaData)
                .then(function() {
                    $scope.product.productStatus = 'Draft'; // If the save successfully, the status can be expected to be draft
                    getAssociatedServicesToOri($scope.editServiceIndex);
                    $scope.componentStatus.isValidationEnabled = true;
                });
        }

        function validateCostShareValues() {
            $scope.validationMsgTracker = {};
            $scope.foundError = false;
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var currentTierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                var currentTierCostShares = service.productSvcJointProps.costShares[currentTierName];
                if (currentTierCostShares) {
                    angular.forEach(currentTierCostShares, function(csInfo, csName) {
                        $scope.validationMsgTracker[csName] = {};
                        angular.forEach(csInfo, function(levelInfo) {
                            if (levelInfo.inputTypes === 'Range') {
                                $scope.validationMsgTracker[csName][levelInfo.providerTier] = {};
                                $scope.validationMsgTracker[csName][levelInfo.providerTier][levelInfo.costShareLevel] = {};
                                $scope.validationMsgTracker[csName][levelInfo.providerTier][levelInfo.costShareLevel]['showError'] = false;
                                $scope.validationMsgTracker[csName][levelInfo.providerTier][levelInfo.costShareLevel]['showLimitsValidation'] = false;
                                $scope.validationMsgTracker[levelInfo.costShareLevel] = {};
                                if (!isNotNullAndUndefined(levelInfo.from) || !isNotNullAndUndefined(levelInfo.min) || !isNotNullAndUndefined(levelInfo.max) ||
                                    !isNotNullAndUndefined(levelInfo.to) || !isNotNullAndUndefined(levelInfo.step) || !isNotNullAndUndefined(levelInfo.scale) || !isNotNullAndUndefined(levelInfo['default'])) {
                                    $scope.validationMsgTracker[csName][levelInfo.providerTier][levelInfo.costShareLevel]['showError'] = true;
                                    $scope.foundError = true;
                                }
                                validateLimitsAndExceptions(levelInfo, csName);
                            }
                        });
                    });
                }
            }
        }

        function validateLimitsAndExceptions(levelInfo, csName) {
            if (levelInfo.costShareType === 'Limits and Exceptions' && levelInfo.format === '%') {
                if ((isNotNullAndUndefined(levelInfo.from) && levelInfo.from < 0) || (isNotNullAndUndefined(levelInfo.to) && levelInfo.to > 100)) {
                    $scope.validationMsgTracker[csName][levelInfo.providerTier][levelInfo.costShareLevel]['showLimitsValidation'] = true;
                    $scope.foundError = true;
                }
            }
        }

        $scope.save = function() {
            $scope.foundError = false;
            if (isEqual()) {
                $scope.componentStatus.isValidationEnabled = true;
                return;
            }
            validateCostShareValues();
            if ($scope.foundError === true) {
                $log.log('Range values not entered');
                return;
            }

            doSave();
        };

        $scope.tabClicked = function($event, tabName) {
            $scope.tierCoveredStatus.applyThisDefToOtherTiers = false;
            $event.preventDefault();
            $event.stopPropagation();
            if (!$scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.isCovered) {
                return; // do not know disabled nav bar still work while click
            }
            setTab(tabName);
        };

        $scope.loadTierCostShareFromProduct = function() {
            $log.log('$scope.tierCoveredStatus.isCovered = ' + $scope.tierCoveredStatus.isCovered);
            if ($scope.tierCoveredStatus.isCovered) {
                // $log.log('Already covered');
                return;
            }
            $log.log('load service index = ' + $scope.editServiceIndex + ' and tier name = ' + $scope.selectedTier);
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var serviceId = service.objectId;
            var linkedProductServiceId = service.productSvcJointProps.linkedProductServiceId;
            var tierName = $scope.selectedTier;
            var productId = $scope.product.objectId;
            ProductCostShareFacadeSvc.loadTierCostShare(productId, serviceId, linkedProductServiceId, tierName);
        };

        $scope.clearValues = function(value, levelInfo) {
            $log.log($scope.associatedServices);

            if (value === 'Values') {
                for (var i = 0; i < levelInfo.rangeValues.length; i++) {
                    levelInfo.rangeValues[i] = '';
                }

            } else if (value === 'Range') {
                delete(levelInfo.min);
                delete(levelInfo.max);
                delete(levelInfo.from);
                delete(levelInfo.to);
                delete(levelInfo.scale);
                delete(levelInfo.step);
                delete(levelInfo['default']);

            }
        };


        $scope.tierNotCovered = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                delete service.productSvcJointProps.costShares[tierName];
            }
        };

        $scope.serviceCovered = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.productSvcJointProps.isCovered) {
                // $log.log('Already covered');
                return;
            }
            service.productSvcJointProps.costShares = {};
            // $log.log('load service name = ' + service.name);
            var serviceId = service.objectId;
            var linkedProductServiceId = service.productSvcJointProps.linkedProductServiceId;
            var productId = $scope.product.objectId;
            ProductCostShareFacadeSvc.loadServiceCostShareOfProduct(productId, serviceId, linkedProductServiceId);
        };

        $scope.serviceNotCovered = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                delete service.productSvcJointProps.costShares;
            }
        };

        function getAssociatedServicesToOri(svcIdx) {
            var fully = arguments.length === 0;
            $timeout(function() {
                // $log.log('%%%%%% renew costshare ori serviceIdx = ' + svcIdx);
                if (fully) {
                    $scope.associatedServicesOri = cleanupCostShareInfoBasedOnLevelSelection(angular.copy($scope.associatedServices));
                } else {
                    $scope.associatedServicesOri[svcIdx] = cleanupCostShareInfoBasedOnLevelSelection(angular.copy($scope.associatedServices))[svcIdx];
                }
            }, 100);
        }

        function isEqual() {
            var wideAcceptedFalse = {
                customEqual: function(o1, o2 /*, propertyName, level*/ ) {
                    return Boolean(o1) === Boolean(o2);
                }
            };

            var config = { // setup configuration
                'value.arrCfg.productSvcJointProps.costShares.*.*.*.applyToMaxOutPocket': wideAcceptedFalse,
                'value.arrCfg.productSvcJointProps.costShares.*.*.*.applyToDeduct': wideAcceptedFalse,
                'value.arrCfg.productSvcJointProps.costShares.*.*.*.preCertificationRqrd': wideAcceptedFalse
            };
            var equalSvc = new PpmFullEqual(config);
            var curValue = cleanupCostShareInfoBasedOnLevelSelection(angular.copy($scope.associatedServices));
            curValue = curValue[$scope.editServiceIndex]; // we only care the current service's cost share
            var oriValue = $scope.associatedServicesOri[$scope.editServiceIndex];
            var compResult = {};
            var isSame = equalSvc.equals(curValue, oriValue, compResult); // rebase need some changes
            //  $log.log('########## Nothing changed: ' + isSame);
            return isSame;
        }

        $scope.backServiceList = function() {
            ValidationCostShareSvc.associatedServices($scope.associatedServices);
            // if (ValidationCostShareSvc.validateMemberCostSharesOfSingleService($scope.editServiceIndex)) {
            //     $log.log('!!!Warning: Cost share validation not passed.');
            //     displayCostShareErrorMsg();
            //     return;
            // } else {
            $q.when(isEqual())
                .then(function(isSame) {
                    if (!isSame) {
                        // save it
                        return doSave();
                    }
                })
                .then(function() {
                    $window.history.back();
                });
            //}
        };

        $scope.$on('$stateChangeSuccess',
            function(event, toState, toParams, fromState, fromParams) {
                $log.log(toState.name + ' <-- ' + fromState.name);
                $log.log(toState.url + ' <-- ' + fromState.url);
                $log.log(angular.toJson(toParams, true));
                $log.log(angular.toJson(fromParams, true));
                if ((fromState.name.indexOf('home.ppm.product.edit.cost-share.details') === 0 || fromState.name === 'home.ppm.product.edit.cost-share') && toState.name.indexOf('home.ppm.product.edit.cost-share.details') === 0) {
                    $location.replace(); //clear last history route
                }
            });

        $scope.$on('ProductCostShareFacadeSvc.associatedServices.changed', function(event, args) {
            $log.log('ProductCostShareFacadeSvc.associatedServices.changed handled');
            $log.log(event);
            $log.log(args);
            if (!$scope.associatedServices.length) {
                $scope.isSvcListEmpty = true;
            } else {
                $scope.isSvcListEmpty = false;
            }
            $scope.associatedServices = args.associatedSvcs;
            transformAssociatedServices();

            if (args.isInitLoad) {
                $scope.editServiceIndex = getServiceIndexByInitServiceId(); // Note: must put after service list is populated
                getAssociatedServicesToOri(); // must put here, called after saving to update original one
                showDefaultTab();
            }
            ProductCostShareFacadeSvc.populateCurrentProductServiceCostSharesIfNotDoneAllready($scope.associatedServices[$scope.editServiceIndex]);

            registerProductCostShareChangedListener();
            if ($scope.isSvcListEmpty) {
                $scope.buildFieldTypeList();
            }
        });

        $scope.$on('ProductCostShareFacadeSvc.associatedServices.OneCostShares.Loaded', function(event, args) {
            $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.costShares = args;
            transformAssociatedServices();
            getAssociatedServicesToOri();
        });

        $scope.$on('ProductCostShareFacadeSvc.tierCostShares.loaded', function( /*event, args*/ ) {
            $log.log('ProductCostShareFacadeSvc.tierCostShares.loaded handled');
            updateTierCoverStatus();
            getTierPreCertificationRequiredValue();
            getCostShareLevelValues();
            updateCostShareTypeList();
        });

        $scope.$on('ppm.input.validation.error', function(event, args) {
            event.stopPropagation();
            if (args.hasError) {
                $scope.fieldsErrorStatus[args.id] = true;
            } else {
                delete $scope.fieldsErrorStatus[args.id];
            }
            $scope.componentStatus.isSaveEnabled = angular.equals($scope.fieldsErrorStatus, {});
        });

        $scope.$watch('associatedServices[editServiceIndex].productSvcJointProps.costShares[selectedTier]', function(newValue, oldValue) {
            if (newValue === oldValue) {
                return;
            }

            $log.log('associatedServices[editServiceIndex].productSvcJointProps.costShares[selectedTier] changed');
            if ($scope.selectedTier !== 'properties' && $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.costShares) { // just avoid exception
                $log.log('and value = ' + $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.costShares[$scope.selectedTier]);
            }
            updateTierCoverStatus();
            getTierPreCertificationRequiredValue();
            getCostShareLevelValues();
            updateCostShareTypeList();
        });

        var unregisterProductCostShareChangedListenerFn = null;

        function registerProductCostShareChangedListener() {
            $timeout(function() {
                $log.log('registerProductCostShareChangedListener');
                if (!unregisterProductCostShareChangedListenerFn) { // make sure only one listener registered
                    unregisterProductCostShareChangedListenerFn = $scope.$watch('associatedServices', function(newValue, oldValue) {
                        if (!newValue || !oldValue || newValue === oldValue) {
                            return;
                        }
                        $scope.componentStatus.isValidationEnabled = false;
                        $log.log('watchCollection associatedServices: $scope.componentStatus.isValidationEnabled = ' + $scope.componentStatus.isValidationEnabled);
                    }, true);
                }
            }, 1000);
        }

        function unregisterProductCostShareChangedListener() {
            $log.log('unregisterProductCostShareChangedListener');
            if (unregisterProductCostShareChangedListenerFn) {
                // $log.log('>>>>> unregisterProductChangedListener');
                unregisterProductCostShareChangedListenerFn();
                unregisterProductCostShareChangedListenerFn = null;
                $log.log('unregisterProductCostShareChangedListener -- 2');
            }
        }

        function setTab(tabName) {
            // Current model, we have 2 set of name in the product, internal name and display name, display name could be 
            // changed by user, but internal name is not. The product tier name is come from product, the internal tier 
            // name is the same between product and product, but display name also could be different. 
            // Currently there are 8 tier name, the internal name sequence/order is alway keep the same in product and product.
            // We suppose that the provider tier internal names list is always the same as the cost share provider tier's name.
            $scope.selectedTier = $scope.tierDisplayNameToName[tabName];

            if (tabName === 'properties') { // "properties" is a special tab, and it is hard coded in html file
                $scope.selectedTier = tabName;
            } else {
                updateTierCoverStatus();
            }

            $log.log(tabName + ' ---> ' + $scope.selectedTier);

            $state.go('home.ppm.product.edit.cost-share.details', {
                tierName: $scope.selectedTier,
                svcIdx: $scope.editServiceIndex
            });
        }

        function showDefaultTab() {
            var defaultTab = $scope.shownTiersNameOnCostShareTab.length > 0 ? $scope.shownTiersNameOnCostShareTab[0] : 'properties';
            if (!$scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.isCovered) {
                defaultTab = 'properties'; // because all other tab are disabled
            }
            setTab(defaultTab);
        }

        function updateTierCoverStatus() {
            $timeout(function() {
                $scope.tierCoveredStatus.isCovered = (!!$scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.costShares) &&
                    (!!$scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.costShares[$scope.selectedTier]);
                $log.log('$scope.tierCoveredStatus.isCovered = ' + $scope.tierCoveredStatus.isCovered);
            });
        }

        // temp values for next sprint use
        $scope.tierCoveredStatus = { // Use the object instead of simple value. Updated automation when switch the tier
            isCovered: false,
            isPreCertificationRequired: false,
            applyThisDefToOtherTiers: false,
            costshareLevels: {},
            addCostShareList: []
        };

        $scope.addSingleCostShare = function(costshareType) {
            var index = -1;
            angular.forEach($scope.tierCoveredStatus.addCostShareList, function(csItem, csKey) {
                if (csItem === costshareType) {
                    index = csKey;
                }
            });
            if (index > -1) {
                var service = $scope.associatedServices[$scope.editServiceIndex];
                var serviceId = service.objectId;
                var linkedProductServiceId = service.productSvcJointProps.linkedProductServiceId;
                var tierName = $scope.selectedTier;
                var productId = $scope.product.objectId;
                var preCertStatus = $scope.tierCoveredStatus.isPreCertificationRequired;
                var moopStatus = $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.isApplyToMOOP;
                var deductibleStatus = $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.isApplyToDeductibles;
                ProductCostShareFacadeSvc.loadSingleTierCostShareFromProduct(productId, serviceId, linkedProductServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus);

                $scope.tierCoveredStatus.addCostShareList.splice(index, 1);
            }
        };

        function transformAssociatedServices() {
            angular.forEach($scope.associatedServices, function(service) {
                // For newly added service, limitsAndException can not be empty array.
                if (service.productSvcJointProps.serviceException === undefined) {
                    service.productSvcJointProps['serviceException'] = '';
                }
                angular.forEach(service.productSvcJointProps.costShares, function(tierInfo) { // out of network
                    angular.forEach(tierInfo, function(csInfo) { // copay
                        angular.forEach(csInfo, function(levelInfo) { // primary
                            if (levelInfo.rangeValues) {
                                levelInfo.rangeValues = levelInfo.rangeValues.filter(function(n) {
                                    return n !== null && n !== '' && n !== undefined;
                                });
                            }
                            if (!levelInfo.severityLevel) {
                                levelInfo.severityLevel = 'Warning';
                            }
                            if (!levelInfo.rangeValues || levelInfo.rangeValues.length === 0) {
                                levelInfo.inputTypes = 'Range';
                                levelInfo.rangeValues = getCostshareInputArray($scope.costShareValueInputs);
                            } else {
                                //push empty values to make sure by default 5 input boxes get added

                                levelInfo.inputTypes = 'Values';
                                var rangeLength = levelInfo.rangeValues.length;
                                if (rangeLength < $scope.costShareValueInputs) {
                                    for (var i = 0; i < $scope.costShareValueInputs - rangeLength; i++) {
                                        levelInfo.rangeValues.push('');
                                    }
                                }
                            }
                        });
                    });
                });
            });

            transformUdf();
        }

        function isNotNullAndUndefined(value) {
            if ((value !== undefined) && (value !== null) && (value !== '')) {
                return true;
            } else {
                return false;
            }
        }

        $scope.buildFieldTypeList = function() {
            var fieldTypes = {};
            var checkBoxCollection = [];

            $scope.disabler = [];

            angular.forEach($scope.productServiceFieldsMetaData, function(field) {
                if (field.nameId.toString().indexOf('udfproductservice_') === -1 && field.type !== 'hrCheckBox') {
                    fieldTypes[field.type] = field;
                    boolBuilder(field.type, field);
                } else if (field.nameId.toString().indexOf('udfproductservice_') === -1) {
                    checkBoxCollection.push(field);
                }
            });
            fieldTypes['hrCheckBox'] = checkBoxCollection;
            $scope.fieldTypesList = fieldTypes;
        };

        (function init() {
            // get cost share from product, update view list via event and save it to backend
            ProductCostShareFacadeSvc.updateProductWithCostShares($stateParams.productId);
            $scope.tierDisplayNameToName = getTierDisplayNameToNameMap();
            $scope.shownTiersNameOnCostShareTab = getTierDisplayNameInGivenOrder();
            // showDefaultTab();  // move to data loaed event, because at this time, costshare service is not successfully loaded
        })();

        function getTierDisplayNameToNameMap() {
            // Before We are use loaed Product, and it structure is a little difference from screen data structure 
            // due to history, so comment out following 2 lines
            // var displayNameList = $scope.product.productTiers.providerTierDisplayNames;
            // var nameList = $scope.product.productTiers.providerTierNames;
            var displayNameList = $scope.product.providerTierDisplayNames;
            var nameList = $scope.product.providerTierNames;

            var map = {};
            angular.forEach(displayNameList, function(displayName, index) {
                map[displayName] = nameList[index];
            });

            return map;
        }

        function getTierDisplayNameInGivenOrder() {
            var shownTiersNameOnCostShare = [];
            // providerTierNamesOrder is the internal name, not display name
            angular.forEach(providerTierNamesOrder, function(tierName /*, index*/ ) {
                var indexInProductTierNames = $scope.product.providerTierNames.indexOf(tierName);
                if (indexInProductTierNames >= 0) {
                    shownTiersNameOnCostShare.push($scope.product.providerTierDisplayNames[indexInProductTierNames]); // tier names and tier display name are always in the same order in product
                }
            });

            return shownTiersNameOnCostShare;
        }

        $scope.tierPreCertificationRequiredChanged = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                angular.forEach(service.productSvcJointProps.costShares[tierName], function(csInfo) {
                    angular.forEach(csInfo, function(levelInfo) {
                        levelInfo.preCertificationRqrd = $scope.tierCoveredStatus.isPreCertificationRequired;
                    });
                });
            }
            var servicePreCertificationRequired = !!service.productSvcJointProps.preCertificationRequired;
            var tierPreCertificationRequired = !!$scope.tierCoveredStatus.isPreCertificationRequired;
            // display warning when tier level value is not the same as service level value 
            if (servicePreCertificationRequired !== tierPreCertificationRequired) {
                var msg = 'This value is not the same as the one under service properties.';
                QueryDialog.open('Pre-Certification Required', msg, 'warning', 'ppm-modal-dialog-warning');
            }
        };

        $scope.applyThisDefToOtherTiersChanged = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var currentTierName = $scope.selectedTier;
            if ($scope.tierCoveredStatus.applyThisDefToOtherTiers) {
                var costShares = {};
                if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                    var currentTierCostShare = service.productSvcJointProps.costShares[currentTierName];
                    costShares[currentTierName] = currentTierCostShare;

                    angular.forEach($scope.product.providerTierNames, function(tierName) {
                        if (tierName !== currentTierName) {
                            costShares[tierName] = getAppliedCostShare(currentTierCostShare, tierName);
                        } else if (tierName === currentTierName) {
                            costShares[tierName] = currentTierCostShare;
                        }
                    });

                    var title = 'Warning';
                    var warningMessage = '<p>The existing cost share range/values will get replaced in the other provider tier(s)</p><p>Do you want to replace?</p>';
                    var modalInstance = QueryDialog.open(title, warningMessage, 'question', 'ppm-modal-dialog-question');
                    modalInstance.result.then(function() {
                        $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps.costShares = costShares;
                        $log.log('Cost share values for the other tiers has been replaced');
                    });
                }

            }
        };

        function getAppliedCostShare(costShareObj, tierName) {
            var costShare = {};
            costShare = angular.copy(costShareObj);
            angular.forEach(costShare, function(costShareTypeOj) {
                if (costShareTypeOj) {
                    angular.forEach(costShareTypeOj, function(costShareLevelObj) {
                        if (costShareLevelObj) {
                            costShareLevelObj.providerTier = tierName;
                        }
                    });
                }
            });
            return costShare;
        }

        function getTierPreCertificationRequiredValue() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                angular.forEach(service.productSvcJointProps.costShares[tierName], function(csInfo) {
                    angular.forEach(csInfo, function(levelInfo) {
                        $scope.tierCoveredStatus.isPreCertificationRequired = !!levelInfo.preCertificationRqrd;
                    });
                });
            }
        }

        function getCostShareLevelValues() {
            $log.log('getCostShareLevelValues is called');
            $scope.tierCoveredStatus.costshareLevels = {};
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                angular.forEach(service.productSvcJointProps.costShares[tierName], function(csInfo, csName) {
                    $scope.tierCoveredStatus.costshareLevels[csName] = {
                        'Primary': false,
                        'Secondary': false,
                        'Tertiary': false
                    };
                    angular.forEach(csInfo, function(levelInfo, levelName) {
                        if (levelName === 'Primary') {
                            $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
                        } else if (levelName === 'Secondary') {
                            if ('Primary' in csInfo) {
                                $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
                            }
                        } else if (levelName === 'Tertiary') {
                            if (('Primary' in csInfo) && ('Secondary' in csInfo)) {
                                $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
                            }
                        }
                    });
                });
            }
        }

        $scope.costshareLevelBtnChanged = function(csName, levelName) {
            if (levelName === 'Primary') {
                $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
            } else if (levelName === 'Secondary') {
                if (!$scope.tierCoveredStatus.costshareLevels[csName][levelName]) {
                    // disable next level
                    $scope.tierCoveredStatus.costshareLevels[csName]['Tertiary'] = false;
                    $scope.costshareLevelBtnChanged(csName, 'Tertiary');
                }
            } else if (levelName === 'Tertiary') {
                // check previous level
                if (!$scope.tierCoveredStatus.costshareLevels[csName]['Secondary']) {
                    $scope.tierCoveredStatus.costshareLevels[csName][levelName] = false;
                }
            }

            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if ($scope.tierCoveredStatus.costshareLevels[csName][levelName]) {
                if (!(levelName in service.productSvcJointProps.costShares[tierName][csName])) {
                    var serviceId = service.objectId;
                    var linkedProductServiceId = service.productSvcJointProps.linkedProductServiceId;
                    var productId = $scope.product.objectId;
                    var preCertStatus = $scope.tierCoveredStatus.isPreCertificationRequired;
                    var moopStatus = service.productSvcJointProps.costShares[tierName][csName]['Primary']['applyToMaxOutPocket'];
                    var deductibleStatus = service.productSvcJointProps.costShares[tierName][csName]['Primary']['applyToDeduct'];
                    ProductCostShareFacadeSvc.loadSingleLevelCostShareFromProduct(productId, serviceId, linkedProductServiceId, tierName, csName, levelName, preCertStatus, moopStatus, deductibleStatus);
                }
            } else {
                cleanupCostShareInfoBasedOnLevelSelection();
            }
        };

        function cleanupCostShareInfoBasedOnLevelSelection(toBeCleanedServices) {
            $log.log('cleanupCostShareInfoBasedOnLevelSelection is called');
            if (!toBeCleanedServices) {
                toBeCleanedServices = $scope.associatedServices;
            }
            var service = toBeCleanedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                angular.forEach(service.productSvcJointProps.costShares[tierName], function(csInfo, csName) {
                    angular.forEach($scope.tierCoveredStatus.costshareLevels[csName], function(value, levelName) {
                        if (!value) {
                            $log.log('delete: ' + levelName);
                            delete csInfo[levelName];
                        }
                    });
                });
            }

            return toBeCleanedServices;
        }

        function applyValueToAllTiers(service, value, name) {
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {
                angular.forEach(service.productSvcJointProps.costShares, function(tierInfo) {
                    angular.forEach(tierInfo, function(csInfo) {
                        angular.forEach(csInfo, function(levelInfo) {
                            levelInfo[name] = value;
                        });
                    });
                });
            }
        }

        $scope.servicepreCertificationRequiredChanged = function() {
            $log.log('servicePreCertificationRequiredChanged is called');
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.productSvcJointProps.preCertificationRequired) {
                applyValueToAllTiers(service, true, 'preCertificationRqrd');
            } else {
                applyValueToAllTiers(service, false, 'preCertificationRqrd');
            }
        };

        $scope.csLevelMoopChanged = function(costShareName, levelName) {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service &&
                service.productSvcJointProps &&
                service.productSvcJointProps.costShares &&
                service.productSvcJointProps.costShares[tierName] &&
                service.productSvcJointProps.costShares[tierName][costShareName] &&
                service.productSvcJointProps.costShares[tierName][costShareName][levelName]) {

                var csOnLevel = service.productSvcJointProps.costShares[tierName][costShareName][levelName];
                var csMoop = !!csOnLevel.applyToMaxOutPocket;
                var serviceMoop = !!service.productSvcJointProps.isApplyToMOOP;

                // display warning when tier level value is not the same as service level value 
                if (csMoop !== serviceMoop) {
                    var msg = 'This value is not the same as the one under service properties.';
                    QueryDialog.open('Apply to Max. Out of Pocket', msg, 'warning', 'ppm-modal-dialog-warning');
                }
            }
        };

        $scope.csLevelDeductibleChanged = function(costShareName, levelName) {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service &&
                service.productSvcJointProps &&
                service.productSvcJointProps.costShares &&
                service.productSvcJointProps.costShares[tierName] &&
                service.productSvcJointProps.costShares[tierName][costShareName] &&
                service.productSvcJointProps.costShares[tierName][costShareName][levelName]) {

                var csOnLevel = service.productSvcJointProps.costShares[tierName][costShareName][levelName];
                var csDeductible = !!csOnLevel.applyToDeduct;
                var serviceDeductible = !!service.productSvcJointProps.isApplyToDeductibles;

                // display warning when tier level value is not the same as service level value 
                if (csDeductible !== serviceDeductible) {
                    var msg = 'This value is not the same as the one under service properties.';
                    QueryDialog.open('Apply to Deductible', msg, 'warning', 'ppm-modal-dialog-warning');
                }
            }

        };

        function getServiceIndexByInitServiceId() {
            var serviceIndex = 0;

            if ($scope.initServiceId && angular.isString($scope.initServiceId)) {
                angular.forEach($scope.associatedServices, function(service, index) {
                    if (service.objectId === $scope.initServiceId) {
                        serviceIndex = index;
                        $scope.initServiceId = null; // This value only for entering using only
                    }
                });
            } else if ($stateParams.svcIdx || $stateParams.svcIdx === 0) { // SLQ what this for? who will init $stateParams.svcIdx
                serviceIndex = $stateParams.svcIdx;
            }
            return serviceIndex;
        }

        function updateCostShareTypeList() {
            // $log.log('updateCostShareTypeList is called');
            $scope.tierCoveredStatus.addCostShareList = [];
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            var tempList = angular.copy($scope.costshareTypes);
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares) {

                angular.forEach(service.productSvcJointProps.costShares[tierName], function(csInfo, csName) {
                    for (var i = tempList.length - 1; i >= 0; i--) {
                        if (tempList[i] === csName) {
                            tempList.splice(i, 1);
                        }
                    }
                });
            }
            $scope.tierCoveredStatus.addCostShareList = tempList;
        }

        $scope.singleCostShareRemoved = function(costshareType) {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares && service.productSvcJointProps.costShares[tierName]) {
                delete service.productSvcJointProps.costShares[tierName][costshareType];
                updateCostShareTypeList();
                getCostShareLevelValues();
            }
        };

        $scope.displayCostShareErrorMsgFlag = function(costshareType) {
            var flag = false;
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.productSvcJointProps && service.productSvcJointProps.costShares && service.productSvcJointProps.costShares[tierName] && service.productSvcJointProps.costShares[tierName][costshareType]) {
                angular.forEach(service.productSvcJointProps.costShares[tierName][costshareType], function(levelInfo) {
                    if (!flag && (costshareType === 'Copay') && !levelInfo.isSlider && (levelInfo.selectedValue < 0)) {
                        flag = true;
                    } else if (!flag && (costshareType === 'Co-insurance') && !levelInfo.isSlider && ((levelInfo.selectedValue < 0) || (levelInfo.selectedValue > 100))) {
                        flag = true;
                    } else if (!flag && (costshareType === 'Deductible') && !levelInfo.isSlider && (levelInfo.selectedValue < 0)) {
                        flag = true;
                    } else if (!flag && costshareType === 'Limits and Exceptions') {
                        flag = false;
                    }
                });
            }
            return flag;
        };

        $scope.displayCostShareErrorMsg = function(costshareType) {
            var message = '';
            var flag = $scope.displayCostShareErrorMsgFlag(costshareType);
            if (flag) {
                if (costshareType === 'Copay') {
                    message = 'Copay amount cannot be less than $0';
                } else if (costshareType === 'Co-insurance') {
                    message = 'Coinsurance amount must be greater than or equal 0% and less than or equal 100%';
                } else if (costshareType === 'Deductible') {
                    message = 'Deductible amount cannot be less than $0';
                }
            }
            return message;
        };

        // Status of opened calendar, internal use only
        $scope.calendarOpened = {};

        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId][$index] = true;

            $log.log('$scope.calendarOpened[nameId][$index] = ' + $scope.calendarOpened[nameId][$index]);
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function

        // For certain type of UDF, do a data transfer
        function transformUdf() {
            angular.forEach($scope.productServiceFieldsMetaData, function(metadata) {
                if (metadata.nameId.indexOf('udfproductservice_') === 0) {
                    angular.forEach($scope.associatedServices, function(service) {
                        if (service.productSvcJointProps) {
                            if (metadata.type === 'radioButton') {
                                var originalValue = service.productSvcJointProps[metadata.nameId];
                                if (originalValue === true) {
                                    service.productSvcJointProps[metadata.nameId] = 'Yes';
                                } else if (originalValue === false) {
                                    service.productSvcJointProps[metadata.nameId] = 'No';
                                } else {
                                    service.productSvcJointProps[metadata.nameId] = originalValue;
                                }
                            }
                        }
                    });
                }
            });
        }


        $scope.setPreviousSelectedRadioBtnValue = function(nameId) {
            $scope.previousRadioSelection = $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps[nameId];
        };

        $scope.radioButtonClicked = function(event, nameId) {
            if ($scope.previousRadioSelection === event.target.value) {
                $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps[nameId] = null;
            } else {
                $scope.associatedServices[$scope.editServiceIndex].productSvcJointProps[nameId] = event.target.value;
            }
        };

        $scope.serviceisApplyToMOOPChanged = function() {
            $log.log('serviceIsApplyToMoopChanged is called');
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.productSvcJointProps.isApplyToMOOP) {
                applyValueToAllTiers(service, true, 'applyToMaxOutPocket');
            } else {
                applyValueToAllTiers(service, false, 'applyToMaxOutPocket');
            }
        };

        $scope.serviceisApplyToDeductiblesChanged = function() {
            $log.log('serviceIsApplyToDeductiblesChanged is called');
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.productSvcJointProps.isApplyToDeductibles) {
                applyValueToAllTiers(service, true, 'applyToDeduct');
            } else {
                applyValueToAllTiers(service, false, 'applyToDeduct');
            }
        };

        $scope.createNew = function() {
            $state.go('home.ppm.product.edit.product-details', {
                productId: ''
            });
        };

        function getCostshareInputArray(num) {
            return new Array(num);
        }

        $scope.addCostShareInput = function(rangeValues) {
            rangeValues.push('');
        };

        $scope.validationFunction = function(rangeValues, costShareType, costShareLevel) {
            $scope.inputValidation = false;
            $scope.inputValuesName = costShareType + '-' + costShareLevel;
            rangeValues = rangeValues.filter(function(n) {
                return isNotNullAndUndefined(n);
            });
            if (rangeValues && rangeValues.length === 0) {
                $scope.inputValidation = true;
            }
        };


        $scope.csServiceCaller = function(exp) {
            for (var i = 0; i < 2; i++) {
                $scope.disabler[$scope.editServiceIndex][i] = !$scope.disabler[$scope.editServiceIndex][i];
            }
            $parse($filter('removeSpaces')('service' + exp))($scope)();
        };

        $scope.csPropertyCaller = function(exp) {
            $parse('service' + exp + 'Changed')($scope)();
        };

        function boolBuilder(fieldType, field) {
            if (fieldType === 'radioButton') {
                for (var i = 0; i < $scope.associatedServices.length; i++) {
                    $scope.disabler[i] = [];
                    for (var j = 0; j < field.options.length; j++) {
                        if (field.options[j].label === 'Covered') {
                            $scope.disabler[i].push($scope.associatedServices[i].productSvcJointProps.isCovered);
                        } else {
                            $scope.disabler[i].push(!$scope.associatedServices[i].productSvcJointProps.isCovered);
                        }

                    }
                }
            }
        }

        $scope.isDisabled = function(opt) {
            if (opt.label === 'Covered') {
                return true;
            } else {
                return false;
            }
        };
    });