'use strict';

angular.module('p2AdvanceApp')
    .controller('CostShareCtrl', function($scope, $state, $stateParams, $window, ENV, localStorageService, planL3,
        CostShareFacadeSvc, ConfirmationModalFactory, $timeout, ProductPlanMgmtSvc, ValidationReportPageslideSvc,
        CostShareFieldsMetaData, ValidationCostShareSvc, planPreviewSvc, $q, PpmFullEqual, $location, $log, QueryDialog) {

        $scope.debugMode = (ENV.name === 'local');

        $scope.planServiceFieldsMetaData = CostShareFieldsMetaData.attributes;
        // $scope.plan = $stateParams.plan;
        $scope.plan = angular.copy(planL3);
        $scope.initServiceId = $stateParams.serviceId; // if go through saveAndContinue, this will be undefined. Otherwise, an id.
        $scope.associatedServices = []; // really set value in init() // CostShareFacadeSvc.associatedServices(); // This value is set when switch from service list; 
        $scope.associatedServicesOri = []; //angular.copy($scope.associatedServices);
        $scope.editServiceIndex = 0; // getServiceIndexByInitServiceId(); // actually init in list on event 'CostShareFacadeSvc.associatedServices.changed'
        $scope.selectedTier = 'properties'; // will be updated in init()
        $scope.shownTiersNameOnCostShareTab = []; // initilized in init()
        $scope.tierDisplayNameToName = {}; // initialized in init();
        $scope.costshareTypes = ['Copay', 'Co-insurance', 'Deductible', 'Limits and Exceptions'];
        // This value should be loaded from backend as metadata in the future
        $scope.quantityBasisOptions = ['Per Year', 'Per Confinement', 'Visits Per Year', 'Visits Per Plan Year',
            'Days Supply', 'Per Visit', 'Per Admission', 'Per Day', 'Per Ear', 'Per Emergency Department Visit',
            'Per Inpatient Stay', 'Per Item', 'Per Item, If Applicable', 'Per Outpatient Surgery', 'Minimum', 'Maximum',
            'Per Prescription', 'Per Trip', 'Per Encounter', 'Per Procedure'
        ];
        // It is better to move this to a angular constant in future
        var providerTierNamesOrder = [
            'Preferred Network 1',
            'Preferred Network 2',
            'Preferred Network 3',
            'In Network',
            'Out of Network',
            'Out of Area',
            'Out of Country',
            'Coverage'
        ];
        $scope.componentStatus = {
            isValidationEnabled: true,
            isSaveEnabled: true
        };
        $scope.fieldsErrorStatus = {};

        $scope.savingHook.action = function() {
            $scope.save(true);
        };
        // before destory the scope, make sure the hooker is removed so that this memory can be released
        $scope.$on('$destroy', function() {
            $scope.savingHook.action = null;
        });

        $scope.previousService = function() {
            ValidationCostShareSvc.associatedServices($scope.associatedServices);
            if (ValidationCostShareSvc.validateMemberCostSharesOfSingleService($scope.editServiceIndex)) {
                $log.log('!!!Warning: Cost share validation not passed.');
                displayCostShareErrorMsg();
                return;
            } else {
                $q.when(isEqual())
                    .then(function(isSame) {
                        if (!isSame) {
                            // save it
                            return doSave(false);
                        }
                    })
                    .then(function() {
                        // previous service
                        navService(--$scope.editServiceIndex);
                        CostShareFacadeSvc.populateCurrentServiceCostSharesIfNotDoneAllready($scope.associatedServices[$scope.editServiceIndex]);
                    });
            }
        };

        $scope.nextService = function() {
            ValidationCostShareSvc.associatedServices($scope.associatedServices);
            if (ValidationCostShareSvc.validateMemberCostSharesOfSingleService($scope.editServiceIndex)) {
                $log.log('!!!Warning: Cost share validation not passed.');
                displayCostShareErrorMsg();
                return;
            } else {
                $q.when(isEqual())
                    .then(function(isSame) {
                        if (!isSame) {
                            // save it
                            return doSave(false);
                        }
                    }).then(function() {
                        // next service
                        navService(++$scope.editServiceIndex);
                        CostShareFacadeSvc.populateCurrentServiceCostSharesIfNotDoneAllready($scope.associatedServices[$scope.editServiceIndex]);
                    });
            }
        };

        function displayCostShareErrorMsg() {
            var msg = 'Unable to create the Plan because you’ve entered one or more invalid Cost Share amounts. Change any Copay or Deductible amount &lt; $0 and any Coinsurance amount &lt; 0% or &gt; 100%.';
            QueryDialog.open('Create Plan', msg, 'minus', 'ppm-modal-dialog-error');
        }

        function navService(serviceIndex) {
            $scope.editServiceIndex = (serviceIndex + $scope.associatedServices.length) % $scope.associatedServices.length;
            // $scope.selectedTier = 'properties'; // this is updated in the setTab()
            showDefaultTab();
        }

        function doSave(showMessage) {
            cleanupCostShareInfoBasedOnLevelSelection();
            var associatedServices = $scope.associatedServices[$scope.editServiceIndex];
            var planId = $scope.plan.objectId;
            unregisterPlanCostShareChangedListener();
            return CostShareFacadeSvc.updateEditPlanService(associatedServices, planId, $scope.planServiceFieldsMetaData)
                .then(function() {
                    $scope.plan.planStatus = 'Draft'; // If the save successfully, the status can be expected to be draft
                    getAssociatedServicesToOri($scope.editServiceIndex);
                    $scope.componentStatus.isValidationEnabled = true;
                    if (showMessage) {
                        var msgtitle;
                        var msg;
                        msgtitle = '';
                        msg = $scope.plan.name + ' updated successfully';
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }
                });
        }

        $scope.validatePlan = function() {
            if (!$scope.componentStatus.isValidationEnabled) {
                $log.log('validation skipped');
                return;
            }

            ProductPlanMgmtSvc.validatePlan($scope.plan.objectId).then(function(data) {
                // update plan status
                $scope.plan.planStatus = data.plan.planStatus;
                // show result
                var result = {
                    warnings: data.warnings,
                    errors: data.errors,
                    planName: data.plan.name,
                    validatedDate: data.validatedDate ? data.validatedDate : new Date(),
                    planId: data.plan.objectId,
                    planStatus: data.plan.planStatus
                };
                if (result.warnings.length === 0 && result.errors.length === 0) { // no error
                    var msgtitle = 'Success';
                    var msg = 'The plan is validated successfully';
                    ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                } else {
                    ValidationReportPageslideSvc.openPageslide('left', result, $scope)
                        .then(function() {
                            $scope.validatePlan();
                        });
                }
            });
        };

        $scope.save = function(showMessage) {

            if (isEqual()) {
                $scope.componentStatus.isValidationEnabled = true;
                return;
            }
            ValidationCostShareSvc.associatedServices($scope.associatedServices);
            if (ValidationCostShareSvc.validateMemberCostSharesOfAllServices()) {
                $log.log('!!!Warning: Cost share validation of services not passed.');
                displayCostShareErrorMsg();
                return;
            } else {
                // NOTE: do not need to save whole plan, becahse ever service will be saved before navigate to next
                // cleanupCostShareInfoBasedOnLevelSelection();
                // var planId = $scope.plan.objectId;
                // CostShareFacadeSvc.savePlanServiceCostShare(planId, $scope.planServiceFieldsMetaData).then(function() {
                //     $scope.componentStatus.isValidationEnabled = true;
                //     $scope.plan.planStatus = 'Draft'; // If the save successfully, the status can be expected to be draft
                //     getAssociatedServicesToOri();
                // });
                doSave(showMessage);
            }
        };

        $scope.tabClicked = function($event, tabName) {
            $event.preventDefault();
            $event.stopPropagation();
            if (!$scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.isServiceCovered) {
                return; // do not know disabled nav bar still work while click
            }
            setTab(tabName);
        };

        $scope.loadTierCostShareFromProduct = function() {
            $log.log('$scope.tierCoveredStatus.isCovered = ' + $scope.tierCoveredStatus.isCovered);
            if ($scope.tierCoveredStatus.isCovered) {
                // $log.log('Already covered');
                return;
            }
            $log.log('load service index = ' + $scope.editServiceIndex + ' and tier name = ' + $scope.selectedTier);
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var serviceId = service.objectId;
            var linkedPlanServiceId = service.planSvcJointProps.linkedPlanServiceId;
            var tierName = $scope.selectedTier;
            var planId = $scope.plan.objectId;
            CostShareFacadeSvc.loadTierCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName);
        };

        $scope.tierNotCovered = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                var title = 'Warning';
                var warningMessage = '<p>Selecting "Not Covered" button will delete all associated cost share information from the tier. </p><p>Do you want to continue?</p>';

                var modalInstance = QueryDialog.open(title, warningMessage, 'question', 'ppm-modal-dialog-question');
                modalInstance.result.then(function() {
                    delete service.planSvcJointProps.costShares[tierName];
                    $log.log('Warning modal continue for tier not cover');
                }, function() {
                    $scope.tierCoveredStatus.isCovered = true;
                    $log.log('Warning modal dismissed for tier not cover');
                });
            }
        };

        $scope.serviceCovered = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.planSvcJointProps.isServiceCovered) {
                // $log.log('Already covered');
                return;
            }
            service.planSvcJointProps.costShares = {};
            // $log.log('load service name = ' + service.name);
            var serviceId = service.objectId;
            var linkedPlanServiceId = service.planSvcJointProps.linkedPlanServiceId;
            var planId = $scope.plan.objectId;
            CostShareFacadeSvc.loadServiceCostShareFromProduct(planId, serviceId, linkedPlanServiceId);
        };

        $scope.serviceNotCovered = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                delete service.planSvcJointProps.costShares;
            }
        };

        $scope.isCarvedOutChanged = function() {
            var jointProps = $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps;
            if (!jointProps.isCarvedOut) {
                jointProps.vendorName = jointProps.vendorPhone = jointProps.vendorWebsite = '';
            }
        };

        function getAssociatedServicesToOri(svcIdx) {
            var fully = arguments.length === 0;
            $timeout(function() {
                // $log.log('%%%%%% renew costshare ori serviceIdx = ' + svcIdx);
                if (fully) {
                    $scope.associatedServicesOri = cleanupCostShareInfoBasedOnLevelSelection(angular.copy($scope.associatedServices));
                } else {
                    $scope.associatedServicesOri[svcIdx] = cleanupCostShareInfoBasedOnLevelSelection(angular.copy($scope.associatedServices))[svcIdx];
                }
            }, 100);
        }

        function isEqual() {
            var wideAcceptedFalse = {
                customEqual: function(o1, o2 /*, propertyName, level*/ ) {
                    return Boolean(o1) === Boolean(o2);
                }
            };

            var config = { // setup configuration
                'value.arrCfg.planSvcJointProps.costShares.*.*.*.applyToMaxOutPocket': wideAcceptedFalse,
                'value.arrCfg.planSvcJointProps.costShares.*.*.*.applyToDeduct': wideAcceptedFalse,
                'value.arrCfg.planSvcJointProps.costShares.*.*.*.preCertificationRqrd': wideAcceptedFalse
            };
            var equalSvc = new PpmFullEqual(config);
            var curValue = cleanupCostShareInfoBasedOnLevelSelection(angular.copy($scope.associatedServices));
            curValue = curValue[$scope.editServiceIndex]; // we only care the current service's cost share
            var oriValue = $scope.associatedServicesOri[$scope.editServiceIndex];
            var compResult = {};
            var isSame = equalSvc.equals(curValue, oriValue, compResult); // rebase need some changes
            //  $log.log('########## Nothing changed: ' + isSame);
            return isSame;
        }

        $scope.backServiceList = function() {
            ValidationCostShareSvc.associatedServices($scope.associatedServices);
            if (ValidationCostShareSvc.validateMemberCostSharesOfSingleService($scope.editServiceIndex)) {
                $log.log('!!!Warning: Cost share validation not passed.');
                displayCostShareErrorMsg();
                return;
            } else {
                $q.when(isEqual())
                    .then(function(isSame) {
                        if (!isSame) {
                            // save it
                            return doSave(false);
                        }
                    })
                    .then(function() {
                        $window.history.back();
                    });
            }
        };

        $scope.$on('$stateChangeSuccess',
            function(event, toState, toParams, fromState, fromParams) {
                $log.log(toState.name + ' <-- ' + fromState.name);
                $log.log(toState.url + ' <-- ' + fromState.url);
                $log.log(angular.toJson(toParams, true));
                $log.log(angular.toJson(fromParams, true));
                if ((fromState.name.indexOf('home.ppm.plan.edit.cost-share.details') === 0 || fromState.name === 'home.ppm.plan.edit.cost-share') && toState.name.indexOf('home.ppm.plan.edit.cost-share.details') === 0) {
                    $location.replace(); //clear last history route
                }
            });

        $scope.$on('CostShareFacadeSvc.associatedServices.changed', function(event, args) {
            $log.log('CostShareFacadeSvc.associatedServices.changed handled');
            $log.log(event);
            $log.log(args);
            $scope.associatedServices = args.associatedSvcs;
            transformAssociatedServices();

            if (args.isInitLoad) {
                $scope.editServiceIndex = getServiceIndexByInitServiceId(); // Note: must put after service list is populated
                getAssociatedServicesToOri(); // must put here, called after saving to update original one
                showDefaultTab();
            }
            CostShareFacadeSvc.populateCurrentServiceCostSharesIfNotDoneAllready($scope.associatedServices[$scope.editServiceIndex]);

            registerPlanCostShareChangedListener();
        });

        $scope.$on('CostShareFacadeSvc.associatedServices.OneCostShares.Loaded', function(event, args) {
            $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.costShares = args;
            transformAssociatedServices();
            getAssociatedServicesToOri();
        });

        $scope.$on('CostShareFacadeSvc.tierCostShares.loaded', function( /*event, args*/ ) {
            $log.log('CostShareFacadeSvc.tierCostShares.loaded handled');
            updateTierCoverStatus();
            getTierPreCertificationRequiredValue();
            getCostShareLevelValues();
            updateCostShareTypeList();
        });

        $scope.$on('ppm.input.validation.error', function(event, args) {
            event.stopPropagation();
            if (args.hasError) {
                $scope.fieldsErrorStatus[args.id] = true;
            } else {
                delete $scope.fieldsErrorStatus[args.id];
            }
            $scope.componentStatus.isSaveEnabled = angular.equals($scope.fieldsErrorStatus, {});
        });

        $scope.$watch('associatedServices[editServiceIndex].planSvcJointProps.costShares[selectedTier]', function(newValue, oldValue) {
            if (newValue === oldValue) {
                return;
            }

            $log.log('associatedServices[editServiceIndex].planSvcJointProps.costShares[selectedTier] changed');
            if ($scope.selectedTier !== 'properties' && $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.costShares) { // just avoid exception
                $log.log('and value = ' + $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.costShares[$scope.selectedTier]);
            }
            updateTierCoverStatus();
            getTierPreCertificationRequiredValue();
            getCostShareLevelValues();
            updateCostShareTypeList();
        });

        var unregisterPlanCostShareChangedListenerFn = null;

        function registerPlanCostShareChangedListener() {
            $timeout(function() {
                $log.log('registerPlanCostShareChangedListener');
                if (!unregisterPlanCostShareChangedListenerFn) { // make sure only one listener registered
                    unregisterPlanCostShareChangedListenerFn = $scope.$watch('associatedServices', function(newValue, oldValue) {
                        if (!newValue || !oldValue || newValue === oldValue) {
                            return;
                        }
                        $scope.componentStatus.isValidationEnabled = false;
                        $log.log('watchCollection associatedServices: $scope.componentStatus.isValidationEnabled = ' + $scope.componentStatus.isValidationEnabled);
                    }, true);
                }
            }, 1000);
        }

        function unregisterPlanCostShareChangedListener() {
            $log.log('unregisterPlanCostShareChangedListener');
            if (unregisterPlanCostShareChangedListenerFn) {
                // $log.log('>>>>> unregisterPlanChangedListener');
                unregisterPlanCostShareChangedListenerFn();
                unregisterPlanCostShareChangedListenerFn = null;
                $log.log('unregisterPlanCostShareChangedListener -- 2');
            }
        }

        function setTab(tabName) {
            // Current model, we have 2 set of name in the plan, internal name and display name, display name could be 
            // changed by user, but internal name is not. The plan tier name is come from product, the internal tier 
            // name is the same between product and plan, but display name also could be different. 
            // Currently there are 8 tier name, the internal name sequence/order is alway keep the same in product and plan.
            // We suppose that the provider tier internal names list is always the same as the cost share provider tier's name.
            $scope.selectedTier = $scope.tierDisplayNameToName[tabName];

            if (tabName === 'properties') { // "properties" is a special tab, and it is hard coded in html file
                $scope.selectedTier = tabName;
            } else {
                updateTierCoverStatus();
            }

            $log.log(tabName + ' ---> ' + $scope.selectedTier);

            $state.go('home.ppm.plan.edit.cost-share.details', {
                tierName: $scope.selectedTier,
                svcIdx: $scope.editServiceIndex
            });
        }

        function showDefaultTab() {
            var defaultTab = $scope.shownTiersNameOnCostShareTab.length > 0 ? $scope.shownTiersNameOnCostShareTab[0] : 'properties';
            if (!$scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.isServiceCovered) {
                defaultTab = 'properties'; // because all other tab are disabled
            }
            setTab(defaultTab);
        }

        function updateTierCoverStatus() {
            $timeout(function() {
                $scope.tierCoveredStatus.isCovered = (!!$scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.costShares) &&
                    (!!$scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.costShares[$scope.selectedTier]);
                $log.log('$scope.tierCoveredStatus.isCovered = ' + $scope.tierCoveredStatus.isCovered);
            });
        }

        // temp values for next sprint use
        $scope.tierCoveredStatus = { // Use the object instead of simple value. Updated automation when switch the tier
            isCovered: false,
            isPreCertificationRequired: false,
            costshareLevels: {},
            addCostShareList: []
        };

        $scope.addSingleCostShare = function(costshareType) {
            var index = -1;
            angular.forEach($scope.tierCoveredStatus.addCostShareList, function(csItem, csKey) {
                if (csItem === costshareType) {
                    index = csKey;
                }
            });
            if (index > -1) {
                var service = $scope.associatedServices[$scope.editServiceIndex];
                var serviceId = service.objectId;
                var linkedPlanServiceId = service.planSvcJointProps.linkedPlanServiceId;
                var tierName = $scope.selectedTier;
                var planId = $scope.plan.objectId;
                var preCertStatus = $scope.tierCoveredStatus.isPreCertificationRequired;
                var moopStatus = $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.applyToMOOP;
                var deductibleStatus = $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps.applyToDeductibles;
                CostShareFacadeSvc.loadSingleTierCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus);

                $scope.tierCoveredStatus.addCostShareList.splice(index, 1);
            }
        };

        function transformAssociatedServices() {
            angular.forEach($scope.associatedServices, function(service) {
                // For newly added service, limitsAndException can not be empty array.
                if (service.planSvcJointProps.limitsAndExceptions === undefined) {
                    service.planSvcJointProps['limitsAndExceptions'] = [''];
                }
                angular.forEach(service.planSvcJointProps.costShares, function(tierInfo) { // out of network
                    angular.forEach(tierInfo, function(csInfo) { // copay
                        angular.forEach(csInfo, function(levelInfo, level) { // primary
                            if (hasValidSliderInfo(levelInfo)) {
                                csInfo[level] = transformInputSliderInfo(levelInfo);
                            } else {
                                deleteInvalidSliderInfoFromInput(levelInfo);
                            }
                        });
                    });
                });
            });

            transformUdf();
        }

        function hasValidSliderInfo(levelInfo) {
            if (isNullOrUndefined(levelInfo.from) || isNullOrUndefined(levelInfo.to) || isNullOrUndefined(levelInfo.min) || isNullOrUndefined(levelInfo.max) || isNullOrUndefined(levelInfo.scale) || isNullOrUndefined(levelInfo.step)) {
                return false;
            } else {
                return true;
            }
        }

        function isNullOrUndefined(value) {
            if ((value === undefined) || (value === null)) {
                return true;
            } else {
                return false;
            }
        }

        function deleteInvalidSliderInfoFromInput(levelInfo) {
            levelInfo.isSlider = false;
            delete levelInfo.from;
            delete levelInfo.to;
            delete levelInfo.max;
            delete levelInfo.min;
            delete levelInfo.step;
            delete levelInfo.scale;
            delete levelInfo['default'];
            delete levelInfo.rangeValues;
        }

        function transformInputSliderInfo(data) {
            var newScale = [];
            if (data.scale > 0 && data.from >= 0 && data.to > 0 && data.from < data.to) {
                for (var i = data.from; i <= data.to; i = i + data.scale) {
                    newScale.push(i);
                }
            }

            var slider = {};
            slider['from'] = data.from;
            slider['to'] = data.to;
            slider['min'] = data.min;
            slider['max'] = data.max;
            slider['step'] = data.step;
            slider['format'] = data.format;
            slider['value'] = data['default'];
            slider['scale'] = newScale;
            slider['round'] = 2;

            if (!data.selectedValue) {
                data.selectedValue = 0;
            }
            data.selectedValue = data.selectedValue.toString(); // slider is expect string as its value, see comment in slider
            // asign slider values
            data['slider'] = slider;
            data['isSlider'] = true;
            return data;
        }

        (function init() {
            // get cost share from product, update view list via event and save it to backend
            CostShareFacadeSvc.updatePlanWithCostShares($stateParams.planId);
            $scope.tierDisplayNameToName = getTierDisplayNameToNameMap();
            $scope.shownTiersNameOnCostShareTab = getTierDisplayNameInGivenOrder();
            // showDefaultTab();  // move to data loaed event, because at this time, costshare service is not successfully loaded
        })();

        function getTierDisplayNameToNameMap() {
            // Before We are use loaed Plan, and it structure is a little difference from screen data structure 
            // due to history, so comment out following 2 lines
            // var displayNameList = $scope.plan.productTiers.providerTierDisplayNames;
            // var nameList = $scope.plan.productTiers.providerTierNames;
            var displayNameList = $scope.plan.providerTierDisplayNames;
            var nameList = $scope.plan.providerTierNames;

            var map = {};
            angular.forEach(displayNameList, function(displayName, index) {
                map[displayName] = nameList[index];
            });

            return map;
        }

        function getTierDisplayNameInGivenOrder() {
            var shownTiersNameOnCostShare = [];
            // providerTierNamesOrder is the internal name, not display name
            angular.forEach(providerTierNamesOrder, function(tierName /*, index*/ ) {
                var indexInPlanTierNames = $scope.plan.providerTierNames.indexOf(tierName);
                if (indexInPlanTierNames >= 0) {
                    shownTiersNameOnCostShare.push($scope.plan.providerTierDisplayNames[indexInPlanTierNames]); // tier names and tier display name are always in the same order in plan
                }
            });

            return shownTiersNameOnCostShare;
        }

        $scope.tierPreCertificationRequiredChanged = function() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                angular.forEach(service.planSvcJointProps.costShares[tierName], function(csInfo) {
                    angular.forEach(csInfo, function(levelInfo) {
                        levelInfo.preCertificationRqrd = $scope.tierCoveredStatus.isPreCertificationRequired;
                    });
                });
            }
            var servicePreCertificationRequired = !!service.planSvcJointProps.isPreCertificationRequired;
            var tierPreCertificationRequired = !!$scope.tierCoveredStatus.isPreCertificationRequired;
            // display warning when tier level value is not the same as service level value 
            if (servicePreCertificationRequired !== tierPreCertificationRequired) {
                var msg = 'This value is not the same as the one under service properties.';
                QueryDialog.open('Pre-Certification Required', msg, 'warning', 'ppm-modal-dialog-warning');
            }
        };

        function getTierPreCertificationRequiredValue() {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                angular.forEach(service.planSvcJointProps.costShares[tierName], function(csInfo) {
                    angular.forEach(csInfo, function(levelInfo) {
                        $scope.tierCoveredStatus.isPreCertificationRequired = !!levelInfo.preCertificationRqrd;
                    });
                });
            }
        }

        function getCostShareLevelValues() {
            $log.log('getCostShareLevelValues is called');
            $scope.tierCoveredStatus.costshareLevels = {};
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                angular.forEach(service.planSvcJointProps.costShares[tierName], function(csInfo, csName) {
                    $scope.tierCoveredStatus.costshareLevels[csName] = {
                        'Primary': false,
                        'Secondary': false,
                        'Tertiary': false
                    };
                    angular.forEach(csInfo, function(levelInfo, levelName) {
                        if (levelName === 'Primary') {
                            $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
                        } else if (levelName === 'Secondary') {
                            if ('Primary' in csInfo) {
                                $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
                            }
                        } else if (levelName === 'Tertiary') {
                            if (('Primary' in csInfo) && ('Secondary' in csInfo)) {
                                $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
                            }
                        }
                    });
                });
            }
        }

        $scope.costshareLevelBtnChanged = function(csName, levelName) {
            if (levelName === 'Primary') {
                $scope.tierCoveredStatus.costshareLevels[csName][levelName] = true;
            } else if (levelName === 'Secondary') {
                if (!$scope.tierCoveredStatus.costshareLevels[csName][levelName]) {
                    // disable next level
                    $scope.tierCoveredStatus.costshareLevels[csName]['Tertiary'] = false;
                    $scope.costshareLevelBtnChanged(csName, 'Tertiary');
                }
            } else if (levelName === 'Tertiary') {
                // check previous level
                if (!$scope.tierCoveredStatus.costshareLevels[csName]['Secondary']) {
                    $scope.tierCoveredStatus.costshareLevels[csName][levelName] = false;
                }
            }

            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if ($scope.tierCoveredStatus.costshareLevels[csName][levelName]) {
                if (!(levelName in service.planSvcJointProps.costShares[tierName][csName])) {
                    var serviceId = service.objectId;
                    var linkedPlanServiceId = service.planSvcJointProps.linkedPlanServiceId;
                    var planId = $scope.plan.objectId;
                    var preCertStatus = $scope.tierCoveredStatus.isPreCertificationRequired;
                    var moopStatus = service.planSvcJointProps.costShares[tierName][csName]['Primary']['applyToMaxOutPocket'];
                    var deductibleStatus = service.planSvcJointProps.costShares[tierName][csName]['Primary']['applyToDeduct'];
                    CostShareFacadeSvc.loadSingleLevelCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName, csName, levelName, preCertStatus, moopStatus, deductibleStatus);
                }
            } else {
                cleanupCostShareInfoBasedOnLevelSelection();
            }
        };

        function cleanupCostShareInfoBasedOnLevelSelection(toBeCleanedServices) {
            $log.log('cleanupCostShareInfoBasedOnLevelSelection is called');
            if (!toBeCleanedServices) {
                toBeCleanedServices = $scope.associatedServices;
            }
            var service = toBeCleanedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                angular.forEach(service.planSvcJointProps.costShares[tierName], function(csInfo, csName) {
                    angular.forEach($scope.tierCoveredStatus.costshareLevels[csName], function(value, levelName) {
                        if (!value) {
                            $log.log('delete: ' + levelName);
                            delete csInfo[levelName];
                        }
                    });
                });
            }

            return toBeCleanedServices;
        }

        function applyValueToAllTiers(service, value, name) {
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                angular.forEach(service.planSvcJointProps.costShares, function(tierInfo) {
                    angular.forEach(tierInfo, function(csInfo) {
                        angular.forEach(csInfo, function(levelInfo) {
                            levelInfo[name] = value;
                        });
                    });
                });
            }
        }

        $scope.serviceApplyToMoopChanged = function() {
            $log.log('serviceApplyToMoopChanged is called');
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.planSvcJointProps.applyToMOOP) {
                applyValueToAllTiers(service, true, 'applyToMaxOutPocket');
            } else {
                applyValueToAllTiers(service, false, 'applyToMaxOutPocket');
            }
        };
        $scope.serviceApplyToDeductibleChanged = function() {
            $log.log('serviceApplyToDeductibleChanged is called');
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.planSvcJointProps.applyToDeductibles) {
                applyValueToAllTiers(service, true, 'applyToDeduct');
            } else {
                applyValueToAllTiers(service, false, 'applyToDeduct');
            }
        };

        $scope.servicePreCertificatinRequiredChanged = function() {
            $log.log('servicePreCertificatinRequiredChanged is called');
            var service = $scope.associatedServices[$scope.editServiceIndex];
            if (service.planSvcJointProps.isPreCertificationRequired) {
                applyValueToAllTiers(service, true, 'preCertificationRqrd');
            } else {
                applyValueToAllTiers(service, false, 'preCertificationRqrd');
            }
        };

        $scope.csLevelMoopChanged = function(costShareName, levelName) {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service &&
                service.planSvcJointProps &&
                service.planSvcJointProps.costShares &&
                service.planSvcJointProps.costShares[tierName] &&
                service.planSvcJointProps.costShares[tierName][costShareName] &&
                service.planSvcJointProps.costShares[tierName][costShareName][levelName]) {

                var csOnLevel = service.planSvcJointProps.costShares[tierName][costShareName][levelName];
                var csMoop = !!csOnLevel.applyToMaxOutPocket;
                var serviceMoop = !!service.planSvcJointProps.applyToMOOP;

                // display warning when tier level value is not the same as service level value 
                if (csMoop !== serviceMoop) {
                    var msg = 'This value is not the same as the one under service properties.';
                    QueryDialog.open('Apply to Max. Out of Pocket', msg, 'warning', 'ppm-modal-dialog-warning');
                }
            }
        };

        $scope.csLevelDeductibleChanged = function(costShareName, levelName) {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;

            if (service &&
                service.planSvcJointProps &&
                service.planSvcJointProps.costShares &&
                service.planSvcJointProps.costShares[tierName] &&
                service.planSvcJointProps.costShares[tierName][costShareName] &&
                service.planSvcJointProps.costShares[tierName][costShareName][levelName]) {

                var csOnLevel = service.planSvcJointProps.costShares[tierName][costShareName][levelName];
                var csDeductible = !!csOnLevel.applyToDeduct;
                var serviceDeductible = !!service.planSvcJointProps.applyToDeductibles;

                // display warning when tier level value is not the same as service level value 
                if (csDeductible !== serviceDeductible) {
                    var msg = 'This value is not the same as the one under service properties.';
                    QueryDialog.open('Apply to Deductible', msg, 'warning', 'ppm-modal-dialog-warning');
                }
            }

        };

        function getServiceIndexByInitServiceId() {
            var serviceIndex = 0;

            if ($scope.initServiceId && angular.isString($scope.initServiceId)) {
                angular.forEach($scope.associatedServices, function(service, index) {
                    if (service.objectId === $scope.initServiceId) {
                        serviceIndex = index;
                        $scope.initServiceId = null; // This value only for entering using only
                    }
                });
            } else if ($stateParams.svcIdx || $stateParams.svcIdx === 0) { // SLQ what this for? who will init $stateParams.svcIdx
                serviceIndex = $stateParams.svcIdx;
            }
            return serviceIndex;
        }

        function updateCostShareTypeList() {
            // $log.log('updateCostShareTypeList is called');
            $scope.tierCoveredStatus.addCostShareList = [];
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            var tempList = angular.copy($scope.costshareTypes);
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {

                angular.forEach(service.planSvcJointProps.costShares[tierName], function(csInfo, csName) {
                    for (var i = tempList.length - 1; i >= 0; i--) {
                        if (tempList[i] === csName) {
                            tempList.splice(i, 1);
                        }
                    }
                });
            }
            $scope.tierCoveredStatus.addCostShareList = tempList;
        }

        $scope.singleCostShareRemoved = function(costshareType) {
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares && service.planSvcJointProps.costShares[tierName]) {
                delete service.planSvcJointProps.costShares[tierName][costshareType];
                updateCostShareTypeList();
                getCostShareLevelValues();
            }
        };

        $scope.displayCostShareErrorMsgFlag = function(costshareType) {
            var flag = false;
            var service = $scope.associatedServices[$scope.editServiceIndex];
            var tierName = $scope.selectedTier;
            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares && service.planSvcJointProps.costShares[tierName] && service.planSvcJointProps.costShares[tierName][costshareType]) {
                angular.forEach(service.planSvcJointProps.costShares[tierName][costshareType], function(levelInfo) {
                    if (!flag && (costshareType === 'Copay') && !levelInfo.isSlider && (levelInfo.selectedValue < 0)) {
                        flag = true;
                    } else if (!flag && (costshareType === 'Co-insurance') && !levelInfo.isSlider && ((levelInfo.selectedValue < 0) || (levelInfo.selectedValue > 100))) {
                        flag = true;
                    } else if (!flag && (costshareType === 'Deductible') && !levelInfo.isSlider && (levelInfo.selectedValue < 0)) {
                        flag = true;
                    } else if (!flag && costshareType === 'Limits and Exceptions') {
                        flag = false;
                    }
                });
            }
            return flag;
        };

        $scope.displayCostShareErrorMsg = function(costshareType) {
            var message = '';
            var flag = $scope.displayCostShareErrorMsgFlag(costshareType);
            if (flag) {
                if (costshareType === 'Copay') {
                    message = 'Copay amount cannot be less than $0';
                } else if (costshareType === 'Co-insurance') {
                    message = 'Coinsurance amount must be greater than or equal 0% and less than or equal 100%';
                } else if (costshareType === 'Deductible') {
                    message = 'Deductible amount cannot be less than $0';
                }
            }
            return message;
        };

        // Status of opened calendar, internal use only
        $scope.calendarOpened = {};

        // Calendar function
        $scope.openCalendar = function($event, $index, nameId) {
            $event.preventDefault();
            $event.stopPropagation();

            if (!$scope.calendarOpened[nameId]) {
                $scope.calendarOpened[nameId] = [];
            }

            $scope.calendarOpened[nameId][$index] = true;

            $log.log('$scope.calendarOpened[nameId][$index] = ' + $scope.calendarOpened[nameId][$index]);
        };

        // Disable weekend selection
        $scope.disabled = function(date, mode) {
            return (mode === 'day' && (date.getDay() === 0 || date.getDay() === 6));
        };

        $scope.dateOptions = {
            showWeeks: false
        };
        // End of Calendar function

        // For certain type of UDF, do a data transfer
        function transformUdf() {
            angular.forEach($scope.planServiceFieldsMetaData, function(metadata) {
                if (metadata.nameId.indexOf('udfplanservice_') === 0) {
                    angular.forEach($scope.associatedServices, function(service) {
                        if (service.planSvcJointProps) {
                            if (metadata.type === 'radioButton') {
                                var originalValue = service.planSvcJointProps[metadata.nameId];
                                if (originalValue === true) {
                                    service.planSvcJointProps[metadata.nameId] = 'Yes';
                                } else if (originalValue === false) {
                                    service.planSvcJointProps[metadata.nameId] = 'No';
                                } else {
                                    service.planSvcJointProps[metadata.nameId] = originalValue;
                                }
                            }
                        }
                    });
                }
            });
        }

        $scope.showPlanSummaryDialog = function() {
            var planId = $scope.plan.objectId;
            planPreviewSvc.previewPlan(planId);
        };

        $scope.viewValidationHistory = function() {
            ProductPlanMgmtSvc.getValidationHistory($scope.plan.objectId).then(function(data) {
                angular.forEach(data, function(record) {
                    record.eventDetails = JSON.parse(record.eventDetails);
                    record.show = false; // add to validation history for show/hide
                    record.creationDate = new Date(record.creationDate);
                });

                var result = {};
                result.validationHistory = data;
                result.planName = $scope.plan['name'];

                ValidationReportPageslideSvc.openHistoryPageslide('left', result, $scope);
            });
        };

        $scope.setPreviousSelectedRadioBtnValue = function(nameId) {
            $scope.previousRadioSelection = $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps[nameId];
        };

        $scope.radioButtonClicked = function(event, nameId) {
            if ($scope.previousRadioSelection === event.target.value) {
                $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps[nameId] = null;
            } else {
                $scope.associatedServices[$scope.editServiceIndex].planSvcJointProps[nameId] = event.target.value;
            }
        };
    });