'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ValidationHistoryPageslideCtrl
 * @description
 * # ValidationHistoryPageslideCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ValidationHistoryPageslideCtrl', function($scope, $q, $compile, $templateCache, $filter, ENV, $timeout, $log) {
        $scope.debugMode = (ENV.name === 'local');
        $scope.position = 'right';
        $scope.vResult = null;

        $scope.isPageslideShown = false;

        var pageSlideCompiledElt;

        $scope.showHideContent = function(objectId) {
            angular.forEach($scope.vResult, function(record) {
                if (record.objectId === objectId) {
                    record.show = !record.show;
                }
            });
        };

        // return promise
        $scope.open = function() {
            $scope.defer = $q.defer();

            compilePageslideAndShow();

            return $scope.defer.promise;
        };

        $scope.ok = function(event) {
            event.stopPropagation();
            cleanManualThing();
            close();
            $scope.defer.resolve('close');
        };

        $scope.cancel = function(event) {
            event.stopPropagation();
            cleanManualThing();
            close();
            $scope.defer.reject('dismiss');
        };

        function cleanManualThing() {
            $scope.manualScope.$destroy();
            $scope.manualElement.remove();
        }

        function close() {
            $scope.isPageslideShown = false;
            $timeout(function() {
                removeOldSlideElement();
            }, 250);
        }

        $scope.reposition = function(event, position) {
            event.stopPropagation();
            $scope.isPageslideShown = false;
            $scope.position = position;
            compilePageslideAndShow();
        };

        // When context scope is destroyed, all is descendant will be destroyed, and this event will be triggered
        $scope.$on('$destroy', function() {
            close();
            $scope.manualElement.remove(); // note scope destroy is already triggered
        });

        $scope.filename = 'validation_report_noname_' + $filter('date')(new Date(), 'yyyy_MM_ddTHH_mm_ss_sss');

        $scope.initFileName = function(name) {
            var fileName = 'validation_report_';
            fileName += name ? name.toString().replace(/ /g, '_') : 'noname';
            fileName += '_';
            fileName += $filter('date')(new Date(), 'yyyy_MM_ddTHH_mm_ss'); // _sss
            fileName += '.csv';
            $log.log(fileName);

            $scope.filename = fileName;
        };

        $scope.getExportArray = function() {
            var report = [];

            report.push({
                a: 'Validation History'
            });
            report.push({
                a: ''
            });

            angular.forEach($scope.vResult, function(record) {
                report.push({
                    a: record.event + ' On:',
                    b: $filter('date')(record.creationDate, 'MMM dd, y'),
                    c: record.event
                });

                report.push({
                    a: record.event + ' By:',
                    b: record.createdBy
                });

                angular.forEach(record.eventDetails, function(item, key) {
                    if ((key === 'comments') || (key === 'errors') || (key === 'warnings')) {
                        var title = key.substr(0, 1).toUpperCase() + key.substr(1).toLowerCase();
                        report.push({
                            a: title
                        });
                        angular.forEach($filter('orderBy')(item, angular.identity), function(value, index) {
                            report.push({
                                a: index + 1,
                                b: value
                            });
                        });
                    }
                });

                report.push({
                    a: ''
                });

            });

            return report;
        };

        function removeOldSlideElement() {
            var oldPageslideElement = angular.element('div.ng-pageslide'); // please note that this element attached scope is root scope but it sub-element attached scope is the desendant of this controller's scope
            if (oldPageslideElement.length) {
                if (pageSlideCompiledElt) {
                    pageSlideCompiledElt.remove();
                }
                oldPageslideElement.remove();
            }
        }

        function compilePageslideAndShow() {
            $log.log('compilePageslideAndShow');

            removeOldSlideElement();

            var pageslideTmpl = $templateCache.get('views/product-plan-management/validation-history.html');

            pageSlideCompiledElt = $compile(pageslideTmpl)($scope);

            $timeout(function() {
                var divElt = angular.element('div.ng-pageslide');
                divElt.css({
                    'overflow-y': 'auto'
                });
                $scope.isPageslideShown = true;
            }, 100);
        }
    });