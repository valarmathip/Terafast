'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductListCtrl
 * @description
 * # ProductListCtrl
 * Controller of the p2AdvanceApp
 * http://www.bennadel.com/blog/2706-always-trigger-the-destroy-event-before-removing-elements-in-angularjs-directives.htm
 */
angular.module('p2AdvanceApp')
.controller('ValidationReportPageslideCtrl', function($scope, $q, $compile, $templateCache, $filter, ENV, $timeout, $log, ProductPlanMgmtSvc, ConfirmationModalFactory, QueryDialog, moment) {
    $scope.debugMode = (ENV.name === 'local');
    $scope.position = 'right';
    $scope.vResult = null;

    $scope.isPageslideShown = false;

    $scope.identity = angular.identity; // http://stackoverflow.com/questions/17936078/orderby-array-item-value-in-angular-ng-repeat

    $scope.panel = {
        oneAtATime: false,
        error: {
            open: true
        },
        warning: {
            open: true
        }
    };

    var pageSlideCompiledElt;

    // return promise
    $scope.open = function() {
        $scope.defer = $q.defer();

        compilePageslideAndShow();

        return $scope.defer.promise;
    };

    $scope.ok = function(event) {
        event.stopPropagation();
        cleanManualThing();
        close();
        $scope.defer.resolve('close');
    };

    $scope.cancel = function(event) {
        event.stopPropagation();
        cleanManualThing();
        close();
        $scope.defer.reject('dismiss');
    };

    function cleanManualThing() {
        $scope.manualScope.$destroy();
        $scope.manualElement.remove();
    }

    function close() {
        $scope.isPageslideShown = false;
        $timeout(function() {
            removeOldSlideElement();
        }, 250);
    }

    $scope.reposition = function(event, position) {
        event.stopPropagation();
        $scope.isPageslideShown = false;
        $scope.position = position;
        compilePageslideAndShow();
    };

    // When context scope is destroyed, all is descendant will be destroyed, and this event will be triggered
    $scope.$on('$destroy', function() {
        close();
        $scope.manualElement.remove(); // note scope destroy is already triggered
    });

    $scope.filename = 'validation_report_noname_' + $filter('date')(new Date(), 'yyyy_MM_ddTHH_mm_ss_sss');

    $scope.initFileName = function() {
        var fileName = 'validation_report_';
        fileName += $scope.vResult.planName ? $scope.vResult.planName.toString().replace(/ /g, '_') : 'noname';
        fileName += '_';
        fileName += $filter('date')(new Date(), 'yyyy_MM_ddTHH_mm_ss'); // _sss
        fileName += '.csv';
        $log.log(fileName);

        $scope.filename = fileName;
    };

    $scope.getExportArray = function() {
        var report = [];

        report.push({
            a: 'Plan Name:',
            b: $scope.vResult.planName
        });
        report.push({
            a: 'validated on:',
            b: $filter('date')($scope.vResult.validatedDate, 'MMM dd, y')
        });
        report.push({
            a: ''
        });
        report.push({
            a: 'Errors:',
            b: ''
        });
        if ($scope.vResult.errors.length) {
            angular.forEach($filter('orderBy')($scope.vResult.errors, angular.identity), function(value, index) {
                report.push({
                    a: index + 1,
                    b: value
                });
            });
        } else {
            report.push({
                a: '',
                b: 'No errors found'
            });
        }
        report.push({
            a: ''
        });
        report.push({
            a: 'Warning:',
            b: ''
        });
        if ($scope.vResult.warnings.length) {
            angular.forEach($filter('orderBy')($scope.vResult.warnings, angular.identity), function(value, index) {
                report.push({
                    a: index + 1,
                    b: value
                });
            });
        } else {
            report.push({
                a: '',
                b: 'No warnings found'
            });
        }

        return report;
    };


    function removeOldSlideElement() {
        var oldPageslideElement = angular.element('div.ng-pageslide'); // please note that this element attached scope is root scope but it sub-element attached scope is the desendant of this controller's scope
        if (oldPageslideElement.length) {
            if (pageSlideCompiledElt) {
                pageSlideCompiledElt.remove();
            }
            oldPageslideElement.remove();
        }
    }

    function compilePageslideAndShow() {
        $log.log('compilePageslideAndShow');
        removeOldSlideElement();

        var pageslideTmpl = $templateCache.get('views/product-plan-management/template/directives/ppm-pageslide.html');

        pageSlideCompiledElt = $compile(pageslideTmpl)($scope);

        $timeout(function() {
            var divElt = angular.element('div.ng-pageslide');
            divElt.css({
                'overflow-y': 'auto'
            });
            $scope.isPageslideShown = true;
        }, 100);
    }

    $scope.sendForOverride = function() {
        // only if plan status = validation failed, this feature is on
        if ($scope.vResult.planStatus !== 'Validation Failed') {
            return;
        }
        var validationReport = {};

        var auditLogData = {};
        auditLogData.objectRef = $scope.vResult.planId;
        auditLogData['event'] = 'Override Review Initiated';
        auditLogData.auditCategory = 'Validation';
        auditLogData.auditSubCategory = 'Plan';

        validationReport.errors = $scope.vResult.errors;
        validationReport.warnings = $scope.vResult.warnings;
        auditLogData.eventDetails = JSON.stringify(validationReport);

        var planId = $scope.vResult.planId;
        var planName = $scope.vResult.planName;

        ProductPlanMgmtSvc.getOverrideData().then(function(response) {
            // Plan Name
            var date = new Date();
            var postData = response.data;
            postData.name = planName + '_' + date.toJSON();

            // Due Date: current date + 6 week days
            postData.dueDate = genDueDate(6);

            angular.forEach(postData.variables, function(item) {
                if (item.name === 'pm_planid') {
                    item.value = planId;
                }
                
                // current date + 2 week days
                else if (item.name === 'pm_task1_due_date') {
                    item.value = genDueDate(2);
                }
                // current date + 4 week days
                else if (item.name === 'pm_task2_due_date') {
                    item.value = genDueDate(4);
                }
                // current date + 6 week days
                else if (item.name === 'pm_task3_due_date') {
                    item.value = genDueDate(6);
                }
            });

            ProductPlanMgmtSvc.sendOverrideRequest(postData).then(function() {
                $log.log('Override request sent.');
                ProductPlanMgmtSvc.sendAuditLog(auditLogData).then(function() {
                    $log.log('Plan status --> Override In Progress');
                    var newStatus = 'Override In Progress';
                    setPlanStatus(planId, newStatus);

                    if ($scope.planDetails) { // plan details page
                        $scope.planDetails.planStatus = newStatus;
                    } else { // serice list, cost share page
                        $scope.plan.planStatus = newStatus;
                    }
                    $scope.vResult.planStatus = newStatus;

                }, function() {
                    var msg = 'Fail to update audit log';
                    $log.log('Failed --> ' + msg);
                });
            }, function(response) {
                var title = '(' + response.data.status + ') ' + response.data.error;
                var msg = '<p>Override Request Failed</p>' + response.data.message;
                $log.log(title + ' --> ' + msg);
                QueryDialog.open(title, msg, 'minus', 'ppm-modal-dialog-error');
            });
        });
    };

    function genDueDate(daysToAdd) {
        var date = addWeekdays(moment(), daysToAdd);
        return date.hours(12).startOf('hour').format('YYYY-MM-DDTHH:mm:ss.SSSZ');
    }

    function addWeekdays(date, daysToAdd) {
        date = moment(date);
        while (daysToAdd > 0) {
            date = date.add(1, 'days');
            // decrease "days" only if it's a weekday.
            if (date.isoWeekday() !== 6 && date.isoWeekday() !== 7) {
                daysToAdd -= 1;
            }
        }
        return date;
    }


    function setPlanStatus(planId, status) {
        var patchData = {
            'planStatus': status
        };
        ProductPlanMgmtSvc.updatePlan(patchData, planId)
            .then(function() {
                var msgtitle = 'Success';
                var msg = 'Override Request Success. Update Plan Status to ' + status + ' Success.';
                $log.log(msgtitle + ' --> ' + msg);
                ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
            }, function() {
                var msg = 'Override Request Success. Update Plan Status to ' + status + ' Failed.';
                $log.log('Failed --> ' + msg);
            });
    }
});