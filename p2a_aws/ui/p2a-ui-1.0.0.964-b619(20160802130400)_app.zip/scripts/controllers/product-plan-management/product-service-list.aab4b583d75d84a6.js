'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.controller:ProductServiceListCtrl
 * @description
 * # ProductServiceListCtrl
 * Controller of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
    .controller('ProductServiceListCtrl', function($rootScope, $scope, $stateParams, $state, $log, $q, $window, $timeout, ENV, filtersMeta, productL3, uiGridConstants,
        ProductCostShareFacadeSvc, FilterService, ppmUtils, PaginationService, ProductPlanMgmtSvc, PpmFullEqual, QueryDialog, ConfirmationModalFactory, dialogFactorySvc) {
        $scope.debugMode = (ENV.name === 'local');
        $scope.productDetails = $stateParams.productDetails;
        $scope.product = productL3;
        $scope.loadedServiceList = [];
        $scope.loadedServiceListOri = angular.copy($scope.loadedServiceList);
        $scope.serviceList = [];
        $scope.removedServiceMap = {};
        $scope.selectedFilters = {};
        $scope.filters = filtersMeta;
        $scope.productId = $stateParams.productId;
        var pageSize = 20;

        $scope.savingHook.action = function() {
            $scope.saveAndContinue(true); // saveOnly = true
        };
        // before destory the scope, make sure the hooker is removed so that this memory can be released
        $scope.$on('$destroy', function() {
            $scope.savingHook.action = null;
        });

        var gridOptionsTpl = {
            'excessRows': 400, // SLQ need to more investigation
            enableSorting: true,
            enablePaginationControls: false,
            paginationPageSizes: ENV.settings.paginationPageSizes,
            paginationPageSize: pageSize,
            enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
            enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
            rowHeight: 105, // never put number in "", like "100"
            minRowsToShow: 6,
            rowTemplate: 'views/product-plan-management/template/product-service-list/row.html',
            expandableRowTemplate: 'views/product-plan-management/template/product-service-list/expandableRow.html',
            expandableRowHeight: 150, // keep the same value as .ppm-expandable-row
            expandableRowHeaderWidth: 40,
            enableExpandableRowHeader: false,
            // row selection setting
            enableRowHeaderSelection: false, //selectionRowHeaderWidth: 0 // hide row head by setting it width to 0 
            enableRowSelection: false
        };

        gridOptionsTpl.columnDefs = [
            /*{
                        displayName: '',
                        name: 'X1',
                        field: 'element1',
                        width: 80,
                        enableColumnMenu: false,
                        enableColumnMenus: false,
                        enableSorting: false,
                        cellTemplate: 'views/product-plan-management/template/product-service-list/icon-col.html',
                        headerCellTemplate: 'views/product-plan-management/template/product-service-list/icon-header.html'
                    }
            ,*/
            {
                displayName: 'Service Name',
                name: 'serviceName',
                field: 'serviceName',
                width: '40%',
                sort: {
                    direction: uiGridConstants.ASC,
                    priority: 0
                },
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                cellTemplate: 'views/product-plan-management/template/product-service-list/name-col.html'
            }, {
                displayName: 'Category',
                field: 'category',
                width: '13%',
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                cellTemplate: 'views/product-plan-management/template/product-service-list/category-col.html'
            }, {
                displayName: 'Sub-Category',
                field: 'subCategory',
                width: '12%',
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                cellTemplate: 'views/product-plan-management/template/product-service-list/location-col.html'
            }, {
                displayName: 'Level',
                field: 'level',
                width: '10%',
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                cellTemplate: 'views/product-plan-management/template/product-service-list/level-col.html'
            }
        ];


        gridOptionsTpl.onRegisterApi = function(gridApi) {
            $scope.grid.gridApi = gridApi;
            gridApi.pagination.on.paginationChanged($scope, function() {
                filterAndrefresh();
                if (!PaginationService.isGoToPageEnabled) {
                    $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.grid.gridApi, $scope.pageVal.pageNumber);
                }
                PaginationService.setGoToPageEnabled(false);
            });
            // gridApi.selection.on.rowSelectionChanged($scope, setOrResetCheckList);
            // gridApi.selection.on.rowSelectionChangedBatch($scope, setCheckList);
        };

        $scope.grid = {
            tmplUrl: 'views/product-plan-management/template/product-service-list/ui-grid.html',
            gridName: 'List of Services',
            gridOptions: gridOptionsTpl
        };


        $scope.grid.gridOptions.data = 'serviceList';

        $scope.hoverItems = [{
            label: 'Edit Service',
            icon: 'fa-pencil',
            isShown: function() {
                return true;
            },
            action: function(row) {
                $scope.contextMenu.edit.action(row.objectId);
            }
        }, {
            label: 'Do Not Cover this Service',
            isShown: function(row) {
                return notCovered(row);
            },
            action: function(row) {
                $scope.contextMenu.notCover.action(row, false);
            }
        }, {
            label: 'Cover this Service',
            isShown: function(row) {
                return isCovered(row);
            },
            action: function(row) {
                $scope.contextMenu.cover.action(row, true);
            }
        }, {
            label: 'Do Not Include this Service',
            isShown: function() {
                return true;
            },
            action: function(row) {
                $scope.contextMenu.doNotInclude.action(row.objectId);
            }
        }];

        $scope.pageVal = {
            pageNumber: ''
        };

        $scope.navPage = function($event, delta) {
            PaginationService.navPage($event, delta, $scope.grid.gridApi);
            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.grid.gridApi, $scope.pageVal.pageNumber);
        };

        $scope.viewPages = function() {
            var ps = [];
            ps = PaginationService.viewPages($scope.grid.gridApi, ps);
            return ps;
        };
        $scope.pageSizeChanged = function() {
            $scope.grid.gridOptions.paginationCurrentPage = 1;
        };

        $scope.goToPage = function(keyEvent, pageNumberObject) {
            PaginationService.goToPage(keyEvent, pageNumberObject.pageVal, $scope.grid.gridApi);
        };

        function createServiceMap() {
            var serviceMap = {};
            angular.forEach($scope.loadedServiceList, function(item) {
                serviceMap[item.objectId] = item.productSvcJointProps.isCovered;
            });
            return serviceMap;
        }

        $scope.addNewServices = function() {
            $log.log('add new services');

            var dlgUrl = 'views/product-plan-management/template/product-service-list/add-services-to-product-dlg.html';
            var controller = 'AddServiceToProductDlgCtrl';
            var data = {
                filtersMeta: function() {
                    return ProductPlanMgmtSvc.getServiceAddNewListFilterMeta(); // TODO: SLQ it should have its own filters
                },
                associatedServiceMap: function() {
                        return createServiceMap();
                    }
                    // , Since it is already pagination at backend, this part is not needed any more
                    // serviceList: function() { // TOTO: this should be removed, becahse add new service is not backend pagination
                    //     return ProductPlanMgmtSvc.getServiceList(productId).then(function(data) {
                    //         return filterOutExistServiceForAddNewList(data);
                    //     });
                    // }
            };
            var options = {
                size: 'lg'
            };
            var modalInstance = dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
            modalInstance.result.then(function(data) {
                $log.log('the item you selected is = ' + data.length);
                if (data.length > 0) {
                    // get the new associated list, if the newly added service is the one just removed, use removed instead
                    var newAdded = [];
                    var alreadyExistSvcs = '';
                    var alreadyExistSvcsNum = 0;
                    angular.forEach(data, function(svc /*, index*/ ) {
                        if (!isServiceAlreadyAdded(svc.objectId)) {
                            if (svc.objectId in $scope.removedServiceMap) {
                                var justRemovedSvc = $scope.removedServiceMap[svc.objectId];
                                newAdded.push(justRemovedSvc);
                            } else {
                                populateProductSvcJointPropsDefaultValueForNewAssociatedService(svc);
                                newAdded.push(svc);
                            }
                        } else {
                            ++alreadyExistSvcsNum;
                            if (alreadyExistSvcs.length > 0) {
                                alreadyExistSvcs += ', ';
                            }
                            alreadyExistSvcs += alreadyExistSvcsNum + '. ' + svc.serviceName;
                        }
                    });

                    if (alreadyExistSvcs.length > 0) {
                        var message = '<p>The following ' + alreadyExistSvcsNum + ' service(s) already in the product: </p><p>' + alreadyExistSvcs + '</p>';
                        QueryDialog.open('Warning', message, 'warning', 'ppm-modal-dialog-warning');
                    }

                    var newSvcList = $scope.loadedServiceList.concat(newAdded);
                    $scope.loadedServiceList = newSvcList;
                    filterAndrefresh();
                    updateFilterMeta();
                }
            }, function(reason) {
                $log.log('reason you dismiss is ' + reason);
            });
        };

        function isServiceAlreadyAdded(serviceId) {
            var existObjectIds = {};
            angular.forEach($scope.loadedServiceList, function(item /*, index*/ ) {
                existObjectIds[item.objectId] = item.objectId;
            });

            return Boolean(existObjectIds[serviceId]);
        }

        function populateProductSvcJointPropsDefaultValueForNewAssociatedService(service) {
            if (!service.productSvcJointProps) {
                service.productSvcJointProps = {};
            }
            service.productSvcJointProps = {
                isCovered: true
            };
        }

        function notCovered(row) {
            if (!row.productSvcJointProps.isCovered || row.productSvcJointProps.isCovered === 'undefined') {
                return false;
            } else {
                return true;
            }
        }

        function isCovered(row) {
            if (row.productSvcJointProps.isCovered) {
                return false;
            } else {
                return true;
            }
        }

        loadData();

        function loadData() {
            $scope.loadedServiceList = [];

            // Always return promise
            // service Id  as key and map to service with extra property plan-service joint (propertiesis filtered)
            function getAssociatedIds() {
                var productObjectId = $scope.product.objectId;
                productObjectId = ppmUtils.removeVersionFromId(productObjectId);
                return ProductCostShareFacadeSvc.getAssociatedIdsForProductEdit(productObjectId);
            }

            getAssociatedIds()
                .then(function(data) {
                    $scope.loadedServiceList = transferInput(data);
                    // refresh data
                    filterAndrefresh();
                    updateFilterMeta();
                    getLoadedServiceListToOri();
                });
        }

        function getLoadedServiceListToOri() {
            $timeout(function() { // wait for some time for system steady
                $scope.loadedServiceListOri = angular.copy($scope.loadedServiceList);
            }, 100);
        }


        function transferInput(data) { // SLQ not sure if we need put this in cost-share-facade.js
            var transferedData = [];
            angular.forEach(data, function(item /*, index*/ ) {
                var transferedItem = {};
                angular.forEach(item, function(value, key) {
                    transferedItem[key] = angular.copy(value); // TODO: if it is really flated data, no deep copy necessary.
                });
                transferedData.push(transferedItem);
            });
            return transferedData;
        }

        $scope.contextMenu = {
            edit: {
                id: 'edit',
                action: function(guid) {
                    $log.log('Edit service guid = ' + guid);
                    // go to next page
                    function goToNextPage() {
                        ProductCostShareFacadeSvc.associatedServices($scope.loadedServiceList); // Since before we put the service in Controller
                        $state.go('home.ppm.product.edit.cost-share', {
                            productId: $scope.productId,
                            serviceId: guid
                        });
                    }

                    $q.when(isEqual())
                        .then(function(isSame) {
                            if (!isSame) {
                                return associateServiceToProduct($scope.loadedServiceList);
                            }
                        })
                        .then(function() {
                            goToNextPage();
                        });
                },
                enabled: true
            },
            cover: {
                id: 'cover',
                action: function(service, value) {
                    if (!service.productSvcJointProps) {
                        service.productSvcJointProps = {};
                    }
                    service.productSvcJointProps.isCovered = value;
                    angular.forEach($scope.loadedServiceList, function(serviceValue) {
                        if (serviceValue.objectId === service.objectId) {
                            serviceValue.productSvcJointProps.isCovered = service.productSvcJointProps.isCovered;
                        }
                    });
                    filterAndrefresh();
                },
                enabled: true
            },
            notCover: {
                id: 'notCover',
                action: function(service, value) {
                    if (!service.productSvcJointProps) {
                        service.productSvcJointProps = {};
                    }
                    service.productSvcJointProps.isCovered = value;
                    angular.forEach($scope.loadedServiceList, function(serviceValue) {
                        if (serviceValue.objectId === service.objectId) {
                            serviceValue.productSvcJointProps.isCovered = service.productSvcJointProps.isCovered;
                        }
                    });
                    filterAndrefresh();
                },
                enabled: true
            },
            doNotInclude: {
                id: 'doNotInclude',
                action: function(id) {
                    // var selectedRows = $scope.grid.gridApi.selection.getSelectedRows();

                    var removedId = {};
                    // angular.forEach(selectedRows, function(row) {
                    removedId[id] = id;
                    // });

                    var message = '<p>Selecting "Do Not Include" will delete this Service from the product. </p><p>Do you want to save this change to the Service?</p>';
                    var modalInstance = QueryDialog.open('Warning', message, 'question', 'ppm-modal-dialog-question');

                    modalInstance.result.then(function() {
                        $scope.selectedServiceList = [];
                        angular.forEach($scope.loadedServiceList, function(service) {
                            if (!!removedId[service.objectId]) {
                                $scope.selectedServiceList.push(service);
                            }
                        });

                        $log.log('Total selected services = ' + $scope.selectedServiceList.length);

                        var newSvcList = [];
                        var removedSvcList = {};
                        angular.forEach($scope.loadedServiceList, function(item /*, index*/ ) {
                            if (!removedId[item.objectId]) {
                                newSvcList.push(item);
                            } else {
                                removedSvcList[item.objectId] = item;
                            }
                        });

                        $scope.loadedServiceList = newSvcList;
                        $scope.removedServiceMap = removedSvcList;
                        filterAndrefresh();
                        updateFilterMeta();
                        if ($scope.loadedServiceList.length - (($scope.grid.gridOptions.paginationCurrentPage - 1) * $scope.grid.gridOptions.paginationPageSize) === 0) {
                            $scope.grid.gridOptions.paginationCurrentPage -= 1;
                            $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.grid.gridApi, $scope.pageVal.pageNumber);
                        }
                        // clear all selected flag
                        // $scope.grid.gridApi.selection.clearSelectedRows();
                    }, function() {
                        $log.log('Warning modal dismissed for Do Not Include.');
                    });
                },
                enabled: true
            }
        };

        function filterAndrefresh() {
            var result;
            if (angular.isUndefined($scope.serviceSearchQuery) || $scope.serviceSearchQuery === '') {
                $scope.serviceList = [];
                result = angular.copy($scope.loadedServiceList);
            } else {
                filterServicesWithNames();
                result = angular.copy($scope.serviceList);
            }
            result = filterItems(result);
            $scope.serviceList = [];
            $scope.serviceList = FilterService.refreshGridData(result, $scope.serviceList);
        }


        /* called when user clicks continue to edit services */
        $scope.saveAndContinue = function(saveOnly) {
            // return promise
            function testEqual() {
                return $q.when(isEqual());
            }
            // return promose
            function doSave() {
                return associateServiceToProduct($scope.loadedServiceList);
            }
            // go to next page
            function goToNextPage() {
                ProductCostShareFacadeSvc.associatedServices($scope.loadedServiceList); // SLQ This service should be generated in fly. Since before we put the service in Controller
                $state.go('home.ppm.product.edit.cost-share', {
                    productId: $scope.productId,
                    svcIdx: 0
                });
            }

            testEqual()
                .then(function(isSame) {
                    if (!isSame) {
                        return doSave();
                        //.then(function(data) {
                        //    // clean cache. Because the data changed and force the UI to reload the updated data
                        //    CostShareFacadeSvc.clearCache();
                        //    return data;
                        //});
                    }
                })
                .then(function() {
                    //$scope.componentStatus.isValidationEnabled = true;
                    if (!saveOnly) {
                        goToNextPage();
                    }
                });
        };


        $scope.backProductDetails = function() {
            // return promise
            function testEqual() {
                return $q.when(isEqual());
            }
            // return promose
            function doSave() {
                return associateServiceToProduct($scope.loadedServiceList);
            }

            testEqual()
                .then(function(isSame) {
                    if (!isSame) {
                        return doSave();
                    }
                })
                .then(function() {
                    // $scope.componentStatus.isValidationEnabled = true;
                    $state.go('home.ppm.product.edit.product-details', {
                        productId: $scope.productId
                    });
                });
        };

        function isEqual() {
            var config = {
                'value': {
                    sortAndCompare: {
                        expression: ['objectId']
                    }
                }
            };
            var equalSvc = new PpmFullEqual(config);
            var compResult = {};
            var isSame = equalSvc.equals($scope.loadedServiceList, $scope.loadedServiceListOri, compResult);

            $log.log('########## Nothing changed: ' + isSame);

            return isSame;
        }

        function associateServiceToProduct(assoList) {
            var productServiceList = fromJointPropertyToLinkedProductServices(assoList);

            var product = {
                'productservices': productServiceList // in ui this is called planSvcJointProps, because service is first order in ui
            };
            return ProductPlanMgmtSvc.updateProduct(product, $scope.product.objectId).then(function(data) {
                if (data.status && data.status !== '200') { // Remember that gateway will return the error info
                    $log.log(data.status);
                } else {
                    $scope.removedServiceMap = {}; // Clear removed map if save successfully
                    $scope.product.status = 'Draft'; // If the update successfully, the status can be expected to be draft
                    return data; // not important
                }
            }, function(reason) {
                $log.log(reason);
                return $q.reject(reason);
            }).then(function() {
                // The return data is plan id, not planservice Id. So the new create planService Id is not set
                // return addJointObjectId(assoList).then(function() { 
                //     $scope.loadedServiceList = assoList; SLQ1626 need to check what this for; loadData will reload them, so do not need it here
                //     filterAndrefresh();  SLQ1626 need to check what this for; these 2 was also called in loadData
                //     updateFilterMeta();  SLQ1626 need to check what this for
                // });

                return ProductCostShareFacadeSvc.updateCachedProductL3ForLinkedProductService($scope.product.objectId, product, assoList);
            }).then(function() {
                loadData();
            });
        } /** End of associateServiceToPlan **/

        function fromJointPropertyToLinkedProductServices(assoList) {
            var linkedProductServiceList = [];

            angular.forEach(assoList, function(service) {
                var linkedProductService = {};

                if (service.productSvcJointProps && service.productSvcJointProps.linkedProductServiceId) {
                    linkedProductService.objectId = service.productSvcJointProps.linkedProductServiceId;
                } else {
                    linkedProductService.productId = $scope.product.objectId; // plan objectId
                    linkedProductService.serviceId = service.objectId; // service ObjectId
                    linkedProductService.productName = $scope.product.name;
                }

                // The following is the properties that could be changed in plan service page
                // All other properties are ignored because they will be able to be changed
                if (service.productSvcJointProps) {
                    linkedProductService.isCovered = service.productSvcJointProps.isCovered;
                }

                // push into list
                linkedProductServiceList.push(linkedProductService);
            });

            return linkedProductServiceList;
        }

        function getValues(fieldName) {
            var values = {};
            angular.forEach($scope.loadedServiceList, function(service) {
                var modifier = service[fieldName];
                if (angular.isArray(modifier)) {
                    angular.forEach(modifier, function(modifierValue) {
                        values[modifierValue] = modifierValue;
                    });
                } else {
                    values[modifier] = modifier;
                }
            });

            return values;
        }

        var filterValuesFinder = {
            'Product': function() {
                return getValues('productClasses');
            },
            'Product Type': function() {
                return getValues('productTypes');
            },
            'Service Category': function() {
                return getValues('category');
            },
            'Service Sub Category': function() {
                return getValues('subCategory');
            },
            'Service Level': function() {
                return getValues('level');
            }
        }; // End of filterValuesFinder


        function makeFilterFromValues(values, attrId, attrName) {
            var filterValues = [];

            angular.forEach(values, function(item) {
                filterValues.push({
                    'AttributeId': attrId,
                    'AttributeName': attrName,
                    'AttributeValue': item,
                    'DisplayValue': item
                });
            });

            return filterValues;
        }

        var filterValuesMaker = {
            'Product': function(values) {
                return makeFilterFromValues(values, 'productClass', 'Product');
            },
            'Product Type': function(values) {
                return makeFilterFromValues(values, 'productTypes', 'Product Type');
            },
            'Service Category': function(values) {
                return makeFilterFromValues(values, 'serviceCategory', 'Service Category');
            },
            'Service Sub Category': function(values) {
                return makeFilterFromValues(values, 'serviceSubCategory', 'Service Sub Category');
            },
            'Service Level': function(values) {
                return makeFilterFromValues(values, 'serviceLevel', 'Service Level');
            }
        }; // End of filterValuesMaker

        $scope.doSearch = function(keyEvent) {
            if (keyEvent.which === 13) {
                $scope.grid.gridOptions.paginationCurrentPage = 1;
                filterServicesWithNames();
                if (Object.keys($scope.selectedFilters).length > 0) {
                    filterAndrefresh();
                }
                $scope.pageVal.pageNumber = PaginationService.resetPageNumber($scope.grid.gridApi, $scope.pageVal.pageNumber);
            }
        };

        function filterServicesWithNames() {
            $scope.serviceList = [];
            var resultSvc = [];
            if ($scope.serviceSearchQuery !== null && $scope.serviceSearchQuery !== '' && $scope.serviceSearchQuery !== undefined && $scope.serviceSearchQuery !== '*') {
                var counter = searchStarCounter($scope.serviceSearchQuery);
                var regExStr = makeRegexStr(counter);
                if (counter === 1) {
                    regExStr = matchRuleShort($scope.serviceSearchQuery);
                } else if (counter === 2) {
                    regExStr = removeStar($scope.serviceSearchQuery);
                }
                angular.forEach($scope.loadedServiceList, function(svc) {
                    if (svc.serviceName.toLowerCase() === $scope.serviceSearchQuery.toLowerCase() || (typeof regExStr === 'object' && regExStr.test(svc.serviceName))) {
                        resultSvc.push(svc);
                    }
                });
            } else {
                angular.forEach($scope.loadedServiceList, function(svcObj) {
                    resultSvc.push(svcObj);
                });
            }
            $scope.serviceList = FilterService.refreshGridData(resultSvc, $scope.serviceList);
        }

        function searchStarCounter(searchQuery) {
            var indices = [];
            for (var i = 0; i < searchQuery.length; i++) {
                if (searchQuery[i] === '*') {
                    indices.push(i);
                }
            }
            if (indices.length > 1) {
                return 2;
            } else if (indices.length === 1) {
                return 1;
            } else {
                if ($scope.matchCase) {
                    return 3;
                } else {
                    return 0;
                }
            }
        }

        function makeRegexStr(counter) {
            var regExStr;
            switch (counter) {
                case 0:
                    var searchQuery = '\\b' + $scope.serviceSearchQuery;
                    regExStr = new RegExp(searchQuery, 'i');
                    break;
                case 1:
                    regExStr = matchRuleShort($scope.serviceSearchQuery);
                    break;
                case 2:
                    regExStr = removeStar($scope.serviceSearchQuery);
                    break;
                case 3:
                    regExStr = $scope.serviceSearchQuery;
                    break;
            }
            return regExStr;
        }

        function matchRuleShort(rule) {
            return new RegExp('^' + rule.replace('*', '.*') + '$', 'i');
        }

        function removeStar(searchQuery) {
            return new RegExp(searchQuery.slice(1, searchQuery.length - 1), 'i');
        }

        $scope.queryData = function(selectedId, objs) {
            $scope.selectedFilters = FilterService.queryData($scope.selectedFilters, selectedId, objs, $scope.grid.gridOptions);
            filterAndrefresh();
        };

        var filtersNeedToBeUpdateWithServiceList = ['Product', /*'Product Type',*/ 'Service Category',
            'Service Sub Category', 'Service Level'
        ];

        function setValueByKey(obj, criteria, newValue, oldValue) {
            angular.forEach(obj, function(item, key) {
                if (key.toString().toLowerCase() === criteria.toString().toLowerCase()) {
                    oldValue.push(item);
                    obj[key] = newValue;
                } else {
                    if (angular.isArray(item) || angular.isObject(item)) {
                        setValueByKey(item, criteria, newValue, oldValue);
                    }
                }
            });
        }

        function updateFilterMeta() {
            angular.forEach(filtersNeedToBeUpdateWithServiceList, function(filter) {
                var filterValues = filterValuesFinder[filter].apply(undefined);
                var newValue = filterValuesMaker[filter].apply(undefined, [filterValues]);

                var oldValue = [];
                setValueByKey($scope.filters, filter, newValue, oldValue);
                if (oldValue.length > 1 || oldValue.length === 0) {
                    throw 'more than one field or no fild found, found number = ' + oldValue.length;
                }
            });
        }

        /*
         * matchFn's signature: matchFn(service, filterValue)
         * matchFn's name is the same as filter Id in filter meta data
         */
        function matchFilters(service, filterValues, matchFn) {
            var matched = false;
            angular.forEach(filterValues, function(filterValue) {
                if (matchFn.apply(undefined, [service, filterValue])) {
                    matched = true;
                    return false;
                }
            });

            return matched;
        }

        /**
         * Collection of matchFn
         */
        var filterComparators = {
            productClass: function(service, filterValue) {
                if (!service.productClasses || service.productClasses.length === 0) {
                    return false;
                }

                return ppmUtils.arryContainStringIgnoreCase(service.productClasses, filterValue);
            },
            productTypes: function(service, filterValue) {
                if (!service.productTypes || service.productTypes.length === 0) {
                    return false;
                }

                return ppmUtils.arryContainStringIgnoreCase(service.productTypes, filterValue);
            },
            marketSegment: function(service, filterValue) {
                if (!service.marketSegments) {
                    return false;
                }

                return filterValue.toString().toLowerCase() === service.marketSegments.toString().toLowerCase();
            },
            serviceCategory: function(service, filterValue) {
                if (!service.category) {
                    return false;
                }

                return filterValue.toString().toLowerCase() === service.category.toString().toLowerCase();
            },
            serviceSubCategory: function(service, filterValue) {
                if (!service.subCategory) {
                    return false;
                }

                return filterValue.toString().toLowerCase() === service.subCategory.toString().toLowerCase();
            },
            serviceLevel: function(service, filterValue) {
                if (!service.level) {
                    return false;
                }

                return filterValue.toString().toLowerCase() === service.level.toString().toLowerCase();
            },
            effectiveStartDate: function(service, filterValue) {
                if (!service.effectiveDate) {
                    return false;
                }

                return CompareDateWithCriterias(service.effectiveDate, filterValue);
            },
            effectiveEndDate: function(service, filterValue) {
                if (!service.endDate) {
                    return false;
                }

                return CompareDateWithCriterias(service.endDate, filterValue);
            },
            copay: function( /*service, filterValue*/ ) {
                ConfirmationModalFactory.open('Not Implemented', 'The copay filter is not finished!', ENV.modalErrorTimeout);

                return true;
            },
            deductibleIndividual: function( /*service, filterValue*/ ) {
                ConfirmationModalFactory.open('Not Implemented', 'The Decutible (Individual) filter is not finished!', ENV.modalErrorTimeout);

                return true;
            },
            deductibleFamily: function( /*service, filterValue*/ ) {
                ConfirmationModalFactory.open('Not Implemented', 'The Decutible (Family) filter is not finished!', ENV.modalErrorTimeout);

                return true;
            },
            coInsurance: function( /*service, filterValue*/ ) {
                ConfirmationModalFactory.open('Not Implemented', 'The Co-insurance filter is not finished!', ENV.modalErrorTimeout);

                return true;
            },
            maxOutOfPocketIndividual: function( /*service, filterValue*/ ) {
                ConfirmationModalFactory.open('Not Implemented', 'The Max out of pocket (Individual) filter is not finished!', ENV.modalErrorTimeout);

                return true;
            },
            maxOutOfPocketFamily: function( /*service, filterValue*/ ) {
                ConfirmationModalFactory.open('Not Implemented', 'The Max out of pocket (Family) filter is not finished!', ENV.modalErrorTimeout);

                return true;
            }
        }; // End of filterComparators

        function CompareDateWithCriterias(dateStr, filterValue) {
            var planDate = new Date(dateStr);
            var today = new Date();
            var date = new Date();

            //console.log('planDate is ' + planDate);
            if (filterValue.toString().toLowerCase() === 'last 6 months') {
                date.setMonth(date.getMonth() - 6);
                return (planDate <= today && planDate >= date);
            } else if (filterValue.toString().toLowerCase() === 'next 6 months') {
                date.setMonth(date.getMonth() + 6);
                return (planDate >= today && planDate <= date);
            } else if (filterValue.toString().toLowerCase() === 'last 12 months') {
                date.setMonth(date.getMonth() - 12);
                return (planDate <= today && planDate >= date);
            } else if (filterValue.toString().toLowerCase() === 'next 12 months') {
                date.setMonth(date.getMonth() + 12);
                return (planDate >= today && planDate <= date);
            }
            return false;
        }

        /**
         * Implement the filter functionality
         */
        function filterItems(services) {
            var result = [];
            angular.forEach(services, function(service) {
                var passFilter = true;
                angular.forEach($scope.selectedFilters, function(filterValues, filterId) {
                    passFilter = passFilter && matchFilters(service, filterValues, filterComparators[filterId]);
                    if (!passFilter) {
                        return false;
                    }
                });
                if (passFilter) {
                    result.push(service);
                }
            });

            return result;
        }

        $scope.clearAll = function() {
            $rootScope.$broadcast('clearAllSelected');
        };

        $scope.createNew = function() {
            $state.go('home.ppm.product.edit.product-details', {
                productId: ''
            });
        };
    });