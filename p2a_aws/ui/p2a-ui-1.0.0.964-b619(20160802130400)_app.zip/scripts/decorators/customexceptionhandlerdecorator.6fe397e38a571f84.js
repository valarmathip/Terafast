'use strict';

/**
 * @ngdoc function
 * @name p2AdvanceApp.decorator:Customexceptionhandler
 * @description
 * # Customexceptionhandler
 * Decorator of the p2AdvanceApp
 */
angular.module('p2AdvanceApp')
  .config(function($provide) {
    $provide.decorator('$exceptionHandler', function($log, $delegate, uiConfig, moment) {
      var LOG_ALERT = 14;
      var ERROR_CONDITIONS = 3;
      return function(exception, cause) {
        $delegate(exception, cause);

        var exceptionData = {
          headers: {
            facility: LOG_ALERT,
            severity: ERROR_CONDITIONS,
            msgid: 'UI-EXCEPTIONS',
            appName: uiConfig.appName,
            version: uiConfig.version,
            timestamps: moment().unix(),
            hostname: window.location.hostname
          }, 
          structuredData: {
            search: window.location.search,
            uuid: ''
          },
          msg: {}
        };

        if (cause) {
          exceptionData.msg.cause = cause;
        }

        if (exception) {
          if (exception.message) {
            exceptionData.msg.message = exception.message;
          }
          if (exception.name) {
            exceptionData.msg.name = exception.name;
          }
          if (exception.stack) {
            exceptionData.msg.stack = exception.stack;
          }
        }

        if (uiConfig.debug) {
          $log.error('exception', exceptionData);
        }

        // TODO Need to be implemented. 
        //SYSLog.send('exception', data);

      };
    });
  });