'use strict';

angular.module('p2AdvanceApp').config(['schemaFormProvider',
    'schemaFormDecoratorsProvider', 'sfPathProvider',
    function(schemaFormProvider, schemaFormDecoratorsProvider, sfPathProvider) {

        // First, we want this to be the default for a combination of schema parameters
        var p2aDropdownSelection = function(name, schema, options) {
            if (schema.type === 'string' && schema.format === 'p2aDropdownSelection') {
                // Initiate a form provider
                var f = schemaFormProvider.stdFormObj(name, schema, options);
                f.key = options.path;
                f.type = 'p2aDropdownSelection';
                // Add it to the lookup dict (for internal use)
                options.lookup[sfPathProvider.stringify(options.path)] = f;
                return f;
            }
        };
        // Add our default to the defaults array
        schemaFormProvider.defaults.string.unshift(p2aDropdownSelection);

        // Second, we want it to show if someone have explicitly set the form type
        schemaFormDecoratorsProvider.addMapping('bootstrapDecorator', 'p2aDropdownSelection',
            'views/workflow-management/template/angular-schema-form-add-ons/p2aDropdownSelection.template.html');
    }
]);

