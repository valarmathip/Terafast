'use strict';
/**
 *  Event:
 *      hrRefineFacets.internal.clearAll: clean all selection in the sub fitler item
 *      hrRefineFacets.internal.facetsChanged: trigged when any of facets value is changed
 * 
 */
angular.module('p2AdvanceApp')
    .directive('hrRefineFacets', function($timeout, $log) { /*jshint ignore:line*/
        function parseMetadateToMap(data) {
            var ret = {};

            angular.forEach(data, function(value, index) { /*jshint ignore:line*/
                ret[value.nameId] = value.displayName;
            });

            return ret;
        }

        return {
            restrict: 'A',
            templateUrl: 'views/ui-framework/templates/hr-refine-facets.html',
            scope: {
                facets: '=hrRefineFacets',
                facetsReferredMetadata: '@hrRefineFacetsReferredMetadata', // use attribute to avoid data binding
                facetsChanged: '&'
            },
            controller: function($scope, $element, $attrs, $transclude) { /*jshint ignore:line*/
                //
            },
            link: function(scope, iElement, iAttrs) { /*jshint ignore:line*/
                scope.result = {};

                scope.clearAll = function() {
                    scope.$broadcast('hrRefineFacets.internal.clearAll');
                    $timeout(function() { // event must be emit in next cycle to make sure all value are cleared
                        scope.$emit('hrRefineFacets.internal.facetsChanged');
                    });
                };

                var nameIdMap = {};
                if (scope.facetsReferredMetadata) {
                    var metadata = scope.$parent.$eval(scope.facetsReferredMetadata);
                    nameIdMap = parseMetadateToMap(metadata) || {};
                }

                scope.getDisplayName = function(facetKey) {
                    var displayName = nameIdMap[facetKey];

                    return displayName || facetKey;
                };

                scope.$on('hrRefineFacets.internal.facetsChanged', function(event) {
                    event.stopPropagation();
                    $log.log(angular.toJson(scope.result, true));

                    var facetsQueryList = [];

                    angular.forEach(scope.result, function(facetValue, facetName) {
                        var facetQuery = facetValue.getQueryString(facetName);
                        if (facetQuery) {
                            facetsQueryList.push('(' + facetQuery + ')');
                        }
                    });

                    var fcetsQueryString = facetsQueryList.join(' && ');

                    $log.log('fcetsQueryString ===== ' + fcetsQueryString);

                    if (scope.facetsChanged) {
                        scope.facetsChanged({
                            queryString: fcetsQueryString
                        });
                    }
                });
            }
        };
    });

angular.module('p2AdvanceApp')
    .factory('hrRefineFacetsService', function($timeout, moment, $log) { /*jshint ignore:line*/

        var service = {
            getDefaultLinkFn: function() {
                return defaultLinkFn;
            },
            getDateRangeLinkFn: function() {
                return dateRangeLinkFn;
            }
        };

        function FacetBase(scope, iElement, iAttrs) { /*jshint ignore:line*/
            var clearFn = this.clearValueFn;
            var queryFn = this.getQueryStringFn;


            // Facet initially is collapsed
            scope.isCollapsed = true;
            // init localValue (one property of the result)
            var parentDirectiveScope = iElement.parents('[hr-refine-facets]').isolateScope();
            if (!parentDirectiveScope.result[scope.facetKey]) {
                parentDirectiveScope.result[scope.facetKey] = {};
            }
            if (!parentDirectiveScope.result[scope.facetKey].data) {
                parentDirectiveScope.result[scope.facetKey].data = clearFn.apply(null); // set the data to its init status
            }
            parentDirectiveScope.result[scope.facetKey].getQueryString = queryFn; // root directive will call this to get query string
            // make a local variable to point the this part of directive in result
            scope.localValue = parentDirectiveScope.result[scope.facetKey].data;
            // Get a local copy of the getDisplayName function
            scope.getDisplayName = parentDirectiveScope.getDisplayName;

            // Define event handler
            scope.valueLabelClicked = function($event) { /*jshint ignore:line*/
                $timeout(function() { // must emit in next cycle to make use result value is updated 
                    scope.$emit('hrRefineFacets.internal.facetsChanged');
                });
            };

            scope.clear = function(event) { /*jshint ignore:line*/
                clearFacetValue();
                scope.$emit('hrRefineFacets.internal.facetsChanged');
            };

            scope.toggleFacetCollapse = function(event) { /*jshint ignore:line*/
                scope.isCollapsed = !scope.isCollapsed;
                var collapseElement = iElement.find('.hr-facet-item-values');
                if (scope.isCollapsed) {
                    collapseElement.removeClass('open');
                } else {
                    collapseElement.addClass('open');
                }
            };
            // Register event listener
            scope.$on('hrRefineFacets.internal.clearAll', clearFacetValue);

            function clearFacetValue() {
                var parentDirectiveScope = iElement.parents('[hr-refine-facets]').isolateScope();
                parentDirectiveScope.result[scope.facetKey].data = scope.localValue = clearFn.apply(null);
            }
        }

        function defaultLinkFn(scope, iElement, iAttrs) { /*jshint ignore:line*/
            var config = {
                getQueryStringFn: function(facetKey) {
                    var ret = [];
                    angular.forEach(this.data, function(value, key) {
                        if (value) {
                            ret.push(facetKey + ' = ' + key);
                        }
                    });

                    return ret.join(' || ');
                },

                clearValueFn: function() {
                    return {};
                }
            };

            FacetBase.apply(config, [scope, iElement, iAttrs]);
        }

        function dateRangeLinkFn(scope, iElement, iAttrs) {
            var config = {
                getQueryStringFn: function(facetKey) {
                    var format = 'YYYY-MM-DD';
                    var min, max;
                    var ret;

                    angular.forEach(this.data, function(value, key) { /*jshint ignore:line*/
                        var start, end;

                        switch (key) {
                            case 'Previous 6 months':
                                if (value) {
                                    start = moment();
                                    end = moment().add(6, 'month');
                                }
                                break;
                            case 'Previous 12 months':
                                if (value) {
                                    start = moment();
                                    end = moment().add(1, 'year');
                                }
                                break;
                            case 'customDateRange':
                                if (value.checkbox && value.start && value.end) {
                                    start = moment(new Date(value.start)); // add new Date() just remove monent warning
                                    end = moment(new Date(value.end));
                                }
                                break;
                        }

                        if (!min || start && min.isAfter(start)) {
                            min = start;
                        }
                        if (!max || end && max.isBefore(end)) {
                            max = end;
                        }
                    });


                    if (max && min) {
                        ret = ' ( ' + facetKey + ' > ' + min.format(format) + ' && ' + facetKey + ' < ' + max.format(format) + ' ) ';
                    }

                    return ret;
                },

                clearValueFn: function() {
                    return {
                        customDateRange: {}
                    };
                }
            };
            // init base setup
            FacetBase.apply(config, [scope, iElement, iAttrs]);

            scope.openStatus = {
                isStartOpen: false,
                isEndOpen: false
            };

            // Calendar
            scope.openStartCalendar = function(event) {
                event.preventDefault();
                event.stopPropagation();
                scope.openStatus.isStartOpen = true;
            };

            scope.openEndCalendar = function(event) {
                event.preventDefault();
                event.stopPropagation();
                scope.openStatus.isEndOpen = true;
            };

            scope.custumDateRangeChanged = function($event) { /*jshint ignore:line*/
                $timeout(function() {
                    scope.$emit('hrRefineFacets.internal.facetsChanged');
                });
            };
        }

        return service;
    });


angular.module('p2AdvanceApp')
    .directive('hrRefineFacetItem', function($timeout, $log, hrRefineFacetsService) { /*jshint ignore:line*/
        return {
            restrict: 'A',
            require: '^hrRefineFacets',
            templateUrl: 'views/ui-framework/templates/hr-refine-facet-default.html',
            // controller: function($scope, $element, $attrs, $transclude) { /*jshint ignore:line*/ },
            link: hrRefineFacetsService.getDefaultLinkFn()
        };
    });

angular.module('p2AdvanceApp')
    .directive('hrRefineFacetItemDateRange', function($timeout, $log, hrRefineFacetsService) { /*jshint ignore:line*/

        return {
            restrict: 'A',
            require: '^hrRefineFacets',
            templateUrl: 'views/ui-framework/templates/hr-refine-facet-date-range.html',
            controller: function($scope, $element, $attrs, $transclude) { /*jshint ignore:line*/
                // not work if put in link Function
                $scope.dateOptions = {
                    showWeeks: false
                };
            },
            link: hrRefineFacetsService.getDateRangeLinkFn()
        };
    });