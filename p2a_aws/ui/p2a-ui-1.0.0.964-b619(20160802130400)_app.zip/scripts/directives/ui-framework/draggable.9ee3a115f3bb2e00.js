'use strict';

angular.module('p2AdvanceApp')
.directive('draggable', function($document, $window) {
    return function(scope, element) {
        var startX = 0, startY = 0, x, y;
        element.css({
            position: 'absolute',
            display: 'block',
            zIndex: 10
        });
        element.on('mousedown', function(event) {
            // Prevent default dragging of selected content
            event.preventDefault();
            if (x === undefined && y === undefined) {
                // initialization
                x = element[0].offsetLeft;
                y = element[0].offsetTop;
            }
            startX = event.clientX - x;
            startY = event.clientY - y;
            $document.on('mousemove', mousemove);
            $document.on('mouseup', mouseup);
        });

        function mousemove(event) {
            if (event.clientY < $window.innerHeight - 50 && event.clientY > 50 && event.clientX < $window.innerWidth - 50 && event.clientX > 50) {
                y = event.clientY - startY;
                x = event.clientX - startX;
                element.css({
                    top: y + 'px',
                    left: x + 'px'
                });
            }
        }
        var w = angular.element($window);

        // reset to prevent window from jumping unexpectedly
        w.bind('resize', function() {
            x = undefined;
            y = undefined;
        });

        function mouseup() {
            $document.off('mousemove', mousemove);
            $document.off('mouseup', mouseup);
        }
    };
});
