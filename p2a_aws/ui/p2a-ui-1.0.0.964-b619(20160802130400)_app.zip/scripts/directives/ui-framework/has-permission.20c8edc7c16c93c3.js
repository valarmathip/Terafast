'use strict';

/**
 * @ngdoc directive
 * @name p2AdvanceApp.directive:hasPermission
 * @description
 * # hasPermission
 */
angular.module('p2AdvanceApp')
  .directive('hasPermission', function (userAuthorizationManager) {
    return {
	    link: function(scope, element, attrs) {
	      if(!angular.isString(attrs.hasPermission)) {
	        throw 'hasPermission value must be a string';
	      }
	      var permissions = extractPermissions(attrs.hasPermission);

	      function extractPermissions(hasPermission) {
	      	var permissions = [];
	      	var hasPermissionArray = hasPermission.split(',');

	      	if (hasPermission === '') {
	      		return permissions;
	      	}

	      	for (var i=0,j=hasPermissionArray.length; i<j; i++) {
	      		var permission = {};
	      		permission.id = hasPermissionArray[i].trim();
	      		permission.notFlag = permission.id[0] === '!';
	      		permission.orFlag = permission.id[0] === '|';
	      		if (permission.notFlag || permission.orFlag) {
			       permission.id = permission.id.slice(1).trim();
			    }
			    permissions.push(permission);
	      	}
	      	
	      	return permissions;
	      } 

	      function toggleVisibilityBasedOnPermission() {
	      	var isShown = true;
	      	if (permissions.length > 0) {
	      		for (var i=0,j=permissions.length; i < j ; i++) {
	      			var permission = permissions[i];
	      			var hasPermission = userAuthorizationManager.hasPermission(permission.id);           
			        if (hasPermission && !permission.notFlag || !hasPermission && permission.notFlag) {
			          isShown = true;
			          // Check if is a OR permission 
			          if (permission.orFlag) {
			          	break;
			          }
			        } else {
			          // Only if is AND permission . 
			          if (!permission.orFlag || i === j - 1) {
			          	isShown = false;
			          	break;
			          }
			        }
	      		}

	      		if (isShown) {
	      			element.show();
	      		} else {
	      			element.hide();
	      		}

	      	} else {
	      		// Asuming that not permissions as undefined action, will show the element 
	      		element.show();
	      	}
	      }

	      toggleVisibilityBasedOnPermission();

	      // Create a lister to update UI element visibility without reload the 
	      // app. 
	      scope.$on('permissionsChanged', toggleVisibilityBasedOnPermission);
	    }
	  };
  });
