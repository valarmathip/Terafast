'use strict';
/**
 * @ngdoc
 * @name attrFilterTags
 * @description directive for tag filters
 * created by vladimir 03.04.2016
 *
 *
 */
angular.module('p2AdvanceApp')
    .directive('attrFilterTags', ['$rootScope',
        function($rootScope) {
            return {
                templateUrl: 'views/ui-framework/templates/attr-filter-tags-template.html',
                restrict: 'E',
                scope: {},
                link: function($scope) {

                    // object where tags for selected filters are stored
                    $scope.tags = {};

                    //functions for events
                    //separated for easier testing
                    $scope.addTagFilter = function(event, data) {
                        // update tags array
                        if (!$scope.tags[data.AttributeName]) {
                            $scope.tags[data.AttributeName] = [];
                            $scope.tags[data.AttributeName].push(data);
                        } else {
                            $scope.tags[data.AttributeName].push(data);
                        }
                    };

                    $scope.removeTagFilter = function(event, data) {
                        // update tags array
                        var index = $scope.tags[data.AttributeName].indexOf(data);
                        if (index !== -1) {
                            $scope.tags[data.AttributeName].splice(index, 1);
                        }
                        if ($scope.tags[data.AttributeName].length === 0) {
                            delete $scope.tags[data.AttributeName];
                        }
                    };

                    $scope.clearFilters = function(event, data) {
                        for (var key in $scope.tags) {
                            if ($scope.tags[key][0].AttributeId === data) {
                                delete $scope.tags[key];
                            }
                        }
                    };

                    $scope.selectAll = function(event, data) {
                        if ($scope.tags[data.attributeName]) {
                            delete $scope.tags[data.attributeName];
                        }
                        $scope.tags[data.attributeName] = [];
                        $scope.tags[data.attributeName] = data.tags;
                    };

                    $scope.deselectAll = function(event, data) {
                        $scope.tags[data.attributeName] = [];
                        delete $scope.tags[data.attributeName];
                    };

                    //START
                    // waiting for events that should make change on $scope.tags
                    //
                    // event for selecting filter
                    $scope.$on('attrFilterTags.addTagFilter', function(event, data) {
                        $scope.addTagFilter(event, data);
                    });
                    //event for deselecting filter
                    $scope.$on('attrFilterTags.removeTagFilter', function(event, data) {
                        $scope.removeTagFilter(event, data);
                    });
                    //event for deselecting all selected filters
                    $scope.$on('attrFilterTags.clearFilters', function(event, data) {
                        $scope.clearFilters(event, data);
                    });
                    //event for selecting all filters by attribute name
                    $scope.$on('attrFilterTags.selectAll', function(event, data) {
                        $scope.selectAll(event, data);
                    });
                    //event for deselecting all filters by attribute name
                    $scope.$on('attrFilterTags.deselectAll', function(event, data) {
                        $scope.deselectAll(event, data);
                    });
                    // waiting for events that should make change on $scope.tags
                    //END

                    // function to remove filter when corresponding tag is removed
                    $scope.removeTag = function(filter, index) {
                        var attributeName = filter.AttributeName;
                        $scope.tags[attributeName].splice(index, 1);

                        if ($scope.tags[attributeName].length === 0) {
                            delete $scope.tags[attributeName];
                        }
                        $rootScope.$broadcast('attrFilterWidget.removeFilterTag', filter);
                    };

                }
            };
        }
    ]);
