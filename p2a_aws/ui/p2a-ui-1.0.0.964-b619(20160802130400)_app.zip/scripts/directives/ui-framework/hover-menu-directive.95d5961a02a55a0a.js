﻿'use strict';

angular.module('p2AdvanceApp')
    .directive('hrHoverMenuWidget', function($parse) {
        return {
            restrict: 'E',
            scope: {
                context: '=',     // the object that these menu items will apply up.
                gridOptions: '=',
                items: '='        // The menu items that will show in the menu.
            },
            link: function(scope, element, attrs) {
                // if menuItem.isEnabled is not defined, the menu item will be enabled.
                // if the "action" function is not set, the menu item will be disabled.
                scope.getEnabledStyle = function(menuItem) {
                    return menuItem.action && (menuItem.isEnabled === undefined || menuItem.isEnabled) ? '' : 'disabled';
                };

                scope.showItem = function(menuItem, context) {
                    return menuItem.isShown === undefined || menuItem.isShown(context)? true: false;
                };

                scope.menuClicked = function(event, menuItem, context) {
                    event.stopPropagation(); // so that it will not trigger the ppm tool tips
                    if (menuItem.action) {
                        menuItem.action(context);
                    }
                };

                scope.getName = (function() {
                    if (attrs['shownProperty']) {
                        return $parse(attrs['shownProperty']);
                    } else {
                        return $parse('name');
                    }
                })();

                //var initialRowHeight = 0;

                var gridDiv = element.parents('div.ui-grid-viewport');
                if (gridDiv) {
                    var dropDownElem = element.find('ul')[0];
                    scope.$watch(function() {
                        return dropDownElem.offsetHeight;
                    }, function() {

                        var rowHeight      = scope.gridOptions.rowHeight;
                        var dropdownHeight = dropDownElem.offsetHeight + 5;

                        // Only Enter to repositioned the Hover Menu (HM) if it  
                        // has options and the HM height is bigger than the row height
                        if ( dropdownHeight > 0 &&   
                             dropdownHeight > rowHeight ) {

                            var newGridHeight = (scope.gridOptions.totalItems === 1) ? dropdownHeight + 65 : dropdownHeight + 150; 
                            var gridHeight    = gridDiv.height();

                            // First check if the grid heght is enoght to display the HM
                            if (newGridHeight >= gridHeight) {
                               gridDiv.height(newGridHeight);
                            } else {
                                // Lookup for row index position on the grid
                                var gridData = scope.gridOptions.data;
                                var i;
                                for (i = 0; i < gridData.length; i++) {
                                    if (scope.context.objectId === gridData[i].objectId) {
                                        break;
                                    }
                                }
                                                        
                                // var pageSize    = scope.gridOptions.paginationPageSize;

                                // var currentPage = scope.gridOptions.paginationCurrentPage;
                                
                                //var scopeOfRecords = pageSize * currentPage;

                                var gridScrollHeight = gridDiv[0].scrollHeight;

                                var gridClientHeight = gridDiv[0].clientHeight;

                                // Get the number of rows necessary to show the HM
                                var cellsToMod = Math.floor(dropdownHeight / rowHeight);

                                //if (gridData.length > scopeOfRecords);
                                // var maxIndex = gridData.length > scopeOfRecords ? pageSize : gridData.length % pageSize;
                                
                                //var multiplier = maxIndex - i + (currentPage - 1) * pageSize;
                                var multiplier = (i + 1);

                                var gridAvailableArea = gridScrollHeight - (multiplier * rowHeight);
                                
                                //var newGridHeight = 0;
                                
                                if (gridScrollHeight > gridClientHeight && 
                                    gridAvailableArea < dropdownHeight) {
                                   // newGridHeight = (scope.gridOptions.totalItems === 1) ? dropdownHeight + 65 : dropdownHeight + 150; 
                                   // if (newGridHeight >= gridHeight) {
                                   //     gridDiv.height(newGridHeight);
                                   // } else {
                                        var newTop = (dropdownHeight - rowHeight) * (( cellsToMod + 1 - multiplier) / (cellsToMod + 7.1));
                                        //if (newTop < 0 && i > gridData.length - 3 ) {
                                            dropDownElem.style.top = newTop + 'px';
                                       // }
                                   // }

                                // } else {
                                //     var numRows = (scope.gridOptions.paginationPageSize <= scope.gridOptions.totalItems) ? scope.gridOptions.paginationPageSize : scope.gridOptions.totalItems;
                                //     newGridHeight = (numRows * rowHeight) + 18;
                                //     if (newGridHeight > gridDiv.height()) {
                                //         gridDiv.height(newGridHeight);   
                                //     }
                                }
                            }
                        }
                    });
                }

                function isContainVisibleItems() {
                    var items = $(element).find('ul.dropdown-menu li');
                    if (!items || items.length === 0) {
                        return false;
                    }

                    // in case all items is hidden by permission
                    var visible = false;
                    for (var i = 0; i < items.length; ++i) {
                        var item = $(items[i]);
                        if (item.css('display') !== 'none') {
                            visible = true;
                            break;
                        }
                    }

                    return visible;
                }

                scope.toggleDropdown = function($event, context) {
                    if (!isContainVisibleItems() && !context.isOpen) {
                        return;
                    }

                    if (context.objectType === 'template') {
                        if (context.templateStatus === 'Expired') {
                            // This is a specific case for story TLT-287 (Updated in PONHR-794). Original source code of directive does not provide such functionality
                            return;
                        }
                        if ($event.type === 'mouseleave' && !context.isOpen) {
                            // fix TLT-727
                            return;
                        }
                    }

                    $event.preventDefault();
                    $event.stopPropagation();

                    if (context.isOpen === undefined) {
                        context.isOpen = false;
                    }
                    context.isOpen = !context.isOpen;
                };
            },
            template:
            ' <div class="cursor-pointer dropdown planDropdown" ng-class="{\'open\' : context.isOpen}" ppm-long-name-tooltip="{{context.name}}" ng-mouseenter="toggleDropdown($event, context)" ng-mouseleave="toggleDropdown($event, context)">' +
            // ' 	<strong>{{context.name}}</strong>' +
            '  <strong><span class="ellipsis">{{getName(context)}}</span></strong>' +
            ' 	<ul class="dropdown-menu dropdown-menu-left-20px">' +
            ' 		<li ng-class="getEnabledStyle(menuItem, context)" ng-show="showItem(menuItem, context)" has-permission="{{menuItem.permission}}" ng-repeat="menuItem in items">' +
            ' 			<a href ng-click="menuClicked($event, menuItem, context)">' +
            ' 				<i class="fa {{menuItem.icon}}"></i>&nbsp;&nbsp;&nbsp;&nbsp;{{menuItem.label}}' +
            ' 			</a>' +
            ' 		</li>' +
            ' 	</ul>' +
            ' </div>'
        };

    });
