﻿'use strict';

angular.module('p2AdvanceApp')
    .directive('attrFilterWidget', function($parse, DatePickerFilterService, $rootScope) {
        return {
            templateUrl: 'views/ui-framework/templates/attr-filter-template.html',
            restrict: 'E',
            transclude: true,
            scope: {
                datePicker: '=',
                calendarOpened: '=',
                dateOptions: '=',
                attrYear: '=',
                attrData: '=',
                attrId: '@',
                attrTitle: '@',
                attrDisplay: '@',
                filterChanged: '&',
                callSearch: '&',
                callCalendar: '&',
                fetchData: '&',
                setDatePickerAttrId: '&'
            },
            link: function($scope, iElement) {
                $scope.isCollapsed = true;
                $scope.selectedAttrId = ''; //selected checkboxes share the same AttributeId in each filter
                $scope.selectedAttrValues = []; //selected checkbox values in each filter widget
                $scope.allAttrSelected = false; //the checkbox with 'All' for total selection
                $scope.attrCheckedList = [];
                $scope.attrRange = [];
                $scope.form = {};
                $scope.showAllOpt = true;

                // FILTERS TAGS RELATED
                $scope.isTag = false;
                $scope.$on('attrFilterWidget.removeFilterTag', function(event, data) {
                    if($scope.attrData[0].AttributeId === data.AttributeId){
                        $scope.isTag = true;
                        $scope.toggleSelection(data, 'AttributeId', 'AttributeValue');
                    }
                });

                $scope.hideAllOpt = function() {
                    if (($scope.attrData && $scope.attrData.length) &&
                        ($scope.attrData[0].AttributeId === 'createdBy' || $scope.attrData[0].AttributeId === 'lastModifiedBy' || $scope.attrData[0].AttributeId === 'modifiedBy' || $scope.attrData[0].AttributeId === 'generatedBy')) {
                        $scope.showAllOpt = false;
                    }
                };

                //for the select all checkbox
                $scope.selectAll = function() {
                    $scope.selectedAttrValues = [];
                    $scope.isDateRangeExist = DatePickerFilterService.isDateRangeExist($scope.selectedAttrValues, 'Date Range', false);

                    // FILTERS TAGS RELATED
                    var broadcastData = {};
                    var tags = [];
                    var attributeName;


                    angular.forEach($scope.attrData, function(item) {
                        var itemValue = item[$scope.attrTitle];
                        var idx = $scope.selectedAttrValues.indexOf(itemValue);

                        // FILTERS TAGS RELATED
                        if(typeof attributeName === 'undefined') { attributeName = item.AttributeName; }
                        tags.push(item);


                        // is newly selected
                        if (idx === -1) {
                            if (!$scope.allAttrSelected) {
                                $scope.selectedAttrValues.push(itemValue);
                                $scope.enableDateWidget = true;
                            } else {
                                $scope.selectedAttrValues = [];
                                $scope.enableDateWidget = false;

                                if ($scope.form.dateRangeForm) {
                                    $scope.form.dateRangeForm.$setPristine();
                                }

                                if ($scope.isDateRangeExist) {
                                    DatePickerFilterService.removeSelectedValues($scope.datePicker['fromDate'], $scope.datePicker['toDate'], $scope.selectedAttrId, $scope.attrRange);
                                }
                            }
                        }

                        $scope.selectedAttrId = item[$scope.attrId]; //each checkbox under 'All' has the same AttributeId
                    });

                    /**
                     * FILTERS TAGS RELATED
                     * check if should remove or add tag filter
                     * broadcast event on which attr-filter-tag directive waits
                     */
                    broadcastData.attributeName = attributeName;
                    broadcastData.tags = tags;
                    if (!$scope.allAttrSelected){
                        $rootScope.$broadcast('attrFilterTags.selectAll', broadcastData);
                    }
                    else {
                        $rootScope.$broadcast('attrFilterTags.deselectAll', broadcastData);
                    }


                    $scope.selectFilterValues('all');
                };

                $scope.getDisplayAttr = (function() {
                    return $parse($scope.attrDisplay);
                })();

                $scope.getAttrId = (function() {
                    return $parse($scope.attrId);
                })();

                $scope.clearAllSelected = function() {
                    $scope.isDateRangeExist = DatePickerFilterService.isDateRangeExist($scope.selectedAttrValues, 'Date Range', false);
                    $scope.allAttrSelected = false;
                    $scope.selectedAttrValues = [];

                    //fix for error 'selectedAttrId undefined' when clicking on clear all
                    if($scope.selectedAttrId === '') {
                        return;
                    }
                    // FILTERS TAGS RELATED
                    $rootScope.$broadcast('attrFilterTags.clearFilters', $scope.selectedAttrId);

                    //Clear text box values based on id
                    iElement.find('input[type=text]').each(function() {
                        if ($(this).attr('id').indexOf($scope.selectedAttrId) !== -1) {
                            if ($scope.selectedAttrId === 'attrYear') {
                                $scope.attrYear.field = '';
                            }
                        }

                        if ($scope.isDateRangeExist) {
                            //Remove date values from datePicker array
                            DatePickerFilterService.removeSelectedValues($scope.datePicker['fromDate'], $scope.datePicker['toDate'], $scope.selectedAttrId, $scope.attrRange);
                        }

                    });

                    //clear those checkboxes which is not 'All' checkbox in each filter
                    iElement.find('input:checkbox').each(function() {
                        if ($(this).attr('id').indexOf($scope.selectedAttrId) !== -1) {
                            $(this).attr('checked', false);
                        }
                    });

                    $scope.enableDateWidget = false; //On unchecking the Date Range checkbox,date range widget is disabled.

                    if ($scope.form.dateRangeForm) {
                        $scope.form.dateRangeForm.$setPristine();
                    }

                    $scope.filterChanged({
                        selectedAttributeId: $scope.selectedAttrId,
                        selectedAttributeValues: $scope.selectedAttrValues.sort()
                    });

                    $scope.fetchData();
                };

                $scope.toggleAttributePane = function() {
                    $scope.isCollapsed = !$scope.isCollapsed;
                };

                $scope.toggleSelection = function(item, attrId, attrValue) {
                    //since the id value is dynamic, pass 2 parameters and read the id value this way
                    $scope.selectedAttrId = item[attrId];

                    var itemAttrValue = item[attrValue];
                    var idx = $scope.selectedAttrValues.indexOf(itemAttrValue);

                    /**
                     * FILTERS TAGS RELATED
                     * check if should remove or add tag filter
                     * broadcast event on which attr-filter-tag directive waits
                     */
                    if(!$scope.isTag) {
                        if (idx > -1) {
                            $rootScope.$broadcast('attrFilterTags.removeTagFilter', item);
                        }
                        else if (idx <= -1) {
                            $rootScope.$broadcast('attrFilterTags.addTagFilter', item);
                        }
                    }
                    else if ($scope.isTag) {
                        $scope.isTag = false;
                    }


                    // is currently selected
                    if (idx > -1 && itemAttrValue.toString().toLowerCase() !== 'date range') {
                        $scope.selectedAttrValues.splice(idx, 1);
                    } else if (idx > -1 && itemAttrValue.toString().toLowerCase() === 'date range') {
                        $scope.selectedAttrValues.splice(idx, 1);
                        $scope.enableDateWidget = false;
                        $scope.form.dateRangeForm.$setPristine();
                        DatePickerFilterService.removeSelectedValues($scope.datePicker['fromDate'], $scope.datePicker['toDate'], $scope.selectedAttrId, $scope.attrRange);
                    }
                    // is newly selected
                    else if (idx <= -1 && itemAttrValue.toString().toLowerCase() !== 'date range') {
                        $scope.selectedAttrValues.push(itemAttrValue);
                    } else if (idx <= -1 && itemAttrValue.toString().toLowerCase() === 'date range') {
                        $scope.selectedAttrValues.push(itemAttrValue);
                        $scope.enableDateWidget = true;
                    }

                    if ($scope.selectedAttrValues.length === $scope.attrData.length) {
                        $scope.allAttrSelected = true;
                    } else {
                        $scope.allAttrSelected = false;
                    }

                    $scope.selectFilterValues('toggle');

                };

                $scope.attrSelected = function(itemAttrValue) {
                    var checked = false;
                    var idx = $scope.selectedAttrValues.indexOf(itemAttrValue);

                    if (idx > -1) {
                        checked = true;
                    }

                    return checked;
                };

                //Set selectedAttrId for text box and date range widget changes
                $scope.searchQuery = function(attr) {
                    if (attr !== 'attrYear') {
                        var attrObj = {};
                        attrObj[attr] = 'Date Range';
                        $scope.selectedAttrId = attr;

                        $scope.isValidDateExist = DatePickerFilterService.isValidDateExist(attr, $scope.datePicker.fromDate, $scope.datePicker.toDate);

                        //DateRange is pushed into selectedId array only if fromdate,todate has valid values and has length>0
                        if ($scope.datePicker.fromDate[attr].length && $scope.datePicker.toDate[attr].length && $scope.isValidDateExist) {
                            $scope.attrRange.push(attrObj);
                            $scope.setDatePickerAttrId({
                                attr: $scope.attrRange
                            });
                        }
                    } else {
                        $scope.selectedAttrId = attr;
                    }
                };

                $scope.$on('clearAllSelected', function() {
                    $scope.clearAllSelected();
                });

                $scope.$on('removeAllOpt', function() {
                    $scope.hideAllOpt();
                });

                $scope.callDoSearch = function(event) {
                    if (event.which === 13 && $scope.attrYear.field !== undefined) {
                        $scope.callSearch({
                            event: event
                        });
                    }
                };

                $scope.callOpenCalendar = function(event, index, date) {
                    $scope.calendarOpened = {};
                    if (!$scope.calendarOpened[date]) {
                        $scope.calendarOpened[date] = [];
                    }
                    $scope.calendarOpened[date][index] = false;
                    $scope.callCalendar({
                        event: event,
                        index: index,
                        fromOrToDate: date
                    });
                };

                //load list data
                $scope.fetchDataWithinRange = function() {

                    $scope.isDateRangeExist = DatePickerFilterService.isDateRangeExist($scope.selectedAttrValues, 'Date Range', false);

                    if ($scope.isDateRangeExist) {
                        $scope.isValidDateExist = DatePickerFilterService.isValidDateExist($scope.selectedAttrId, $scope.datePicker['fromDate'], $scope.datePicker['toDate']);
                        $scope.isFromDateTouched = $scope.form.dateRangeForm.fromDate.$dirty;
                        $scope.isToDateTouched = $scope.form.dateRangeForm.toDate.$dirty;
                    }

                    if (($scope.isDateRangeExist && $scope.isValidDateExist) || (!$scope.isDateRangeExist)) {
                        $scope.fetchData();
                    } else if ($scope.isDateRangeExist && !$scope.form.dateRangeForm.fromDate.$modelValue && !$scope.form.dateRangeForm.toDate.$modelValue && $scope.isFromDateTouched && $scope.isToDateTouched) {
                        var selectedValuesClone = angular.copy($scope.selectedAttrValues);
                        var rangeIdx = selectedValuesClone.indexOf('Date Range');
                        selectedValuesClone.splice(rangeIdx, 1);

                        $scope.filterChanged({
                            selectedAttributeId: $scope.selectedAttrId,
                            selectedAttributeValues: selectedValuesClone.sort()
                        });
                    }
                };

                $scope.selectFilterValues = function(selectionType) {
                    $scope.isDateRangeExist = DatePickerFilterService.isDateRangeExist($scope.selectedAttrValues, 'Date Range', false);

                    if ($scope.isDateRangeExist) {
                        $scope.isValidDateExist = DatePickerFilterService.isValidDateExist($scope.selectedAttrId, $scope.datePicker['fromDate'], $scope.datePicker['toDate']);
                    }

                    var selectedValuesClone = angular.copy($scope.selectedAttrValues);
                    var rangeIdx = selectedValuesClone.indexOf('Date Range');
                    selectedValuesClone.splice(rangeIdx, 1);

                    if ((selectionType === 'toggle' && !$scope.isDateRangeExist) || ($scope.isDateRangeExist && $scope.isValidDateExist)) {
                        $scope.filterChanged({
                            selectedAttributeId: $scope.selectedAttrId,
                            selectedAttributeValues: $scope.selectedAttrValues.sort()
                        });
                    } else if ((selectionType === 'all' && !$scope.isDateRangeExist) || ($scope.isDateRangeExist && $scope.isValidDateExist)) {
                        $scope.filterChanged({
                            selectedAttributeId: $scope.selectedAttrId,
                            selectedAttributeValues: $scope.selectedAttrValues.sort(),
                            selectedAllAttrs: !$scope.allAttrSelected
                        });
                    } else if (selectionType === 'toggle' && $scope.isDateRangeExist && !$scope.isValidDateExist) {
                        $scope.filterChanged({
                            selectedAttributeId: $scope.selectedAttrId,
                            selectedAttributeValues: selectedValuesClone.sort()
                        });
                    } else if (selectionType === 'all' && $scope.isDateRangeExist && !$scope.isValidDateExist) {
                        $scope.filterChanged({
                            selectedAttributeId: $scope.selectedAttrId,
                            selectedAttributeValues: selectedValuesClone.sort(),
                            selectedAllAttrs: !$scope.allAttrSelected
                        });
                    }
                };

                $scope.hideAllOpt();
            }
        };
    });
