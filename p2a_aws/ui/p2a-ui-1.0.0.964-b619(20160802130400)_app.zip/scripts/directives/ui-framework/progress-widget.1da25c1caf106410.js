'use strict';

angular.module('p2AdvanceApp')
    .directive('progressWidget', function () {
        return {
            restrict: 'E',
            scope: {
                data: '=',
                actionFunction: '=',
                isOpen: '='
            },
            link: function postLink(scope, element) {
                scope.isPaneCollapsed = false;
                var newElem = element.parent('div')[0];
                if (newElem && newElem.id === 'footerDiv') {
                    var leftPos = newElem.clientWidth - element[0].firstChild.clientWidth - 15;
                    element.find('span').first().css({left: leftPos + 'px'});
                }

                scope.toggleImage = function() {
                    scope.isPaneCollapsed = !scope.isPaneCollapsed;
                };

                scope.showPercentage = function () {
                    var completeCount = 0;
                    var data = scope.progressGridOptions.data;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].progress === 100) {
                            completeCount++;
                        }
                    }
                    return completeCount + '/' + data.length;
                };

                scope.areAllComplete = function() {
                    var isComplete = false;
                    var completeCount = 0;
                    var data = scope.progressGridOptions.data;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].progress === 100) {
                            completeCount++;
                        }
                    }
                    if (completeCount === data.length) {
                        isComplete = true;
                    }
                    return isComplete;
                };
                scope.actionTask = function(rowData) {
                    var action = 'pause';
                    if (rowData.paused === undefined) {
                        rowData.paused = true;
                    } else {
                        rowData.paused = !rowData.paused;
                        if (!rowData.paused) {
                            action = 'play';
                        }
                    }
                    scope.actionFunction(rowData, action);
                };
                scope.stopTask = function(row) {
                    var index = scope.progressGridOptions.data.indexOf(row.entity);
                    scope.progressGridOptions.data.splice(index,1);
                };

                scope.clearData = function() {
                    var length = scope.progressGridOptions.data.length;
                    for (var i = 0; i < length; i++) {
                        scope.progressGridOptions.data.pop();
                    }
                };

                scope.progressGridOptions = {
                    overall: 47,
                    showHeader: false,
                    enableHorizontalScrollbar: 0,
                    enableColumnResizing: false,
                    columnDefs: [
                        {field: 'progress', width: 45, cellTemplate: '<div class="ui-grid-cell-contents hr-color-brand-info"><span>{{COL_FIELD}}%</span></div>'},
                        {field: 'name', width: 247, cellTemplate: '<div class="ui-grid-cell-contents"><span popover-placement="bottom" popover-append-to-body="true" popover="{{COL_FIELD}}"' +
                            ' popover-trigger="mouseenter" popover-popup-delay="300">{{COL_FIELD}}</span>'},
                        {
                            field: 'buttons',
                            width: 45,
                            cellTemplate:
                                ' <span class="hr-padding-5px">' +
                                '    <span ng-show="row.entity.progress < 100 && !row.entity.failed">' +
                                '       <i ng-click="grid.appScope.actionTask(row.entity)" class="hr-modal-button fa" ng-class="{\'fa-pause\': !row.entity.paused, \'fa-play\': row.entity.paused}"></i>' +
                                '       <i ng-click="grid.appScope.stopTask(row)" class="hr-modal-button fa fa-close"></i>' +
                                '    </span>' +
                                '    <span ng-show="row.entity.progress >= 100 && !row.entity.failed">' +
                                '       <span class="hr-padding-5px hr-color-success fa fa-check"></span>' +
                                '    </span>' +
                                '    <span ng-show="row.entity.failed">' +
                                '       <span class="hr-padding-5px hr-color-warning fa fa-exclamation-triangle"></span>' +
                                '    </span>' +
                                ' </span>'
                        }
                    ],
                    data: scope.data
                };

                scope.progressGridOptions.onRegisterApi = function(gridApi) {
                   scope.gridApi = gridApi;
                };
            },
            template:
                ' <span draggable class="hr-progress-modal" id="progressWidgetId" ng-show="(progressGridOptions.data && progressGridOptions.data.length > 0)">' +
                '    <div class="row">' +
                '       <div class="col-md-16">' +
                '          <div class="hr-progress-modal-header">' +
                '             <span class="hr-progress-modal-header-text">Progress: {{showPercentage()}}</span>' +
                '             <span class="hr-float-right">' +
                '                <button type="button" id="progressCloseButton" ng-click="clearData()" class="close hr-modal-button" ng-show="areAllComplete()"><i class="fa fa-close"></i></button>' +
                '                <button type="button" id="progressCollapseButton" ng-click="toggleImage()" class="close hr-modal-button" data-toggle="collapse" data-target="#progressTable">' +
                '                   <i class="fa" ng-class="{\'fa-minus-square\': !isPaneCollapsed, \'fa-plus-square\': isPaneCollapsed}"></i>' +
                '                </button>' +
                '             </span>' +
                '          </div>' +
                '          <div id="progressTable" class="collapse in">' +
                '             <div ui-grid="progressGridOptions" class="hr-progress-grid"></div>' +
                '          </div>' +
                '       </div>' +
                '    </div>' +
                ' </span>'
        };
    });
