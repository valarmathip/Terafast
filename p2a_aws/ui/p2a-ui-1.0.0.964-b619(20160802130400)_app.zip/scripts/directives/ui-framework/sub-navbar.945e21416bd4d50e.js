'use strict';

angular.module('p2AdvanceApp')
    .directive('hrSubNavBar', ['$location', '$timeout', function(location, $timeout) {
        return {
            restrict: 'EA',
            require: '?ngModel',
            scope: {
                tabs: '='
            },
            priority: 1,
            link: function(scope, element, attrs) {
                var navId = attrs.id;
                scope.isActive = function(viewLocation) {
                    return viewLocation === location.path();
                };

                $(window).on('resize', function() {
                    reAdjust();
                });
                var thisNavBar = $('#' + navId);
                var scrollBarWidths = 50;

                // The total width of sub navbars
                var widthOfList = function() {
                    var itemsWidth = 0;
                    thisNavBar.find('.list li').each(function() {
                        var itemWidth = $(this).outerWidth();
                        itemsWidth += itemWidth;
                    });
                    return itemsWidth;
                };

                var widthOfHidden = function() {
                    return ((thisNavBar.find('.wrapper').outerWidth()) - widthOfList() - getLeftPosi()) - scrollBarWidths;
                };

                var getLeftPosi = function() {
                    return (thisNavBar.find('.list').position() && thisNavBar.find('.list').position().left) ? thisNavBar.find('.list').position().left : 0;
                };

                var reAdjust = function() {
                    $timeout(function() {
                        thisNavBar.find('.item').animate({
                            left: '-=' + getLeftPosi() + 'px'
                        }, 'slow');

                        if (navId === 'mainNavBar') {
                            var wrapper = thisNavBar.find('.wrapper');
                            if (wrapper[0]) {
                                var sectionNavs = thisNavBar.find('.section-nav');
                                var scrollers = thisNavBar.find('.scroller');

                                var maxActualItemWidth = thisNavBar.find('.section-nav .hr-sub-nav-bar-title')
                                    .get().reduce(function(prevWidth, curEle) {
                                        var width = $(curEle).outerWidth();
                                        return width > prevWidth ? width : prevWidth;
                                    }, 0);
                                maxActualItemWidth += 2 * 25; // Left and right padding 25px max (for badge info)

                                var wrapperWidth = wrapper.outerWidth();
                                if (!wrapperWidth && $('#navDiv').outerWidth() < 769) { // small screen, the sub-navbar is not show default.
                                    wrapperWidth = $('#navDiv').outerWidth();
                                }
                                var maxAvailableItemWidth = (wrapperWidth / sectionNavs.length) - 2; // 2 is border width

                                // Following 25 is just adjust value, no reason why it is 25, just make use if the sub nav bar is
                                // just a little longer than viewport, it should not show arrow for scrolling.
                                if (maxActualItemWidth - 25 < maxAvailableItemWidth) { // Enough space, hide left and right arrow, and set each item width is the same as max one
                                    sectionNavs.css({
                                        'min-width': maxAvailableItemWidth + 'px',
                                        'max-width': maxAvailableItemWidth + 'px'
                                    });
                                    scrollers[0].style.display = 'none';
                                    scrollers[1].style.display = 'none';
                                } else { // Do not have enough, use each item is own size
                                    sectionNavs.each(function() { // set each item the width as its title width plus 25*2
                                        var itemEle = $(this);
                                        var itemWidth = itemEle.find('.hr-sub-nav-bar-title').outerWidth();
                                        itemWidth += 2 * 25; // Left and right padding 25px max (for badge info)
                                        itemEle.css({
                                            'min-width': itemWidth + 'px',
                                            'max-width': itemWidth + 'px'
                                        });
                                    });
                                    var totalActualItemWidth = sectionNavs.get().reduce(function(prevWidth, curEle) {
                                        return $(curEle).outerWidth() + prevWidth;
                                    }, 0);
                                    if (totalActualItemWidth > wrapperWidth) {
                                        scrollers[0].style.display = 'block';
                                        scrollers[1].style.display = 'block';
                                    } else {
                                        scrollers[0].style.display = 'none';
                                        scrollers[1].style.display = 'none';
                                    }
                                }
                            }

                            thisNavBar.find('.list')[0].style.left = '0px';
                        }
                    });
                };

                reAdjust();

                scope.$watch('tabs', function() {
                    reAdjust();
                });

                thisNavBar.find('.scroller-right').click(function() {
                    thisNavBar.find('.list').animate({
                        left: '+=' + widthOfHidden() + 'px'
                    }, 'slow', function() {});
                });

                thisNavBar.find('.scroller-left').click(function() {
                    thisNavBar.find('.list').animate({
                        left: '-=' + getLeftPosi() + 'px'
                    }, 'slow', function() {});
                });
            },
            templateUrl: 'views/ui-framework/templates/subNavBarTemplate.html'
        };
    }]);