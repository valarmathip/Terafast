'use strict';

angular.module('p2AdvanceApp')
    .directive('productRangeWidget', function() {
        return {
            templateUrl: 'views/ui-framework/templates/product-range-template.html',
            restrict: 'E',
            scope: {
                name: '=',
                globalCostShares: '=',
                isSave: '='
            },
            link: function($scope) {
                $scope.from = null;
                $scope.to = null;
                $scope.min = null;
                $scope.max = null;
                $scope.step = null;
                $scope.scale = null;
                $scope.def = null;
                $scope.level = null;
                $scope.isRangeValidationEnforced = false;
                $scope.allowZero = false;
                $scope.severityLevel = 'Warning';
                $scope.fromMinValidation = false;
                $scope.minMaxValidation = false;
                $scope.maxToValidation = false;
                $scope.placeValueValidation = false;
                $scope.placeValueIncrementsValidation = false;
                $scope.defaultValidation = false;
                $scope.coInsuranceValidation = false;
                $scope.zeroValidation = false;
                if (angular.isDefined($scope.globalCostShares)) {
                    angular.forEach($scope.globalCostShares, function(costShares) {
                        if (angular.isDefined(costShares)) {
                            if (costShares.costShareType === $scope.name) {
                                $scope.from = costShares.from;
                                $scope.min = costShares.min;
                                $scope.max = costShares.max;
                                $scope.to = costShares.to;
                                $scope.step = costShares.step; //Place Value
                                $scope.scale = costShares.scale; //Increment
                                $scope.def = costShares['default'];
                                $scope.allowZero = costShares.isZeroAllowed;
                                $scope.isRangeValidationEnforced = costShares.isRangeValidationEnforced;
                                $scope.severityLevel = costShares.severityLevel;
                                if (angular.isDefined(costShares.costShareLevel)) {
                                    $scope.level = costShares.costShareLevel;
                                }
                            }
                        }
                    });
                }
                $scope.setCostShareValues = function(severityLevel) {
                    var costShareExists = false;
                    nonZeroTest();
                    if (angular.isUndefined($scope.globalCostShares)) {
                        $scope.globalCostShares = {};
                    }
                    if (angular.isDefined(severityLevel)) {
                        $scope.severityLevel = severityLevel;
                    }
                    if ($scope.name === 'Co-insurance') {
                        if ($scope.from < 0 || $scope.to > 100) {
                            $scope.coInsuranceValidation = true;
                        } else {
                            $scope.coInsuranceValidation = false;
                        }
                    }
                    angular.forEach($scope.globalCostShares, function(costShares, key) {
                        if (angular.isDefined(costShares)) {
                            if (costShares.costShareType === $scope.name) {
                                costShareExists = true;
                                if ($scope.from === null || $scope.min === null || $scope.max === null || $scope.to === null) {
                                    $scope.allowZero = false;
                                    $scope.isRangeValidationEnforced = false;
                                }
                                // DOGHR-2522 Min range set to zero but did not checked 'Allow zero' still prompts user with error. 
                                // Automaticaly check allow zero if min is 0.
                                if ($scope.min === 0) {
                                    $scope.allowZero = true;
                                }
                                costShares.from = $scope.from;
                                costShares.min = $scope.min;
                                costShares.max = $scope.max;
                                costShares.to = $scope.to;
                                costShares.step = $scope.step;
                                costShares.scale = $scope.scale;
                                costShares['default'] = $scope.def;
                                costShares.isZeroAllowed = $scope.allowZero;
                                costShares.isRangeValidationEnforced = $scope.isRangeValidationEnforced;
                                costShares.severityLevel = $scope.severityLevel;
                                if (costShares.from === null && costShares.min === null && costShares.max === null && costShares.to === null && costShares.step === null && costShares.scale === null && costShares['default'] === null) {
                                    $scope.globalCostShares.splice(key, 1);
                                }
                            }
                        } else {
                            $scope.globalCostShares.splice(0, key + 1);
                        }
                    });
                    if (!costShareExists) {
                        $scope.globalCostShares.push({
                            costShareType: $scope.name,
                            from: $scope.from,
                            min: $scope.min,
                            max: $scope.max,
                            to: $scope.to,
                            step: $scope.step,
                            scale: $scope.scale,
                            'default': $scope.def,
                            isZeroAllowed: $scope.allowZero,
                            isRangeValidationEnforced: $scope.isRangeValidationEnforced,
                            severityLevel: $scope.severityLevel
                        });
                    }
                };
                $scope.validationFunction = function(id) {
                    if (id.from !== null && id.min !== null && id.max !== null && id.to !== null) {
                        isValueValid(id);
                    } else {
                        $scope.fromMinValidation = false;
                        $scope.minMaxValidation = false;
                        $scope.maxToValidation = false;
                        $scope.placeValueValidation = false;
                        $scope.placeValueIncrementsValidation = false;
                        $scope.defaultValidation = false;

                    }
                    if ($scope.fromMinValidation === true || $scope.minMaxValidation === true || $scope.maxToValidation === true || $scope.placeValueValidation === true) {
                        $scope.isSave = true;
                    } else if ($scope.placeValueIncrementsValidation === true || $scope.defaultValidation === true || $scope.coInsuranceValidation === true || $scope.zeroValidation === true) {
                        $scope.isSave = true;
                    } else {
                        $scope.isSave = false;
                    }
                };

                function isValueValid(id) {
                    if (id.min < id.from) {
                        $scope.fromMinValidation = true;
                    } else {
                        $scope.fromMinValidation = false;
                    }
                    if (id.max <= id.min) {
                        $scope.minMaxValidation = true;
                    } else {
                        $scope.minMaxValidation = false;
                    }
                    if (id.to < id.max) {
                        $scope.maxToValidation = true;
                    } else {
                        $scope.maxToValidation = false;
                    }
                    if (id.step >= id.max) {
                        $scope.placeValueValidation = true;
                    } else {
                        $scope.placeValueValidation = false;
                    }
                    if (id.step > id.scale) {
                        $scope.placeValueIncrementsValidation = true;
                    } else {
                        $scope.placeValueIncrementsValidation = false;
                    }
                    if (id.def !== null && (id.def < id.min || id.def > id.max)) {
                        $scope.defaultValidation = true;
                    } else {
                        $scope.defaultValidation = false;
                    }
                }

                function nonZeroTest() {
                    $scope.zeroValidation = ($scope.from < 0 || $scope.min < 0 || $scope.max < 0 || $scope.to < 0 || $scope.step < 0 || $scope.scale < 0 || $scope.def < 0) ? true : false;
                }
            }
        };
    });