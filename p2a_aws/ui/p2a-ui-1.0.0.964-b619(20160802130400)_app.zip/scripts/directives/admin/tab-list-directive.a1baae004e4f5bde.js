﻿'use strict';

angular.module('p2AdvanceApp')
    .directive('tabSelection', ['$state', function($state) {
        return {
            restrict: 'E',
            scope: {
                tabLabel: '@',
                tabId: '@',
                tabLink: '@',
                tabEnabled: '@',
                activeTab: '@',
                tabs: '='
            },
            link: function($scope) {

                $scope.setCurrentTab = function(tabId) {
                    $scope.selectedTab = tabId;
                };

                $scope.tabIsSelected = function(tabId, activeTab) {
                    if (activeTab != null) {
                        return activeTab === tabId;
                    } else {
                        return $scope.selectedTab === tabId;
                    }
                };

                $scope.tabIsEnabled = function(isActive) {
                    if (isActive !== null && isActive === true) {
                        return true;
                    } else {
                        return false;
                    }
                };

                $scope.goToState = function(state) {
                    $state.go(state);
                };

            },
            templateUrl: 'views/admin/media-management/tab-list-template.html'
        };

    }]);