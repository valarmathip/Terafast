'use strict';
/**
 * @ngdoc
 * @name taskSummaryForm
 * @description directive for generating dynamic task summary form
 *
 *
 */
angular.module('p2AdvanceApp')
  .directive('taskSummaryForm', ['ModalDialogFactory', '$compile', 'WorkflowDataFactory',
    function(ModalDialogFactory, $compile, WorkflowDataFactory) {
      return {
        templateUrl: 'views/workflow-management/template/task/task-summary-form.html',
        restrict: 'E',
        transclude: true,
        scope: {
          config: '='
        },
        link: function(scope) {

          /**
           * @description object in which we store the values of the dynamicly added fields
           * @type {Object}
           */
          scope.form = {};

          /**
           * @description the div where the fields will be appended
           */
          var formFieldsDiv = angular.element(document.querySelector('#formFields'));

          /**
           * @description function that process the data for the form, and append the fields provided
           * Currently it supports these kind of fields:
           * -textarea
           * -input text
           * -input button
           * -input checkbox
           * @param  {[type]} fields        [description]
           * @param  {[type]} formFieldsDiv [description]
           */
          function appendFields(fields, formFieldsDiv) {
            for (var i = 0; i < fields.length; i++) {

              //if the field is input checkbox
              if(fields[i].type === 'checkbox') {
                formFieldsDiv.append('<br>');

                formFieldsDiv.append(
                  '<label class="control-label">' +
                  '<' + fields[i].element + ' ' +
                  'type="' + fields[i].type + '"' + ' ' +
                  'value="' + fields[i].value + '"' + ' ' +
                  'id="' + fields[i].id + '"' + ' ' +
                  'ng-model="' + fields[i].model + '"' + ' ' +
                  'placeholder="' + fields[i].placeholder + '"' + ' ' +
                  'class="' + fields[i].fieldClass +
                  '"></' + fields[i].element + '>' +
                  fields[i].label +
                  '</label>'
                );
              }
              //if the field is textarea, input text, input button
              else {
                formFieldsDiv.append('<br>');
                //label
                formFieldsDiv.append(
                  '<label class="control-label"'+
                  'for="' + fields[i].id + '"' +
                  '>' +
                  fields[i].label +
                  ':</label>'
                );
                //field
                formFieldsDiv.append(
                  '<' + fields[i].element + ' ' +
                  'type="' + fields[i].type + '"' + ' ' +
                  'value="' + fields[i].value + '"' + ' ' +
                  'id="' + fields[i].id + '"' + ' ' +
                  'ng-model="' + fields[i].model + '"' + ' ' +
                  'placeholder="' + fields[i].placeholder + '"' + ' ' +
                  'class="' + fields[i].fieldClass +
                  '"></' + fields[i].element + '>');
              }

              $compile(formFieldsDiv.contents())(scope);
            }
          }

        //   var mockupFormFields = [
        //     {
        //       'element': 'textarea',
        //       'id': 'comment',
        //       'label': 'Comment',
        //       'placeholder': 'Please provide a detail comment!',
        //       'type': 'text',
        //       'value': '',
        //       'model': 'form.comment',
        //       'fieldClass': 'form-control'
        //     },
        //     {
        //       'element': 'input',
        //       'id': 'txt',
        //       'label': 'Some Input Text',
        //       'placeholder': 'Placeholder for first input',
        //       'type': 'text',
        //       'value': '',
        //       'model': 'form.txt',
        //       'fieldClass': 'form-control'
        //     },
        //     {
        //       'element': 'input',
        //       'id': 'check',
        //       'label': ' Some Checkbox',
        //       'placeholder': '',
        //       'type': 'checkbox',
        //       'value': '',
        //       'model': 'form.check',
        //       'fieldClass': ''
        //     },
        //     {
        //       'element': 'input',
        //       'id': 'txt2',
        //       'label': 'Another Input Text',
        //       'placeholder': 'Placeholder for second input',
        //       'type': 'text',
        //       'value': '',
        //       'model': 'form.txt2',
        //       'fieldClass': 'form-control'
        //     },
        //     {
        //       'element': 'input',
        //       'id': 'check2',
        //       'label': ' Another Checkbox',
        //       'placeholder': '',
        //       'type': 'checkbox',
        //       'value': '',
        //       'model': 'form.check2',
        //       'fieldClass': ''
        //     }
        //  ];

          WorkflowDataFactory.getTaskSummaryForm(scope.config.caseId, scope.config.taskId).then(function(data) {
            scope.config.formDetails = data;
            scope.config.formFields = data.fields;
            scope.config.formActions = data.actions;
            appendFields(scope.config.formFields, formFieldsDiv);

            // appendFields(mockupFormFields, formFieldsDiv);

          });

          //modal actions
          scope.close = function() {
            scope.config.$modalInstance.dismiss('cancel');
          };

          scope.acceptTask = function() {
            ModalDialogFactory.closeDialog({
              action: 'accept',
              task: scope.config.taskDetails
            });
          };

          scope.rejectTask = function() {
            ModalDialogFactory.closeDialog({
              action: 'reject',
              task: scope.config.taskDetails
            });
          };

          scope.routeToL1 = function() {
            ModalDialogFactory.closeDialog({
              action: 'routeToL1',
              task: scope.config.taskDetails
            });
          };

          scope.routeToL2 = function() {
            ModalDialogFactory.closeDialog({
              action: 'routeToL2',
              task: scope.config.taskDetails
            });
          };

          /** TODO
            function for other action buttons?
          */

          // $scope.completeTask = function(){
          //   ModalDialogFactory.closeDialog({
          //     action: 'reject',
          //     task: $scope.taskDetails
          //   });
          // };
          //
          // $scope.claimTask = function(){
          //   ModalDialogFactory.closeDialog({
          //     action: 'reject',
          //     task: $scope.taskDetails
          //   });
          // };
          //
          // $scope.delegateTask = function(){
          //   ModalDialogFactory.closeDialog({
          //     action: 'reject',
          //     task: $scope.taskDetails
          //   });
          // };
          //
          // $scope.resolveTask = function(){
          //   ModalDialogFactory.closeDialog({
          //     action: 'reject',
          //     task: $scope.taskDetails
          //   });
          // };
        }
      };
    }
  ]);
