(function() {
    'use strict';

    angular
        .module('p2AdvanceApp')
        .directive('previousAttachmentsWidget', previousAttachmentsWidget);

    previousAttachmentsWidget.$inject = ['uiGridConstants', 'ENV', '$log', '$filter', 'PaginationService'];

    /* @ngInject */
    function previousAttachmentsWidget(uiGridConstants, ENV, $log, $filter, PaginationService) {

        var directive = {
            templateUrl: 'views/workflow-management/template/widgets/previous-attachments/previous-attachments-widget.view.html',
            link: link,
            restrict: 'E',
            scope: {
                config: '=?'

            }
        };
        return directive;

        function link(scope) {

            scope.attachmentsList = [{
                'name': 'test',
                'dateAttached': '2131231',
                'attachedBy': 'asdasdas',
                'attachedFor': 'asdasd'
            }, {
                'name': 'test2',
                'dateAttached': '00202020',
                'attachedBy': 'ghjhgj',
                'attachedFor': 'ghjghjghj'
            }];
            scope.selectedAttachments = [];
            scope.checkList = {};
            var paginationOptions = {
                pageSize: 20
            };
            var gridOptions = {
                'excessRows': 400, // SLQ need to more investigation
                //'scrollThreshold': 4,
                //"excessColumns": 4,
                enableSorting: true,
                // pagination
                enablePaginationControls: false,
                paginationPageSizes: ENV.settings.paginationPageSizes,
                paginationPageSize: 20,
                enableRowSelection: false,
                // scroll bar
                enableVerticalScrollbar: uiGridConstants.scrollbars.ALWAYS,
                enableHorizontalScrollbar: uiGridConstants.scrollbars.ALWAYS, //, uiGridConstants.scrollbars.ALWAYS, uiGridConstants.scrollbars.NEVER
                rowHeight: 105, // never put number in "", like "100"
                minRowsToShow: 5,
                rowTemplate: 'views/product-plan-management/template/plan-list/row.html',
                enableRowHeaderSelection: false,
                useExternalPagination: true,
                useExternalSorting: true
            };

            var setOrResetCheckList = function(row) {
                scope.checkList = PaginationService.setOrResetCheckList(row, scope.checkList);
            };
            var setCheckList = function() {
                scope.checkList = PaginationService.setCheckList(scope.gridApi, scope.checkList);
            };

            gridOptions.onRegisterApi = function(gridApi) {
                scope.gridApi = gridApi;

                scope.gridApi.core.on.sortChanged(scope, function(grid, sortColumns) {
                    if (sortColumns.length >= 0) {
                        PaginationService.setSortColumns($filter('orderBy')(sortColumns, '+sort.priority'));
                    }
                    //scope.loadAttachments();
                });
                gridApi.pagination.on.paginationChanged(scope, function(newPage, pageSize) {
                    paginationOptions.pageNumber = newPage;
                    paginationOptions.pageSize = pageSize;
                    //scope.loadAttachments();
                    if (!PaginationService.isGoToPageEnabled) {
                        scope.pageVal.pageNumber = PaginationService.resetPageNumber(scope.gridApi, scope.pageVal.pageNumber);
                    }
                    PaginationService.setGoToPageEnabled(false);
                });

                scope.gridApi.grid.registerDataChangeCallback(function(data) {
                    data.selection.selectAll = false;
                }, [uiGridConstants.dataChange.ROW]);

                gridApi.selection.on.rowSelectionChanged(scope, setOrResetCheckList);
                gridApi.selection.on.rowSelectionChangedBatch(scope, setCheckList);
            };

            gridOptions.columnDefs = [{
                displayName: '',
                name: 'X1',
                field: 'element1',
                width: '10%',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: false,
                headerCellTemplate: 'views/product-plan-management/template/plan-list/icon-col-header.html',
                cellTemplate: 'views/workflow-management/template/widgets/previous-attachments/ui-grid/icon-col.html'
            }, {
                displayName: 'Attachment Name',
                name: 'name',
                width: '54%',
                field: 'name',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: true,
                cellTemplate: 'views/workflow-management/template/widgets/previous-attachments/ui-grid/name-col.html'
            }, {
                displayName: 'Attached On',
                name: 'dateAttached',
                width: '12%',
                field: 'dateAttached',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: true,
                cellTemplate: 'views/workflow-management/template/widgets/previous-attachments/ui-grid/attached-date-col.html'
            }, {
                displayName: 'Attached By',
                field: 'attachedBy',
                width: '12%',
                enableColumnMenu: false,
                enableHiding: false,
                enableSorting: false,
                cellTemplate: 'views/workflow-management/template/widgets/previous-attachments/ui-grid/attached-by-col.html'
            }, {
                displayName: 'Attached For',
                field: 'attachedFor',
                enableColumnMenu: false,
                enableColumnMenus: false,
                enableSorting: true,
                width: '12%',
                cellTemplate: 'views/workflow-management/template/widgets/previous-attachments/ui-grid/attached-for-col.html'
            }];


            gridOptions.data = 'attachmentsList';
            gridOptions.totalItems = scope.attachmentsList.length;
            scope.gridOptions = gridOptions;


            scope.toggleRowSelection = function(event, row) {
                scope.gridApi.selection.toggleRowSelection(row.entity);
                scope.selectedrows = scope.gridApi.selection.getSelectedRows();
                if (paginationOptions.pageSize === scope.selectedrows.length) {
                    scope.gridApi.grid.selection.selectAll = true;
                }
                if (event.currentTarget.checked === true) {
                    scope.selectedAttachments.push(row.entity);
                } else {
                    for (var key in scope.selectedAttachments) {
                        if (scope.selectedAttachments[key].objectId === row.entity.objectId) {
                            scope.selectedAttachments.splice(key, 1);
                        }
                    }
                }
            };

            scope.toggleAllRowSelection = function(event) {
                var rows = scope.gridApi.grid.rows;
                if (event.currentTarget.checked) {
                    scope.gridApi.selection.selectAllRows();
                    if (scope.selectedAttachments.length === 0) {
                        angular.forEach(rows, function(row) {
                            scope.selectedAttachments.push(row.entity);
                        });
                    } else {
                        angular.forEach(scope.selectedAttachments, function(item) {
                            angular.forEach(rows, function(row) {
                                if (item.entity.objectId !== row.entity.objectId) {
                                    scope.selectedAttachments.push(row.entity);
                                }
                            });
                        });
                    }
                } else {
                    scope.gridApi.selection.clearSelectedRows();
                    angular.forEach(rows, function(rowone) {
                        angular.forEach(scope.selectedAttachments, function(row) {
                            if (rowone.entity.objectId === row.objectId) {
                                scope.selectedAttachments.splice(scope.selectedAttachments.indexOf(row), 1);
                            }
                        });
                    });
                }
            };

            scope.deleteAttachment = function(attachment) {
                $log.debug(attachment);
            };

            scope.deleteSelectedAttachments = function() {
                $log.debug(scope.selectedAttachments);
            };

            scope.downloadAttachment = function(attachment) {
                $log.debug(attachment);
            };

            scope.downloadSelectedAttachments = function() {
                $log.debug(scope.selectedAttachments);
            };

            scope.loadAttachments = function() {

            };

        }
    }

})();
