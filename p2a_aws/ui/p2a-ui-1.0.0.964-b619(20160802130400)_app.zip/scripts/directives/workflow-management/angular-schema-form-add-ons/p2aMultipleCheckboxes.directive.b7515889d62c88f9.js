'use strict';

angular.module('p2AdvanceApp').directive('p2aMultipleCheckboxesDirective', function() {
    return {
        require: ['ngModel'],
        restrict: 'A',
        scope: false,
        controller: ['$scope', function($scope) {
            $scope.fieldName = $scope.form.key[0];
            if (typeof $scope.model[$scope.fieldName] === 'undefined') {
                    $scope.model[$scope.fieldName] = [];
            }
            $scope.checkboxChanged = function(checkbox) {
                if (typeof $scope.model[$scope.fieldName] !== 'undefined') {
                    var index = $scope.model[$scope.fieldName].indexOf(checkbox);
                    if (index !== -1) {
                        $scope.model[$scope.fieldName].splice(index, 1);
                    } else {
                        $scope.model[$scope.fieldName].push(checkbox);
                    }
                }
            };

        }],
        link: function(scope, iElement, iAttrs, ngModelCtrl) {
            scope.ngModel = ngModelCtrl;
        }
    };
});
