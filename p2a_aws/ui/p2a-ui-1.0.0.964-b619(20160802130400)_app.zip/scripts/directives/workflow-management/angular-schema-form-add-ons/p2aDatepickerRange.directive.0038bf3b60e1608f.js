'use strict';

angular.module('p2AdvanceApp').directive('p2aDatepickerRangeDirective', function() {
    return {
        require: ['ngModel'],
        restrict: 'A',
        scope: false,
        controller: ['$scope', function($scope) {
            $scope.fieldName = $scope.form.key[0];
            $scope.dateStartChange = function() {
                if (typeof $scope.model[$scope.fieldName] === 'undefined') {
                    $scope.model[$scope.fieldName] = {
                        dateStart: null,
                        dateEnd: null
                    };
                    $scope.model[$scope.fieldName].dateStart = $scope.dateStart;
                } else {
                    $scope.model[$scope.fieldName].dateStart = $scope.dateStart;
                }
            };
            $scope.dateEndChange = function() {
                if (typeof $scope.model[$scope.fieldName] === 'undefined') {
                    $scope.model[$scope.fieldName] = {
                        dateStart: null,
                        dateEnd: null
                    };
                    $scope.model[$scope.fieldName].dateEnd = $scope.dateEnd;
                } else {
                    $scope.model[$scope.fieldName].dateEnd = $scope.dateEnd;
                }
            };
            $scope.open1 = function($event) {
                $event.preventDefault();
                $event.stopPropagation();
                $scope.opened1 = true;
            };

            $scope.open2 = function($event) {
                $event.preventDefault();
                $event.stopPropagation();
                $scope.opened2 = true;
            };

        }],
        link: function(scope, iElement, iAttrs, ngModelCtrl) {
            scope.ngModel = ngModelCtrl;
        }
    };
});
