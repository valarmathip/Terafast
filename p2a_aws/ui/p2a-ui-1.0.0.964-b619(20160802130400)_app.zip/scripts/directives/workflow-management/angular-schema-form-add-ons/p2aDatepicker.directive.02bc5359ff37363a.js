'use strict';

angular.module('p2AdvanceApp').directive('p2aDatepickerDirective', function() {
    return {
        require: ['ngModel'],
        restrict: 'A',
        scope: false,
        controller: ['$scope', function($scope) {
            $scope.open = function($event) {
                $event.preventDefault();
                $event.stopPropagation();

                $scope.opened = true;
            };

        }],
        link: function(scope, iElement, iAttrs, ngModelCtrl) {
            scope.ngModel = ngModelCtrl;
        }
    };
});