'use strict';

angular.module('p2AdvanceApp').directive('p2aDropdownSelectionDirective', function() {
    return {
        require: ['ngModel'],
        restrict: 'A',
        scope: false,
        controller: ['$scope', '$q', '$http', 'ENV_WORKFLOW_MANAGEMENT', 'ENV', function($scope, $q, $http, ENV_WORKFLOW_MANAGEMENT, ENV) {
            var restApiEndpoint = ENV_WORKFLOW_MANAGEMENT.apiEndpoint + ENV_WORKFLOW_MANAGEMENT.contextPath;
            var AUTH_KEY = ENV_WORKFLOW_MANAGEMENT.authKey;
            var isContractor = (ENV.name === 'contractor');

            $scope.getSelections = function() {
                var defer = $q.defer();
                var api = restApiEndpoint + $scope.form.selectionsUrl;
                $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                }).success(function(response) {
                    defer.resolve(response);
                }).error(function(response) {
                    defer.reject(response);
                });
                return defer.promise;
            };

            if ($scope.form.asynchronousSelection) {
                $scope.getSelections().then(function(data) {
                    $scope.asynchronousSelections = data.response;
                });
            }
        }],
        link: function(scope, iElement, iAttrs, ngModelCtrl) {
            scope.ngModel = ngModelCtrl;
        }
    };
});
