'use strict';

angular.module('p2AdvanceApp').directive('p2aRadioButtonsDirective', function() {
    return {
        require: ['ngModel'],
        restrict: 'A',
        scope: false,
        controller: ['$scope', function($scope) {
            $scope.fieldName = $scope.form.key[0];
            if (typeof $scope.model[$scope.fieldName] === 'undefined') {
                if ($scope.form.defaultSelection) {
                    $scope.model[$scope.fieldName] = $scope.form.defaultSelection;
                } else {
                    $scope.model[$scope.fieldName] = $scope.form.selections[0];
                }
            }

        }],
        link: function(scope, iElement, iAttrs, ngModelCtrl) {
            scope.ngModel = ngModelCtrl;
        }
    };
});
