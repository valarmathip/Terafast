(function() {
    'use strict';

    angular
        .module('p2AdvanceApp')
        .directive('uploadAttachmentsWidget', uploadAttachmentsWidget);

    uploadAttachmentsWidget.$inject = ['$upload', '$auth', 'ENV_MEDIA_MANAGEMENT'];

    /* @ngInject */
    function uploadAttachmentsWidget($upload, $auth, ENV_MEDIA_MANAGEMENT) {
        var directive = {
            templateUrl: 'views/workflow-management/template/widgets/upload-attachments/upload-attachments-widget.view.html',
            link: link,
            restrict: 'E',
            scope: {
                config: '=?'
            }
        };
        return directive;

        function link(scope) {
            scope.ENV_MEDIA_MANAGEMENT = ENV_MEDIA_MANAGEMENT;
            scope.uploadQueue = [];
            scope.addToUploadQueue = function(files) {
                angular.forEach(files, function(value) {
                    scope.uploadQueue.push(value);
                });
            };

            scope.removeAttachmentFromUploadQueue = function(file, index) {
                scope.uploadQueue.splice(index, 1);
            };

            scope.$on('uploadAttachmentsWidget.clearQueue', function() {
                scope.uploadQueue = [];
            });

            scope.$on('uploadAttachmentsWidget.upload', function() {
                if (scope.uploadQueue && scope.uploadQueue.length) {
                        for (var i = 0; i < scope.uploadQueue.length; i++) {
                            var file = scope.uploadQueue[i];
                            $upload.upload({
                                url: scope.ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents',
                                headers: {
                                    'Content-Type': undefined,
                                    'Authorization': $auth.getApiToken()
                                },

                                fileFormDataName: ['file', 'metadata'],
                                file: file
                            }).progress(function () {
                            }).success(function (data, status, headers, config) {
                                console.log('file ' + config.file.name + 'uploaded. Response: ' + data);
                            });
                        }
                    }
            });


        }
    }
})();
