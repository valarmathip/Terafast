'use strict';
angular.module('p2AdvanceApp')
    .directive('comparisonReport', function() {
        return {
            restrict: 'E',
            link: function(scope, element, attrs) {
                scope.$on('comaparisonplansdatabind', function() {
                    scope.reportPlanDetails = scope[attrs.reportData]; //plansToShow object
                    scope.allPlans = scope[attrs.planData]; // array of plan objects
                    scope.allPlansHeaders = scope[attrs.planHeaders]; // plans headers
                    scope.properties = scope[attrs.reportProperties]; // report properties
                    scope.planDetailsInfo = scope[attrs.allPlansDetails]; //plan and it's properties
                    initReportTable();
                });

                var stickyHeaderHtml = '';
                var stickySideBarHtml = '';
                var scrollContentHtml = '';
                var attrObj = {};
                var costShareDefaultOrder = ['Cost Share Value Copay', 'Cost Share Value Co-insurance', 'Cost Share Value Deductible', 'Cost Share Value Limits and Exceptions',
                    '_Cost Share Value Copay', '_Cost Share Value Co-insurance', '_Cost Share Value Deductible', '_Cost Share Value Limits and Exceptions'
                ];

                function sortServiceObj(obj) {
                    var tempArray = [];
                    for (var key in obj) {
                        if (obj.hasOwnProperty(key)) {
                            tempArray.push(key);
                        }
                    }

                    tempArray.sort();
                    scope.sortedServiceobj = {};
                    for (var i = 0; i < tempArray.length; i++) {
                        scope.sortedServiceobj[tempArray[i]] = obj[tempArray[i]];
                    }
                    return scope.sortedServiceobj;
                }

                function sortCostShareObj(obj) {
                    var sortedCostShareObj = {};
                    angular.forEach(costShareDefaultOrder, function(item) {
                        if (obj.hasOwnProperty(item)) {
                            sortedCostShareObj[item] = obj[item];
                        }
                    });

                    return sortedCostShareObj;
                }

                scope.planNameWidth = '';
                scope.constructPlanNameRow = function() {
                    stickyHeaderHtml = '<div class="column-headers chrome-column-headers column-header-width" id="clscroll-column-headers"><table border = "1"><tr>';
                    angular.forEach(scope.reportPlanDetails.plansToShow, function(plan, key) {
                        scope.planNameWidth = plan.planHeaders.length * 188 + 'px';
                        var planNature = setBasePlanColor(scope.reportPlanDetails.plansToShow, key);
                        if (planNature === 'basePlan') {
                            stickyHeaderHtml += '<th style="width:' + scope.planNameWidth + '" class="centered header-border plan-name-break ' + scope.basePlanDiff + ' corner-header-head" colspan=' + plan.planHeaders.length + '>';
                            stickyHeaderHtml += '<div style="width:' + scope.planNameWidth + '">' + plan.planName + '<br/>Base Plan' + '</div></th>';
                        } else {
                            stickyHeaderHtml += '<th style="width:' + scope.planNameWidth + '" class="centered header-border plan-name-break ' + scope.basePlanDiff + ' corner-header-head" colspan=' + plan.planHeaders.length + '>';
                            stickyHeaderHtml += '<div style="width:' + scope.planNameWidth + '">' + plan.planName + '</div></th>';
                        }
                    });
                    stickyHeaderHtml = stickyHeaderHtml + '</tr><tr>';
                };

                scope.constructPlanHeadersRow = function() {
                    angular.forEach(scope.allPlans, function(plans, key) {
                        setBasePlanColor(scope.allPlans, key);
                        angular.forEach(plans.planHeaders, function(header) {
                            if (scope.reportPlanDetails.plansToShow[0]['planHeaders'].indexOf(header) !== -1) {
                                stickyHeaderHtml += '<th class="plan-tier-td-width header-border  ' + scope.basePlanDiff + ' corner-header-head"><div class="centered plan-tier-td-width">' + header + '</div></th>';
                            } else {
                                stickyHeaderHtml += '<th class="plan-tier-td-width header-border header-difference ' + scope.basePlanDiff + ' corner-header-head"><div class="centered plan-tier-td-width">' + header + '</div></th>';
                            }
                        });
                    });
                    stickyHeaderHtml = stickyHeaderHtml + '</tr></table></div>';
                };


                scope.costShareDataContainerWidth = '';
                scope.populateTierData = function(service, stickySideBarHtml, scrollContentHtml, serviceNameClone, serviceName) {
                    var serviceNameCloneStr = serviceNameClone;
                    var sectionObject = {};
                    var serviceNameStr = null;
                    if (angular.isUndefined(serviceName)) {
                        serviceNameStr = '';
                    } else {
                        serviceNameStr = serviceName;
                    }

                    var doesCostShareExist = false;
                    var allKeys = [];

                    angular.forEach(service, function(serviceProperty, serviceNameKey) {
                        if ((serviceNameKey.lastIndexOf('_', 0)) === 0) {
                            doesCostShareExist = true;
                        }

                        var hasCostShareValue = false;
                        var csData;

                        if ((serviceNameKey.lastIndexOf('Cost Share Level ', 0)) === 0) {
                            doesCostShareExist = false;
                            serviceProperty = sortCostShareObj(serviceProperty);
                            makeAttrObjForCostShareLevels(allKeys, serviceProperty, hasCostShareValue, serviceNameStr, serviceNameKey);
                        } else if ((serviceNameKey.lastIndexOf('Cost Share Value', 0)) === 0) {
                            var pc = 0;
                            angular.forEach(scope.allPlans, function(plans, key) {
                                pc++;
                                var plandiff = setBasePlanColor(scope.allPlans, key);
                                angular.forEach(plans.planHeaders, function(head) {
                                    csData = fillCostShareValues(attrObj, plans, serviceNameKey, head, csData, plandiff, pc, scope.allPlans);
                                });
                            });
                            doesCostShareExist = false;
                        }

                        if (angular.isObject(serviceProperty) && doesPlanHeaderExist(serviceProperty, scope.allPlansHeaders) && !doesCostShareExist) {
                            stickySideBarHtml += '<tr><td class="no-wrap corner-header-head"><div class="sticky-column-width" title="' + serviceNameKey + '">&emsp;&emsp;&emsp;<b><i>' + serviceNameKey + '</i></b></td></div></tr>';
                            if ((serviceNameKey.lastIndexOf('Cost Share Value', 0)) === -1) {
                                scrollContentHtml += '<tr class="no-wrap">';
                                angular.forEach(scope.allPlans, function(plan) {
                                    scrollContentHtml += '<td class=" corner-header-head border-for-plans" colspan="' + plan.planHeaders.length + '"><div>' + '' + '</div></td>';
                                });
                                scrollContentHtml += '</tr>';
                            }
                            if (csData) {
                                scrollContentHtml += '<tr>' + csData + '</tr>';
                            }

                            serviceNameCloneStr = serviceNameCloneStr + '.' + serviceNameKey;
                            serviceNameStr = serviceNameStr + '.' + serviceNameKey;
                            sectionObject['scrollContentHtml'] = scrollContentHtml;
                            sectionObject['stickySideBarHtml'] = stickySideBarHtml;
                            sectionObject = scope.populateTierData(serviceProperty, stickySideBarHtml, scrollContentHtml, serviceNameCloneStr, serviceNameStr);
                            scrollContentHtml = sectionObject.scrollContentHtml;
                            stickySideBarHtml = sectionObject.stickySideBarHtml;
                            //console.log(serviceNameStr + '.' + serviceNameKey);
                            serviceNameStr = serviceNameStr.substr(0, serviceNameStr.lastIndexOf(serviceNameKey) - 1);

                        } else if (!doesCostShareExist) {
                            stickySideBarHtml += '<tr><td class="no-wrap corner-header-head"><div class="sticky-column-width" title="' + serviceNameKey + '">&emsp;&emsp;&emsp;&emsp;' + serviceNameKey + '</div></td></tr>';
                            var plancounter = 0;
                            scrollContentHtml += '<tr>';
                            angular.forEach(scope.allPlans, function(plans, key) {
                                scope.costShareDataContainerWidth = plans.planHeaders.length * 188 + 'px';
                                plancounter++;
                                setBasePlanColor(scope.allPlans, key);
                                var properties = 'Properties';
                                var planserviceudfs = 'Plan Service UDFs';
                                if ((serviceNameStr.indexOf(properties) === -1) && (serviceNameStr.indexOf(planserviceudfs) === -1)) {
                                    angular.forEach(plans.planHeaders, function(head) {
                                        var newObj = colspanproperties(serviceNameStr, plans.planName, serviceNameKey, head, plancounter, scope.allPlans, true);
                                        var result = newObj['tierValue'];
                                        result = removeEnclosingBrackets(result);

                                        if (head === plans.planHeaders[0]) {
                                            scrollContentHtml += '<td class=" corner-header-head no-wrap border-for-plans ' + newObj['tierClass'] + ' ' + scope.basePlanDiff + '">';
                                            scrollContentHtml += ' <div class="plan-tier-td-width individual-tier-box text-overflow" title="' + result + '">' + result + '</div></td>';
                                        } else {
                                            scrollContentHtml += '<td class="no-wrap corner-header-head ' + newObj['tierClass'] + ' ' + scope.basePlanDiff + '">';
                                            scrollContentHtml += '<div class="plan-tier-td-width individual-tier-box text-overflow" title="' + result + '">' + result + '</div></td>';
                                        }
                                    });
                                } else {
                                    var head = plans.planHeaders[0];
                                    var newObj = colspanproperties(serviceNameStr, plans.planName, serviceNameKey, head, plancounter, scope.allPlans, false);
                                    var result = newObj['tierValue'];
                                    result = removeEnclosingBrackets(result);
                                    scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans ' + newObj['tierClass'] + ' ' + scope.basePlanDiff + '" colspan="' + plans.planHeaders.length + '" >';
                                    scrollContentHtml += '<div class="text-overflow" style="width:' + scope.costShareDataContainerWidth + '"  title="' + result + '">' + result + '</div></td>';
                                }
                            });
                            scrollContentHtml += '</tr>';
                        }
                        sectionObject['scrollContentHtml'] = scrollContentHtml;
                        sectionObject['stickySideBarHtml'] = stickySideBarHtml;

                    });
                    return sectionObject;
                };


                function colspanproperties(serviceNameStr, planName, serviceNameKey, head, counter, planList, isCostShare) {
                    var planDetailsInfoKey = formPlanDetailsInfoKey(serviceNameStr, planName, serviceNameKey, head);
                    //var planDetailsInfoKeyBasePlan = planDetailsInfoKey.split('.');
                    //planDetailsInfoKeyBasePlan[0] = planList[0].planName;
                    var planDetailsInfoKeyBasePlan = '';
                    if (isCostShare) {
                        planDetailsInfoKeyBasePlan = formPlanDetailsInfoKey(serviceNameStr, planList[0].planName, serviceNameKey, head);
                    } else {
                        planDetailsInfoKeyBasePlan = formPlanDetailsInfoKey(serviceNameStr, planList[0].planName, serviceNameKey, planList[0].planHeaders[0]);
                    }

                    var planDetailsInfoKeyHolder = [];
                    var planDetailsInfoKeyBasePlanKeyHolder = [];
                    planDetailsInfoKeyBasePlanKeyHolder.push(planDetailsInfoKeyBasePlan);
                    planDetailsInfoKeyHolder.push(planDetailsInfoKey);
                    var baseResult = planDetailsInfoKeyBasePlanKeyHolder.map(getTierValue.bind(null, scope.planDetailsInfo));
                    var result = planDetailsInfoKeyHolder.map(getTierValue.bind(null, scope.planDetailsInfo));
                    var tierObject = {};
                    result = result[0];
                    if (result === '[]') {
                        result = removeEnclosingBrackets(result);

                    }
                    if (counter !== 1) {
                        baseResult = baseResult[0];
                        if (baseResult === '[]') {
                            baseResult = removeEnclosingBrackets(baseResult);

                        }
                        if (baseResult !== '' && !angular.isUndefined(baseResult)) {
                            scope.flag = false;
                        } else if (baseResult === '' || angular.isUndefined(baseResult)) {
                            scope.flag = true;
                        }

                    }
                    tierObject = getTierObject(result, counter, planList);
                    return tierObject;
                }

                scope.emptyCellContainerWidth = '';
                scope.populateReportProperties = function() {
                    stickySideBarHtml = '<div id="row-headers-main"><div id="row-headers-submain"><div id="clscroll-row-headers"><div class="row-headers"><table border = "1" class="plan-table">';
                    scrollContentHtml = '<div class="table-content-new chrome-table-content-new" id="clscroll-content"><table border = "1" class="plan-table">';
                    angular.forEach(scope.properties, function(sectionProperty, sectionName) {
                        if (sectionName !== 'unAssociatedServices') {
                            stickySideBarHtml += '<tr><td class="no-wrap corner-header-head"><div class="sticky-column-width" title="' + sectionName + '"><b><i>' + sectionName + '</b></i></div></td></tr>';
                            scrollContentHtml += '<tr>';
                            angular.forEach(scope.allPlans, function(plans) {
                                scope.emptyCellContainerWidth = plans.planHeaders.length * 188.8 + 'px';
                                scrollContentHtml += '<td style="width:' + scope.emptyCellContainerWidth + '" class=" centered basePlan border-for-plans corner-header-head no-wrap" colspan="' + plans.planHeaders.length + '">';
                                scrollContentHtml += '<div class="text-overflow" style="width:' + scope.emptyCellContainerWidth + '" >' + ' ' + '</div></td>';
                            });
                            scrollContentHtml += '</tr>';
                        }
                        if (sectionName !== scope.reportPlanDetails.infoToDisplayinUI.planServiceSection && sectionName !== 'unAssociatedServices') {
                            buildPlanDetailsInfoObject(sectionProperty, sectionName);
                        } else if (sectionName === scope.reportPlanDetails.infoToDisplayinUI.planServiceSection || sectionName === 'unAssociatedServices') {
                            sortServiceObj(sectionProperty);
                            angular.forEach(scope.sortedServiceobj, function(serviceProperty, serviceName) {
                                stickySideBarHtml += '<tr><td class="no-wrap corner-header-head">';
                                stickySideBarHtml += '<div class="sticky-column-width" title="' + serviceName + '"><b>&emsp;&emsp;' + serviceName + '</b></div></td></tr>';
                                scrollContentHtml += '<tr class="no-wrap">';
                                angular.forEach(scope.allPlans, function(plan) {
                                    scrollContentHtml += '<td class=" corner-header-head border-for-plans" colspan="' + plan.planHeaders.length + '"></td>';
                                });
                                scrollContentHtml += '</tr>';
                                var sectionObject = scope.populateTierData(serviceProperty, stickySideBarHtml, scrollContentHtml, serviceName, serviceName);
                                scrollContentHtml = sectionObject.scrollContentHtml;
                                stickySideBarHtml = sectionObject.stickySideBarHtml;
                            });
                        }
                    });
                };

                scope.difference = 'false';
                scope.tierDataContainerWidth = '';

                function buildPlanDetailsInfoObject(sectionProperty, sectionName) {
                    angular.forEach(sectionProperty, function(tierPair, sectionSubProp) {
                        stickySideBarHtml += '<tr><td class="no-wrap corner-header-head"><div class="sticky-column-width" title="' + sectionSubProp + '">&emsp;&emsp;&emsp;&emsp;' + sectionSubProp + '</div></td></tr>';
                        var tierData;
                        var planList = scope.allPlans;
                        var planObj;
                        scrollContentHtml += '<tr>';
                        for (var plan = 0; plan < planList.length; plan++) {
                            setBasePlanColor(planList, plan);
                            var planname = planList[plan];
                            var headers = planname.planHeaders[0];
                            scope.tierDataContainerWidth = planname.planHeaders.length * 188 + 'px';
                            //for (var head = 0; head < headers.length; head++) {
                            tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][headers];
                            if (typeof(tierData) === 'object') {
                                if (sectionSubProp.search('Split Tiers') !== -1) {
                                    angular.forEach(planname.planHeaders, function(head) {
                                        tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][head];
                                        angular.forEach(tierData, function(value, key) {
                                            if (tierData.hasOwnProperty('diff')) {
                                                if (tierData.diff === true) {
                                                    scope.difference = 'difference';
                                                } else {
                                                    scope.difference = 'no-difference';
                                                }
                                            }
                                            if (key === 'value') {
                                                var formattedTierData = removeEnclosingBrackets(value);
                                                if (head === planname.planHeaders[0]) {
                                                    scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans split-tier-td-width ' + scope.difference + ' ' + scope.basePlanDiff + '">';
                                                    scrollContentHtml += '<div class="plan-tier-td-width text-overflow" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                                } else {
                                                    scrollContentHtml += '<td class="no-wrap corner-header-head centered split-tier-td-width ' + scope.difference + ' ' + scope.basePlanDiff + '">';
                                                    scrollContentHtml += '<div class="plan-tier-td-width text-overflow" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                                }
                                            }
                                        });
                                    });
                                } else {
                                    angular.forEach(tierData, function(value, key) {
                                        if (tierData.hasOwnProperty('diff')) {
                                            if (tierData.diff === true) {
                                                scope.difference = 'difference';
                                            } else {
                                                scope.difference = 'no-difference';
                                            }
                                        }
                                        if (key === 'value') {
                                            var formattedTierData = removeEnclosingBrackets(value);
                                            scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans ' + scope.difference + ' ' + scope.basePlanDiff + '" colspan="' + planname.planHeaders.length + '"';
                                            scrollContentHtml += 'style="width:' + scope.tierDataContainerWidth + '">';
                                            scrollContentHtml += '<div class="text-overflow" style="width:' + scope.tierDataContainerWidth + '" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                        }
                                    });
                                }

                            } else {
                                if (sectionSubProp.search('Split Tiers') !== -1) {
                                    angular.forEach(planname.planHeaders, function(head) {
                                        tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][head];
                                        if (angular.isDefined(tierData)) {
                                            var formattedTierData = removeEnclosingBrackets(tierData);
                                            if (head === planname.planHeaders[0]) {
                                                scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans split-tier-td-width ' + scope.basePlanDiff + '">';
                                                scrollContentHtml += '<div class="split-tier-td-width text-overflow" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                            } else {
                                                scrollContentHtml += '<td class="no-wrap corner-header-head centered plan-tier-td-width ' + scope.basePlanDiff + '">';
                                                scrollContentHtml += '<div class="split-tier-td-width text-overflow" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                            }
                                        } else {

                                            if (head === planname.planHeaders[0]) {
                                                scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans ' + scope.basePlanDiff + '"><div class="plan-tier-td-width">' + '' + '<div></td>';
                                            } else {
                                                scrollContentHtml += '<td class="no-wrap corner-header-head centered ' + scope.basePlanDiff + '"><div class="plan-tier-td-width">' + '' + '<div></td>';
                                            }
                                        }
                                    });
                                } else {
                                    tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][headers];
                                    if (angular.isDefined(tierData)) {
                                        var formattedTierData = removeEnclosingBrackets(tierData);
                                        scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans ' + scope.basePlanDiff + '" colspan="' + planname.planHeaders.length + '" style="width:' + scope.tierDataContainerWidth + '">';
                                        scrollContentHtml += '<div class="text-overflow" style="width:' + scope.tierDataContainerWidth + '" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                    } else {
                                        //html += '<td></td>';
                                        scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans ' + scope.basePlanDiff + '" colspan="' + planname.planHeaders.length + '"';
                                        scrollContentHtml += 'style="width:' + scope.tierDataContainerWidth + '">' + '' + '</td>';
                                        planObj = planname.planName;
                                    }
                                }
                            }
                        }
                        scrollContentHtml += '</tr>';
                    });
                }

                function doesPlanHeaderExist(object, headers) {
                    var boo = true;
                    angular.forEach(headers, function(item) {
                        if (angular.isDefined(object[item])) {
                            boo = false;
                        }
                    });
                    return boo;
                }

                function formPlanDetailsInfoKey(serviceNameCloneStr, planName, serviceNameKey, head) {
                    return planName + '.' + scope.reportPlanDetails.infoToDisplayinUI.planServiceSection + '.' + serviceNameCloneStr + '.' + serviceNameKey + '.' + head;
                }

                function makeAttrObjForCostShareLevels(allKeys, serviceProperty, hasCostShareValue, serviceNameStr, serviceNameKey) {
                    allKeys = Object.keys(serviceProperty);
                    attrObj = {};
                    var reportObjKey = serviceNameStr.split('.');
                    angular.forEach(scope.allPlans, function(plan) {
                        attrObj[plan.planName] = {};
                    });
                    for (var costShareKey = 0; costShareKey < allKeys.length; costShareKey++) {
                        if ((allKeys[costShareKey].lastIndexOf('_', 0)) === 0 && !hasCostShareValue) {
                            assignAttrObjVal(reportObjKey, allKeys, costShareKey, serviceNameKey, attrObj);
                            //attrObj[allKeys[costShareKey]] = serviceProperty[allKeys[costShareKey]];
                        }
                    }
                }

                function getTierValue(planDetailsInfoObj, planDetailsInfoKey) {
                    return planDetailsInfoKey
                        .split('.')
                        .reduce(function(resultObj, resultKey) {
                            if (angular.isUndefined(resultObj[resultKey]) || resultObj[resultKey] === null) {
                                return '';
                            } else {
                                return resultObj[resultKey];
                            }
                        }, planDetailsInfoObj);
                }

                function removeEnclosingBrackets(tierData) {
                    if (angular.isDefined(tierData) && !(tierData instanceof Array) && (tierData.indexOf('[') === 0) && (tierData.lastIndexOf(']') === tierData.length - 1)) {
                        return tierData.substr(1, tierData.length - 2);
                    } else if (angular.isDefined(tierData) && tierData instanceof Array && (typeof(tierData[0]) === 'string' && tierData[0].indexOf('[') === 0) && (typeof(tierData[0]) === 'string' && tierData[0].lastIndexOf(']') === tierData[0].length - 1)) {
                        return tierData[0].substr(1, tierData[0].length - 2);
                    } else {
                        return tierData;
                    }
                }

                function assignAttrObjVal(reportObjKey, allKeys, costShareKey, serviceNameKey, attrObj) {
                    angular.forEach(scope.allPlans, function(plan) {
                        var tierValue = null;
                        if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]])) {
                            if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]])) {
                                if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][serviceNameKey])) {
                                    if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][serviceNameKey][allKeys[costShareKey]])) {
                                        tierValue = scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][serviceNameKey][allKeys[costShareKey]];
                                    } else {
                                        tierValue = '';
                                    }
                                } else {
                                    tierValue = '';
                                }
                            } else {
                                tierValue = '';
                            }
                        } else {
                            tierValue = '';
                        }

                        if (tierValue) {
                            attrObj[plan.planName][allKeys[costShareKey]] = tierValue;
                        } else {
                            attrObj[plan.planName][allKeys[costShareKey]] = '';
                        }
                    });
                }
                scope.flag = false;

                function fillCostShareValues(attrObj, plans, serviceNameKey, head, csData, plandiffcolor, counter, planlist) {
                    var costShareValueObj = attrObj[plans.planName];
                    var costShareValueOfBasePlan = attrObj[planlist[0].planName];
                    var checkEmptyObj = Object.getOwnPropertyNames(costShareValueObj).length === 0;
                    if (checkEmptyObj === true) {
                        if (angular.isUndefined(csData)) {
                            if (head === plans.planHeaders[0]) {
                                csData = '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                            } else {
                                csData = '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                            }
                        } else {
                            if (head === plans.planHeaders[0]) {
                                csData = csData + '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                            } else {
                                csData = csData + '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                            }
                        }
                    } else if (!costShareValueObj.hasOwnProperty('_' + serviceNameKey) && !csData) {
                        if (head === plans.planHeaders[0]) {
                            csData = '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                        } else {
                            csData = '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                        }
                    } else if (!costShareValueObj.hasOwnProperty('_' + serviceNameKey) && csData) {
                        if (head === plans.planHeaders[0]) {
                            csData += '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                        } else {
                            csData += '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                        }
                    } else {
                        angular.forEach(costShareValueObj, function(tierObj, costShareKey) {
                            var costShareValueKey = costShareKey.substr(1, costShareKey.length);
                            if (counter !== 1) {
                                var tierObjectForBasePlan = costShareValueOfBasePlan[costShareKey];
                                var basePlantierValue = tierObjectForBasePlan[head];
                                if (basePlantierValue !== '' && !angular.isUndefined(basePlantierValue)) {
                                    scope.flag = false;
                                } else {
                                    scope.flag = true;
                                }
                            }
                            var tierObject = getTierObject(tierObj[head], counter, planlist);
                            var tierData = tierObject['tierValue'];
                            if (costShareValueKey === serviceNameKey && csData && tierData) {
                                if (head === plans.planHeaders[0]) {
                                    csData = csData + '<td class="no-wrap corner-header-head border-for-plans ' + tierObject['tierClass'] + ' ' + plandiffcolor + '">' + tierData + '</td>';
                                } else {
                                    csData = csData + '<td class="no-wrap corner-header-head ' + tierObject['tierClass'] + ' ' + plandiffcolor + '">' + tierData + '</td>';
                                }
                                //html = html + '<td>' + tierObj[head] + '</td>';
                            } else if (costShareValueKey === serviceNameKey && !csData && tierData) {
                                if (head === plans.planHeaders[0]) {
                                    csData = '<td class="no-wrap corner-header-head border-for-plans ' + tierObject['tierClass'] + ' ' + plandiffcolor + '">' + tierData + '</td>';
                                } else {
                                    csData = '<td class="no-wrap corner-header-head ' + tierObject['tierClass'] + ' ' + plandiffcolor + '">' + tierData + '</td>';
                                }
                            } else if (costShareValueKey === serviceNameKey && csData && !tierData) {
                                if (head === plans.planHeaders[0]) {
                                    csData = csData + '<td class="no-wrap corner-header-head border-for-plans ' + tierObject['tierClass'] + ' ' + plandiffcolor + '">' + '' + '</td>';
                                } else {
                                    csData = csData + '<td class="no-wrap corner-header-head ' + tierObject['tierClass'] + ' ' + plandiffcolor + '">' + '' + '</td>';
                                }
                            }
                        });
                    }
                    return csData;
                }


                function getTierObject(tierObject, counter, plans) {
                    var obj = {};
                    var baseplantocompare = plans[0];
                    obj['tierClass'] = 'no-difference';
                    if (typeof(tierObject) === 'object') {
                        angular.forEach(tierObject, function(tierValue, key) {
                            if (key === 'diff') {
                                if (tierValue === true) {
                                    obj['tierClass'] = 'difference';
                                }
                            } else {
                                obj['tierValue'] = tierValue;
                            }
                        });
                    } else if (tierObject === '' || typeof(tierObject) === 'undefined') {
                        if (baseplantocompare && counter === 1) {
                            scope.flag = true;
                        } else {
                            if (scope.flag === false) {
                                obj['tierClass'] = 'difference';
                            }
                        }
                        obj['tierValue'] = ' ';
                    } else {
                        obj['tierValue'] = tierObject;
                        scope.flag = false;
                    }
                    return obj;
                }

                function setBasePlanColor(planList, planIteration) {
                    var basePlan = planList[0];
                    if (planIteration === 0 && basePlan) {
                        scope.basePlanDiff = 'basePlan';
                    } else {
                        scope.basePlanDiff = 'compareplan';
                    }
                    return scope.basePlanDiff;
                }

                function initReportTable() {
                    scope.constructPlanNameRow();
                    scope.constructPlanHeadersRow();
                    scope.populateReportProperties();
                    var cornerHeaderHtml = '<div class="corner-header"><table class="corner-header-table"><tr> <th class="corner-header-head" id="setrowheight" ></th></tr>';
                    cornerHeaderHtml += '<tr> <th class="corner-header-head corner-header-head-height">&nbsp;<br/></th></tr></table></div>';
                    stickySideBarHtml += '</table></div></div></div></div>';
                    scrollContentHtml += '</table></div>';
                    var html = '<div class="outer-wrapper">';
                    html += cornerHeaderHtml + stickyHeaderHtml + stickySideBarHtml + scrollContentHtml + '</div>';
                    element.context.innerHTML = html;
                    scope.$watch('$viewContentLoaded', function() {
                        scope.planNameRowHeight = angular.element('.column-headers').height() - 30 + 'px';
                        angular.element('#setrowheight').attr('height', scope.planNameRowHeight);
                    });
                    var thing = angular.element('#clscroll-content');
                    var extra = 100;
                    var old = angular.element(thing).scrollTop();
                    angular.element('#clscroll-content').scroll(function() {
                        if (angular.element(thing).scrollTop() < old) {
                            angular.element(thing).scrollTop(angular.element(thing).scrollTop() - extra);
                        } else if (angular.element(thing).scrollTop() > old) {
                            angular.element(thing).scrollTop(angular.element(thing).scrollTop() + extra);
                        }
                        old = angular.element(thing).scrollTop();
                        angular.element('#clscroll-row-headers').scrollTop($('#clscroll-content').scrollTop());
                        angular.element('#clscroll-column-headers').scrollLeft($('#clscroll-content').scrollLeft());
                    });

                    angular.element('#clscroll-column-headers').scroll(function() {
                        angular.element('#clscroll-content').scrollLeft($('#clscroll-column-headers').scrollLeft());
                    });

                    angular.element('#clscroll-row-headers').scroll(function() {
                        angular.element('#clscroll-content').scrollTop($('#clscroll-row-headers').scrollTop());
                    });
                }
            }
        };
    });