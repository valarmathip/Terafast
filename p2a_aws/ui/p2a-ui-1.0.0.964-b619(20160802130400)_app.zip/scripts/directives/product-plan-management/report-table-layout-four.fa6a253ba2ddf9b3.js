'use strict';
angular.module('p2AdvanceApp')
    .directive('reportTableLayoutFour', function() {
        return {
            restrict: 'E',
            link: function(scope, element, attrs) {

                scope.$on('bindDataForLayout4', function() {
                    scope.reportPlanDetails = scope[attrs.reportData]; //plansToShow object
                    scope.allPlans = scope[attrs.planData]; // array of plan objects
                    scope.allPlansHeaders = scope[attrs.planHeaders]; // plans headers
                    scope.properties = scope[attrs.reportProperties]; // report properties
                    scope.planDetailsInfo = scope[attrs.allPlansDetails]; //plan and it's properties
                    initReportTable();
                });

                var html = '<div class="table-responsive" style="max-height:2000px;"><table class="table table-striped table-bordered table-hover table-condensed small "><tr><th></th>';
                /*var attrObj = {};*/
                var valuesToBeRepeated = [];

                scope.constructPlanHeadersRow = function() {
                    angular.forEach(scope.allPlansHeaders, function(headers) {
                        html += '<th class="centered" colspan=' + valuesToBeRepeated.length + '>' + headers + '</th>';
                    });
                    html = html + '</tr><tr><th></th>';
                };

                scope.constructPlanServiceRow = function() {
                    angular.forEach(scope.allPlansHeaders, function() {
                        angular.forEach(valuesToBeRepeated, function(header) {
                            html += '<td>' + header + '</td>';
                        });

                    });
                    html += '</tr>';
                };

                scope.populateValuesToBeRepeated = function() {
                    angular.forEach(scope.properties, function(planServiceValue, planService) {
                        if (planService === 'Plan Service') {
                            angular.forEach(planServiceValue, function(serviceObject, serviceName) {
                                if (serviceName !== '') {
                                    valuesToBeRepeated.push('<b>' + serviceName + '</b>');
                                }
                                iterateOverProperties(serviceObject);
                                iterateOverPlanServiceCostShares(serviceObject);
                            });
                        }

                    });

                };

                function iterateOverProperties(serviceObject) {
                    if (angular.isDefined(serviceObject['Properties'])) {
                        valuesToBeRepeated.push('Covered/Not Covered');
                    }

                }

                function iterateOverPlanServiceCostShares(serviceObject) {
                    angular.forEach(serviceObject, function(planJson, planHeader) {
                        if (planHeader === 'Plan Service Cost Shares') {
                            // valuesToBeRepeated.push('<b><em>' + planHeader + '</em></b>');
                            angular.forEach(scope.allPlans[0]['planserviceHeaders'], function(costShareLevelValue, costShareLevel) {
                                if (costShareLevel === 'Plan Service Cost Shares') {
                                    angular.forEach(costShareLevelValue, function(costShareLevelNameValue, costShareLevelName) {
                                        valuesToBeRepeated.push('<em><b>' + costShareLevelName + '</b></em>');
                                        angular.forEach(costShareLevelNameValue, function(copayValue, copay) {
                                            valuesToBeRepeated.push(copay);
                                            angular.forEach(copayValue, function(applyToDeductValue, applyToDeduct) {
                                                valuesToBeRepeated.push(applyToDeduct);
                                            });
                                        });
                                    });
                                }
                            });
                        }
                    });
                }

                scope.populateData = function() {
                    angular.forEach(scope.allPlans, function(plans) {
                        html += '<tr><td class="no-wrap"><b>' + plans.planName + '</b></td>';
                        angular.forEach(scope.allPlansHeaders, function(header) {
                            angular.forEach(plans.sections[0], function(serviceObject, sectionName) {
                                if (sectionName === 'Plan Service') {
                                    angular.forEach(serviceObject, function(planServiceDetails, planServiceName) {
                                        if (angular.isUndefined(planServiceName.header)) {
                                            html += '<td></td>';
                                        }
                                        scope.iterateOverPropertiesData(header, planServiceDetails);
                                    });
                                }
                            });
                        });
                    });
                    html += '</tr>';
                };

                scope.iterateOverPropertiesData = function(header, planServiceDetails) {
                    angular.forEach(planServiceDetails, function(serviceData, serviceHeader) {
                        if (serviceHeader === 'Properties') {
                            angular.forEach(serviceData, function(servicePropertyDetail) {

                                if (servicePropertyDetail.hasOwnProperty(header)) {
                                    html += '<td>' + servicePropertyDetail[header] + '</td>';
                                } else {
                                    html += '<td></td>';
                                }
                            });
                        } else {
                            scope.iterateOverCostShareData(header, serviceData);
                        }

                    });
                    return html;
                };

                scope.iterateOverCostShareData = function(header, serviceData) {
                    angular.forEach(scope.allPlans[0]['planserviceHeaders']['Plan Service Cost Shares'], function(costShareLevelObject, costShareLevelName) {
                        html += '<td></td>';
                        var populatedCostShareData = {};
                        if (!angular.isUndefined(serviceData)) {
                            populatedCostShareData = serviceData[costShareLevelName];
                        }

                        angular.forEach(costShareLevelObject, function(levelObject, levelName) {
                            if (!angular.isUndefined(populatedCostShareData) && !angular.isUndefined(populatedCostShareData['_' + levelName]) && !angular.isUndefined(populatedCostShareData['_' + levelName][header])) {
                                var copayValue = populatedCostShareData['_' + levelName][header];
                                html += '<td>' + copayValue + '</td>';
                            } else {

                                html += '<td></td>';
                            }

                            var costSharetierDetail = {};
                            if (!angular.isUndefined(populatedCostShareData)) {
                                costSharetierDetail = populatedCostShareData[levelName];
                            }
                            angular.forEach(levelObject, function(levelDate, levelheaderName) {

                                if (!angular.isUndefined(costSharetierDetail) && !angular.isUndefined(costSharetierDetail[levelheaderName]) && !angular.isUndefined(costSharetierDetail[levelheaderName][header])) {
                                    var test = costSharetierDetail[levelheaderName][header];
                                    html += '<td>' + test + '</td>';
                                } else {

                                    html += '<td></td>';
                                }


                            });

                        });
                    });
                };

                function initReportTable() {
                    scope.populateValuesToBeRepeated();
                    scope.constructPlanHeadersRow();
                    scope.constructPlanServiceRow();
                    scope.populateData();
                    html = html + '</table></div>';
                    element.replaceWith(html);

                }
            }
        };
    });