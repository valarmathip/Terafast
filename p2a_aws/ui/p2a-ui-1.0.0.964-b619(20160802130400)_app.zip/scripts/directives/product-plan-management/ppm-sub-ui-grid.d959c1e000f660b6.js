'use strict';

/**
    This directive is apply to the root ui grid and will automatically update all its sub ui grid size
 */
angular.module('p2AdvanceApp')
    .directive('ppmSubGridResize', function($compile, $templateCache, $timeout, AccountMgmtSvc, $log) {
        // constant
        // the header of the sub-grid, such as 'Associated Plan', or 'Generated document'
        var subGridLevel1HeadHeight = 35;
        // the header of the sub-grid table column
        var subGridLevel1BodyGridHeadHeight = 35;
        var subGridLevel1BodyGridRowHeight = 70; /*jshint ignore:line*/
        var level2TopAndBottomPadding = 10;

        var link = {
            restrict: 'A',
            link: function(scope, iElement, iAttrs) { /*jshint ignore:line*/
                scope.$on('ppm.sub.grid.resize', function(event) { /*jshint ignore:line*/
                    $log.log('ppm.sub.grid.resize handler');

                    $timeout(function() {
                        updateExpandableRowWidth(iElement);
                        updateExpandableRowHeight(iElement);
                        $timeout(function() {
                            updateExpandableRowWidth(iElement);
                            updateExpandableRowHeight(iElement);
                            scope.$emit('ppm.root.grid.resize.requested');
                        }, 50);
                    });

                });

                // window is resized
                scope.$on('ppm.root.grid.resized', function(event) { /*jshint ignore:line*/
                    scope.$emit('ppm.sub.grid.resize');
                });
            }
        };

        function updateExpandableRowWidth(rootUiGridElement) {
            $log.log('updateExpandableWidth');
            var allEmbodiedRowList = rootUiGridElement.find('.ppm-expandable-row');

            if (allEmbodiedRowList.length !== 0) {
                allEmbodiedRowList.each(function() {
                    var ppmExpandableRowElement = angular.element(this);
                    // get the ppm expandalbe row width
                    var ppmExpandableRowWidth = ppmExpandableRowElement.width()-1; // minus 1 because in mid size, the right border is hidden
                    $log.log('updateExpandableRowWidth set viewport width = ' + ppmExpandableRowWidth);

                    // update junction ui-grid-viewport and ui-grid-canvas width, between my defined
                    // expandalbe row and expandable cell.
                    ppmExpandableRowElement.find('.ui-grid-viewport').first().css('width', ppmExpandableRowWidth + 'px');
                    ppmExpandableRowElement.find('.ui-grid-canvas').first().css('width', ppmExpandableRowWidth + 'px');

                    // update ppm expandalbe cell parent width
                    var ppmExpandableCellElement = ppmExpandableRowElement.find('.ppm-expandable-cell').first();
                    ppmExpandableCellElement.parent().css('width', '100%');
                    ppmExpandableCellElement.parent().css('min-width', '100%');
                    ppmExpandableCellElement.parent().css('max-width', '100%');

                    // sub ui-grid element under ppm-expandable-cell
                    // *REMEMBER* that ppm-expandalbe-cell-level-1 has the border of widht 1px, please check scss file
                    ppmExpandableCellElement.find('div[ui-grid]').first().css('width', ppmExpandableRowWidth-2 + 'px'); // minus 2 for the left and right border of ppm-expandable-cell is 1px.
                });
            }
        }

        function updateExpandableRowHeight(rootUiGridElement) {
            var allEmbodiedRowList = rootUiGridElement.find('.ppm-expandable-row');

            // if embodied row exist, update every row size from end of list
            if (allEmbodiedRowList.length !== 0) {
                angular.element(allEmbodiedRowList.get().reverse()).each(function() {
                    var ppmExpandableRowElement = angular.element(this);
                    var ppmExpandableCellElement = ppmExpandableRowElement.find('.ppm-expandable-cell').first();
                    var subGridElement = ppmExpandableCellElement.find('[ui-grid]').first();

                    var expandableSubUiGridHeight = updateUiGridHeight(subGridElement);


                    var juntionViewPortHeight = expandableSubUiGridHeight + subGridLevel1HeadHeight;

                    juntionViewPortHeight += level2TopAndBottomPadding + 8;
                    /**
                     * viewport between my defined expandable row and cell, call this junction viewport
                     * the height should be expandable viewport + grid table head + expandable header
                     */
                    var junctionViewPortElement = ppmExpandableRowElement.find('.ui-grid-viewport').first();
                    junctionViewPortElement.css('height', juntionViewPortHeight + 'px');

                    /**
                     *  row itself
                     */
                    ppmExpandableRowElement.css('height', juntionViewPortHeight + 'px');

                    /**
                     * update row parent div
                     */
                    ppmExpandableRowElement.parents('[ui-grid-expandable-row]').first().css('height', juntionViewPortHeight + 'px');
                });

            }

            // update current ui-grid canvas size, do not update viewport size
            var viewPort = rootUiGridElement.find('.ui-grid-viewport').first();
            updateUiGridCanvasHeight(viewPort);
        }

        function updateUiGridHeight(uiGridElement) {
            var viewPortElement = uiGridElement.find('.ui-grid-viewport').first();
            var canvasHeight = updateUiGridCanvasHeight(viewPortElement);

            var expandableViewportHeight = canvasHeight + 8; // add adjustment, so there is not scroll happens
            /**
             * viewport in my defined expandable cell div, which hold all the plan list, the height
             * should be the rowNumber * rowHeight. We name this as expandable viewport.
             * It can also be the height of ui-grid-canvas, and plus a little adjustment (if you do not want calculate 
             * padding, margin and border width value)
             */
            viewPortElement.css('height', expandableViewportHeight + 'px');
            //viewPortElement.css('max-height', expandableViewportHeight + 'px');

            var subUiGridHeight = expandableViewportHeight + subGridLevel1BodyGridHeadHeight;
            uiGridElement.css('height', subUiGridHeight + 'px');

            return subUiGridHeight;
        }

        // update ui-grid canvas height, and return the height
        function updateUiGridCanvasHeight(viewPortElement) {
            var rowsHeight = getAllRowsHeight(viewPortElement);
            var expandedRowsHeight = getAllExpandedRowHeight(viewPortElement);
            var canvasCalculatedHeight = rowsHeight + expandedRowsHeight;
            var canvasElement = viewPortElement.find('.ui-grid-canvas').first();

            // canvasCalculatedHeight += 15; // add a adjustment

            canvasElement.css('height', canvasCalculatedHeight + 'px');

            return canvasCalculatedHeight;
        }

        // Get totoal height of all rows height
        function getAllRowsHeight(viewPortElement) {
            var h = 0;
            viewPortElement.find('div.ui-grid-canvas').first().find('>div[ng-repeat]')
                .each(function(index, rowElement) {
                    h += angular.element(rowElement).height();
                });

            return h;
        }

        // Get total height of all expandable rows height
        function getAllExpandedRowHeight(viewPortElement) {
            var h = 0;
            // NOTE: div[ng-repeat] height is just the row height
            viewPortElement.find('div.ui-grid-canvas').first().find('>div[ng-repeat]>div[ui-grid-expandable-row]')
                .each(function(index, rowElement) {
                    h += angular.element(rowElement).height();
                });

            return h;
        }


        return link;
    });

/**
    The Adapter is between ui-grid expandable cell and the sub ui grid, and is adapter between them.

    How to setup scope property: subGridAdapter:
        Note:
        * This row is exactly the subGrid row, which is generate in the following way in the rowExpandedStateChanged function
            gridApi.expandable.on.rowExpandedStateChanged($scope, function(row) {
                if (row.isExpanded) {
                    ...
                    row.entity.subGridOptions.data = [{
                        assocatedId: row.entity.objectId,
                        associatedName: row.entity.name
                    }];

                } else {
                    ...
                }
            });

        * You can access our constroller scope by using: <currentScope>.grid.appScope.grid.appScope, it is the Controller scope or
          the scope that inhreit our controller scope. For example, 

          <div sub-grid-adapter="{rowEntity: row.entity, scopeName: grid.appScope.scopeName, scopeNameInCtrl: grid.appScope.grid.appScope.scopeName}"  
          template = "views/account-management/template/account-list/plan-list/ui-grid.html"
          expandable-prefix = "account-list-expandable"
          expandable-level = "level-1" ></div>

        * Surely, if you like, you can also put the property in our controller scope to row entity, for example:

                    row.entity.subGridOptions.data = [{
                                    assocatedId: row.entity.objectId,
                                    associatedName: row.entity.name
                                    someProperty: $scope.someProperty
                                }];

            Note above code is in our controller, so it can access our contrller scope

    Structure of the grid and sub grid:
        1. expand row structure:
           div.ppm-expandable-row --- ppm defined expandable row --- in row.html
              junction div.ui-grid-viewport
                 junction div.ui-grid-canvas
                    div.ppm-expandable-cell --- ppm defined expandable cell --- in cell.html
                       div[sub-grid-adapter] --- in cell.html
                          div.ppm-sub-grid-container.ppm-sub-grid-container-level-#  --- in ui-grid.html
                             div.ppm-sub-grid-header.ppm-sub-grid-header-level-1
                             div[ui-grid=gridOption].sub-grid-body.sub-grid-body-level-#  --- start a whole new ui-grid --- in the expand cell

        2. ui-grid structure:
           div[ui-grid=gridOption].some-grid-class
              div.ui-grid-render-container.ui-grid-render-container-body
                 div.ui-grid-header
                 div.ui-grid-viewport
                    div.ui-grid-canvas
                       div[ng-repeat].ui-grid-row
                          div[ng-repeat].ui-grid-cell
                       div[ui-grid-expandable-row].expandableRow
                          div.ppm-expandable-row --- ppm defined expandable row

*/
angular.module('p2AdvanceApp')
    .directive('subGridAdapter', function($compile, $templateCache, $timeout, $log) {
        $log.log('subGridAdapter');

        return {
            restrict: 'A',
            controller: function($scope) {
                $scope.slqProperty = 'slq00110011';
            },
            transclude: true,
            scope: {
                subGridAdapter: '=',
                expandablePrefix: '@', // SLQ currently we do not use this properties
                expandableLevel: '@' // SLQ currently we do not use this properties
            },
            compile: function(tElement, tAttrs, transclude) { /*jshint ignore:line*/
                var template = tAttrs['template'];
                var htmlStr = $templateCache.get(template);
                var compiledLink = $compile(htmlStr);

                return function(scope, iElement, iAttrs, controller, transclude) {
                    $log.log('subGridAdapter-link and subGridAdapter = ' + angular.toJson(scope.subGridAdapter, true));

                    var expandableRowPrefix = scope.expandablePrefix;
                    var expandableLevel = scope.expandableLevel;
                    if (!expandableRowPrefix || !expandableLevel) {
                        $log.error('Atrributes "expandable-prefix" and "expandable-level" must be set');
                    }


                    // transclude to use specified scope
                    var newScope = scope.$new();
                    transclude(newScope, function(clone) {
                        iElement.append(clone);
                    });

                    // generate DOM element
                    var uigridElem = compiledLink(newScope, function(clonedElement, scope) { /*jshint ignore:line*/
                        iElement.append(clonedElement);
                    });

                    updateCssProperties();

                    function updateCssProperties() {
                        // var expandableRow = iElement.parents('#' + expandableRowPrefix + '-' + expandableLevel + '-row');
                        var expandableRow = iElement.parents('.ppm-expandable-row').first();
                        // between expand row and cell, there is a ui-grid-viewport, that can scroll,
                        // disable it. This viewport is known as junction viewport
                        var junctionViewprtElement = expandableRow.find('.ui-grid-viewport').first();
                        junctionViewprtElement.css('overflow', 'hidden')
                            .css('overflow-x', 'hidden') // in ie, this 2 is set to override the general overflow.
                            .css('overflow-y', 'hidden');
                    }
                };
            }
        };
    });