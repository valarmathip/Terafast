'use strict';
/**
    PPM Popup Manager to manger the popup postion, show/hide.

    Manager Event List:
        'ppmPopup.Manager.SizeChanged': fired when window size, or something similar, changed, notify sub-element to reset its size
        'ppmPopup.Manager.HostElmt.PositionChanged': fire when host element postion changed, usually caused by scroll, resize.

    Popup Event List:
        'ppmPopup.Manager.SubElement.SizeReset': fired when subElement size is changed
        'ppmPopup.Manager.SubElement.Ready': fired when sub-element first created and size-reset is done. Notify manager to show the element

    This directive has the following auxiliary directive/attribute
        1. "directiveType + '-z-index'", such as ppm-hover-menu-z-index: The css z-index value setting
        2. "directiveType + '-context-path'", such as ppm-hover-menu-context-path: The path to get the context value

    @Auth: SLQ

*/
angular.module('p2AdvanceApp')
    .provider('popupManager', function popupManagerProvider() {
        /**
         * This is a helper function for translating camel-case to snake-case.
         */
        function snakeCase(name) {
            var regexp = /[A-Z]/g;
            var separator = '-';
            return name.replace(regexp, function(letter, pos) {
                return (pos ? separator : '') + letter.toLowerCase();
            });
        }

        var triggerMap = {
            'mouseover': 'mouseover',
            'click': 'click',
            'outsideClick': 'outsideClick',
            'focus': 'blur',
            'none': ''
        };

        this.$get = function popupManagerFactory($compile, $window, $document, $timeout, $log) { /* jshint ignore:line */
            /* jshint unused:false */
            return function popupManager(directiveType, prefix, defaultTriggerShow, config) { // directive definition 
                var directiveName = snakeCase(directiveType);
                var templateStr = '<div id="slq-template-str" class="ppm-popup" ' + directiveName + '-popup' + '></div>';
                var defaultZIndex = 2100;

                var popupManagerDirectiveDefinitionObj = { // directive object
                    compile: function(tElement, tAttrs, transclude) { /* jshint ignore:line */
                        // $log.log('popupManager compile');
                        var directiveTmplLinker = $compile(templateStr);

                        var linkFnObj = {
                            // pre link function
                            pre: function preLink( /*scope, iElement, iAttrs, controller*/ ) {
                                // $log.log('popupManager pre-link');
                            }, // end of pre link function
                            // post link function
                            post: function postLink(scope, iElement, iAttrs /*, controller*/ ) {
                                // $log.log('popupManager post-link');
                                // Popup Management scope, it is isolutate scope, and the parent scope of popup scope
                                var popupManagerScope = scope.$new(true); // isolated scope
                                // Popup element
                                var directiveElmt;
                                // Popup scope
                                var directiveElmtScope;

                                popupManagerScope.isOpen = false;


                                // pre-defined trigger in triggerMap
                                function getTrigger() {
                                    var show = defaultTriggerShow;
                                    var hide = triggerMap[defaultTriggerShow];
                                    var triggerMapper = {
                                        'show': show,
                                        'hide': hide // 'dblclick'
                                    };

                                    return triggerMapper;
                                }

                                ////////////////////////////////////////////////////////////////////
                                // setup show/hide trigger
                                ////////////////////////////////////////////////////////////////////
                                function toggleListener(event) {
                                    // if (event.currentTarget === iElement[0]) {
                                    event.preventDefault(); // this necessary
                                    event.stopPropagation(); // this necessary, make sure body will not receive this event
                                    // }

                                    // For mouseover, this trigger only used to open popup, and close will trigger by mouseover outside or click on popup
                                    if (getTrigger().hide === 'mouseover' && popupManagerScope.isOpen) {
                                        return;
                                    }

                                    scope.$apply(function() {
                                        togglePopup();
                                    });
                                }

                                function showListener(event) {
                                    // if (event.currentTarget === iElement[0]) {
                                    event.preventDefault(); // this necessary
                                    event.stopPropagation(); // this necessary
                                    // }
                                    scope.$apply(function() { // need to put it in scope.apply, otherwise, such as tool-top content is not updated in the html tag
                                        showPopup();
                                    });
                                }

                                function hideListener(event) {
                                    // if (event.currentTarget === iElement[0]) {
                                    event.preventDefault(); // this necessary
                                    event.stopPropagation(); // this necessary
                                    // }
                                    scope.$apply(function() {
                                        hidePopup();
                                    });
                                }

                                function prepareTrigger(hostElmt, targetElmt) {
                                    unregisterTrigger(hostElmt, targetElmt);

                                    var triggerMapper = getTrigger();

                                    if (triggerMapper.show === triggerMapper.hide) {
                                        hostElmt.on(triggerMapper.show, toggleListener);
                                    } else {
                                        hostElmt.on(triggerMapper.show, showListener);
                                        hostElmt.on(triggerMapper.hide, hideListener);
                                    }
                                }

                                function unregisterTrigger(hostElmt /*, targetElmt*/ ) {
                                    var triggerMapper = getTrigger();

                                    if (triggerMapper.show === triggerMapper.hide) {
                                        hostElmt.off(triggerMapper.show, toggleListener);
                                    } else {
                                        hostElmt.off(triggerMapper.show, showListener);
                                        hostElmt.off(triggerMapper.hide, hideListener);
                                    }
                                }
                                // end of setup show/hide trigger


                                ////////////////////////////////////////////////////////////////////////////
                                // Rigister outside of popup event
                                ////////////////////////////////////////////////////////////////////////////
                                function insidePopupEventPreventDefaultAndStopPropagation(event) {
                                    event.preventDefault();
                                    event.stopPropagation();
                                }

                                function outsidePopupEventClosePopupListener( /*event*/ ) {
                                    // if (event.target === iElement[0]) { 
                                    //     $log.log('>>>>> outsidePopupEventClosePopupListener');
                                    //     return;
                                    // }
                                    // $log.log('outsidePopupEventClosePopupListener called');
                                    if (popupManagerScope.isOpen) {
                                        scope.$apply(function() {
                                            hidePopup();
                                        });
                                    }
                                }

                                function prepareOutsidePopupEventCloseTrigger(targetElmt) {
                                    unregisterOutsidePopupEventCloseTrigger(targetElmt);

                                    var triggerMapper = getTrigger();
                                    // show event will also trigger close popup when happen outside of pupup
                                    targetElmt.on(triggerMapper.show, insidePopupEventPreventDefaultAndStopPropagation);
                                    $document.find('body').on(triggerMapper.show, outsidePopupEventClosePopupListener);

                                    // I know this is not match with mouseover/mouseout, the mouseout trigger too many events
                                    // We also need to statisfy the click outside for tool tip
                                    // Maybe it is better to define registration event on each individual directive, not in manager
                                    if (triggerMapper.hide === 'mouseover') {
                                        targetElmt.on('mouseleave', outsidePopupEventClosePopupListener);
                                    }
                                }

                                function unregisterOutsidePopupEventCloseTrigger(targetElmt) {
                                    var triggerMapper = getTrigger();
                                    targetElmt.off(triggerMapper.show, insidePopupEventPreventDefaultAndStopPropagation);
                                    $document.find('body').off(triggerMapper.show, outsidePopupEventClosePopupListener);

                                    // I know this is not match with mouseover/mouseout, the mouseout trigger too many events
                                    // We also need to statisfy the click outside for tool tip
                                    // Maybe it is better to define registration event on each individual directive, not in manager
                                    if (triggerMapper.hide === 'mouseover') {
                                        targetElmt.off('mouseleave', outsidePopupEventClosePopupListener);
                                    }
                                }

                                // not used by now
                                // function unregisterOutsidePopupEventCloseTriggerDefautlAndStop(targetElmt) {
                                //     var triggerMapper = getTrigger();
                                //     targetElmt.off(triggerMapper.show, insidePopupEventPreventDefaultAndStopPropagation);
                                //     // body event will be removed by create new outside event
                                // }
                                // end of Rigister outside of popup event


                                ////////////////////////////////////////////////////////////////////////////////////
                                // Create and remove ui component
                                ////////////////////////////////////////////////////////////////////////////////////
                                /**
                                    Create popup element and attache it to the body
                                */
                                function createPopup() {
                                    directiveElmtScope = popupManagerScope.$new();

                                    directiveElmtScope.content = iAttrs[directiveType];
                                    // remember to set it to null when popupManagerScope is destroyed
                                    directiveElmtScope.contextScope = scope; // The context scope that popup supposed to connected/inherited
                                    // Configurable css z-index value, default is 2100
                                    directiveElmtScope.zindex = iAttrs[directiveType + 'ZIndex'] || defaultZIndex;
                                    // Add the host attributes into popupManagerScope, so that xxx-popup directive can access them
                                    directiveElmtScope.hostAttrs = tAttrs;

                                    // use cloned element, otherwise, in ui-grid, all the attached element is the same one
                                    directiveElmt = directiveTmplLinker(directiveElmtScope, function( /*clonedElmt, directiveElmtScope*/ ) {});
                                    directiveElmt.css({
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        display: 'none',
                                        //'z-index': 1029 // header, and foot div is 1030 /* This has been commented for modal dialog added with new value*/
                                        'z-index': directiveElmtScope.zindex
                                    });
                                    popupManagerScope.popupId = 'slq-popup-' + (new Date()).getTime() + '-' + Math.floor(Math.random() * 10000);
                                    directiveElmt.attr('id', popupManagerScope.popupId);
                                    // attach some event
                                    registerOnWindowResize(iElement);
                                    registerScroll(iElement);

                                    $document.find('body').append(directiveElmt);
                                    // attach popup outside click
                                    prepareOutsidePopupEventCloseTrigger(directiveElmt);
                                }
                                /**
                                    Remove the popup element and its related scope. Question: which one should be removed first
                                */
                                function removePopup() {
                                    // detach the popup outside click close event, if there is time compete time for unregister body even, we can use another unregister function
                                    unregisterOutsidePopupEventCloseTrigger(directiveElmt);
                                    // detach some event
                                    unregisterOnWindowResize(iElement);
                                    unregisterScroll(iElement);
                                    // destroy the scope
                                    if (directiveElmtScope) {
                                        directiveElmtScope.contextScope = null; // Just clean this big object to make sure directiveElmtScope can be garbage collected.
                                        directiveElmtScope.zindex = null;
                                        directiveElmtScope.hostAttrs = null;

                                        directiveElmtScope.$destroy();
                                        directiveElmtScope = null;
                                    }
                                    // destroy the element
                                    if (directiveElmt) {
                                        directiveElmt.remove();
                                        directiveElmt = null;
                                    }
                                }
                                // End of Create and remove ui component

                                //////////////////////////////////////////////////////////////
                                // Position setup 
                                //////////////////////////////////////////////////////////////
                                function positionCss(x, y) {
                                    return {
                                        left: x + 'px',
                                        top: y + 'px'
                                    };
                                }

                                function parseStrValue(str) {
                                    var p = /^\s*((\-|\+)?(\d+|(\d*(\.\d*)))?)([^\d]*)$/;
                                    return Number(p.exec(str)[1]);
                                }

                                function placeBelow(hostElmtTop) {
                                    var screenHeight = $($window).height();
                                    var screenScrollTop = $($window).scrollTop();
                                    var hostElmtScreenTop = hostElmtTop - screenScrollTop;
                                    if (hostElmtScreenTop < screenHeight / 2) {
                                        return true; // place below
                                    } else {
                                        return false; // place above
                                    }
                                }

                                /**
                                    Calculate the popup position
                                */
                                function positionPopup(hostElmt, popupElmt) {
                                    var extra = 0;

                                    var hostElmtOffset = hostElmt.offset();
                                    var hostElmtHeight = hostElmt.height();
                                    // var screenHeight = $($window).height();
                                    var x = 0;
                                    var y = 0;
                                    // if (hostElmtOffset.top < screenHeight / 2) { // position below
                                    if (placeBelow(hostElmtOffset.top)) {
                                        // var marginTop = parseStrValue(hostElmt.css('margin-top'));
                                        // var marginBottom = parseStrValue(hostElmt.css('margin-bottom'));
                                        var paddingTop = parseStrValue(hostElmt.css('padding-top'));
                                        var paddingBottom = parseStrValue(hostElmt.css('padding-bottom'));
                                        x = hostElmtOffset.left + extra;
                                        y = hostElmtOffset.top + /*marginTop +*/ paddingTop + hostElmtHeight + paddingBottom /*+ marginBottom*/ ;
                                        popupElmt.css(positionCss(x, y));
                                    } else { // position above
                                        var popupHeight = popupElmt.height();
                                        x = hostElmtOffset.left + extra;
                                        y = hostElmtOffset.top - popupHeight;
                                        popupElmt.css(positionCss(x, y));
                                    }
                                }
                                // End of position setup

                                //////////////////////////////////////////////////////////////////
                                // Handle the host Element position change
                                //////////////////////////////////////////////////////////////////
                                popupManagerScope.$on('ppmPopup.Manager.HostElmt.PositionChanged', onHostElmtPositionChanged);
                                // this is emit by the sub element
                                popupManagerScope.$on('ppmPopup.Manager.SubElement.SizeReset', onHostElmtPositionChanged);

                                function onHostElmtPositionChanged() {
                                    if (popupManagerScope.isOpen) {
                                        positionPopup(iElement, directiveElmt);
                                        var visible = isHostElmtVisiable(iElement);
                                        // $log.log('this element is visible: ' + visible);
                                        if (!visible) { // simplify if host element is not visible, just destroy the popup element
                                            scope.$apply(function() {
                                                hidePopup();
                                            });
                                        }
                                    }
                                }

                                function isHostElmtVisiable(hostElmt) {
                                    var scrollElmtList = getScrollElements(hostElmt);
                                    if (scrollElmtList.length === 0) { // this is no scroll element
                                        return true;
                                    }

                                    var scrollElmtViewRects = getViewRectList(scrollElmtList);
                                    var hostViewRect = getViewRect(hostElmt);

                                    return isHostElmtVisibleInViewPort(hostViewRect, scrollElmtViewRects);
                                }

                                function isHostElmtVisibleInViewPort(hostRect, scrollViews) {
                                    var isVisible = true;
                                    for (var i = 0; i < scrollViews.length; ++i) {
                                        isVisible = isVisible && isHostRecInView(hostRect, scrollViews[i]);
                                        if (!isVisible) {
                                            break;
                                        }
                                    }

                                    return isVisible;
                                }

                                function isHostRecInView(host, view) {
                                    var isNotVisible = false;
                                    isNotVisible = isNotVisible || host.bottom < view.top; // above the view
                                    isNotVisible = isNotVisible || host.top > view.bottom; // bellow the view
                                    isNotVisible = isNotVisible || host.right < view.left; // far from left of view
                                    isNotVisible = isNotVisible || host.left > view.right; // far from right of view

                                    return !isNotVisible;
                                }

                                function getViewRectList(elemList) {
                                    var rectList = [];
                                    angular.forEach(elemList, function(elmt) {
                                        rectList.push(getViewRect(elmt));
                                    });

                                    return rectList;
                                }

                                function getViewRect(elem) {
                                    var elemOffset = elem.offset();
                                    return {
                                        top: elemOffset.top,
                                        left: elemOffset.left,
                                        right: elemOffset.left + elem.width(),
                                        bottom: elemOffset.top + elem.height()
                                    };
                                }
                                // End of Handle the host element position changed

                                ///////////////////////////////////////////////////////////
                                // When window resize
                                ///////////////////////////////////////////////////////////
                                function onWindowResize( /*event*/ ) {
                                    // When window size changed, it will notify sub-element to let sub-element adjust its size.
                                    // After sub-element resize, it will notify another event to let Manager to reposition.
                                    $timeout(function() { // fired in next cycle so that the viewport size has been successfully changed
                                        // $log.log('Broadcast ppmPopup.Manager.SizeChanged');
                                        popupManagerScope.$broadcast('ppmPopup.Manager.SizeChanged');
                                    });
                                }

                                function registerOnWindowResize( /*hostElmt*/ ) {
                                    $($window).on('resize', onWindowResize);
                                }

                                function unregisterOnWindowResize( /*hostElmt*/ ) {
                                    $($window).off('resize', onWindowResize);
                                }
                                // End of when window resize

                                ////////////////////////////////////////////////////
                                //  When Scroll
                                ////////////////////////////////////////////////////
                                function findAncestors(elmt) {
                                    // if (elmt.parent().length === 0) {
                                    if (elmt[0].tagName.toLowerCase() === 'html') {
                                        return elmt;
                                    }
                                    return [elmt].concat(findAncestors(elmt.parent()));
                                }

                                // element is DOM element
                                function isScrollable(element) {
                                    var verticallyScrollable, horizontallyScrollable;
                                    if ($(element).css('overflow') === 'scroll' || $(element).css('overflowX') === 'scroll' || $(element).css('overflowY') === 'scroll') {
                                        return true;
                                    }

                                    verticallyScrollable = (element.clientHeight < element.scrollHeight) && ($.inArray($(element).css('overflowY'), ['scroll', 'auto']) !== -1 || $.inArray($(element).css('overflow'), ['scroll', 'auto']) !== -1);
                                    if (verticallyScrollable) {
                                        return true;
                                    }

                                    horizontallyScrollable = (element.clientWidth < element.scrollWidth) && ($.inArray($(element).css('overflowX'), ['scroll', 'auto']) !== -1 || $.inArray($(element).css('overflow'), ['scroll', 'auto']) !== -1);
                                    return horizontallyScrollable;
                                }

                                function getScrollElements(hostElmt) {
                                    var scrollableElmts = [];

                                    var ancestorList = findAncestors(hostElmt.parent()); // SLQ do we need add window into the list
                                    angular.forEach(ancestorList, function(ancestor) {
                                        if (isScrollable(ancestor[0])) { // use DOM element
                                            scrollableElmts.push(ancestor);
                                        }
                                    });

                                    return scrollableElmts;
                                }

                                function onElementScroll(event) {
                                    event.preventDefault(); // SLQ do we need this
                                    event.stopPropagation();
                                    popupManagerScope.$broadcast('ppmPopup.Manager.HostElmt.PositionChanged', {});
                                }

                                function registerScroll(hostElmt) {
                                    var scrollElmtList = getScrollElements(hostElmt);
                                    angular.forEach(scrollElmtList, function(elmt) {
                                        elmt.on('scroll', onElementScroll);
                                    });
                                }

                                function unregisterScroll(hostElmt) {
                                    var scrollElmtList = getScrollElements(hostElmt);
                                    angular.forEach(scrollElmtList, function(elmt) {
                                        elmt.off('scroll', onElementScroll);
                                    });
                                }
                                // End of when scroll

                                /**
                                    Show popup, should be called in scope.$apply
                                */
                                function showPopup() {
                                    // Not necessary, even mouseover only trigger one time when from out to over
                                    // if (popupManagerScope.isOpen) {
                                    //     return;
                                    // }

                                    popupManagerScope.isOpen = true;
                                    createPopup();
                                    positionPopup(iElement, directiveElmt);
                                    // show the widget until sub element say its is ready
                                    popupManagerScope.$on('ppmPopup.Manager.SubElement.Ready', function() {
                                        if (!directiveElmtScope.hasVisibleContent || directiveElmtScope.hasVisibleContent()) { // hasVisibleContent is a function and used to define if the popup has right content
                                            directiveElmt.show();
                                        }
                                    });
                                }
                                /**
                                    Hide popup by remove it, should be called in scope.$apply
                                */
                                function hidePopup() {
                                    directiveElmt.hide();
                                    removePopup();
                                    popupManagerScope.isOpen = false;
                                }
                                /**
                                    Toggle popup show/hide, should be called in scope.$apply
                                */
                                function togglePopup() {
                                    if (popupManagerScope.isOpen) {
                                        hidePopup();
                                    } else {
                                        showPopup();
                                    }
                                }

                                prepareTrigger(iElement, directiveElmt);

                                /**
                                    Clean up
                                */
                                scope.$on('$destroy', function onDestroyPopupManager( /*event*/ ) {
                                    // $log.log('>>>>> scope $destroy');
                                    unregisterTrigger(iElement, directiveElmt);
                                    // removePopup(); // remove the popup if it still display
                                    if (popupManagerScope.isOpen) {
                                        hidePopup();
                                    }
                                    popupManagerScope = null;
                                });

                                // popupManagerScope.$on('$destroy', function onDestroyPopupManager( /*event*/ ) {
                                //     $log.log('>>>>> popupManagerScope $destroy');
                                // });

                                /**
                                 * Observe the relevant attributes.
                                 */
                                // This is equivlent to the one in create function
                                // iAttrs.$observe(directiveType, function(val) {
                                //     popupManagerScope.content = val;

                                //     //if (!val && ttScope.isOpen) {
                                //     //    hide();
                                //     //}
                                // });

                                /////////////////////////////////////////////////////////////////////////////////////
                                // Manager Scope Function
                                /////////////////////////////////////////////////////////////////////////////////////
                                popupManagerScope.getFirstScrollElmtViewPort = function() {
                                    var scrollElmtList = getScrollElements(iElement);
                                    if (scrollElmtList.length > 0) {
                                        return getViewRect(scrollElmtList[0]);
                                    }

                                    return null;
                                };

                                popupManagerScope.getHostElmtViewPort = function() {
                                    return getViewRect(iElement);
                                };

                                popupManagerScope.closePopup = function(event) {
                                    event.preventDefault();
                                    event.stopPropagation(); // necessary
                                    hidePopup();
                                };

                            } /* end of post link function */
                        }; /* end of linkFnObj */

                        return linkFnObj;
                    }
                };

                return popupManagerDirectiveDefinitionObj;
            }; // directive function
        }; // end of popupManagerFactory
    }); // end of popupManagerProvider

/////////////////////////////////////////////////////////////////////////////
// PPM Long Name Tool Tip
/////////////////////////////////////////////////////////////////////////////
angular.module('p2AdvanceApp')
    .directive('ppmLongNameTooltipPopup', function($window, $timeout, $log) {
        return {
            restrict: 'A',
            templateUrl: 'views/product-plan-management/template/directives/ppm-tool-tip-long-name.html',
            // controller: function($scope, $element, $attrs, $transclude, $timeout, $log) {
            // },
            link: function(scope, iElement /*, iAttrs*/ ) {
                // $log.log('>>>>> ppmLongNameTooltipPopup link function 1');
                var domElmt = iElement.find('.ppm-tool-tip-long-name');

                function setupSize() {
                    // $log.log('>>>>> resize in ppmLongNameTooltipPopup');
                    var rightMargin = 30;
                    var width = 100;
                    var containerView = scope.getFirstScrollElmtViewPort();
                    var hostView = scope.getHostElmtViewPort();
                    if (containerView && hostView) {
                        width = containerView.right - hostView.left - rightMargin;
                    }

                    // $log.log('>>>>> resize in ppmLongNameTooltipPopup width = ' + width);
                    domElmt.css({
                        'max-width': width + 'px'
                    });

                    // force the manager to reposition 
                    $timeout(function() {
                        scope.$emit('ppmPopup.Manager.SubElement.SizeReset', {});
                    });
                    // not work
                    // scope.$evalAsync(function() {
                    //     scope.$emit('ppmPopup.Manager.SubElement.SizeReset', {});
                    // });
                    // still a little early
                    // $(document).ready(function() { 
                    //     $log.log('sub element is ready');
                    //     scope.$emit('ppmPopup.Manager.SubElement.SizeReset', {});
                    // });
                }

                // scope.$on('ppmToolTipSizeChanged', setupSize);
                scope.$on('ppmPopup.Manager.SizeChanged', setupSize);

                // iElement.on('$destroy', function() {
                //     $log.log('element.distory');
                // });

                // init
                setupSize();
                // notify manager to show the widget
                $timeout(function() {
                    $log.log('sub element is ready for displaying');
                    scope.$emit('ppmPopup.Manager.SubElement.Ready', {});
                });
            }
        };
    });

angular.module('p2AdvanceApp')
    .directive('ppmLongNameTooltip', function(popupManager) {
        // setup some configure here
        return popupManager('ppmLongNameTooltip', 'ppmLongNameTooltip', 'click', {});
    });

///////////////////////////////////////////////////////////////////////////////////////
// PPM Popup Menu
///////////////////////////////////////////////////////////////////////////////////////
angular.module('p2AdvanceApp')
    .directive('ppmHoverMenuPopup', function($window, $timeout, $parse, $log) {
        return {
            restrict: 'A',
            templateUrl: 'views/product-plan-management/template/directives/ppm-hover-menu.html',
            controller: function($scope, $element, $attrs, $transclude, $timeout, $log) { /* jshint ignore:line*/
                (function init() {
                    // Configurable popup menu context path, such as 'row.entity', it is should be configured popup manager directive
                    // and the value should be read from 
                    // the scope that this popup menu located, not in popup manager element or popup diretive element
                    var contextPath = $scope.hostAttrs['ppmHoverMenuContextPath'];
                    if (!contextPath) {
                        contextPath = 'row.entity';
                        $log.error('Now ppm-hover-menu required set another attribute "ppm-hover-menu-context-path" to setup the context path!');
                    }
                    $scope.context = $parse(contextPath)($scope.contextScope); // context property is used in the html template
                    $scope.items = $parse($scope.content)($scope.contextScope);
                })();

                // if menuItem.isEnabled is not defined, the menu item will be enabled.
                // if the "action" function is not set, the menu item will be disabled.
                $scope.getEnabledStyle = function(menuItem) {
                    return menuItem.action && (menuItem.isEnabled === undefined || menuItem.isEnabled) ? '' : 'disabled';
                };

                $scope.showItem = function(menuItem, context) {
                    return menuItem.isShown === undefined || menuItem.isShown(context) ? true : false;
                };

                $scope.menuClicked = function(event, menuItem, context) {
                    // event.stopPropagation(); // so that it will not trigger the ppm tool tips; not necessary, because it is children of body.
                    if (menuItem.action) {
                        menuItem.action(context);
                    }
                };

                $scope.hasVisibleContent = function() {
                    return isContainVisibleItems();
                };

                function isContainVisibleItems() {
                    var items = $($element).find('ul.dropdown-menu li');
                    if (!items || items.length === 0) {
                        return false;
                    }

                    // in case all items is hidden by permission
                    var visible = false;
                    for (var i = 0; i < items.length; ++i) {
                        var item = $(items[i]);
                        if (item.css('display') !== 'none') {
                            visible = true;
                            break;
                        }
                    }

                    return visible;
                }

            },
            link: function(scope, iElement /*, iAttrs*/ ) {
                $log.log('>>>>>>>>>>> ppmHoverMenuPopup link function');
                var domElmt = iElement.find('.ppm-homver-menu');

                function setupSize() {
                    // $log.log('>>>>> resize in ppmLongNameTooltipPopup');
                    var rightMargin = 30;
                    var width = 100;
                    var containerView = scope.getFirstScrollElmtViewPort();
                    var hostView = scope.getHostElmtViewPort();
                    if (containerView && hostView) {
                        width = containerView.right - hostView.left - rightMargin;
                    }

                    // $log.log('>>>>> resize in ppmLongNameTooltipPopup width = ' + width);
                    domElmt.css({
                        'max-width': width + 'px'
                    });

                    // force the manager to reposition
                    $timeout(function() {
                        scope.$emit('ppmPopup.Manager.SubElement.SizeReset', {});
                    });
                }

                // scope.$on('ppmToolTipSizeChanged', setupSize);
                scope.$on('ppmPopup.Manager.SizeChanged', setupSize);

                // iElement.on('$destroy', function() {
                //     $log.log('element.distory');
                // });

                // init
                setupSize();
                // notify manager to show the widget
                $timeout(function() {
                    $log.log('sub element is ready for displaying');
                    scope.$emit('ppmPopup.Manager.SubElement.Ready', {});
                });
            }
        };
    });

angular.module('p2AdvanceApp')
    .directive('ppmHoverMenu', function(popupManager) {
        return popupManager('ppmHoverMenu', 'ppmHoverMenu', 'mouseover', {});
    });