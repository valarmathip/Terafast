'use strict';
angular.module('p2AdvanceApp')
    .directive('reportTableLayoutThree', function() {
        return {
            restrict: 'E',
            link: function(scope, element, attrs) {

                scope.$on('bindDataForLayout3', function() {
                    scope.reportPlanDetails = scope[attrs.reportData]; //plansToShow object
                    scope.allPlans = scope[attrs.planData]; // array of plan objects
                    scope.allPlansHeaders = scope[attrs.planHeaders]; // plans headers
                    scope.properties = scope[attrs.reportProperties]; // report properties
                    scope.planDetailsInfo = scope[attrs.allPlansDetails]; //plan and it's properties
                    // scope.allPlansHeaders = ['Preferred Network 1', 'Preferred Network 2', 'Preferred Network 3', 'In Network', 'Out of Network', 'Out of Area', 'Out of Country', 'Coverage']; // plans headers
                    initReportTable();
                });

                var html = '<div class="table-responsive"  style="max-height:2000px;"><table style="width:100%" class="table table-striped table-bordered table-hover table-condensed small"><tr><td width="350"></td><td width="230"></td>';
                var attrObj = {};

                scope.constructPlanNameRow = function() {
                    angular.forEach(scope.reportPlanDetails.plansToShow, function(plan) {
                        html += '<td class="report_plan"><b>' + plan.planName + '</b></td>';
                    });
                    html = html + '</tr>';
                };

                scope.constructPlanHeadersRow = function() {
                    html = html + '<td valign="top" class="report_td"><table  width="230" class="report">';
                    angular.forEach(scope.allPlansHeaders, function(value) {
                        html = html + '<tr><td>' + value + '</td></tr>';
                    });
                    html = html + '</table></td>';
                };

                scope.populateTierData = function(service, html, serviceNameClone, serviceName) {
                    var serviceNameCloneStr = serviceNameClone;
                    var serviceNameStr = null;
                    if (angular.isUndefined(serviceName)) {
                        serviceNameStr = '';
                    } else {
                        serviceNameStr = serviceName;
                    }
                    var doesCostShareExist = false;
                    var allKeys = [];

                    angular.forEach(service, function(serviceProperty, serviceNameKey) {
                        if ((serviceNameKey.lastIndexOf('_', 0)) === 0) {
                            doesCostShareExist = true;
                        }

                        var hasCostShareValue = false;
                        var csData;

                        if ((serviceNameKey.lastIndexOf('Cost Share Level ', 0)) === 0) {
                            doesCostShareExist = false;
                            makeAttrObjForCostShareLevels(allKeys, serviceProperty, hasCostShareValue, serviceNameStr, serviceNameKey);
                        } else if ((serviceNameKey.lastIndexOf('Cost Share Value', 0)) === 0) {

                            angular.forEach(scope.allPlans, function(plans) {

                                if (angular.isUndefined(csData)) {
                                    csData = '<td valign="top" class="report_td"><table style="width:100%" class="report">';
                                } else {
                                    csData = csData + '<td valign="top" class="report_td"><table style="width:100%" class="report">';
                                }
                                angular.forEach(scope.allPlansHeaders, function(head) {
                                    csData = fillCostShareValues(attrObj, plans, serviceNameKey, head, csData);
                                });
                                csData = csData + '</table></td>';
                            });
                            doesCostShareExist = false;
                        }


                        if (angular.isObject(serviceProperty) && doesPlanHeaderExist(serviceProperty, scope.allPlansHeaders) && !doesCostShareExist) {
                            html = setSectionHeader(serviceNameKey, html);

                            if (csData) {
                                html = html + scope.constructServicePlanHeadersRow(scope.allPlansHeaders) + csData + '</tr>';
                            }
                            serviceNameStr = serviceNameStr + '.' + serviceNameKey;
                            html = scope.populateTierData(serviceProperty, html, serviceNameCloneStr, serviceNameStr);
                            //console.log(serviceNameStr + '.' + serviceNameKey);
                            serviceNameStr = serviceNameStr.substr(0, serviceNameStr.lastIndexOf(serviceNameKey) - 1);
                        } else if (!doesCostShareExist) {
                            html = costShareNotExist(serviceNameKey, html, serviceNameStr);

                        }
                        html = html + '</tr>';


                    });
                    return html;
                };

                function setSectionHeader(serviceNameKey, html) {

                    if (serviceNameKey !== 'Properties' && serviceNameKey !== 'Plan Service Cost Shares') {
                        if (serviceNameKey === 'Cost Share Level Primary' || serviceNameKey === 'Cost Share Level Secondary' || serviceNameKey === 'Cost Share Level Tertiary') {
                            html = html + '<tr><td><b><i>&nbsp;' + serviceNameKey + '</i></b></td>';
                        } else {
                            html = html + '<tr><td><b><i>&nbsp;&nbsp;' + serviceNameKey + '</i></b></td>';
                        }
                    }
                    return html;
                }

                function costShareNotExist(serviceNameKey, html, serviceNameStr) {
                    html = html + '</tr><tr><td>&nbsp;&nbsp;&nbsp;&nbsp;' + serviceNameKey + '</td>';
                    html = html + scope.constructServicePlanHeadersRow(scope.allPlansHeaders);
                    angular.forEach(scope.allPlans, function(plans) {
                        html = html + '<td valign="top" class="report_td"><table  style="width:100%" class="report">';
                        angular.forEach(scope.allPlansHeaders, function(head) {
                            var planDetailsInfoKey = formPlanDetailsInfoKey(serviceNameStr, plans.planName, serviceNameKey, head);
                            var planDetailsInfoKeyHolder = [];
                            planDetailsInfoKeyHolder.push(planDetailsInfoKey);
                            var result = planDetailsInfoKeyHolder.map(getTierValue.bind(null, scope.planDetailsInfo));
                            var formattedResult = removeEnclosingBrackets(result);
                            html = html + '<tr><td><span>' + formattedResult + '<br/></span></td></tr>';
                        });
                        html = html + '</table></td>';
                    });
                    return html;
                }
                scope.constructServicePlanHeadersRow = function(planHeaders) {
                    var header = '<td valign="top" class="report_td"><table  width="230" class="report">';
                    angular.forEach(planHeaders, function(head) {
                        header = header + '<tr><td>' + head + '</td></tr>';
                    });
                    header = header + '</table></td>';
                    return header;
                };

                scope.populateReportProperties = function() {
                    angular.forEach(scope.properties, function(sectionProperty, sectionName) {
                        if (sectionName !== 'unAssociatedServices' && sectionName !== 'Plan Service') {
                            html = html + '<tr><td class="report_section"><b><i>' + sectionName + '</b></i></td><td></td></tr>';
                        }
                        if (sectionName !== scope.reportPlanDetails.infoToDisplayinUI.planServiceSection && sectionName !== 'unAssociatedServices') {
                            buildPlanDetailsInfoObject(sectionProperty, sectionName);
                        } else if (sectionName === scope.reportPlanDetails.infoToDisplayinUI.planServiceSection || sectionName === 'unAssociatedServices') {
                            angular.forEach(sectionProperty, function(serviceProperty, serviceName) {
                                html = html + '<tr><td><b><i>' + serviceName + '</b></i></td></tr>'; // serviceName= service1, serviceProperty= object
                                html = scope.populateTierData(serviceProperty, html, serviceName, serviceName);
                            });
                        }
                    });
                };

                function buildPlanDetailsInfoObject(sectionProperty, sectionName) {
                    angular.forEach(sectionProperty, function(tierPair, sectionSubProp) {
                        html = html + '<tr><td class="report_td" valign="top">&nbsp;&nbsp;' + sectionSubProp + '</td>';
                        var tierData;
                        var planList = scope.allPlans;
                        scope.constructPlanHeadersRow();
                        var planObj;

                        for (var plan = 0; plan < planList.length; plan++) {
                            html = html + '<td valign="top" class="report_td"><table style="width:100%" class="report">';
                            var planname = planList[plan];
                            var headers = scope.allPlansHeaders;
                            for (var head = 0; head < headers.length; head++) {
                                tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][headers[head]];
                                var formattedTierData = removeEnclosingBrackets(tierData);
                                if (angular.isDefined(tierData)) {
                                    html = html + '<tr><td valign="top"><span>' + formattedTierData + '<br/></span></td></tr>';
                                } else {
                                    html = html + '<tr><td valign="top"><span>' + '' + '<br/></span></td></tr>';
                                    planObj = planname.planName;
                                }
                            }
                            html = html + '</table></td>';
                        }

                    });
                    html = html + '</tr>';
                }

                function doesPlanHeaderExist(object, headers) {
                    var boo = true;
                    angular.forEach(headers, function(item) {
                        if (angular.isDefined(object[item])) {
                            boo = false;
                        }
                    });
                    return boo;
                }

                function formPlanDetailsInfoKey(serviceNameCloneStr, planName, serviceNameKey, head) {
                    return planName + '.' + scope.reportPlanDetails.infoToDisplayinUI.planServiceSection + '.' + serviceNameCloneStr + '.' + serviceNameKey + '.' + head;
                }

                function makeAttrObjForCostShareLevels(allKeys, serviceProperty, hasCostShareValue, serviceNameStr, serviceNameKey) {
                    allKeys = Object.keys(serviceProperty);
                    attrObj = {};
                    var reportObjKey = serviceNameStr.split('.');
                    angular.forEach(scope.allPlans, function(plan) {
                        attrObj[plan.planName] = {};
                    });
                    for (var costShareKey = 0; costShareKey < allKeys.length; costShareKey++) {
                        if ((allKeys[costShareKey].lastIndexOf('_', 0)) === 0 && !hasCostShareValue) {
                            assignAttrObjVal(reportObjKey, allKeys, costShareKey, serviceNameKey, attrObj);
                            //attrObj[allKeys[costShareKey]] = serviceProperty[allKeys[costShareKey]];
                        }
                    }
                }

                function getTierValue(planDetailsInfoObj, planDetailsInfoKey) {
                    return planDetailsInfoKey
                        .split('.')
                        .reduce(function(resultObj, resultKey) {
                            if (angular.isUndefined(resultObj[resultKey]) || resultObj[resultKey] === null) {
                                return '';
                            } else {
                                return resultObj[resultKey];
                            }
                        }, planDetailsInfoObj);
                }

                function removeEnclosingBrackets(tierData) {
                    if (angular.isDefined(tierData) && !(tierData instanceof Array) && (tierData.indexOf('[') === 0) && (tierData.lastIndexOf(']') === tierData.length - 1)) {
                        return tierData.substr(1, tierData.length - 2);
                    } else if (angular.isDefined(tierData) && tierData instanceof Array && (tierData[0].indexOf('[') === 0) && (tierData[0].lastIndexOf(']') === tierData[0].length - 1)) {
                        return tierData[0].substr(1, tierData[0].length - 2);
                    } else {
                        return tierData;
                    }
                }


                function assignAttrObjVal(reportObjKey, allKeys, costShareKey, serviceNameKey, attrObj) {
                    angular.forEach(scope.allPlans, function(plan) {
                        var tierValue = null;
                        if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]])) {
                            if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]])) {
                                if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][reportObjKey[2]])) {
                                    if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][reportObjKey[2]][serviceNameKey])) {
                                        if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][reportObjKey[2]][serviceNameKey][allKeys[costShareKey]])) {
                                            tierValue = scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][reportObjKey[2]][serviceNameKey][allKeys[costShareKey]];
                                        } else {
                                            tierValue = '';
                                        }
                                    } else {
                                        tierValue = '';
                                    }
                                } else {
                                    tierValue = '';
                                }

                            } else {
                                tierValue = '';
                            }
                        } else {
                            tierValue = '';
                        }

                        if (tierValue) {
                            attrObj[plan.planName][allKeys[costShareKey]] = tierValue;
                        } else {
                            attrObj[plan.planName][allKeys[costShareKey]] = '';
                        }
                    });
                }

                function fillCostShareValues(attrObj, plans, serviceNameKey, head, csData) {
                    var costShareValueObj = attrObj[plans.planName];
                    var count = findObjectLength(costShareValueObj);
                    if (count !== 0) {
                    angular.forEach(costShareValueObj, function(tierObj, costShareKey) {
                        var costShareValueKey = costShareKey.substr(1, costShareKey.length);
                        if (costShareValueKey === serviceNameKey && csData && tierObj[head]) {
                            csData = csData + '<tr><td>' + tierObj[head] + '</td></tr>';
                        } else if (costShareValueKey === serviceNameKey && !csData && tierObj[head]) {
                            csData = '<tr><td>' + tierObj[head] + '</td></tr>';
                        } else if (costShareValueKey === serviceNameKey && csData && !tierObj[head]) {
                            csData = csData + '<tr><td><span>' + '' + '<br/></span></td></tr>';
                        }
                    });
                    } else {
                        csData = csData + '<tr><td><span>' + '' + '<br/></span></td></tr>';
                    }
                    return csData;
                }

                function findObjectLength(object) {
                    var length = 0;
                    for (var key in object) {
                        if (object.hasOwnProperty(key)) {
                            ++length;
                        }
                    }
                    return length;
                }

                function initReportTable() {
                    scope.constructPlanNameRow();
                    //scope.constructSection();
                    ///scope.constructPlanHeadersRow();
                    scope.populateReportProperties();
                    html = html + '</table></div>';
                    element.replaceWith(html);
                }
            }
        };

    });