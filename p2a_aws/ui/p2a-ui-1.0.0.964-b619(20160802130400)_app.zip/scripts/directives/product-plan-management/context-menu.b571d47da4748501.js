'use strict';

/************************************************
 *    Context Menu
 ************************************************/
angular.module('p2AdvanceApp')
    .directive('ppmContextMenu', function($log) {
        return {
            restrict: 'A',
            transclude: true,
            templateUrl: 'views/product-plan-management/template/context-menu-container.html',
            //scope: {},
            link: function($scope, iElement, iAttrs) {
                $log.log('outer link function is called');
                var $title = iElement.find('span.ppm-context-menu-title');
                var $menu = iElement.find('ul.ppm_context_menu_box');
                var $menuParent = $menu.parent('[context-menu-item]');
                var options = $scope.$eval(iAttrs.ppmContextMenu);
                $scope.contextMenu = options;
                $title.on('mouseover', function(event) {
                    $scope.$apply(function() {
                        $log.log('mouseover' + new Date());
                        if ($menu.length === 0 || $menuParent.length === 0) {
                            $log.log('mouseover have to find the $menu again');
                            $menu = iElement.find('ul.ppm_context_menu_box');
                            $menuParent = $menu.parent('[context-menu-item]');
                            setupMenuEvent();
                        }
                        event.preventDefault();
                        event.stopPropagation();
                        $menu = $menu.detach();
                        $(document).find('body').append($menu);
                        var position = $title.position();
                        var offset = $title.offset();
                        var height = $title.height() - 3;
                        var x = offset.left + position.left;
                        var y = offset.top + position.top + height;
                        // x = 0;
                        // y = 15;
                        $menu.css({
                            display: 'block',
                            top: y + 'px',
                            left: x + 'px',
                            'z-index': '99999 !important'
                        });
                    });
                });

                function setupMenuEvent() {
                    $menu.on('mouseover', function(event) {
                        event.preventDefault();
                        event.stopPropagation();
                    });
                    $(document).find('body').on('mouseover', function() {
                        $menu.css({
                            display: 'none'
                        });
                        $menuParent.append($menu);
                    });
                    $menu.on('click', function(event) { // turn off the context menu, if mouse click on it.
                        $scope.$apply(function() {
                            event.preventDefault();
                            event.stopPropagation();
                            $log.log('menu item clicked');
                            var target = $(event.target);
                            var actionEle = target.parent('[ng-click]');
                            var action = actionEle.attr('ng-click');
                            $scope.$eval(action);

                            $menu.css({
                                display: 'none'
                            });
                            $menuParent.append($menu);
                        });
                    });
                }

                if ($menu.length > 0 && $menuParent.length > 0) {
                    setupMenuEvent();
                }

                iElement.on('$destroy', function() {
                    $log.log('element.distory');
                });

                $scope.$on('$destroy', function() {
                    $log.log('$scope.distory');
                    if ($menu) {
                        $menu.remove();
                    }
                });
            },
            controller: function() {

            }
        };
    })
    .directive('contextMenuItem', function($log) {
        return {
            require: '^ppmContextMenu',
            restrict: 'A',
            transclude: true,
            link: function($scope, iElement) {
                $log.log('menu item link function is called');

                iElement.on('$destroy', function() {
                    $log.log('element.distory');
                });

                $scope.$on('$destroy', function() {
                    $log.log('$scope.distory');
                });
            },
            templateUrl: 'views/product-plan-management/template/product-list-context-menu-item.html'
        };
    });
/** End of Context Menu  **/

/************************************************
 *    Line Text
 ************************************************/
angular.module('p2AdvanceApp')
    .directive('ppmLineText', function($log) {
        return {
            restrict: 'A',
            transclude: true,
            templateUrl: 'views/product-plan-management/template/directives/line-text.html',
            link: function(scope, iElement) {
                $log.log('directive line-text');
                iElement.ready(function() {
                    $log.log('dom fully loaded');
                    setup();
                });

                $(window).resize(function() {
                    setup();
                });

                function setup() {
                    var $container = iElement.find('div.ppm-line-text-container');
                    var $lineText = $container.find('div.ppm-line-text');
                    var $rightLine = $container.find('div.ppm-right-line');
                    var $leftLine = $container.find('div.ppm-left-line');
                    $lineText.find('*').each(function() {
                        $log.log($(this).css('display'));
                        if ($(this).css('display') === 'block') {
                            $(this).css('display', 'inline-block');
                        }
                    });
                    $rightLine.css({
                        width: 0 + 'px',
                        top: '0px'
                    });
                    $leftLine.css({
                        width: 0 + 'px',
                        top: '0px'
                    });
                    var width = $container.width();
                    var $textElement = $lineText.children().first();
                    var textWidth = $textElement.outerWidth();
                    var textHeight = $textElement.height();
                    var marginTopCss = $textElement.css('margin-top');
                    var textMarginTop = marginTopCss ? parseInt(marginTopCss.replace('px', ''), 10) : 0;
                    var paddingTopCss = $textElement.css('padding-top');
                    var textPaddingTop = paddingTopCss ? parseInt(paddingTopCss.replace('px', ''), 10) : 0;
                    var lineWidth = (width - textWidth) / 2;
                    var lineTop = textMarginTop + textPaddingTop + textHeight / 2;
                    $rightLine.css({
                        width: lineWidth + 'px',
                        top: lineTop + 'px'
                    });
                    $leftLine.css({
                        width: lineWidth + 'px',
                        top: lineTop + 'px'
                    });
                }
            }
        };
    });
/** End of Line Text  **/


/************************************************
 *      Checkbox Button Wrapper
 *
 * This is speciall created for the provider
 * tier name, which wrap the checkbox button
 ************************************************/
angular.module('p2AdvanceApp')
    .directive('ppmCheckboxBtnWrapper', function($log) {
        return {
            restrict: 'A',
            transclude: true,
            templateUrl: 'views/product-plan-management/template/directives/ppm-checkbox-btn-wrapper.html',
            scope: {
                btnNameLabel: '=',
                btnNameId: '=',
                btnNameChanged: '&',
                btnNameValid: '&'
            },
            controller: function($scope, $element, $attrs, $transclude, $timeout, $log) {
                $log.log('nameEditableButton controller function called');
                $scope.isEditMode = false;
                $scope.editFlag = false;
                $scope.enterBtnFlag = false;

                $scope.toggleStatus = function() {
                    if ($scope.editFlag === false) {
                        if (!$scope.isEditMode) {
                            var btnElement = $element.find('span.ppm-name-editable-button label.btn');
                            var width = btnElement.outerWidth();
                            var height = btnElement.outerHeight();
                            var txtElement = $element.find('span.ppm-name-editable-text input');
                            txtElement.css({
                                'width': width + 'px',
                                'height': height + 'px'
                            });
                            $timeout(function() {
                                txtElement.focus();
                            });
                        }
                        $scope.isEditMode = !$scope.isEditMode;
                    } else {
                        $scope.btnNameValid.apply();
                    }
                };

                $scope.exitEdit = function() {
                    if (!$scope.enterBtnFlag) {
                        // set view value of input by removing space
                        var txtElement = $element.find('span.ppm-name-editable-text input');
                        txtElement.val($scope.btnNameLabel);
                        // $scope.btnNameLabel is already trimed by AngularJs

                        if ($scope.btnNameValid) {
                            $timeout(function() {
                                if (!$scope.btnNameValid.apply()) { // if not valide, still in edit mode if the name is not valid
                                    $scope.isEditMode = true;
                                    $scope.editFlag = true;
                                    var txtElement = $element.find('span.ppm-name-editable-text input');
                                    txtElement.focus();
                                    return;
                                }
                            });
                        }

                        $scope.isEditMode = false;
                        $scope.editFlag = false;

                        if ($scope.btnNameChanged) {
                            $log.log('in directive $scope.btnNameChanged.apply()');
                            $scope.btnNameChanged.apply();
                        }
                    }

                    $scope.enterBtnFlag = false;
                };

                $scope.keyup = function(event) {
                    if (event.keyCode === 13) {
                        $scope.exitEdit();
                        $scope.enterBtnFlag = true;
                    }
                };
            },
            link: function( /*scope, iElement, iAttrs, controller*/ ) {
                $log.log('nameEditableButton link function called');
            }
        };
    });
/** End of Checkbox Button Wrapper */

/*
 * This directive is for adjusting the ui-grid height according the screen size at runtime
 */
angular.module('p2AdvanceApp')
    .directive('ppmUiGridScroll', function($rootScope, $window, $interval, $timeout, $log) {
        return {
            restrict: 'A',
            priority: -300, // ui-grid min is -200
            require: 'uiGrid',
            link: function(scope, element /*, attrs, uiGridCtrl*/ ) {
                var scrollBarWidth = 17; // http://www.textfixer.com/tutorials/browser-scrollbar-width.php
                var borderWidth = 1;
                var extraValue = 1;

                // event Main.AdjustHeightAndPadding is fired after windows size changed
                // and after header/footer of ui-frame setup
                scope.$on('Main.AdjustHeightAndPadding', windowResizeOrUiGridRendered);

                // Only used by this directive to wait for the ui-grid rendering is done
                scope.$on('UiGrid.RenderingComplete', windowResizeOrUiGridRendered);

                function windowResizeOrUiGridRendered() {
                    adjustUiGridHeight();
                    // should be passive listener
                    $timeout(function() {
                        scope.$broadcast('ppm.root.grid.resized');
                    });
                }

                scope.$on('ppm.root.grid.resize.requested', adjustUiGridHeight);

                var stopInterval = $interval(function() {
                    $log.log('Waiting for gridApi initialized');
                    var gridApi = getGridApi();
                    if (gridApi) { // wait for gridApi is initialized
                        gridApi.core.on.rowsRendered(scope, function() { // renderingComplete: the DOM is not really setup
                            $timeout(function() {
                                $rootScope.$broadcast('UiGrid.RenderingComplete');
                                //$log.log('broadcase UiGrid.RenderingComplete');
                            }, 100);
                        });
                        // also raise a event
                        $timeout(function() {
                            $rootScope.$broadcast('UiGrid.RenderingComplete');
                            //$log.log('broadcase UiGrid.RenderingComplete after waiting done');
                        }, 200);
                        // cancel the timer
                        $interval.cancel(stopInterval);
                    }
                }, 100);

                function getGridApi() {
                    /*
                     scope.gridApi: used by plan list and product list
                     scope.grid.gridApi: used by service-list
                     */
                    var gridApi = scope.gridApi || scope.grid.gridApi;
                    //var myGrid = uiGridCtrl.grid;

                    return gridApi;
                }

                function adjustUiGridHeight() {
                    // var gridApi = getGridApi();
                    // $log.log('adjustUiGridHeight');
                    // var footerDivOffsetTop = angular.element('#footerDiv').offset().top;
                    var footerDivHeight = angular.element('#footerDiv').height();
                    var windowHeight = angular.element(window).height();
                    var uiGridOffsetTop = element.offset().top;
                    // var scrollGridHeight = element.find('.ui-grid-viewport')[0].scrollHeight;
                    var uiGridHeaderHeight = element.find('.ui-grid-header').height(); // 30px
                    var gridHeight = windowHeight - (uiGridOffsetTop + uiGridHeaderHeight) - footerDivHeight - scrollBarWidth;

                    if (gridHeight < 210) {
                        gridHeight = 210; // 2 rows + scroll
                    }

                    // we use the canvas height instead of calculating the height by rows height and number
                    // if (gridApi) { 
                    //     var rowHeight = gridApi.grid.options.rowHeight;
                    //     var rowNumber = gridApi.grid.rows.length;
                    //     var calculatedHeight = (rowNumber * rowHeight);

                    //     if (calculatedHeight > 0 && calculatedHeight < gridHeight) { // calculatedHeight === 0 means no data is loaded
                    //         gridHeight = calculatedHeight;
                    //     }
                    // }

                    var canvasHeight = element.find('.ui-grid-canvas').first().height();
                    $log.log('adjustUiGridHeight canvasHeight = ' + canvasHeight);
                    $log.log('adjustUiGridHeight gridHeight = ' + gridHeight);
                    if (canvasHeight > 0 && canvasHeight < gridHeight) {
                        gridHeight = canvasHeight;
                    }


                    // since we could have sub-grid, and here we only set the root level grid size
                    element.find('.ui-grid-viewport').first().css('height', gridHeight + scrollBarWidth + extraValue + 'px');
                    element.find('.ui-grid-render-container-body').first().css('height', gridHeight + scrollBarWidth + uiGridHeaderHeight + borderWidth + extraValue + 'px');
                    element.css('height', gridHeight + scrollBarWidth + uiGridHeaderHeight + borderWidth + extraValue + 'px');

                    // $('.ui-grid-viewport').css('height', ($('#footerDiv').offset().top - $('.ui-grid').offset().top - $('.ui-grid-header').height() + 'px'));
                    // $('.ui-grid-render-container-body').css('height', (($('#footerDiv').offset().top - $('.ui-grid').offset().top - $('.ui-grid-header').height() + 40) + 'px'));
                    // $('.ui-grid').css('height', (($('#footerDiv').offset().top - $('.ui-grid').offset().top - $('.ui-grid-header').height() + 40) + 'px'));
                }
            }
        };
    });
// End of ppmUiGridScroll

/**
 * Spinner Directive to show spin so that all the screen is disabled
 */
angular.module('p2AdvanceApp')
    .directive('ppmSpinner', function() {
        return function($scope, element /*, attrs*/ ) {
            $scope.$on('ppm.spinner.show', function() {
                return element.show();
            });

            return $scope.$on('ppm.spinner.hide', function() {
                return element.hide();
            });
        };
    });
/** End of ppmSpinner */

/**
 * ppmShow Directive to show/hide field based following 3 properties, one of then is false, 
 * the field will be hidden.
 *
 *   1. field.isHiddenByRole: Boolean, if it is false, the field will be hidden. If this value is
        not set/defined, it will treat as false, that mean this field is not hidden by role
 *   2. field.showHideExpression: jsonPath expression, will be evaluated again some json object,
        if it is evalued to false, the field will be hidden.
 *   3. field.show: Boolean, if it is false, the field will be hidden. if show value is not defined,
        it will be treated as true, that means the field will be shown.
 */
angular.module('p2AdvanceApp')
    .directive('ppmShow', function(jsonPath, $parse, $animate, $log) { /* jshint ignore:line */
        var isShowExpressionProp = 'showHideExpression';
        var isHiddenByRoleProp = 'isHiddenByRole';
        var showProp = 'show';

        return {
            restrict: 'A',
            link: function($scope, $element, $attr, ctrl, $transclude) { /* jshint ignore:line */
                // We suppose the current context is host element's scope
                var isHiddenByRolePath = $attr.ppmShow + '.' + isHiddenByRoleProp;
                var isShowPath = $attr.ppmShow + '.' + showProp;
                var isShowExpressionPath = $attr.ppmShow + '.' + isShowExpressionProp;

                // for debug
                // var fieldInfo = $parse($attr.ppmShow)($scope);
                // if (fieldInfo.displayName === 'Pharmacy Individual Max. Out of Pocket') {
                //     $log.log(fieldInfo.displayName);
                // }

                // If isHiddenByRole is true, the element will not display always
                var isHiddenByRole = Boolean($parse(isHiddenByRolePath)($scope));
                // if it is already hidden by role, just hide the DOM element
                if (isHiddenByRole) {
                    showFieldWatchAction(false); // hide the DOM element and do not create $watch
                    return;
                }

                // We suppose that metadata isShowExpressionProp jsonpath expression value does not change frequently, such as in run time
                var pathStr = $parse(isShowExpressionPath)($scope);
                // $log.log('jsonPathStr = ' + angular.toJson(pathStr, true));

                // xxxxx.show is evaluated in the controller
                function isFieldShow() {
                    var fieldShow = $parse(isShowPath)($scope);
                    fieldShow = angular.isDefined(fieldShow) ? fieldShow : true; // if fieldShow is not defined, we suppose this field should be displayed

                    return Boolean(fieldShow);
                }

                function isJsonPathEvaluatedShow() {
                    // if the pathStr is not defined, that means this element is not conditional show/hide element
                    // So no show/hide action is necessary, 
                    // we suppose that the field is shown, unless its shown value is false.
                    // if the pathStr is define, use pathStr to read the value, and watch changes
                    if (!pathStr) {
                        return true;
                    }
                    // suppose the transfer happened in the controller, that means controller has to transfer it back to the loaded format
                    var jsonObj = $parse($attr.ppmShowJsonObj)($scope);
                    pathStr = pathStr.replace(/'/g, '"'); // jsonpath cannot use single quota such as 'individual + 1 (Spouse)'

                    var parsedPathValue;
                    try {
                        parsedPathValue = jsonPath(jsonObj, pathStr);
                    } catch (e) { // any exception mean that required structure could not exist, at least in current load expansion level
                        parsedPathValue = false;
                    }
                    // $log.log(fieldInfo.displayName + '  parsedPathValue = ' + angular.toJson(Boolean(parsedPathValue), true));

                    return Boolean(parsedPathValue);
                }

                function showFieldWatch() {
                    // $log.log('>>>> do evaluation : ' + fieldInfo.displayName);
                    return !isHiddenByRole && isFieldShow() && isJsonPathEvaluatedShow();
                }

                function showFieldWatchAction(isShow) {
                    // $log.log('>>>> do action : ' + fieldInfo.displayName);
                    $animate[isShow ? 'removeClass' : 'addClass']($element, 'ng-hide');
                }

                $scope.$watch(showFieldWatch, function(newValue /*, oldValue*/ ) {
                    showFieldWatchAction(newValue);
                });
            }
        };
    });
/** End of ppmShow */