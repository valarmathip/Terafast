'use strict';
angular.module('p2AdvanceApp')
    .directive('reportTable', function() {
        return {
            restrict: 'E',
            link: function(scope, element, attrs) {

                scope.$on('bindData', function() {
                    scope.reportPlanDetails = scope[attrs.reportData]; //plansToShow object
                    scope.allPlans = scope[attrs.planData]; // array of plan objects
                    scope.allPlansHeaders = scope[attrs.planHeaders]; // plans headers
                    scope.properties = scope[attrs.reportProperties]; // report properties
                    scope.planDetailsInfo = scope[attrs.allPlansDetails]; //plan and it's properties
                    initReportTable();
                });

                //var html = '<div class="table-responsive"><table class="table table-striped table-bordered table-hover table-condensed small"><tr><th></th>';
                var stickyHeaderHtml = '';
                var stickySideBarHtml = '';
                var scrollContentHtml = '';
                var attrObj = {};

                scope.planNameWidth = '';
                scope.constructPlanNameRow = function() {
                    stickyHeaderHtml = '<div class="column-headers chrome-column-headers column-header-width-custom" id="clscroll-column-headers"><table border = "1" style="border-right: 1px solid black;"><tr>';
                    angular.forEach(scope.reportPlanDetails.plansToShow, function(plan) {
                        scope.planNameWidth = plan.planHeaders.length * 188 + 'px';
                        stickyHeaderHtml += '<th style="width:' + scope.planNameWidth + '" class="centered header-border plan-name-break plan-name-custom" colspan=' + plan.planHeaders.length + '>';
                        stickyHeaderHtml += '<div style="width:' + scope.planNameWidth + '">' + plan.planName + '</div></th>';
                    });
                    stickyHeaderHtml = stickyHeaderHtml + '</tr><tr>';
                };

                scope.constructPlanHeadersRow = function() {
                    angular.forEach(scope.allPlansHeaders, function(header) {
                        stickyHeaderHtml += '<th class="plan-tier-td-width-custom header-border"><div class="centered plan-tier-td-width-custom">' + header + '</div></th>';
                    });
                    stickyHeaderHtml = stickyHeaderHtml + '</tr></table></div>';
                };

                scope.populateTierData = function(service, stickySideBarHtml, scrollContentHtml, serviceNameClone, serviceName) {
                    var serviceNameCloneStr = serviceNameClone;
                    var serviceNameStr = null;
                    var sectionObject = {};
                    if (angular.isUndefined(serviceName)) {
                        serviceNameStr = '';
                    } else {
                        serviceNameStr = serviceName;
                    }

                    var doesCostShareExist = false;
                    var allKeys = [];

                    angular.forEach(service, function(serviceProperty, serviceNameKey) {
                        if ((serviceNameKey.lastIndexOf('_', 0)) === 0) {
                            doesCostShareExist = true;
                        }

                        var hasCostShareValue = false;
                        var csData;

                        if ((serviceNameKey.lastIndexOf('Cost Share Level ', 0)) === 0) {
                            doesCostShareExist = false;
                            makeAttrObjForCostShareLevels(allKeys, serviceProperty, hasCostShareValue, serviceNameStr, serviceNameKey);
                        } else if ((serviceNameKey.lastIndexOf('Cost Share Value', 0)) === 0) {
                            angular.forEach(scope.allPlans, function(plans) {
                                if (angular.isUndefined(csData)) {
                                    csData = '';
                                }
                                angular.forEach(plans.planHeaders, function(head) {
                                    csData = fillCostShareValues(attrObj, plans, serviceNameKey, head, csData);
                                });
                            });
                            doesCostShareExist = false;
                        }

                        if (angular.isObject(serviceProperty) && doesPlanHeaderExist(serviceProperty, scope.allPlansHeaders) && !doesCostShareExist) {
                            stickySideBarHtml = stickySideBarHtml + '<tr><td class="no-wrap corner-header-head" title="' + serviceNameKey + '">&emsp;&emsp;&emsp;<b><i>' + serviceNameKey + '</i></b></td></tr>';
                            if (serviceNameKey.search('Value') === -1) {
                                scrollContentHtml += '<tr class="no-wrap">';
                                angular.forEach(scope.allPlans, function(plan) {
                                    scrollContentHtml += '<td class=" corner-header-head border-for-plans plan-tier-td-width-custom no-wrap scrollcontent-td-height" colspan="' + plan.planHeaders.length + '">';
                                    scrollContentHtml += '<div class = "text-overflow plan-tier-td-width-custom scrollcontent-div-height"></div></td>';
                                });
                                scrollContentHtml += '</tr>';
                            }

                            if (csData) {
                                scrollContentHtml = '<tr>' + scrollContentHtml + csData + '</tr>';
                            }

                            serviceNameCloneStr = serviceNameCloneStr + '.' + serviceNameKey;
                            serviceNameStr = serviceNameStr + '.' + serviceNameKey;

                            sectionObject['scrollContentHtml'] = scrollContentHtml;
                            sectionObject['stickySideBarHtml'] = stickySideBarHtml;
                            sectionObject = scope.populateTierData(serviceProperty, stickySideBarHtml, scrollContentHtml, serviceNameCloneStr, serviceNameStr);
                            scrollContentHtml = sectionObject.scrollContentHtml;
                            stickySideBarHtml = sectionObject.stickySideBarHtml;

                            serviceNameStr = serviceNameStr.substr(0, serviceNameStr.lastIndexOf(serviceNameKey) - 1);

                        } else if (!doesCostShareExist) {

                            stickySideBarHtml = stickySideBarHtml + '</tr><tr><td class="no-wrap corner-header-head" title="' + serviceNameKey + '">&emsp;&emsp;&emsp;&emsp;' + serviceNameKey + '</td>';
                            angular.forEach(scope.allPlans, function(plans) {
                                angular.forEach(plans.planHeaders, function(head) {
                                    var planDetailsInfoKey = formPlanDetailsInfoKey(serviceNameStr, plans.planName, serviceNameKey, head);
                                    var planDetailsInfoKeyHolder = [];
                                    planDetailsInfoKeyHolder.push(planDetailsInfoKey);
                                    var result = planDetailsInfoKeyHolder.map(getTierValue.bind(null, scope.planDetailsInfo));
                                    var formattedResult = removeEnclosingBrackets(result);

                                    if (head === plans.planHeaders[0]) {
                                        scrollContentHtml += '<td class="border-for-plans corner-header-head no-wrap centered plan-tier-td-width-custom scrollcontent-td-height">';
                                        scrollContentHtml += '<div class="text-overflow plan-tier-td-width-custom scrollcontent-div-height" title="' + formattedResult + '">' + formattedResult + '</div></td>';
                                    } else {
                                        scrollContentHtml += '<td class="corner-header-head no-wrap centered plan-tier-td-width-custom scrollcontent-td-height">';
                                        scrollContentHtml += '<div class="text-overflow plan-tier-td-width-custom scrollcontent-div-height" title="' + formattedResult + '">' + formattedResult + '</div></td>';
                                    }
                                });
                            });
                        }
                        scrollContentHtml = scrollContentHtml + '</tr>';
                        sectionObject['scrollContentHtml'] = scrollContentHtml;
                        sectionObject['stickySideBarHtml'] = stickySideBarHtml;

                    });
                    return sectionObject;
                };

                scope.populateReportProperties = function() {
                    stickySideBarHtml = '<div id="row-headers-main"><div id="row-headers-submain"><div id="clscroll-row-headers"><div class="row-headers-custom"><table border = "1" class="plan-table">';
                    scrollContentHtml = '<div class="table-content-new" id="clscroll-content"><table border = "1" class="plan-table">';
                    angular.forEach(scope.properties, function(sectionProperty, sectionName) {
                        if (sectionName !== 'unAssociatedServices') {
                            stickySideBarHtml += '<tr><td class="no-wrap corner-header-head"><div class="sticky-column-width-custom" title="' + sectionName + '"><b><i>' + sectionName + '</b></i></div></td></tr>';
                            scrollContentHtml += '<tr>';
                            angular.forEach(scope.allPlans, function(plans) {
                                scope.emptyCellContainerWidth = plans.planHeaders.length * 188 + 'px';
                                scrollContentHtml += '<td style="width:' + scope.emptyCellContainerWidth + '" class=" corner-header-head tier_invisible no-wrap border-for-plans plan-tier-td-width-custom scrollcontent-td-height"';
                                scrollContentHtml += 'colspan="' + plans.planHeaders.length + '">';
                                scrollContentHtml += '<div style="width:' + scope.emptyCellContainerWidth + '" class="text-overflow plan-tier-td-width-custom scrollcontent-div-height"></div></td>';
                            });
                            scrollContentHtml += '</tr>';
                        }
                        if (sectionName !== scope.reportPlanDetails.infoToDisplayinUI.planServiceSection && sectionName !== 'unAssociatedServices') {
                            buildPlanDetailsInfoObject(sectionProperty, sectionName);
                        } else if (sectionName === scope.reportPlanDetails.infoToDisplayinUI.planServiceSection || sectionName === 'unAssociatedServices') {
                            angular.forEach(sectionProperty, function(serviceProperty, serviceName) {
                                stickySideBarHtml += '<tr><td class="no-wrap corner-header-head">';
                                stickySideBarHtml += '<div class="sticky-column-width-custom" title="' + serviceName + '"><b>&emsp;&emsp;' + serviceName + '</b></div></td></tr>';
                                scrollContentHtml += '<tr class="no-wrap">';
                                angular.forEach(scope.allPlans, function(plan) {
                                    scope.emptyCellContainerWidth = plan.planHeaders.length * 188 + 'px';
                                    scrollContentHtml += '<td style="width:' + scope.emptyCellContainerWidth + '" class=" corner-header-head border-for-plans no-wrap scrollcontent-td-height" colspan="' + plan.planHeaders.length + '"></td>';
                                });
                                scrollContentHtml += '</tr>';
                                var sectionObject = scope.populateTierData(serviceProperty, stickySideBarHtml, scrollContentHtml, serviceName, serviceName);
                                scrollContentHtml = sectionObject.scrollContentHtml;
                                stickySideBarHtml = sectionObject.stickySideBarHtml;
                            });
                        }
                    });
                };


                function buildPlanDetailsInfoObject(sectionProperty, sectionName) {
                    angular.forEach(sectionProperty, function(tierPair, sectionSubProp) {
                        stickySideBarHtml += '<tr><td class="no-wrap corner-header-head"><div class="sticky-column-width" title="' + sectionSubProp + '">&emsp;&emsp;&emsp;&emsp;' + sectionSubProp + '</div></td></tr>';
                        var tierData;
                        var planList = scope.allPlans;
                        var planObj;
                        scrollContentHtml += '<tr>';
                        for (var plan = 0; plan < planList.length; plan++) {
                            var planname = planList[plan];
                            angular.forEach(planname.planHeaders, function(head) {
                                tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][head];
                                if (angular.isDefined(tierData)) {
                                    var formattedTierData = removeEnclosingBrackets(tierData);
                                    if (head === planname.planHeaders[0]) {
                                        scrollContentHtml += '<td class="plan-tier-td-width-custom corner-header-head no-wrap centered border-for-plans scrollcontent-td-height" >';
                                        scrollContentHtml += '<div class="plan-tier-td-width-custom text-overflow scrollcontent-div-height"  title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                    } else {
                                        scrollContentHtml += '<td class="plan-tier-td-width-custom corner-header-head no-wrap centered scrollcontent-td-height">';
                                        scrollContentHtml += '<div class="plan-tier-td-width-custom text-overflow scrollcontent-div-height"  title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                    }
                                } else {
                                    if (head === planname.planHeaders[0]) {
                                        scrollContentHtml += '<td class="plan-tier-td-width-custom corner-header-head no-wrap centered scrollcontent-td-height border-for-plans"';
                                        scrollContentHtml += '>' + '' + '</td>';
                                    } else {
                                        scrollContentHtml += '<td class="plan-tier-td-width-custom corner-header-head no-wrap centered scrollcontent-td-height"';
                                        scrollContentHtml += '>' + '' + '</td>';
                                    }
                                }
                            });
                            planObj = planname.planName;
                        }
                        displaySubSections(tierData, planObj, sectionName, sectionSubProp, planList);
                        scrollContentHtml = scrollContentHtml + '</tr>';
                    });
                }

                function displaySubSections(tierData, planObj, sectionName, sectionSubProp, planList) {
                    if (angular.isUndefined(tierData)) {
                        var subPropList = scope.planDetailsInfo[planObj][sectionName][sectionSubProp];
                        angular.forEach(subPropList, function(tier, subProp) {
                            stickySideBarHtml = stickySideBarHtml + '<tr><td class="no-wrap corner-header-head split-tier-colm" title="' + subProp + '"><div class="split-tier-colm"><i>' + subProp + '</i></div></td>';
                            scrollContentHtml = scrollContentHtml + '<tr>';
                            for (var plan = 0; plan < planList.length; plan++) {
                                var planname = planList[plan];

                                angular.forEach(planname.planHeaders, function(head) {
                                    tierData = scope.planDetailsInfo[planname.planName][sectionName][sectionSubProp][subProp][head];
                                    if (angular.isDefined(tierData)) {
                                        var formattedTierData = removeEnclosingBrackets(tierData);
                                        if (head === planname.planHeaders[0]) {
                                            scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans plan-tier-td-width-custom scrollcontent-td-height">';
                                            scrollContentHtml += '<div class="plan-tier-td-width-custom text-overflow scrollcontent-div-height" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                        } else {
                                            scrollContentHtml += '<td class="no-wrap corner-header-head centered plan-tier-td-width-custom scrollcontent-td-height">';
                                            scrollContentHtml += '<div class="plan-tier-td-width-custom text-overflow scrollcontent-div-height" title="' + formattedTierData + '">' + formattedTierData + '</div></td>';
                                        }
                                    } else {

                                        if (head === planname.planHeaders[0]) {
                                            scrollContentHtml += '<td class=" corner-header-head no-wrap centered border-for-plans scrollcontent-td-height"><div class="scrollcontent-div-height plan-tier-td-width-custom">' + '' + '<div></td>';
                                        } else {
                                            scrollContentHtml += '<td class="scrollcontent-td-height no-wrap corner-header-head centered"><div class="scrollcontent-div-height plan-tier-td-width-custom">' + '' + '<div></td>';
                                        }
                                    }
                                });

                            }
                            scrollContentHtml = scrollContentHtml + '</tr>';
                        });
                    }
                }

                function doesPlanHeaderExist(object, headers) {
                    var boo = true;
                    angular.forEach(headers, function(item) {
                        if (angular.isDefined(object[item])) {
                            boo = false;
                        }
                    });
                    return boo;
                }

                function formPlanDetailsInfoKey(serviceNameCloneStr, planName, serviceNameKey, head) {
                    return planName + '.' + scope.reportPlanDetails.infoToDisplayinUI.planServiceSection + '.' + serviceNameCloneStr + '.' + serviceNameKey + '.' + head;
                }

                function makeAttrObjForCostShareLevels(allKeys, serviceProperty, hasCostShareValue, serviceNameStr, serviceNameKey) {
                    allKeys = Object.keys(serviceProperty);
                    attrObj = {};
                    var reportObjKey = serviceNameStr.split('.');
                    angular.forEach(scope.allPlans, function(plan) {
                        attrObj[plan.planName] = {};
                    });
                    for (var costShareKey = 0; costShareKey < allKeys.length; costShareKey++) {
                        if ((allKeys[costShareKey].lastIndexOf('_', 0)) === 0 && !hasCostShareValue) {
                            assignAttrObjVal(reportObjKey, allKeys, costShareKey, serviceNameKey, attrObj);
                            //attrObj[allKeys[costShareKey]] = serviceProperty[allKeys[costShareKey]];
                        }
                    }
                }

                function getTierValue(planDetailsInfoObj, planDetailsInfoKey) {
                    return planDetailsInfoKey
                        .split('.')
                        .reduce(function(resultObj, resultKey) {
                            if (angular.isUndefined(resultObj[resultKey]) || resultObj[resultKey] === null) {
                                return '';
                            } else {
                                return resultObj[resultKey];
                            }
                        }, planDetailsInfoObj);
                }

                function removeEnclosingBrackets(tierData) {
                    if (angular.isDefined(tierData) && !(tierData instanceof Array) && (tierData.indexOf('[') === 0) && (tierData.lastIndexOf(']') === tierData.length - 1)) {
                        return tierData.substr(1, tierData.length - 2);
                    } else if (angular.isDefined(tierData) && tierData instanceof Array && (tierData[0].indexOf('[') === 0) && (tierData[0].lastIndexOf(']') === tierData[0].length - 1)) {
                        return tierData[0].substr(1, tierData[0].length - 2);
                    } else {
                        return tierData;
                    }
                }



                function assignAttrObjVal(reportObjKey, allKeys, costShareKey, serviceNameKey, attrObj) {
                    angular.forEach(scope.allPlans, function(plan) {
                        var tierValue = null;
                        if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]])) {
                            if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]])) {
                                if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][serviceNameKey])) {
                                    if (angular.isDefined(scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][serviceNameKey][allKeys[costShareKey]])) {
                                        tierValue = scope.planDetailsInfo[plan.planName][scope.reportPlanDetails.infoToDisplayinUI.planServiceSection][reportObjKey[0]][reportObjKey[1]][serviceNameKey][allKeys[costShareKey]];
                                    } else {
                                        tierValue = '';
                                    }
                                } else {
                                    tierValue = '';
                                }
                            } else {
                                tierValue = '';
                            }
                        } else {
                            tierValue = '';
                        }

                        if (tierValue) {
                            attrObj[plan.planName][allKeys[costShareKey]] = tierValue;
                        } else {
                            attrObj[plan.planName][allKeys[costShareKey]] = '';
                        }
                    });
                }

                function fillCostShareValues(attrObj, plans, serviceNameKey, head, csData) {
                    var costShareValueObj = attrObj[plans.planName];
                    var checkEmptyObj = Object.getOwnPropertyNames(costShareValueObj).length === 0;
                    if (checkEmptyObj === true) {
                        if (angular.isUndefined(csData)) {
                            if (head === plans.planHeaders[0]) {
                                csData = '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                            } else {
                                csData = '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                            }
                        } else {
                            if (head === plans.planHeaders[0]) {
                                csData = csData + '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                            } else {
                                csData = csData + '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                            }
                        }
                    } else if (!costShareValueObj.hasOwnProperty('_' + serviceNameKey) && !csData) {
                        if (head === plans.planHeaders[0]) {
                            csData = '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                        } else {
                            csData = '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                        }
                    } else if (!costShareValueObj.hasOwnProperty('_' + serviceNameKey) && csData) {
                        if (head === plans.planHeaders[0]) {
                            csData += '<td class="no-wrap corner-header-head border-for-plans">' + ' ' + '</td>';
                        } else {
                            csData += '<td class="no-wrap corner-header-head">' + ' ' + '</td>';
                        }
                    } else {
                        angular.forEach(costShareValueObj, function(tierObj, costShareKey) {
                            var costShareValueKey = costShareKey.substr(1, costShareKey.length);

                            if (costShareValueKey === serviceNameKey && csData && tierObj[head]) {
                                if (head === plans.planHeaders[0]) {
                                    csData = csData + '<td class="no-wrap centered corner-header-head border-for-plans text-overflow scrollcontent-td-height" title="' + tierObj[head] + '">' + tierObj[head] + '</td>';
                                } else {
                                    csData = csData + '<td class="no-wrap centered corner-header-head text-overflow scrollcontent-td-height" title="' + tierObj[head] + '">' + tierObj[head] + '</td>';
                                }
                            } else if (costShareValueKey === serviceNameKey && !csData && tierObj[head]) {
                                if (head === plans.planHeaders[0]) {
                                    csData = '<td class="no-wrap centered corner-header-head border-for-plans text-overflow scrollcontent-td-height" title="' + tierObj[head] + '">' + tierObj[head] + '</td>';
                                } else {
                                    csData = '<td class="no-wrap centered corner-header-head text-overflow scrollcontent-td-height" title="' + tierObj[head] + '">' + tierObj[head] + '</td>';
                                }
                            } else if (costShareValueKey === serviceNameKey && csData && !tierObj[head]) {
                                if (head === plans.planHeaders[0]) {
                                    csData = csData + '<td class="no-wrap corner-header-head border-for-plans scrollcontent-td-height">' + '' + '</td>';
                                } else {
                                    csData = csData + '<td class="no-wrap corner-header-head scrollcontent-td-height">' + '' + '</td>';
                                }
                            } else if (costShareValueKey === serviceNameKey && !csData && !tierObj[head]) {
                                csData = csData + '<td class="no-wrap corner-header-head scrollcontent-td-height">' + '' + '</td>';
                            }
                        });
                    }
                    return csData;
                }

                function initReportTable() {
                    scope.constructPlanNameRow();
                    scope.constructPlanHeadersRow();
                    scope.populateReportProperties();
                    var cornerHeaderHtml = '<div class="corner-header-custom"><table class="corner-header-table-custom"><tr> <th class="corner-header-head" id="setrowheight"></th></tr>';
                    cornerHeaderHtml += '<tr> <th class="corner-header-head corner-header-head-height">&nbsp;<br/></th></tr></table></div>';
                    stickySideBarHtml += '</table></div></div></div></div>';
                    scrollContentHtml += '</table></div>';
                    var html = '<div class="outer-wrapper">';
                    html += cornerHeaderHtml + stickyHeaderHtml + stickySideBarHtml + scrollContentHtml + '</div>';
                    element.context.innerHTML = html;
                    scope.$watch('$viewContentLoaded', function() {
                        scope.planNameRowHeight = angular.element('.column-headers').height() - 30 + 'px';
                        angular.element('#setrowheight').attr('height', scope.planNameRowHeight);
                    });
                    var thing = angular.element('#clscroll-content');
                    var extra = 100;
                    var old = angular.element(thing).scrollTop();
                    angular.element('#clscroll-content').scroll(function() {
                        if (angular.element(thing).scrollTop() < old) {
                            angular.element(thing).scrollTop(angular.element(thing).scrollTop() - extra);
                        } else if (angular.element(thing).scrollTop() > old) {
                            angular.element(thing).scrollTop(angular.element(thing).scrollTop() + extra);
                        }
                        old = angular.element(thing).scrollTop();
                        angular.element('#clscroll-row-headers').scrollTop($('#clscroll-content').scrollTop());
                        angular.element('#clscroll-column-headers').scrollLeft($('#clscroll-content').scrollLeft());
                    });

                    angular.element('#clscroll-column-headers').scroll(function() {
                        angular.element('#clscroll-content').scrollLeft($('#clscroll-column-headers').scrollLeft());
                    });

                    angular.element('#clscroll-row-headers').scroll(function() {
                        angular.element('#clscroll-content').scrollTop($('#clscroll-row-headers').scrollTop());
                    });
                }
            }
        };

    });