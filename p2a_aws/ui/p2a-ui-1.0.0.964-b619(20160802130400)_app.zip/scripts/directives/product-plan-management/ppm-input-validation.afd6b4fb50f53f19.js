'use strict';

//////////////////////////////////////////////////////////////////////////////////
//    ppm-start-date-input
//////////////////////////////////////////////////////////////////////////////////

/**
    This directive should used with AngularJs bootstrap ui datepicker
 */
angular.module('p2AdvanceApp')
    .directive('ppmEndDateInput', function($timeout, $filter, PpmInputValidationSvc, moment, $log) {
        var dateFormatter = 'MMM dd y';

        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 100,
            link: function(scope, iElement, iAttrs, ngModelCtrl) {
                if (iAttrs['datepickerPopup']) {
                    dateFormatter = iAttrs['datepickerPopup'];
                }

                if (!iAttrs['minDate']) {
                    throw new Error('Directive ppm-start-date-input require the attribute max-date attribute');
                }

                var oldValue;

                ngModelCtrl.$formatters.push(function(value) {
                    oldValue = value; // init old date value
                    return value;
                });

                var validationErrorMsg = PpmInputValidationSvc.ValidationErrorMsg(iElement);

                iElement.on('blur', function() {
                    $log.log('ppmEndDateInput ngModelCtrl.$viewValue = ' + ngModelCtrl.$viewValue);
                    $log.log('ppmEndDateInput ngModelCtrl.$modelValue = ' + ngModelCtrl.$modelValue);
                    var minDate = scope.$eval(iAttrs['minDate']);
                    $log.log('ppmEndDateInput minDate = ' + minDate);
                    if (!minDate) {
                        $log.error('Directive ppm-end-date-input: the min-date is not defined');
                        return;
                    }

                    if (iElement.val() && !ngModelCtrl.$modelValue) { // invalid date
                        var restoredValue = $filter('date')(oldValue, dateFormatter);
                        ngModelCtrl.$setViewValue(restoredValue);
                        iElement.val(restoredValue);
                        $log.log('Invalid date');
                        validationErrorMsg.drawErrorElement('Invalid Date! The value is restored to last correct value: ' + restoredValue);
                    } else if (iElement.val() && ngModelCtrl.$modelValue) { // valid date
                        if (minDate && moment(ngModelCtrl.$modelValue).isBefore(minDate)) { // invalid end date
                            var restoredValue2 = $filter('date')(oldValue, dateFormatter);
                            ngModelCtrl.$setViewValue(restoredValue2);
                            iElement.val(restoredValue2);
                            $log.log('End Date should be after Start Date');
                            validationErrorMsg.drawErrorElement('End Date should be after Start Date! The value is restored to last correct value: ' + restoredValue2);
                        } else { // valid end date
                            // format to correct format: July 11, 2016 --> Jul 11 2016
                            iElement.val($filter('date')(ngModelCtrl.$modelValue, dateFormatter));
                            oldValue = ngModelCtrl.$modelValue; // update old value
                            validationErrorMsg.removeErrorElement();
                        }
                    }
                });
            }
        };
    });



//////////////////////////////////////////////////////////////////////////////////
//    ppm-start-date-input
//////////////////////////////////////////////////////////////////////////////////

/**
     This directive should used with AngularJs bootstrap ui datepicker
 */
angular.module('p2AdvanceApp')
    .directive('ppmStartDateInput', function($timeout, $filter, PpmInputValidationSvc, moment, $log) {
        var dateFormatter = 'MMM dd y';

        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 100,
            link: function(scope, iElement, iAttrs, ngModelCtrl) {
                if (iAttrs['datepickerPopup']) {
                    dateFormatter = iAttrs['datepickerPopup'];
                }

                if (!iAttrs['maxDate']) {
                    throw new Error('Directive ppm-start-date-input require the attribute max-date attribute');
                }

                var oldValue;

                ngModelCtrl.$formatters.push(function(value) {
                    oldValue = value; // init old date value
                    return value;
                });

                var validationErrorMsg = PpmInputValidationSvc.ValidationErrorMsg(iElement);

                iElement.on('blur', function() {
                    $log.log('ppmStartDateInput ngModelCtrl.$viewValue = ' + ngModelCtrl.$viewValue);
                    $log.log('ppmStartDateInput ngModelCtrl.$modelValue = ' + ngModelCtrl.$modelValue);
                    var maxDate = scope.$eval(iAttrs['maxDate']);
                    $log.log('ppmStartDateInput maxDate = ' + maxDate);
                    if (!maxDate) {
                        $log.error('Directive ppm-start-date-input: the max-date is not defined');
                    }

                    if (iElement.val() && !ngModelCtrl.$modelValue) { // invalid date
                        var restoredValue = $filter('date')(oldValue, dateFormatter);
                        ngModelCtrl.$setViewValue(restoredValue);
                        iElement.val(restoredValue);
                        $log.log('Invalid date');
                        validationErrorMsg.drawErrorElement('Invalid Date! The value is restored to last correct value: ' + restoredValue);
                    } else if (iElement.val() && ngModelCtrl.$modelValue) { // valid date
                        if (maxDate && moment(ngModelCtrl.$modelValue).isAfter(maxDate)) { // invalid start date
                            var restoredValue2 = $filter('date')(oldValue, dateFormatter);
                            ngModelCtrl.$setViewValue(restoredValue2);
                            iElement.val(restoredValue2);
                            $log.log('Start Date should be before End Date');
                            validationErrorMsg.drawErrorElement('Start Date should be before End Date! The value is restored to last correct value: ' + restoredValue2);
                        } else { // valid start date
                            // format to correct format: July 11, 2016 --> Jul 11 2016
                            iElement.val($filter('date')(ngModelCtrl.$modelValue, dateFormatter));
                            oldValue = ngModelCtrl.$modelValue; // update old value
                            validationErrorMsg.removeErrorElement();
                        }
                    }
                });
            }
        };
    });


//////////////////////////////////////////////////////////////////////////////////
//    ppm-date-input
//////////////////////////////////////////////////////////////////////////////////

/**
    This directive should used with AngularJs bootstrap ui datepicker
 */
angular.module('p2AdvanceApp')
    .directive('ppmDateInput', function($timeout, $filter, PpmInputValidationSvc, $log) {
        var dateFormatter = 'MMM dd y';

        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 100,
            link: function(scope, iElement, iAttrs, ngModelCtrl) {
                if (iAttrs['datepickerPopup']) {
                    dateFormatter = iAttrs['datepickerPopup'];
                }

                var oldValue;

                ngModelCtrl.$formatters.push(function(value) {
                    oldValue = value; // init old date value
                    return value;
                });

                var validationErrorMsg = PpmInputValidationSvc.ValidationErrorMsg(iElement);

                iElement.on('blur', function() {
                    $log.log('ppmDateInput ngModelCtrl.$viewValue = ' + ngModelCtrl.$viewValue);
                    $log.log('ppmDateInput ngModelCtrl.$modelValue = ' + ngModelCtrl.$modelValue);
                    var renderValue = iElement.val();
                    if (renderValue && !ngModelCtrl.$modelValue) {
                        var restoredValue = $filter('date')(oldValue, dateFormatter);
                        ngModelCtrl.$setViewValue(restoredValue);
                        iElement.val(restoredValue);
                        $log.log('Invalid date');
                        validationErrorMsg.drawErrorElement('Invalid Date! The value is restored to last correct value: ' + restoredValue);
                    } else {
                        // format to correct format: July 11, 2016 --> Jul 11 2016
                        iElement.val($filter('date')(ngModelCtrl.$modelValue, dateFormatter));
                        oldValue = ngModelCtrl.$modelValue; // update old value
                        validationErrorMsg.removeErrorElement();
                    }
                });
            }
        };
    });

//////////////////////////////////////////////////////////////////////////////////
//    ppm-url-input
//////////////////////////////////////////////////////////////////////////////////
/**
    Event: 
        ppm.input.validation.error
 */
angular.module('p2AdvanceApp')
    .directive('ppmUrlInput', function($timeout, PpmInputValidationSvc, $log) {
        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 1,
            link: function(scope, iElement, iAttrs, ngModelCtrl) {
                // http://stackoverflow.com/questions/8188645/javascript-regex-to-match-a-url-in-a-field-of-text
                // var urlExp = new RegExp('(http|ftp|https)://[a-z0-9\-_]+(\.[a-z0-9\-_]+)+([a-z0-9\-\.,@\?^=%&;:/~\+#]*[a-z0-9\-@\?^=%&;/~\+#])?', 'i');
                // var urlExp = new RegExp('(http|ftp|https)://[\w-]+(\.[\w-]*)+([\w.,@?^=%&amp;:/~+#-]*[\w@?^=%&amp;/~+#-])?'); 
                // from AngularJS https://docs.angularjs.org/api/ng/input/input%5Burl%5D
                var urlExp = /^[a-z][a-z\d.+-]*:\/*(?:[^:@]+(?::[^@]+)?@)?(?:[^\s:/?#]+|\[[a-f\d:]+\])(?::\d+)?(?:\/[^?#]*)?(?:\?[^#]*)?(?:#.*)?$/i;
                var validationErrorMsg = PpmInputValidationSvc.ValidationErrorMsg(iElement);

                var listener = function(event) {
                    var url = iElement.val();
                    var startWithProtocol = isStartWithProtocol(url);
                    if (!startWithProtocol) {
                        url = 'http://' + url;
                    }
                    ngModelCtrl.$setViewValue(url.trim());


                    var element, start, end;
                    // remomber the cursor position
                    if (event && event.type === 'keydown') {
                        var oldText = iElement.val();
                        element = iElement[0];
                        start = element.selectionStart;
                        end = element.selectionEnd;
                        var diff = oldText.length - url.length;
                        if (diff) {
                            start -= diff;
                            end -= diff;
                        }
                    }

                    iElement.val(url);
                    // restore cursor position
                    if (event && event.type === 'keydown') {
                        element.selectionStart = start;
                        element.selectionEnd = end;
                    }
                };

                // This runs when the model gets updated on the scope directly and keeps our view in sync
                ngModelCtrl.$render = function() {
                    iElement.val(ngModelCtrl.$viewValue);
                };

                iElement.on('change', listener);
                iElement.on('keydown', function(event) {
                    if (PpmInputValidationSvc.skipKeyStroke(event)) {
                        return;
                    }
                    $timeout(function() { // Have to do this or changes don't get picked up properly
                        listener(event);
                    });
                });

                iElement.on('paste cut', function() {
                    $timeout(listener);
                });

                iElement.on('blur', function() {
                    $timeout(function() {
                        listener();
                        iElement.val(ngModelCtrl.$viewValue); // remove the spaces
                        if (ngModelCtrl.$viewValue && !urlExp.test(ngModelCtrl.$viewValue)) {
                            $log.log('invalid url');
                            validationErrorMsg.drawErrorElement('Invalid URL');
                            scope.$emit('ppm.input.validation.error', {
                                hasError: true,
                                id: iAttrs['id']
                            });
                        } else {
                            validationErrorMsg.removeErrorElement();
                            scope.$emit('ppm.input.validation.error', {
                                hasError: false,
                                id: iAttrs['id']
                            });
                        }
                    });
                });

                function isStartWithProtocol(url) {
                    return checkIfStartWithProtocal(url, 'http://') || checkIfStartWithProtocal(url, 'https://'); // || urlExp.test(url);
                }

                function checkIfStartWithProtocal(url, procotol) {
                    var length = url.length > procotol.length ? procotol.length : url.length;
                    return procotol.substring(0, length) === url.substring(0, length);
                }
            }
        };
    });


/************************************************
 *    ppm-pnone-input
 ************************************************/
angular.module('p2AdvanceApp')
    .directive('ppmPhoneInput', function($filter, $timeout, PpmInputValidationSvc) {
        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 1, // if not set, first display is not firmatted
            link: function(scope, iElement, iAttrs, ngModelCtrl) {
                /* jshint_NOT_SET unused:false */
                var validationErrorMsg = PpmInputValidationSvc.ValidationErrorMsg(iElement);
                var phoneRegex = /[^0-9A-Za-z]/g;

                /*jshint maxcomplexity:50 */
                var listener = function(event) {
                    var element, start, end;
                    // remomber the cursor position
                    if (event && event.type === 'keydown') {
                        var keyCode = event.keyCode || event.which;

                        element = iElement[0];
                        start = element.selectionStart;
                        end = element.selectionEnd;

                        if (keyCode === 8) { // backspace
                            switch (start) {
                                case 5:
                                    --start;
                                    --end;
                                    break;
                            }
                        } else if (keyCode === 46 || keyCode === 110) { // delete
                            switch (start) {
                                case 0:
                                case 5:
                                case 9:
                                    ++start;
                                    ++end;
                                    break;
                                case 4:
                                    start += 2;
                                    end += 2;
                                    break;
                            }
                        } else {
                            switch (start) {
                                case 1:
                                case 10:
                                    ++start;
                                    ++end;
                                    break;
                                case 5:
                                    start += 2;
                                    end += 2;
                                    break;
                            }
                        }
                    }
                    // Render to UI
                    var value = iElement.val().replace(phoneRegex, '');
                    iElement.val($filter('ppmTel')(value, false));
                    // restore cursor position
                    if (event && event.type === 'keydown') {
                        element.selectionStart = start;
                        element.selectionEnd = end;
                    }
                };

                // This runs when we update the text field
                ngModelCtrl.$parsers.push(function(viewValue) {
                    return viewValue.replace(phoneRegex, '').slice(0, 10);
                });

                // This runs when the model gets updated on the scope directly and keeps our view in sync
                ngModelCtrl.$render = function() {
                    iElement.val($filter('ppmTel')(ngModelCtrl.$viewValue, false));
                };

                iElement.on('change', listener);

                iElement.on('keydown', function(event) {
                    if (PpmInputValidationSvc.skipKeyStroke(event)) {
                        return;
                    }
                    $timeout(function() { // Have to do this or changes don't get picked up properly
                        listener(event);
                    });
                });

                iElement.on('paste cut', function() {
                    $timeout(listener);
                });

                iElement.on('blur', function() {
                    $timeout(function() {
                        listener();
                        var value = iElement.val().replace(phoneRegex, '');
                        if (value.trim().length > 0 && value.toString().length !== 10) {
                            validationErrorMsg.drawErrorElement('Invalid phone number');
                            scope.$emit('ppm.input.validation.error', {
                                hasError: true,
                                id: iAttrs['id']
                            });
                        } else {
                            validationErrorMsg.removeErrorElement();
                            scope.$emit('ppm.input.validation.error', {
                                hasError: false,
                                id: iAttrs['id']
                            });
                        }
                    });
                });
            }
        };
    });

/************************************************
 *    ppm-char-restrict
 ************************************************/
/**
    1. property value is a valid regex or string can be convert to regex by eval()
    2. treat property value as the property name in scope, and
        a) this value can be treat as 1
        b) this value is a return value of function and can be treat as 1
        c) this value is a function, and can be manually executed and return value
           cann be treated as 1
    3. If use string, remember to use double \\, such as '/[\\w*]/', this is useful
       when defining regex in html file such as char-restrict="/[\\w*]/"
    4. In javascrip, suggest to use regex direct, such as "$scope.someRegex = /[\w]/;"
       or in function "return /[\w]/;"
    5. Remember to use falg g, if you want to remve all chars, such as no $ in the name
       can be look like '/[$]/g', or /[$]/g;
    6. We are use replace to remove all restrict character, so place always use regex
       format like /[acde+=]/g. Also we will parse the details character that a restricted,
       so place list all character, do not use this way /[a-d6-8]/g, instead of /[abcd678]/g
 */
angular.module('p2AdvanceApp')
    .directive('ppmCharRestrict', function($timeout, PpmInputValidationSvc, $log) {
        return {
            restrict: 'A',
            priority: 1,
            require: 'ngModel',

            link: function(scope, iElement, iAttrs, ngModel) {
                if (!ngModel) {
                    throw new Error('directive char-restrict: ngModel is required');
                }
                var restrictPattern = scope.ppmCharRestrictRegex = '';

                var validationErrorMsg = PpmInputValidationSvc.ValidationErrorMsg(iElement);

                // model to ui
                ngModel.$render = function() {
                    if (!ngModel.$viewValue) {
                        return;
                    }
                    var renderValue = restrictPattern ? ngModel.$viewValue.replace(restrictPattern, '') : ngModel.$viewValue;
                    render(renderValue, null);
                };

                iElement.on('change', function(event) {
                    // $log.log('>>>> change');
                    if (PpmInputValidationSvc.skipKeyStroke(event)) {
                        return;
                    }
                    scope.$evalAsync(function() {
                        listener(event);
                    });
                });

                iElement.on('blur', function(event) {
                    // $log.log('>>>> blur');
                    if (PpmInputValidationSvc.skipKeyStroke(event)) {
                        return;
                    }

                    scope.$evalAsync(function() {
                        render(ngModel.$viewValue, event); // remove the space, because $viewValue is already space trimmed
                        listener(event);
                    });
                });

                iElement.on('keydown', function(event) {
                    // $log.log('>>>> keydown');
                    if (PpmInputValidationSvc.skipKeyStroke(event)) {
                        return;
                    }
                    $timeout(function() { // Have to do this or changes don't get picked up properly
                        listener(event);
                    });
                });

                iElement.on('paste cut', function(event) {
                    $timeout(function() {
                        listener(event);
                    });
                });

                var listener = function(event) {
                    if (!ngModel.$viewValue) {
                        return;
                    }

                    var renderValue = iElement.val(); // ngModel.$viewValue; the spance is already trimmed in $viewValue
                    if (restrictPattern) {
                        // show auto hide message in another "thread" to make listener run fast
                        var viewErrorVlaue = renderValue;
                        $timeout(function() {
                            if (restrictPattern.test(viewErrorVlaue)) {
                                addErrorMsg();
                            } else if (event.type === 'keydown') {
                                validationErrorMsg.removeErrorElement();
                            }
                        });
                        renderValue = renderValue.replace(restrictPattern, '');
                    }

                    ngModel.$setViewValue(renderValue.trim()); // trim the space for $viewValue
                    render(renderValue, event);
                };

                function addErrorMsg() {
                    var msg = 'The following characters should not be contained: <strong>' + getUnsupportChars() + '</strong>.';
                    validationErrorMsg.drawErrorElement(msg);

                }

                function getUnsupportChars() {
                    var source = restrictPattern.source; // only [some char define here]
                    var chars = source.substring(1, source.length - 1).split('');
                    var chars2 = [];
                    var inBackSlash = false;
                    for (var i = 0; i < chars.length; ++i) {
                        var curChar = chars[i];
                        if (curChar === '\\' && !inBackSlash) {
                            inBackSlash = true;
                            continue;
                        }
                        chars2.push(curChar);
                        inBackSlash = false;
                    }

                    return chars2.join(', ');
                }

                var render = function(value, event) {
                    var element, start, end;
                    // remomber the cursor position
                    if (event && event.type === 'keydown') {
                        var oldText = iElement.val();
                        element = iElement[0];
                        start = element.selectionStart;
                        end = element.selectionEnd;
                        var diff = oldText.length - value.length;
                        if (diff) {
                            start -= diff;
                            end -= diff;
                        }
                    }

                    iElement.val(value);
                    // restore cursor position
                    if (event && event.type === 'keydown') {
                        element.selectionStart = start;
                        element.selectionEnd = end;
                    }
                };

                function isRegExp(value) {
                    return Object.prototype.toString.call(value) === '[object RegExp]';
                }

                function getRegexFromString(patternStr) {
                    try {
                        // eval(patternStr);
                        if (patternStr.indexOf('/') === 0) { // it is supposed to be a regex string
                            var last = patternStr.lastIndexOf('/');
                            var patStr = patternStr.substring(1, last);
                            var flag;
                            if (last < patternStr.length - 1) {
                                flag = patternStr.substring(last + 1);
                            }

                            return flag ? new RegExp(patStr, flag) : new RegExp(patStr);
                        }
                    } catch (e) {
                        $log.log(angular.toJson(e, true));
                    }

                    return patternStr;
                }

                function generateRegex(charsStr) {
                    var ret;

                    function stringToRegex(strOrRegex) {
                        if (isRegExp(strOrRegex)) {
                            return strOrRegex;
                        } else if (angular.isString(strOrRegex)) {
                            var result = getRegexFromString(strOrRegex);
                            if (isRegExp(result)) {
                                return result;
                            }
                        }

                        return null;
                    }

                    try {
                        var regexPat = charsStr;

                        ret = stringToRegex(regexPat);
                        if (!ret) { // attribute value is not a regex or cannot covert to a regex (not a right regex format)
                            // treat the attribute value as the property name of scope, 
                            // and read this property value, or execute the function property associated
                            // and get the return value of function
                            regexPat = scope.$eval(charsStr);
                            ret = stringToRegex(regexPat);
                            if (!ret) { // the value is not a regex or cannot convert to a regex
                                if (angular.isFunction(regexPat)) {
                                    // This is a special thing that attribute="functionName", not "functionName(params)"
                                    regexPat = regexPat.apply(scope); // have the function run and get return value
                                    ret = stringToRegex(regexPat);
                                }
                            }
                        }
                    } catch (e) {
                        $log.log(angular.toJson(e, true));
                    }

                    if (!ret) {
                        // change to info because if there is no valid regex, do nothing.
                        // and it dynamic udf, it is possible, some of them has strict, but others do not.
                        $log.info('directive char-restrict: given property value must be a valid regex');
                    }

                    return ret;
                }

                (function init(propStr) {
                    scope.ppmCharRestrictRegex = restrictPattern = generateRegex(propStr);
                    $log.log('restrictPattern = ' + restrictPattern);
                })(iAttrs['ppmCharRestrict']);
            } /* end of link*/
        }; /* end of return*/
    });