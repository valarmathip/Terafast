'use strict';

 angular.module('config', [])

.constant('ENV', {name:'devint',modalErrorTimeout:4000,apiGatewayEndpoint:'',dateFormat:'MMM DD YYYY hh:mm A',PPMCONST:{URL:{ppmService:{apiEndpoint:'',contextPath:'gateway/ppm'},ppmSearchService:{apiEndpoint:'',contextPath:'gateway/search'},cmService:{apiEndpoint:'',contextPath:'gateway/cm'},workflowService:{apiEndpoint:'',contextPath:'gateway/workflow'}}},settings:{paginationPageSizes:[20,40,60,80,100]},sessionAlertTimeout:1500000,sessionLogoutTimeout:1800000})

.constant('ENV_MEDIA_MANAGEMENT', {name:'media-management',modalErrorTimeout:4000,mediaApiEndpoint:'/gateway/mm/api/v1',restApiEndpoint:'/gateway/cm',restSearchApiEndpoint:'/gateway/search?q=',docGenerationApiEndpoint:'/gateway/docgen/api/v1',shortNameMaxLength:50})

.constant('ENV_WORKFLOW_MANAGEMENT', {apiEndpoint:'',contextPath:'/gateway/workflow'})

.constant('ENV_ACCOUNT_MANAGEMENT', {name:'account-management',modalErrorTimeout:4000,apiEndpoint:'',contextPath:'/gateway/ppm'})

.constant('ENV_DISTRIBUTION', {name:'distribution-app',hostName:'https://devdistribution.highroads.com/Distribution/Index.aspx',hostNameDraft:'https://devdistribution.highroads.com/Distribution/pages/PriorDistribution.aspx',hostNameSent:'https://devdistribution.highroads.com/Distribution/pages/SentDistribution.aspx',hostNameAdmin:'https://devdistribution.highroads.com/Distribution/Index.aspx?ReturnUrl=pages%2fadmin%2fManageDistribution.aspx',tokenParameter:'?t='})

;