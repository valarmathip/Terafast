'use strict';

angular.module('p2AdvanceApp')
    .factory('modalBaseFactory', function(runtimeStates, $state, ValidationRuleDataService) {
        // Public API here
        return {
            getBaseModalState: function(parentName, modalTitle, scope) {
                return {
                    'abstract': true,
                    onEnter: ['$modal', function($modal) {
                        var modalInstance = $modal.open({
                            templateUrl: 'views/admin/media-management/short-name-modal-base.html',
                            controller: 'ModalBaseCtrl',
                            size: 'lg',
                            backdrop: false,
                            resolve: {
                                parentName: function() {
                                    return parentName;
                                },
                                modalTitle: function() {
                                    return modalTitle;
                                }
                            }
                        });
                        modalInstance.result.then(function(result) {
                            angular.forEach(result, function(tag) {
                                /* Commented for PONVT-932 Bug. Cursor always should be end of contenteditable div.
                                 Modules involved: Conditions Rule & Validation Rule
                                if(!angular.isDefined(scope.expression)){
                                   scope.expression=tag.ShortName+' ';
                                }
                                else{
                                   scope.insertTextInPosition(tag.ShortName+' ');

                                }
                                */

                                if (ValidationRuleDataService.getNodeSelected() === null) {
                                    scope.setCursorPositionLast();
                                }
                                scope.insertTextInPosition(tag.ShortName + ' ');
                            });
                        });
                    }]
                };
            },
            getShortNameBody: function() {
                return {
                    onEnter: function() {
                        console.log('modal.shortnames');
                    },
                    views: {
                        'modalbody@': {
                            templateUrl: 'views/admin/media-management/filtered-list-short-names.html',
                            controller: 'ListShortNamesCtrl',
                            resolve: {
                                isModal: function() {
                                    return true;
                                },
                                filterList: function($q, ConfirmationModalFactory, ShortNameDictionaryService) {
                                    var deferred = $q.defer();
                                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading Short Name Filters, please wait...')
                                    ShortNameDictionaryService.getFilterValues().success(function(response) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        deferred.resolve(response);
                                    }).error(function(response) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        deferred.reject(response);
                                    });
                                    return deferred.promise;
                                }
                            }
                        }
                    }
                };
            },
            addShortNameModalState: function(stateName, scope) {
                if ($state.get(stateName + '.modal.shortnames') === null) {
                    runtimeStates.addState(stateName + '.modal', this.getBaseModalState(stateName, 'Select Field References', scope));
                    runtimeStates.addState(stateName + '.modal.shortnames', this.getShortNameBody());
                }
            }
        };
    });