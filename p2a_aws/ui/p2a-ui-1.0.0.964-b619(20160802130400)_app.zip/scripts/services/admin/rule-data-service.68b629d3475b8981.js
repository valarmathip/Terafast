﻿'use strict';

angular.module('p2AdvanceApp')
    .factory('RuleDataService', function ($http, $q, $log, ENV_MEDIA_MANAGEMENT, QueryDialog) {

        var mediaApi = ENV_MEDIA_MANAGEMENT.mediaApiEndpoint;
        var restApiEndpoint = ENV_MEDIA_MANAGEMENT.restApiEndpoint;
        var restSearchApiEndpoint = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint;
        var docGenerationApi = ENV_MEDIA_MANAGEMENT.docGenerationApiEndpoint;
        //var restSearchApiEndpoint = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint;
        var currentDataFields = [];
        var rulesDataList = [];
        var optionFindReplace = [{
            'name': 'FindAll',
            'dispname': 'Find all'
        }, {
            'name': 'ReplaceFirst',
            'dispname': 'Replace first'
        }, {
            'name': 'StartsWith',
            'dispname': 'Starts with'
        }, {
            'name': 'ReplaceLast',
            'dispname': 'Replace last'
        }, {
            'name': 'Exact',
            'dispname': 'Exact'
        }, {
            'name': 'ReplaceEntirePhrase',
            'dispname': 'Replace entire phrase'
        }, {
            'name': 'AddBefore',
            'dispname': 'Add before'
        }, {
            'name': 'AddAfter',
            'dispname': 'Add after'
        }, {
            'name': 'EndsWith',
            'dispname': 'Ends with'
        }];
        var booleanExpressions = [];
        var optionOperators = [{
            'name': 'InsertOperator',
            'dispname': 'Insert Operator'
        }, {
            'name': 'AND',
            'dispname': 'AND'
        }, {
            'name': 'OR',
            'dispname': 'OR'
        }, {
            'name': 'NOT',
            'dispname': 'NOT'
        }, {
            'name': '(',
            'dispname': '('
        }, {
            'name': ')',
            'dispname': ')'
        }, {
            'name': '=',
            'dispname': '='
        }, {
            'name': '<>',
            'dispname': '<>'
        }, {
            'name': '>',
            'dispname': '>'
        }, {
            'name': '>=',
            'dispname': '>='
        }, {
            'name': '<',
            'dispname': '<'
        }, {
            'name': '<=',
            'dispname': '<='
        }, {
            'name': '+',
            'dispname': '+'
        }, {
            'name': '-',
            'dispname': '-'
        }, {
            'name': '/',
            'dispname': '/'
        }, {
            'name': '*',
            'dispname': '*'
        }, {
            'name': 'StartsWith',
            'dispname': 'Starts With'
        }, {
            'name': 'EndsWith',
            'dispname': 'Ends With'
        }, {
            'name': 'Contains',
            'dispname': 'Contains'
        }, {
            'name': 'exists()',
            'dispname': 'Exists'
        }];

        function RuleDataService() {
            var self = this;

            self.getDeletionRules = function() {
                var deletionRuleApi = mediaApi + '/deletionRules/grid';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading list of trim rules, please wait...')

                $http.get(deletionRuleApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };

            self.getDeletionRuleById = function(objectId) {
                return $http.get(restApiEndpoint + '/deletionRules/' + objectId);
            };

            self.getMMDeletionRuleById = function(objectId) {
                return $http.get(mediaApi + '/deletionRules/grid/' + objectId);
            };
            self.getMMShowRulesById = function(objectId) {
                return $http.get(mediaApi + '/showRules/grid/' + objectId);
            };

            self.createDeletionRule = function(postRuleData, selectedDataFieldIds) {
                var createRuleApi = restApiEndpoint + '/deletionRules';
                var defer = $q.defer();
                var that = self;

                $http({
                         method : 'POST',
                         url : createRuleApi,
                         data: JSON.stringify(postRuleData),
                         headers : {
                            'Content-Type': 'application/json'
                         }
                    }).success(function(data, status) {
                        if (data) {
                            //Will be changed to Single API call in future. Fixing this issue now for PONVT-540
                            that.updateAssociateDataFieldsToRule(selectedDataFieldIds, data, 'deletionRules')
                                .then(function () {
                                    defer.resolve(data);
                                }, function (reason) {
                                    defer.reject(reason);
                                });
                        }
                        else {
                            // since status code is 200 so no server error, we need to pop up the error dialog manually
                            var responseObj = {
                                errorCode: 'Trim rule was not created successfully.',
                                errorDetails: data ? data : 'Trim rule was created but no objectId returned.',
                                errorId: status,
                                errorMessage: 'Trim rule was not created successfully.',
                                httpStatus: data ? data.httpStatus : 'Server Error',
                                httpStatusCode: data ? data.httpStatusCode : status
                            };

                            QueryDialog.open(responseObj.httpStatus, responseObj, 'warning', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                            defer.reject('Trim rule was not created successfully.');
                        }
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;

            };

            self.createBooleanExpression = function(postRuleData) {
                var createRuleApi = restApiEndpoint + '/booleanExpressions';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Creating condition expression, please wait...')
                $http.post(createRuleApi, postRuleData, {
                        'Content-Type': 'application/json'
                    }).success(function(data) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });

                return defer.promise;

            };

            self.checkSyntax = function(expression) {
                var checksyntaxApi = docGenerationApi + '/expression/validate';
                var defer = $q.defer();
                $http.post(checksyntaxApi, expression, {
                        'Content-Type': 'application/json'
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });
                return defer.promise;
            };

            self.updateDeletionRule = function(patchData, objectId, selectedDataFieldIds, selectedFieldsPair) {
                var updateRuleApi = restApiEndpoint + '/deletionRules/' + objectId;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Updating trim rule, please wait...')

                var that = self;

                $http({
                        method: 'PATCH',
                        url: updateRuleApi,
                        data: JSON.stringify(patchData),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function(data) {
                        var addSelectFieldIds = selectedDataFieldIds.filter(function(DataFieldIds) {
                            return selectedFieldsPair.filter(function(FieldsPair) {
                                return FieldsPair.objectId === DataFieldIds.objectId;
                            }).length === 0;
                        });
                        var deleteSelectFieldIds = selectedFieldsPair.filter(function(FieldsPair) {
                            return selectedDataFieldIds.filter(function(DataFieldIds) {
                                return DataFieldIds.objectId === FieldsPair.objectId;
                            }).length === 0;
                        });

                        that.deleteAssociateDataFieldsToRule(deleteSelectFieldIds, objectId, 'deletionRules')
                            .then(function() {
                                that.updateAssociateDataFieldsToRule(addSelectFieldIds, objectId, 'deletionRules')
                                    .then(function() {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.resolve(data);
                                    }, function(reason) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.reject(reason);
                                    });
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;

            };

            self.deactivateRule = function(objectId, type) {
                var deactivateRuleApi = '';
                var ruleName = '';
                if (type === 'deletionRule') {
                    deactivateRuleApi = restApiEndpoint + '/deletionRules/' + objectId;
                    ruleName = 'trim';
                } else if (type === 'findReplaceRule') {
                    deactivateRuleApi = restApiEndpoint + '/findReplaceRules/' + objectId;
                    ruleName = 'find and replace';
                } else if (type === 'showRule') {
                    deactivateRuleApi = restApiEndpoint + '/showRules/' + objectId;
                    ruleName = 'show';
                }

                var defer = $q.defer();


                var ruleObj = {
                    ruleStatus: 'Inactive'
                };
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the ' + ruleName + ' rule, please wait...')
                $http({
                        method: 'PATCH',
                        url: deactivateRuleApi,
                        data: JSON.stringify(ruleObj),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                    .success(function(response) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.resolve(response);
                    })
                    .error(function(response) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(response);
                    });

                return defer.promise;
            };

            self.getFindReplaceRules = function() {
                var findReplaceRuleApi = mediaApi + '/findReplaceRules/grid';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading list of find and replace rules, please wait...')

                $http.get(findReplaceRuleApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };

            self.getFindReplaceRuleById = function(objectId) {
                return $http.get(restApiEndpoint + '/findReplaceRules/' + objectId);
            };

            self.getMMFindReplaceRuleById = function(objectId) {
                return $http.get(mediaApi + '/findReplaceRules/grid/' + objectId);
            };
            self.getBooleanExpressionById = function(objectId) {
                return $http.get(restApiEndpoint + '/booleanExpressions/' + objectId);
            };

            self.createFindandReplaceRule = function(postRuleData, selectedDataFieldIds) {
                var createRuleApi = restApiEndpoint + '/findReplaceRules';

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Creating find and replace rule, please wait...')

                var that = self;

                $http({
                         method : 'POST',
                         url : createRuleApi,
                         data: JSON.stringify(postRuleData),
                         headers: {
                            'Content-Type': 'application/json'
                         }
                       }).success(function(data, status) {
                           if (data) {
                               that.updateAssociateDataFieldsToRule(selectedDataFieldIds, data, 'findReplaceRules')
                                .then(function () {
                                    defer.resolve(data);
                                }, function (reason) {
                                    defer.reject(reason);
                                });
                           }
                           else {
                               // since status code is 200 so no server error, we need to pop up the error dialog manually
                               var responseObj = {
                                   errorCode: 'Find/Replace rule was not created successfully.',
                                   errorDetails: data ? data : 'Find/Replace rule was created but no objectId returned.',
                                   errorId: status,
                                   errorMessage: 'Find/Replace rule was not created successfully.',
                                   httpStatus: data ? data.httpStatus : 'Server Error',
                                   httpStatusCode: data ? data.httpStatusCode : status
                               };

                               QueryDialog.open(responseObj.httpStatus, responseObj, 'warning', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                               defer.reject('Find/Replace rule was not created successfully.');
                           }
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });

                return defer.promise;

            };

            self.deactivateFindReplaceRule = function(objectId) {

                var deactivateRuleApi = restApiEndpoint + '/findReplaceRules/' + objectId;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the find and replace rule, please wait...')

                var ruleObj = {
                    ruleStatus: 'Inactive'
                };

                $http({
                        method: 'PATCH',
                        url: deactivateRuleApi,
                        data: JSON.stringify(ruleObj),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                    .success(function(response) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.resolve(response);
                    })
                    .error(function(response) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(response);
                    });

                return defer.promise;
            };

            self.getoptionFindReplaceList = function() {
                return optionFindReplace;
            };
            self.getoptionConitionList = function() {
                return optionOperators;
            };

            self.updateOptionDropdown = function(findType) {
                var keyValue = 0;
                angular.forEach(optionFindReplace, function(value, key) {
                    if (optionFindReplace[key]['name'] === findType || optionFindReplace[key]['dispname'] === findType) {
                        keyValue = key;
                    }
                });
                return optionFindReplace[keyValue];

            };

            self.getCurrentRuleDataFields = function() {
                return currentDataFields;
            };

            self.setCurrentRuleDataFieldNames = function(data) {
                currentDataFields = angular.isDefined(data) ? data.split(', ') : '';
            };

            self.getCurrentRuleBooleanExpressions = function() {
                return booleanExpressions;
            };

            self.setCurrentRuleBooleanExpressions = function(data) {
                booleanExpressions = angular.isDefined(data) ? data.split(' ') : '';
            };
            var currentRuleDataFieldNamesPair = [];
            var currentRuleBooleanExpressionsPair = [];
            var currentRuleDataFieldNamesRulePair = [];
            self.getCurrentRuleDataFieldsPair = function() {
                return currentRuleDataFieldNamesPair;
            };
            self.setCurrentRuleDataFieldNamesPair = function(data) {

                currentRuleDataFieldNamesPair = [];
                if (angular.isDefined(data)) {
                    angular.forEach(data, function(item) {
                        currentRuleDataFieldNamesPair.push({
                            objectId: item.objectId,
                            dataFieldName: item.Title
                        });
                    });
                }
            };
            self.getCurrentRuleBooleanExpressionsPair = function() {
                return currentRuleBooleanExpressionsPair;
            };
            self.setCurrentRuleBooleanExpressionsPair = function(data) {
                currentRuleBooleanExpressionsPair = [];
                currentRuleBooleanExpressionsPair.push({
                    objectId: data.ObjectId,
                    name: data.name
                });


            };
            self.getCurrentRuleDataFieldsRulePair = function() {
                return currentRuleDataFieldNamesRulePair;
            };

            self.setCurrentRuleDataFieldNamesRulePair = function(data, templateObject) {

                currentRuleDataFieldNamesRulePair = [];
                if (angular.isDefined(data)) {
                    angular.forEach(data, function(item) {
                        currentRuleDataFieldNamesRulePair.push({
                            objectId: item.objectId,
                            dataFieldName: item.Title,
                            templates: angular.isDefined(item.dataFieldTemplate) ? getDataFieldsTemplate(item.dataFieldTemplate, templateObject) : ''
                        });
                    });
                }
            };

            function moveSelectedIndexAsFirstElement(arr, fromIndex, toIndex) {
                var element = arr[fromIndex];
                arr.splice(fromIndex, 1);
                arr.splice(toIndex, 0, element);
            }

            self.setPreSelectedRow = function(tags, tagsSelected, gridApi, pageName) {
                var count = 0;

                if (tags && tagsSelected) {
                    $.each(tags, function (key, value) {
                        $.each(tagsSelected, function (key1) {
                            if (tagsSelected[key1].objectId === tags[key].objectId) {
                                if (pageName === 'tags' || pageName === 'showHideConditions' || pageName === 'showHideDatafield') {
                                    moveSelectedIndexAsFirstElement(tags, key, 0);
                                }
                                count++;
                                if (gridApi !== undefined) {
                                    gridApi.selection.selectRow(value, true);
                                }
                            }
                        });
                    });

                    if (pageName === 'tags' || pageName === 'showHideDatafield' || pageName === 'showHideDatafield') {
                        if (tags.length > 0 && tagsSelected.length > 0 && (count === tags.length) && (count === tagsSelected.length)) {
                            gridApi.selection.selectAllRows(true);
                        }
                    }
                }

            };

            function getDataFieldsTemplate(dataFieldsTemplate, templateObject) {
                var templates = [];
                angular.forEach(dataFieldsTemplate, function(item) {
                    templates.push(
                        templateObject[item]
                    );
                });
                return templates;
            }
            self.updateFindandReplaceRule = function(patchData, objectId, selectedDataFieldIds, selectedFieldsPair) {
                var updateRuleApi = restApiEndpoint + '/findReplaceRules/' + objectId;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Updating find and replace rule, please wait...')

                var that = self;

                $http({
                        method: 'PATCH',
                        url: updateRuleApi,
                        data: JSON.stringify(patchData),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function(data) {
                        var addSelectFieldIds = selectedDataFieldIds.filter(function(DataFieldIds) {
                            return selectedFieldsPair.filter(function(FieldsPair) {
                                return FieldsPair.objectId === DataFieldIds.objectId;
                            }).length === 0;
                        });
                        var deleteSelectFieldIds = selectedFieldsPair.filter(function(FieldsPair) {
                            return selectedDataFieldIds.filter(function(DataFieldIds) {
                                return DataFieldIds.objectId === FieldsPair.objectId;
                            }).length === 0;
                        });

                        that.deleteAssociateDataFieldsToRule(deleteSelectFieldIds, objectId, 'findReplaceRules')
                            .then(function() {
                                that.updateAssociateDataFieldsToRule(addSelectFieldIds, objectId, 'findReplaceRules')
                                    .then(function() {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.resolve(data);
                                    }, function(reason) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.reject(reason);
                                    });
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });

                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });

                return defer.promise;

            };

            self.updateBooleanExpression = function(patchData, objectId) {
                var updateRuleApi = restApiEndpoint + '/booleanExpressions/' + objectId;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Updating condition expression, please wait...')
                $http({
                        method: 'PATCH',
                        url: updateRuleApi,
                        data: JSON.stringify(patchData),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function(data) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });

                return defer.promise;

            };


            self.getShowRules = function() {

                var showRuleApi = mediaApi + '/showRules/grid';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading list of show rules, please wait...')

                $http.get(showRuleApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };


            self.createShowRule = function(postRuleData, showRuleExpressionId, selectedDataFieldIds) {
                var createRuleApi = restApiEndpoint + '/showRules';

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Creating show rule, please wait...')
                var that = self;
                $http.post(createRuleApi, postRuleData, {
                        'Content-Type': 'application/json'
                    }).success(function(data) {

                        //Will be changed to single API call in future enhancement-Fixing this one for PONVT-355.
                        var newObject = data;
                        that.associateBooleanExpressionToRule(showRuleExpressionId, newObject, 'showRules')
                            .then(function() {
                                that.updateAssociateDataFieldsToRule(selectedDataFieldIds, newObject, 'showRules')
                                    .then(function() {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.resolve(data);
                                    }, function(reason) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.reject(reason);
                                    });
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });

                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;
            };
            self.updateShowRule = function(patchData, objectId, selectedDataFieldIds, showRuleExpressionId, selectedFieldsPair, selectedBooleanPair) {
                var updateRuleApi = restApiEndpoint + '/showRules/' + objectId;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Updating show rule, please wait...')
                var that = self;
                $http({
                        method: 'PATCH',
                        url: updateRuleApi,
                        data: JSON.stringify(patchData),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function() {

                        var addSelectFieldIds = selectedDataFieldIds.filter(function(DataFieldIds) {
                            return selectedFieldsPair.filter(function(FieldsPair) {
                                return FieldsPair.objectId === DataFieldIds.objectId;
                            }).length === 0;
                        });
                        var deleteSelectFieldIds = selectedFieldsPair.filter(function(FieldsPair) {
                            return selectedDataFieldIds.filter(function(DataFieldIds) {
                                return DataFieldIds.objectId === FieldsPair.objectId;
                            }).length === 0;
                        });

                        //Will be changed to single API call in future enhancement-Fixing this one for PONVT-355.
                        that.deleteAssociateBooleanExpressionToRule(selectedBooleanPair, objectId, 'showRules')
                            .then(function() {
                                that.associateBooleanExpressionToRule(showRuleExpressionId, objectId, 'showRules')
                                    .then(function() {
                                        that.deleteAssociateDataFieldsToRule(deleteSelectFieldIds, objectId, 'showRules')
                                            .then(function() {
                                                that.updateAssociateDataFieldsToRule(addSelectFieldIds, objectId, 'showRules')
                                                    .then(function() {
                                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                                        defer.resolve();
                                                    }, function(reason) {
                                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                                        defer.reject(reason);
                                                    });
                                            }, function(reason) {
                                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                                defer.reject(reason);
                                            });
                                    }, function(reason) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.reject(reason);
                                    });
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;
            };

            self.getShowDataFields = function() {
                // currently boolean expression grid doesn't use server side pagination
                var dataFieldApi = restSearchApiEndpoint + encodeURI('TYPE:"booleanExpression" &associationExpansionLevel=1&sort=lastModificationDate desc');

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of condition expressions, please wait...')
                $http.get(dataFieldApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };

            self.getShowRuleById = function(objectId) {
                return $http.get(restApiEndpoint + '/showRules/' + objectId);
            };
            self.getConditionRules = function () {
                // currently boolean expression grid doesn't use server side pagination
                var conditionRuleApi = restSearchApiEndpoint + encodeURI('TYPE:"booleanExpression" &associationExpansionLevel=1&sort=lastModificationDate desc');

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of condition expressions, please wait...')

                $http.get(conditionRuleApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };



            self.getDataFields = function(gridType) {
                var dataFieldApi = mediaApi + '/dataFields/rule/grid/' + gridType;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of data fields, please wait...')

                $http.get(dataFieldApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };

            self.getDataFieldsForShowRule = function() {
                var dataFieldApi = mediaApi + '/dataFields/showRule/grid';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of data fields, please wait...')

                $http.get(dataFieldApi).success(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };

            self.getTemplateName = function() {
                var dataFieldApi = restApiEndpoint + '/templates';
                var defer = $q.defer();
                //   ConfirmationModalFactory.open('Loading a list of data fields, please wait...');

                $http.get(dataFieldApi).success(function(response) {
                    //    ConfirmationModalFactory.close();
                    defer.resolve(response);
                }).error(function(response) {
                    //   ConfirmationModalFactory.close();
                    defer.reject(response);
                });
                return defer.promise;
            };

            //Association of ShowRule with Boolean expression. ruleType  = "showRules"
            self.associateBooleanExpressionToRule = function(bExpressionId, ruleObjectId, ruleType) {
                var associatebExpressionApi = restApiEndpoint + '/' + ruleType + '/' + ruleObjectId;
                associatebExpressionApi = associatebExpressionApi + '/showRuleExpression/' + bExpressionId;

                var defer = $q.defer();

                var dummyData = {};
                if (bExpressionId.length > 0 && ruleObjectId.length > 0 && ruleType.length > 0) {
                    $http.post(associatebExpressionApi, dummyData, {
                            'Content-Type': 'application/json'
                        }).success(function() {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.resolve();
                        })
                        .error(function(reason) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.reject(reason);
                        });

                } else {
                    defer.resolve();
                }
                return defer.promise;
            };
            self.deleteAssociateBooleanExpressionToRule = function(bExpressionId, ruleObjectId, ruleType) {
                var associatebExpressionApi = restApiEndpoint + '/' + ruleType + '/' + ruleObjectId;
                associatebExpressionApi = associatebExpressionApi + '/showRuleExpression/' + bExpressionId;
                var defer = $q.defer();
                $http({
                        method: 'DELETE',
                        url: associatebExpressionApi,
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function() {
                        //ConfirmationModalFactory.close();
                        defer.resolve();
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;
            };
            self.associateDataFieldsToRule = function(fields, ruleObjectId, ruleType) {
                var associateDataFieldsApi = restApiEndpoint + '/' + ruleType + '/' + ruleObjectId;
                associateDataFieldsApi = associateDataFieldsApi + '/ruleDataFields/';
                var associateContentRulesApi = restApiEndpoint + '/dataFields/';

                var defer = $q.defer();
                var fieldsLength = fields.length;
                var countResponses = 0;
                angular.forEach(fields, function(field) {
                    var associateDataFieldsApiWithFieldId = associateDataFieldsApi + field;
                    var associateContentRulesApiWithFieldId = associateContentRulesApi + field.objectId + '/contentRules/' + ruleObjectId;
                    var dummyData = {};
                    $http.post(associateDataFieldsApiWithFieldId, dummyData, {
                            'Content-Type': 'application/json'
                        }).success(function() {
                            $http.post(associateContentRulesApiWithFieldId, dummyData, {
                                'Content-Type': 'application/json'
                            }).success(function () {
                                countResponses++;
                                if (countResponses === fieldsLength) {
                                    defer.resolve();
                                    return defer.promise;
                                }
                            })
                           .error(function (reason) {
                               /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                               defer.reject(reason);
                               return defer.promise;
                           });
                        })
                        .error(function(reason) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.reject(reason);
                            return defer.promise;
                        });
                });
                return defer.promise;
            };
            self.updateAssociateDataFieldsToRule = function(fields, ruleObjectId, ruleType) {
                var associateDataFieldsApi = restApiEndpoint + '/' + ruleType + '/' + ruleObjectId;
                associateDataFieldsApi = associateDataFieldsApi + '/ruleDataFields/';
                var associateContentRulesApi = restApiEndpoint + '/dataFields/';
                var defer = $q.defer();
                var fieldsLength = fields.length;
                var countResponses = 0;
                if (fields.length > 0) {
                    angular.forEach(fields, function (field) {
                        var associateDataFieldsApiWithFieldId = associateDataFieldsApi + field.objectId;
                        var associateContentRulesApiWithFieldId = associateContentRulesApi + field.objectId + '/contentRules/' + ruleObjectId;
                        var dummyData = {};
                        $http.post(associateDataFieldsApiWithFieldId, dummyData, {
                            'Content-Type': 'application/json'
                        }).success(function () {
                            $http.post(associateContentRulesApiWithFieldId, dummyData, {
                                'Content-Type': 'application/json'
                            }).success(function () {
                                countResponses++;
                                if (countResponses === fieldsLength) {
                                    defer.resolve();
                                    return defer.promise;
                                }
                            })
                            .error(function (reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                                return defer.promise;
                            });
                        })
                        .error(function (reason) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.reject(reason);
                            return defer.promise;
                        });
                    });
                } else {
                    defer.resolve();
                }
                return defer.promise;
            };

            self.deleteAssociateDataFieldsToRule = function(fields, ruleObjectId, ruleType) {
                var associateDataFieldsApi = restApiEndpoint + '/' + ruleType + '/' + ruleObjectId;
                associateDataFieldsApi = associateDataFieldsApi + '/ruleDataFields/';
                var associateContentRulesApi = restApiEndpoint + '/dataFields/';
                var defer = $q.defer();

                var fieldsLength = fields.length;
                var countResponses = 0;
                if (fields.length > 0) {
                    angular.forEach(fields, function (field) {
                        var associateDataFieldsApiWithFieldId = associateDataFieldsApi + field.objectId;
                        var associateContentRulesApiWithFieldId = associateContentRulesApi + field.objectId + '/contentRules/' + ruleObjectId;
                        $http({
                            method: 'DELETE',
                            url: associateDataFieldsApiWithFieldId,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).success(function () {
                            $http({
                                method: 'DELETE',
                                url: associateContentRulesApiWithFieldId,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            }).success(function () {
                                countResponses++;
                                if (countResponses === fieldsLength) {
                                    defer.resolve();
                                    return defer.promise;
                                }
                            })
                            .error(function (reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                                return defer.promise;
                            });
                        })
                        .error(function (reason) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.reject(reason);
                            return defer.promise;
                        });
                    });
                } else {
                    defer.resolve();
                }

                return defer.promise;
            };

            self.getGridDataFields = function(dataFields) {
                var fields = '';
                angular.forEach(dataFields, function(field) {
                    if (fields === '') {
                        fields = field.Title;
                    } else {
                        fields = fields + ', ' + field.Title;
                    }
                });
                return fields;
            };
            self.getGridConditions = function(dataFields) {

                var fields = '';
                if (dataFields != null) {
                    fields = dataFields.Expression;
                }
                return fields;
            };

            self.setListData = function(rulesData) {
                rulesDataList = rulesData;
            };

            self.getListData = function() {
                return rulesDataList;
            };

            /*PONVT-614 remove spaces, breaks and unnecessary formatting html tags in the provided expression*/
            self.unescapeText = function(escapedHTML) {
                return escapedHTML.replace(/&nbsp;/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/[<]br[^>]*[>]/g, '').replace(/&amp;/g, '&').replace(/<[^>]+>/gm, '');
            };

        }
        return new RuleDataService();

    });