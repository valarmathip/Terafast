﻿'use strict';

angular.module('p2AdvanceApp')
    .factory('ShortNameDictionaryService', function ($http, $q, ENV_MEDIA_MANAGEMENT/*, ConfirmationModalFactory*/) {

        var restApiEndpoint = ENV_MEDIA_MANAGEMENT.restApiEndpoint;
        var restSearchApiEndpoint = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint;
        var mediaApi = ENV_MEDIA_MANAGEMENT.mediaApiEndpoint;

        function ShortNameDictionaryService() {
            var self = this;

            self.getShortNames = function () {

                var shortNamesApi = restApiEndpoint + '/shortNameDictionarys';

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of short names, please wait...')

                $http.get(shortNamesApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function(response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                // Now return the promise
                return defer.promise;
            };

            self.getShortNameById = function(id) {
                var shortNameByIdApi = restApiEndpoint + '/shortNameDictionarys/' + id;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading short name, please wait...')

                $http.get(encodeURI(shortNameByIdApi)).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                // Now return the promise
                return defer.promise;
            };

            self.getShortNameByName = function (name) {
                var shortNameSearchApi = restSearchApiEndpoint + 'TYPE:"shortNameDictionary" AND (=shortName:' + '"' + name + '")';
                return $http.get(encodeURI(shortNameSearchApi));
            };

            self.createShortName = function (shortNameObj, alias) {
                var createShortNameApi = restApiEndpoint + '/shortNameDictionarys';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('creating Short Name, please wait...')
                // payload
                var dataObj = {
                    shortName: alias,
                    path: shortNameObj.path,
                    businessDataType: shortNameObj.businessDataType,
                    name: alias
                };

                $http.post(createShortNameApi, JSON.stringify(dataObj), { 'Content-Type': 'application/json' }).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                // Now return the promise
                return defer.promise;
            };

            self.editShortNameAlias = function (shortNameObj, alias) {
                var updateShortNameApi = restApiEndpoint + '/shortNameDictionarys/' + shortNameObj.objectId;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('updating Short Name Alias, please wait...')
                // payload
                var dataObj = {
                    shortName: alias,
                    name: alias
                };

                $http({
                    method: 'PATCH',
                    url: updateShortNameApi,
                    data: JSON.stringify(dataObj),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                })
                .error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                //Now return the promise
                return defer.promise;
            };

            self.getFilteredShortNames = function(filterObject) {
                var shortNameFieldsByTenantApi = mediaApi + '/ShortNameDictionaries/FilterCriteria'; //+ tenant;
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading Fields List, please wait...')
                $http.post(shortNameFieldsByTenantApi, JSON.stringify(filterObject), { 'Content-Type': 'application/json' }).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                // Now return the promise
                return defer.promise;
            };

            self.getFieldsGridItems = function() {
                var shortNameFieldsByTenantApi = mediaApi + '/ShortNameDictionaries';  //TODO add '/<some tenant value> to URL
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading Fields List, please wait...')

                $http.get(encodeURI(shortNameFieldsByTenantApi)).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                // Now return the promise
                return defer.promise;
            };

            self.getFilterValues = function() {
                var shortNameFilterValuesApi = mediaApi + '/ShortNameDictionaries/FilterValues';
                return $http.get(shortNameFilterValuesApi);
            };

        }
        return new ShortNameDictionaryService();

    });