'use strict';

angular.module('p2AdvanceApp')
    .factory('ValidationRuleDataService', function($http, $q, $log, ENV_MEDIA_MANAGEMENT, $upload, $auth, $document, $window, moment, PPMENV) {
        var restApiEndpoint = ENV_MEDIA_MANAGEMENT.restApiEndpoint;
        var mediaApiEndpoint = ENV_MEDIA_MANAGEMENT.mediaApiEndpoint;
        var restSearchApiEndpoint = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint;
        var nodeSelected = null;
        var cursorPosition;
        var needsMathObject = {
            abs: true,
            ceil: true,
            floor: true,
            max: true,
            min: true,
            round: true
        };
        var symbols = {
            // Symbol table to look up expression references and validate them.
            // Pre-loaded reserve words
            'then': {
                kind: 'reserved'
            },
            'if': {
                kind: 'reserved'
            },
            'true': {
                kind: 'reserved'
            },
            'false': {
                kind: 'reserved'
            },
            'includes': {
                kind: 'reserved'
            }, // switch to overloading > to exploit set operator is subset; also '<, <=, >='  ?
            '_': {
                kind: 'reserved'
            }, // reserve as a reference to implied parm in chaining syntax
            '_^': {
                kind: 'reserved'
            }, // reserve as a reference to top of partially ordered graph of expressions, not recognized by parser, not legal var name


            'abs': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'NUMBER',
                parmTypes: []
            },
            'ceil': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'NUMBER',
                parmTypes: []
            },
            'floor': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'NUMBER',
                parmTypes: []
            },
            'max': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'NUMBER',
                parmTypes: ['NUMBER']
            },
            'min': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'NUMBER',
                parmTypes: ['NUMBER']
            },
            'round': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'NUMBER',
                parmTypes: []
            },
            'indexOf': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'STRING',
                parmTypes: ['STRING', 'NUMBER']
            },
            'length': {
                type: 'NUMBER',
                isSet: false,
                kind: 'function',
                impliedParmType: 'STRING',
                parmTypes: []
            },
            'substr': {
                type: 'STRING',
                isSet: false,
                kind: 'function',
                impliedParmType: 'STRING',
                parmTypes: ['NUMBER', 'NUMBER']
            },
            'toLowerCase': {
                type: 'STRING',
                isSet: false,
                kind: 'function',
                impliedParmType: 'STRING',
                parmTypes: []
            },
            'toUpperCase': {
                type: 'STRING',
                isSet: false,
                kind: 'function',
                impliedParmType: 'STRING',
                parmTypes: []
            },
            'trim': {
                type: 'STRING',
                isSet: false,
                kind: 'function',
                impliedParmType: 'STRING',
                parmTypes: []
            },
            'exists': {
                type: 'BOOLEAN',
                isSet: false,
                kind: 'function',
                impliedParmType: 'ANY',
                parmTypes: []
            }
        };

        var functionsAvailable = [{
            'name': 'indexOf',
            'description': 'The indexOf(searchValue,fromIndex) method returns the index within the calling String object of the first occurrence of the specified value, starting the search at fromIndex. Returns -1 if the value is not found.',
            'displayName': 'field.indexOf(searchValue,fromIndex)'
        }, {
            'name': 'length',
            'description': 'The length() function returns the length of a string.',
            'displayName': 'field.length()'
        }, {
            'name': 'substr',
            'description': 'The substr(start,length) method returns the characters in a string beginning at the specified location through the specified number of characters.',
            'displayName': 'field.substr(start,length)'
        }, {
            'name': 'toLowerCase',
            'description': 'The toLowerCase() method returns the calling string value converted to lowercase.',
            'displayName': 'field.toLowerCase()'
        }, {
            'name': 'toUpperCase',
            'description': 'The toUpperCase() method returns the calling string value converted to uppercase.',
            'displayName': 'field.toUpperCase()'
        }, {
            'name': 'trim',
            'description': 'The trim() method removes whitespace from both ends of a string. Whitespace in this context is all the whitespace characters (space, tab, no-break space, etc.) and all the line terminator characters (LF, CR, etc.).',
            'displayName': 'field.trim()'
        }, {
            'name': 'abs',
            'description': 'The abs(num) function returns the absolute value of a number.',
            'displayName': 'field.abs()'
        }, {
            'name': 'ceil',
            'description': 'The ceil(num) function returns the smallest integer greater than or equal to a given number.',
            'displayName': 'field.ceil()'
        }, {
            'name': 'floor',
            'description': 'The floor(num) function returns the largest integer less than or equal to a given number.',
            'displayName': 'field.floor()'
        }, {
            'name': 'max',
            'description': 'The max(num1,num2) function returns the largest of two numbers.',
            'displayName': 'field.max(num)'
        }, {
            'name': 'min',
            'description': 'The min(num1,num2) function returns the smallest of two numbers.',
            'displayName': 'field.min(num)'
        }, {
            'name': 'round',
            'description': 'The round(num) function returns the value of a number rounded to the nearest integer.',
            'displayName': 'field.round()'
        }, {
            'name': 'exists',
            'description': 'The exists() function returns true or false based on whether the Field Reference can be found in the plan. Invoked as fieldRef.exists()',
            'displayName': 'field.exists()'
        }];

        var optionOperators = [{
            'name': 'InsertOperator',
            'dispname': 'Insert Operator'
        }, {
            'name': '{',
            'dispname': '{'
        }, {
            'name': '}',
            'dispname': '}'
        }, {
            'name': '>',
            'dispname': '>'
        }, {
            'name': '(',
            'dispname': '('
        }, {
            'name': ')',
            'dispname': ')'
        }, {
            'name': '=',
            'dispname': '='
        }, {
            'name': '<>',
            'dispname': '<>'
        }, {
            'name': '>=',
            'dispname': '>='
        }, {
            'name': '<',
            'dispname': '<'
        }, {
            'name': '<=',
            'dispname': '<='
        }, {
            'name': '+',
            'dispname': '+'
        }, {
            'name': '-',
            'dispname': '-'
        }, {
            'name': '/',
            'dispname': '/'
        }, {
            'name': '*',
            'dispname': '*'
        }, {
            'name': '%',
            'dispname': '%'
        }, {
            'name': '!',
            'dispname': '!'
        }, {
            'name': '||',
            'dispname': '||'
        }, {
            'name': '^',
            'dispname': '^'
        }, {
            'name': '&&',
            'dispname': '&&'
        }, {
            'name': 'true',
            'dispname': 'true'
        }, {
            'name': 'false',
            'dispname': 'false'
        }, {
            'name': 'if',
            'dispname': 'if'
        }, {
            'name': 'then',
            'dispname': 'then'
        }, {
            'name': 'else',
            'dispname': 'else'
        }, {
            'name': 'includes',
            'dispname': 'includes'
        }];


        function ValidationRuleDataService() {

            var self = this;
            self.symbols = symbols;
            self.functionsAvailable = functionsAvailable;
            self.optionOperators = optionOperators;
            var sortNamesList = [];
            self.shortNamesList = sortNamesList;

            self.getValidationRuleById = function(objectId) {
                return $http.get(restApiEndpoint + '/rulesExpressions/' + objectId);
            };
            self.getNodeSelected = function() {
                return nodeSelected;
            };
            self.setNodeSelected = function(nodeSelection) {
                nodeSelected = nodeSelection;
            };

            self.getCursorPosition = function() {
                return cursorPosition;
            };
            self.setCursorPosition = function(position) {
                cursorPosition = position;
            };

            self.getValidationRuleList = function(rows, rulesList, inputRow, defer) {
                var start = 0;
                var tempRows = 250;
                var that = self;
                if (rows === undefined || rows === '' || rows > tempRows) {
                    rows = tempRows;
                }

                if (rulesList === undefined || rulesList.length < 0) {
                    defer = $q.defer();
                    rulesList = [];
                    inputRow = rows;

                } else {
                    start = inputRow;
                    inputRow = inputRow + rows;
                }


                var url = 'TYPE:"rulesExpression" &associationExpansionLevel=0 &start=' + start + '&rows=' + rows + '&sort=lastModificationDate desc';
                $http.get(restSearchApiEndpoint + encodeURI(url)).then(function(data) {
                        var inputData = data.data;
                        var totalItems = inputData.response.numFound;
                        var loadedRuleList = inputData.response.docs;
                        angular.forEach(loadedRuleList, function(item) {
                            rulesList.push({
                                objectId: item.objectId,
                                name: item.name,
                                lastModifiedBy: item.lastModifiedBy,
                                lastModificationDate: item.lastModificationDate,
                                creationDate: item.creationDate,
                                severity: item.severity,
                                validationMessage: item.validationMessage,
                                expression: angular.isDefined(item.expression) ? item.expression : '',
                                ruleStatus: item.ruleStatus
                            });
                        });

                        if (inputRow < totalItems) {
                            var remainingRows = totalItems - inputRow;
                            that.getValidationRuleList(remainingRows, rulesList, inputRow, defer);
                        }

                        if (rulesList.length === totalItems) {
                            defer.resolve(rulesList);
                        }
                    },
                    function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            };

            self.getValidationRuleListBySearch = function() {
                return $http.get(restSearchApiEndpoint + encodeURI('TYPE:"rulesExpression" &associationExpansionLevel=0 &start=0&rows=20&sort=lastModificationDate desc'));
            };

            self.getPaginationAPI = function(filterQuery) {
                return $http.get(PPMENV.getPpmSearchUrl() + encodeURI(filterQuery));
            };

            self.createValidationRule = function(postRuleData) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Creating Validation Rule, please wait...')
                var createRuleApi = restApiEndpoint + '/rulesExpressions';
                var defer = $q.defer();
                $http({
                        method: 'POST',
                        url: createRuleApi,
                        data: JSON.stringify(postRuleData),
                        skipInterceptorError: true,
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function(data) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;
            };
            self.updateValidationRule = function(patchData, objectId) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Updating ValidationRule, please wait...')
                var updateRuleApi = restApiEndpoint + '/rulesExpressions/' + objectId;
                var defer = $q.defer();
                $http({
                        method: 'PATCH',
                        url: updateRuleApi,
                        data: JSON.stringify(patchData),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }).success(function(data) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });
                return defer.promise;
            };


            var annotations = [ // parse tree annotations
                { // Annotate relop nodes with a BOOLEAN if both sides datatypes match
                    target: function(n) {
                        return (relop(n) || boolop(n)) ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            var lType = getDatatype(t.left, symbolTable);
                            var rType = getDatatype(t.right, symbolTable);
                            if (lType !== rType) {
                                return false;
                            } else {
                                if (lType === 'BOOLEAN') {
                                    if (relop(t) && !(t.type === '=' || t.type === '!=')) {
                                        return false;
                                    }
                                }
                                return true;
                            }
                        };
                    }(symbols)),
                    /*jshint unused:false*/
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = 'BOOLEAN';
                            return o;
                        };
                    }(symbols))
                }, { // Annotate unary nodes with the left type if left is either BOOLEAN (for !) or NUMBER (for -)
                    target: function(n) {
                        return (unaryop(n)) ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            var lType = getDatatype(t.left, symbolTable);
                            if (lType === 'BOOLEAN' && t.type === 'ULOGICNOT') {
                                return true;
                            }
                            if (lType === 'NUMBER' && t.type === 'UMINUS') {
                                return true;
                            }
                            return false;
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.left, symbolTable);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate PAREN nodes with the left type 
                    target: function(n) {
                        return (n.type === 'PAREN') ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            if (t && t.left) {
                                return true;
                            } else {
                                return true;
                            }
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.left, symbolTable);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate binary operator nodes with type common across left and right
                    target: function(n) {
                        return (binop(n) && !relop(n) && !mathop(n)) ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return getDatatype(t.left, symbolTable) === getDatatype(t.right, symbolTable);
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.left, symbolTable);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate math operator nodes with type restricted across left and right
                    target: function(n) {
                        return (binop(n) && !relop(n)) ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            var lType = getDatatype(t.left, symbolTable);
                            var rType = getDatatype(t.right, symbolTable);
                            if (lType !== rType) {
                                return false;
                            } else {
                                if (lType === 'STRING') {
                                    if (t.type === '+') {
                                        return true;
                                    }
                                }
                                if (lType === 'NUMBER') {
                                    return true;
                                }
                                return false;
                            }
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.left, symbolTable);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate IF nodes with the common datatype across the THEN/ELSE
                    target: function(n) {
                        return (n.type === 'IF') ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            if (getDatatype(t.left, symbolTable) === 'BOOLEAN') {
                                if (t.right.datatype) {
                                    return true;
                                }
                            }
                            return false;
                        };
                    }(symbols)),
                    /*jshint unused:false*/
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = t.right.datatype;
                            return o;
                        };
                    }(symbols))
                }, { // Annotate a list op node ( ARG or ELEMENT ) with the datatype of their left
                    target: function(n) {
                        return listop(n) ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            if (getDatatype(t.left, symbolTable) !== 'UNDEFINED') { // TR: chk quotes ok
                                return true;
                            }
                            return false;
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.left, symbolTable);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate a SET node with the datatype of common across elements
                    target: function(n) {
                        return n.type === 'SET' ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            var that = self;
                            if (that.getListType(t) !== 'UNDEFINED') {
                                //if ( getListType(t) != "UNDEFINED" ) {
                                return true;
                            }
                            return false;
                        };
                    }(symbols)),
                    /*jshint unused:false*/
                    act: (function(symbolTable) {
                        return function(o, t) {
                            var that = self;
                            t.datatype = that.getListType(t);
                            //t.datatype = getListType(t);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate a FUNCTION node with the datatype of common across arguments
                    target: function(n) {
                        return n.type === 'FUNCTION' ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            var that = self;
                            if (that.argAndParmTypesMatch(t, symbolTable)) {
                                //if ( arg_n_ParmTypesMatch(t, symbolTable) ) {
                                return true;
                            }
                            if (isExists(t.left)) {
                                return true;
                            }
                            return false;
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.left, symbolTable);
                            return o;
                        };
                    }(symbols))
                }, { // Annotate a '.' (chain) node with the datatype of the right node
                    // Check the datatype of the left node is compatible with the implied parm of the right
                    target: function(n) {
                        return n.type === '.' ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            var that = self;
                            if (t.right.type === 'FUNCTION') {
                                var impliedType = that.getFunctionImpliedParmType(t.right, symbolTable);
                                //if ( t.right.type == "FUNCTION" ) {
                                //    var impliedType = getFunctionImpliedParmType( t.right, symbolTable );
                                if (getDatatype(t.left, symbolTable) === impliedType) {
                                    // Chaining types match
                                    return true;
                                }
                                if (impliedType === 'ANY') {
                                    // right function takes any type - e.g. exists()
                                    return true;
                                }
                            }
                            return false;
                        };
                    }(symbols)),
                    act: (function(symbolTable) {
                        return function(o, t) {
                            t.datatype = getDatatype(t.right, symbolTable);
                            return o;
                        };
                    }(symbols))
                }

            ];

            var checks = [ // parse tree semantic checks
                { // SYMBOLs must be found in the symbol table
                    target: function(n) {
                        return (n.type === 'SYMBOL') ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !symbolTable[t.left];
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Symbol: \'' + t.left + '\' not recognized.');
                        return o;
                    }
                }, { // Set value field comparisons are limited to relational operators including "includes"
                    target: function(n) {
                        if (lnr(n)) {
                            if (!(relop(n))) {
                                if (n.left && n.left.type === 'SYMBOL') {
                                    return [n.left];
                                }
                            }
                        }
                        return null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return (t.left && symbolTable[t.left] &&
                                symbolTable[t.left].isSet === true);
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Symbol: ' + t.left +
                            ' references a set valued field which can only be used in relational comparisons.');
                        return o;
                    }
                }, { // Set valued fields must be compared to sets
                    target: function(n) {
                        return (n.left && n.left.type === 'SYMBOL') ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            //return validateSet(t, symbolTable);
                            return symbolTable[t.left.left] && symbolTable[t.left.left].isSet && t.right.type !== 'SET';
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Symbol: ' + t.left.left +
                            ' references a set valued field and the expression to the right of the \'' +
                            t.type + '\' is not a set expression.');
                        return o;
                    }
                }, { // Non-Set valued fields must be compared to non-sets
                    target: function(n) {
                        return (n.left && n.left.type === 'SYMBOL') ? [n] : null;
                    },
                    qualify: (function(symbolTable) {
                        return function(t) {
                            //return validateSet(t, symbolTable);
                            return symbolTable[t.left.left] && symbolTable[t.left.left].isSet === false && t.right && t.right.type === 'SET';
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Symbol: ' + t.left.left +
                            ' references a scalar valued field and the expression to the right of the \'' +
                            t.type + '\' is a set expression.');
                        return o;
                    }
                }, { // Conditional results must be the same datatype across the THEN and the ELSE
                    target: function(n) {
                        return (n.type === 'THEN/ELSE') ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !(t.datatype && t.datatype !== 'UNDEFINED');
                        };
                    }(symbols)),
                    /*jshint unused:false*/
                    act: function(o, t) {
                        o.push('Conditional results must be the same datatype for both the \'then\' and the \'else\'');
                        return o;
                    }
                }, { // Check types across relational operators
                    target: function(n) {
                        return (relop(n)) ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !(t.datatype && t.datatype !== 'UNDEFINED');
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Incompatible datatypes compared with relational operator: ' + t.type);
                        return o;
                    }
                }, { // Check types across boolean operators
                    target: function(n) {
                        return (boolop(n)) ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !(t.datatype && t.datatype === 'BOOLEAN');
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Boolean operator: ' + t.type + ' requires both sides to have boolean values');
                        return o;
                    }
                }, { // Check types across math operators 
                    target: function(n) {
                        return (mathop(n)) ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !(t.datatype && t.datatype !== 'UNDEFINED');
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Calculation operator: ' + t.type + ' requires compatible operands.');
                        return o;
                    }
                }, { // Check function parm / arg type compatibility
                    target: function(n) {
                        return (n.type === 'FUNCTION') ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !(t.datatype && t.datatype !== 'UNDEFINED');
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('Arguments passed to the function ' + t.left.left + ' must match the parameter type.');
                        return o;
                    }
                }, { // Check chaining composition operators ('.') for predecessor / successor datatype compatibility
                    target: function(n) {
                        return (n.type === '.') ? [n] : null;
                    },
                    /*jshint unused:false*/
                    qualify: (function(symbolTable) {
                        return function(t) {
                            return !(t.datatype && t.datatype !== 'UNDEFINED');
                        };
                    }(symbols)),
                    act: function(o, t) {
                        o.push('The chained function ' + t.right.left.left + ' implied parameter must match the datatype of its predecessor.');
                        return o;
                    }
                }

            ];
            /*jshint unused:false*/
            function validateSet(node, symbolTable) {
                var canExecute = false;
                var types = ['SET', 'FUNCTION'];
                if (symbolTable[node.left.left] && symbolTable[node.left.left].isSet) {
                    if (types.indexOf(node.right.type) === -1) {
                        canExecute = true;
                    } else if (node.right.type === 'FUNCTION' && node.right.left.left !== 'exists') {
                        canExecute = true;
                    }
                }
                return canExecute;
            }

            self.validateParseTree = function(node, nodeIsRoot, entry, symbols, out) {
                // semantic checking of the syntax tree
                if (node == null) {
                    return out;
                }
                if (typeof node === 'object') {
                    // literal leaf nodes are marked in a higher node with their type

                    // initial value is error output array
                    out = checks.reduce(applyTo(node), out);

                    out = this.validateParseTree(node.left, false, entry, symbols, out);
                    out = this.validateParseTree(node.right, false, entry, symbols, out);

                }

                if (nodeIsRoot) {
                    entry.type = getDatatype(node, symbols);
                }

                return out;

            };


            self.annotateParseTree = function(node, nodeIsRoot, symbols, out) {
                // semantic annotation of the syntax tree
                if (node == null) {
                    return out;
                }
                if (typeof node === 'object') {
                    if (node.type === 'SYMBOL') {
                        if (node.left !== null) {
                            this.shortNamesList.push(node.left);
                        }
                        if (node.right !== null) {
                            this.shortNamesList.push(node.right);
                        }
                    }
                    // literal leaf nodes are marked in a higher node with their type
                    out = this.annotateParseTree(node.left, false, symbols, out);
                    annotations.reduce(applyTo(node), out);

                    out = this.annotateParseTree(node.right, false, symbols, out);
                    annotations.reduce(applyTo(node), out);
                }

                return out;

            };

            function applyTo(node) {
                return function(out, c) {
                    var targetNodes = c.target(node);
                    if (targetNodes) {
                        return out.concat(
                            targetNodes.filter(c.qualify)
                            .reduce(c.act, []) // pass in array to capture errors
                        );
                    }
                    return out;
                };
            }

            function getDatatype(n, symbolTable) {
                if (n.datatype) {
                    return n.datatype;
                }
                if ('NUMBER STRING BOOLEAN DATE'.indexOf(n.type) >= 0) {
                    return n.type;
                }
                if (n.type === 'SYMBOL') {
                    if (symbolTable[n.left]) {
                        return symbolTable[n.left].type;
                    }
                }

                return 'UNDEFINED';
            }

            function lnr(n) {
                return n.left && n.right;
            }

            self.collectBindings = function(node, symbolTable, bindings) {
                if (node.left) {
                    bindings = this.collectBindings(node.left, symbolTable, bindings);
                }
                if (node.right) {
                    bindings = this.collectBindings(node.right, symbolTable, bindings);
                }
                if (node.type === 'SYMBOL') {
                    var symbolEntry = symbolTable[node.left];
                    if (!(symbolEntry && symbolEntry.kind === 'function')) {
                        if (bindings.indexOf(node.left) === -1) {
                            bindings.push(node.left);
                        }
                    }
                }
                return bindings;
            };

            self.hasUnsafeSelfReferences = function(entry, node, isRightBelowThenElse, ifCondBoolean) {

                if (!node) {
                    return false;
                }
                if (node.type === 'SYMBOL' && node.left === entry.symbol) {
                    if (!isRightBelowThenElse && !ifCondBoolean) {
                        return true;
                    }

                    if (entry.kind !== 'field') {
                        return true; // only data fld self references are safe
                    }
                }

                if (this.hasUnsafeSelfReferences(entry, node.left, (node.type === 'THEN/ELSE'), (ifCondBoolean || node.type === 'IF'))) {
                    // in an IF, node.left is the IF condition boolean
                    return true;
                }

                if (this.hasUnsafeSelfReferences(entry, node.right, (node.type === 'THEN/ELSE'), false)) {
                    return true;
                }

                return false;

            };

            self.upsertSymbol = function(symbolTable, argEntry) {
                var entry = symbolTable[argEntry.symbol];
                if (entry) {
                    // Update the existing entry selectively with the new values from argEntry
                    for (var k in argEntry) {
                        // Disallow some updates
                        if (k === 'kind' && entry[k] === 'field') {
                            // can't change the kind of field
                            $log.log('cant change the kind of field');
                        } else if (k === 'type' && entry['kind'] === 'field') {
                            // can't change a data field type - decided by inbound JSON data dictionary
                            $log.log('cant change a data field type - decided by inbound JSON data dictionary');
                        } else if (k === 'isSet') {
                            // can't change isSet (only valid for 'field') - determined by inbound JSON data dictionary
                            $log.log('cant change isSet (only valid for field) - determined by inbound JSON data dictionary');
                        } else {
                            entry[k] = argEntry[k];
                        }
                    }
                } else {
                    // if entry is not in the table, insert into table
                    symbolTable[argEntry.symbol] = argEntry;
                }
                return symbolTable[argEntry.symbol];
            };

            self.convertBusinessDatatype = function(businessDatatype) {
                // function to convert a business data type to an underlying (Javascript) data type
                if (businessDatatype.toLowerCase().indexOf('enum') > -1) {
                    return 'STRING';
                }
                var datatype = {
                    'currency': 'NUMBER',
                    'percentage': 'NUMBER',
                    'decimal': 'NUMBER',
                    'integer': 'NUMBER',
                    'datetime': 'STRING',
                    'enum': 'STRING',
                    'boolean': 'BOOLEAN',
                    'phone': 'STRING',
                    'string': 'STRING'
                };
                return datatype[businessDatatype.toLowerCase()];
            };

            self.argAndParmTypesMatch = function(n, symbolTable) {
                // make sure the number of arguments matches the number of parms
                // make sure the types of the arguments matches the corresponding parms
                var doMatch = true;
                var symbol = symbolTable[n.left.left]; // left -> symbol -- left.left -> symbol name
                var numParms = 0;
                var parmTypes = [];
                if (symbol) {
                    parmTypes = symbol.parmTypes; // left -> symbol -- left.left -> symbol name
                    numParms = parmTypes.length;
                } else {
                    numParms = 0;
                }
                for (var l = n.right, i = 0; l; l = l.right, i++) {
                    if (i >= numParms) {
                        doMatch = false;
                    }
                }
                for (var r = n.right, j = 0; r && j < numParms; r = r.right, j++) {
                    if (!(r.datatype && r.datatype === parmTypes[j])) {
                        doMatch = false;
                    }
                }
                return doMatch;
            };

            function isExists(n) {
                return n.type === 'SYMBOL' && n.left === 'exists';
            }

            self.getFunctionImpliedParmType = function(functionNode, symbolTable) {
                if (functionNode.type === 'FUNCTION') {
                    if (functionNode.left.type === 'SYMBOL') {
                        if (functionNode.left.left) {
                            var symbolEntry = symbolTable[functionNode.left.left];
                            if (symbolEntry.kind === 'function') {
                                return symbolEntry.impliedParmType;
                            }
                        }
                    }
                }
                return 'UNDEFINED';

            };

            self.getListType = function(n) {
                var type = n.left.datatype ? n.left.datatype : 'UNDEFINED';
                for (var l = n.left; l && type !== 'UNDEFINED'; l = l.right) {
                    if (!(l.datatype && l.datatype === type)) {
                        type = 'UNDEFINED';
                    }
                }
                return type;
            };

            self.insertValidShortNameToSymbols = function(shortNames) {
                var shortNamesDetailsApi = mediaApiEndpoint + '/ShortNameDictionaries/ShortNamesDetails';
                var defer = $q.defer();
                var count = 0;
                var that = self;

                $http.post(shortNamesDetailsApi, shortNames, {
                        'Content-Type': 'application/json'
                    }).success(function(data) {
                        if (data.length === 0) {
                            defer.resolve(data);
                        }
                        angular.forEach(data, function(shorNameObj) {
                            var isSet = false;
                            if (shorNameObj.IsMultiValue) {
                                isSet = true;
                            }
                            var convertedBusineesType = that.convertBusinessDatatype(shorNameObj.BusinessDataType);
                            var entry = {
                                symbol: shorNameObj.ShortName,
                                kind: 'field',
                                type: convertedBusineesType,
                                businessDataType: shorNameObj.BusinessDataType,
                                path: shorNameObj.Path,
                                isSet: isSet // depends upon if the data field is multi-valued or not – if mv, set to true
                            };
                            that.upsertSymbol(symbols, entry);
                            count++;
                            if (count === data.length) {
                                defer.resolve(data);
                            }

                        });
                    })
                    .error(function(reason) {
                        //ConfirmationModalFactory.close();
                        defer.reject(reason);
                    });
                return defer.promise;

            };

            self.validateNetwork = function(packageName, symbolTable, validationMsgDict) {
                // Browser/client side walk of all expressions / validations to find issues
                // needing attention in the network
                var startTime = Date.now();
                var isValid = true;
                var that = self;
                for (var s in symbolTable) {
                    if (s) {
                        var entry = symbolTable[s];
                        if (entry.kind !== 'function' && entry.source) {
                            var parseOk = true;
                            var result = '';
                            try {
                                result = parser.parse(entry.source);
                            } catch (e) {
                                parseOk = false;
                            }
                            if (parseOk) {
                                entry.bindings = that.collectBindings(result, symbolTable, []);
                            }
                        }
                    }
                }

                validationMsgDict[packageName] = validationMsgDict[packageName] || [];
                var validationMsgs = validationMsgDict[packageName];


                var isFixPoint = that.ensureFixPoint(symbols, validationMsgs);
                validationMsgs.push.apply(validationMsgDict[packageName], validationMsgs);

                if (isFixPoint) {
                    var edges = extractNetworkEdges(symbolTable);
                    var dependencyOrderedSymbols = tsort(edges).reverse();
                    var thatSelf = self;
                    var validateEntry = function(symbolTable, validationMsgDict) {
                        return function(symbol) {
                            validationMsgDict[symbol] = validationMsgDict[symbol] || [];
                            validationMsgs = validationMsgDict[symbol];

                            var entry = symbolTable[symbol];
                            var result = '';
                            if (entry && entry.source) {
                                try {
                                    result = parser.parse(entry.source);
                                } catch (e) {
                                    validationMsgs.push(e);
                                }

                                if (thatSelf.hasUnsafeSelfReferences(entry, result, false, false)) {
                                    entry.hasUnsafeSelfReference = true;
                                }

                                var aMsgs = thatSelf.annotateParseTree(result, true, symbolTable, []);
                                validationMsgs.push.apply(validationMsgs, aMsgs);
                                var vMsgs = thatSelf.validateParseTree(result, true, entry, symbolTable, []);
                                validationMsgs.push.apply(validationMsgs, vMsgs);
                                validationMsgDict[symbol].push.apply(validationMsgDict[symbol], validationMsgs);
                                if (validationMsgDict[symbol].length === 0) {
                                    // generate the target javscript output
                                    // pass an empty string as the initial output buffer
                                    thatSelf.generateTargetCode(result, true, entry, symbolTable, '');
                                }
                            }
                        };
                    };
                    dependencyOrderedSymbols.forEach(validateEntry(symbolTable, validationMsgDict));

                } else {
                    isValid = false;
                    validationMsgDict[packageName].push('Fix point check failed.');
                }
                validationMsgDict[packageName].push('Validation Duration: ' + (Date.now() - startTime) + ' milliseconds.');
                return isValid;
            };

            self.ensureFixPoint = function(symbolTable, messages) {
                var that = self;
                var selfReference = false;
                for (var s in symbolTable) {
                    if (symbolTable[s].hasUnsafeSelfReference) {
                        // Entry was annotated earlier
                        // A safe self ref = an simple self ref(not in expr) in an THEN or an ELSE
                        // or a self ref in a IF condition boolean
                        messages.push('Self referencing expression detected at expression: ' + s + '.');
                        selfReference = true;
                    }
                }
                // NB: currently only detecting a single cycle, other cycles might exist,
                // so this function needs to be re-run until it returns true
                var cyclicSymbol = that.cycleDetection(symbolTable);
                if (cyclicSymbol) {
                    // output message indicating a cycle has been detected
                    messages.push('Cycle in expressions detected at expression: ' + cyclicSymbol + '.');
                    return false;
                }
                return selfReference ? false : true;
            };

            function extractNetworkEdges(symbolTable) {
                var edges = [];
                for (var s in symbolTable) {
                    if (s) {
                        var bindings = symbolTable[s].bindings;
                        var len = bindings ? bindings.length : 0;
                        if (len) {
                            for (var i = 0; i < len; i++) {
                                edges.push([s, bindings[i]]);
                            }
                        } else { // add to the graph from the distinguished "_top" node
                            edges.push(['_^', s]);
                        }
                    }
                }
                return edges;
            }

            function tsort(edges) {
                var nodes = {}, // hash: stringified id of the node => { id: id, afters: lisf of ids }
                    sorted = [], // sorted list of IDs ( returned value )
                    visited = {}; // hash: id of already visited node => true

                var Node = function(id) {
                    this.id = id;
                    this.afters = [];
                };

                // 1. build data structures
                edges.forEach(function(v) {
                    var from = v[0],
                        to = v[1];
                    if (!nodes[from]) {
                        nodes[from] = new Node(from);
                    }
                    if (!nodes[to]) {
                        nodes[to] = new Node(to);
                    }
                    nodes[from].afters.push(to);
                });

                // 2. topological sort
                Object.keys(nodes).forEach(function visit(idstr, ancestors) {
                    var node = nodes[idstr],
                        id = node.id;

                    // if already exists, do nothing
                    if (visited[idstr]) {
                        return;
                    }

                    if (!Array.isArray(ancestors)) {
                        ancestors = [];
                    }

                    ancestors.push(id);

                    visited[idstr] = true;

                    node.afters.forEach(function(afterID) {
                        if (ancestors.indexOf(afterID) >= 0 && node.id !== afterID) { // if already in ancestors, a closed chain exists.
                            throw new Error('closed chain : ' + afterID + ' is in ' + id);
                        }
                        visit(afterID.toString(), ancestors.map(function(v) {
                            return v;
                        })); // recursive call
                    });

                    sorted.unshift(id);
                });

                return sorted;
            }

            self.generateTargetCode = function(node, nodeIsRoot, entry, symbols, out) {
                // generate target code from annotated, validated parse tree
                var that = self;
                if (node === null) {
                    return out;
                }

                if (node.type === 'SYMBOL' || node.type === 'NUMBER' || node.type === 'STRING' || node.type === 'BOOLEAN' || node.type === 'CONSTANT') {

                    if (node.type === 'CONSTANT') {
                        // PI and E require Math class
                        out = out + ' Math.' + node.left + ' ';
                    } else {
                        out = that.setInitialValue(node, out, entry);

                    }
                } else {
                    out = subFnGenerateTargetCode(node, nodeIsRoot, entry, symbols, out);

                }

                if (nodeIsRoot) {
                    // save the generated javascript string in the symbol table entry
                    entry.targetCode = out;
                }

                return out;
            };

            self.setInitialValue = function(node, out, entry) {
                if (node.type === 'SYMBOL') {
                    // check if this is a safe self reference, if so, provide initial value
                    if (node.left === entry.symbol) {
                        // current value of field will have been bound
                        out = out + ' this.result.initial_value() ';
                    } else {
                        out = out + ' ' + node.left + ' ';
                    }
                } else {
                    out = out + ' ' + node.left + ' ';
                }
                return out;
            };

            function subFnGenerateTargetCode(node, nodeIsRoot, entry, symbols, out) {
                var that = self;

                if (node.right && node.right.type === 'SET') {
                    out = generateTargetCodeForSet(node, entry, symbols, out);

                } else if (node.type === '.' && node.right.type === 'FUNCTION' && node.right.left &&
                    node.right.left.type === 'SYMBOL' && node.right.left.left === 'exists' && node.left.type === 'SYMBOL') {
                    out = generateTargetCodeForShiftExists(node, entry, out);
                } else if (node.type === '.' && node.datatype === 'NUMBER' && needsMathObject[node.right.left.left]) {
                    out = out + generateNestedFunction(node, nodeIsRoot, entry, symbols, out);

                } else if (node.type === 'FUNCTION' && node.left.left !== 'exists' && !needsMathObject[node.left.left]) {
                    out = generateTargetCodeForFunction(node, entry, symbols, out);

                } else if (node.type === 'IF') {
                    out = generateTargetCodeForIf(node, entry, symbols, out);
                } else if (node.type === '^') {
                    out = generateTargetCodeForHat(node, entry, symbols, out);
                } else if (node.type === 'PAREN') {
                    // Translate the parenthesis into parenthesis
                    out += '( ' + that.generateTargetCode(node.left, false, entry, symbols, '') + ' )';
                } else if (node.type === 'ULOGICNOT') {
                    var temp = that.generateTargetCode(node.left, false, entry, symbols, '');
                    out += '(!( ' + temp + ' ))';

                } else if (node.type === 'UMINUS') {
                    // Translate the parenthesis into parenthesis
                    out += '( -( ' + that.generateTargetCode(node.left, false, entry, symbols, '') + ' ) )';
                } else {
                    out = generateTargetCodeForRemaining(node, entry, symbols, out);
                }
                return out;
            }


            function generateTargetCodeForShiftExists(node, entry, out) {
                // look for exists() to the right, if find, need to switch from chain to nest form invocation
                // target code should chg foo.exists() to exists(foo)
                out += ' exists(' + node.left.left + ')';
                entry.existsList = entry.existsList || [];
                if (entry.existsList.indexOf(node.left.left) === -1) {
                    // record the symbol a one checked by exist()
                    entry.existsList.push(node.left.left);
                }
                return out;
            }

            function generateTargetCodeForSet(node, entry, symbols, out) {
                var that = self;
                out = out + ' setFieldOp(' + node.left.left + ', "' + that.translateOps(node.type) + '", ';

                out = out + '[';
                // e is an element node
                for (var e = node.right.left; e; e = e.right) {
                    if (e !== node.right.left) {
                        out = out + ',';
                    }
                    out = that.generateTargetCode(e.left, false, entry, symbols, out);
                }
                out = out + '])';
                return out;
            }

            function generateTargetCodeForHat(node, entry, symbols, out) {
                var that = self;
                // Translate the hat into Math.pow() invocation
                out += ' Math.pow(' + that.generateTargetCode(node.left, false, entry, symbols, out) + ', ' + that.generateTargetCode(node.right, false, entry, symbols, out) + ' )';
                return out;
            }

            function generateTargetCodeForFunction(node, entry, symbols, out) {
                var that = self;
                // left is function name, right is args
                if (node.left.type === 'SYMBOL') {
                    if (node.left.left) {
                        out = out + node.left.left;
                    }
                }
                if (node.left.left !== 'length') {
                    out += '(';
                    for (var argNode = node.right; argNode; argNode = argNode.right) {
                        if (argNode.type === 'ARG') {
                            // create target code for this argument
                            if (argNode !== node.right) { // the first argument
                                // commas separating arguments
                                out += ', ';
                            }
                            out = that.generateTargetCode(argNode.left, false, entry, symbols, out);
                        }
                    }
                    out += ')';
                }
                return out;
            }

            function generateTargetCodeForIf(node, entry, symbols, out) {
                var that = self;
                // left is boolean condiation, right is THEN & ELSE consequences
                out += 'if';
                out = that.generateTargetCode(node.left, false, entry, symbols, out);
                out += ' { ';
                var thenElseNode = node.right;
                if (thenElseNode.type === 'THEN/ELSE') {
                    var ifOut = that.generateTargetCode(thenElseNode.left, false, entry, symbols, '');
                    out += ' this.result(' + ifOut + '); } else { ';
                    var elseOut = that.generateTargetCode(thenElseNode.right, false, entry, symbols, '');
                    out += 'this.result(' + elseOut + ');}';
                }
                return out;
            }

            function generateTargetCodeForRemaining(node, entry, symbols, out) {
                var that = self;
                out += '(';
                out = that.generateTargetCode(node.left, false, entry, symbols, out);
                if (!(node.type === 'ARG' || node.type === 'SET' || node.type === 'ELEMENT')) {
                    out = out + ' ' + that.translateOps(node.type) + ' ';
                }
                if (node.right) {
                    // for boolExpr relations - don't dump out the type
                    out = that.generateTargetCode(node.right, false, entry, symbols, out);
                }
                if (out.indexOf('! exists(') === -1) {
                    out += ')';
                }
                return out;
            }

            self.translateOps = function(op) {
                // translate expression language operators to Javascript operators
                if (op === '!=') {
                    return '!==';
                }
                if (op === '=') {
                    return '===';
                }
                if (op === 'INCLUDES') {
                    return '>=';
                }
                return op;
            };

            function emit(stmtStr) {
                var buffer = '';
                return buffer += stmtStr;
            }

            function emitln(stmtStr) {
                //        return emit( stmtStr + '\n' );
                return emit(stmtStr + '\n');
            }

            function emitList(list, quote) {
                var buffer = '';
                if (list) {
                    list.forEach(function(s, idx) {
                        var str = quote ? '"' + s + '"' : s;
                        if (idx === 0) {
                            // no comma for prior element if first element
                            buffer += emit(str);
                        } else {
                            buffer += emit(', ' + str);
                        }
                    });
                }
                return buffer;
            }

            self.cycleDetection = function(symbolTable) {
                // Prepare a DFS to find cycles in the symbols graph
                // NB: only visiting symbols in the symbol table
                // because non-symbol-table symbols can't refer to other symbols
                var color = {};

                for (var s in symbolTable) {
                    if (s) {
                        color[s] = 'white';
                    }
                }
                for (var st in symbolTable) {
                    if (color[st] === 'white') {
                        if (DFSVisit(symbolTable, st, color)) {
                            return st;
                        }
                    }
                }

                return null;
            };

            function DFSVisit(symbolTable, s, color) {
                color[s] = 'gray';
                var len = symbolTable[s].bindings ? symbolTable[s].bindings.length : 0;
                for (var i = 0; i < len; i++) {
                    var s2 = symbolTable[s].bindings[i];
                    if (color[s2] === 'gray' && s !== s2) {
                        // self reference detection is done more separately in ensureFixPoint() 
                        return true;
                    } else if (color[s2] === 'white') {
                        if (DFSVisit(symbolTable, s2, color)) {
                            return true;
                        }
                    }
                }
                color[s] = 'black';
                return false;
            }

            self.generateNetwork = function(packageName, validationMsgDict) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Compiling all the rules, please wait...')
                var that = self;
                var symbolTable = that.symbols;
                var isValid = that.validateNetwork(packageName, symbolTable, validationMsgDict);
                if (!isValid) {
                    // Don't return the target code
                    return null;
                }
                var messages = createValidationFactory(symbolTable);

                var expressions = createExpression(symbolTable);

                // generate the javascript source for accessors
                var accessorFactory = '';
                accessorFactory += emitln('define(function() {');
                // accessorFactory += emitln('var accessorObject = {');
                accessorFactory += emitln('var accessorArray = [');
                var firstForAccessor = true;
                var accessorCount = 0;
                for (var symbolForAccessor in symbolTable) {

                    if (symbolForAccessor) {
                        accessorCount++;
                        var entryForAccessor = symbolTable[symbolForAccessor];
                        if (entryForAccessor.kind === 'field') {
                            // only emit expressions that were able to compile
                            if (firstForAccessor) {
                                firstForAccessor = false;
                            } else {
                                accessorFactory += emit(',');
                            }
                            // accessorFactory += emitln('accessorObject' + accessorCount + ':{');
                            accessorFactory += emitln('{');
                            accessorFactory += emitln('  name: "' + symbolForAccessor + '",');
                            if (entryForAccessor.path) {
                                accessorFactory += emitln('  path: "' + entryForAccessor.path + '",');
                            }
                            accessorFactory += emitln('  type: "' + entryForAccessor.type + '",');
                            accessorFactory += emitln('  isSet: ' + entryForAccessor.isSet + '');
                            accessorFactory += emitln('}');
                        }
                    }
                }
                //accessorFactory += emitln('};');
                //accessorFactory += emitln('return accessorObject;');
                accessorFactory += emitln('];');
                accessorFactory += emitln('return accessorArray;');
                accessorFactory += emitln('});');
                var accessors = accessorFactory;


                var localVariables = createLocalVariable(symbolTable);

                return {
                    message: messages,
                    expression: expressions,
                    accessor: accessors,
                    localVariable: localVariables
                };
            };



            function createLocalVariable(symbolTable) {
                // generate the javascript source for local variables
                var localFactory = '';
                localFactory += emitln('define(function() {');
                // localFactory += emitln('var localDictElem = {');
                localFactory += emitln('var localVarArray = [');
                var firstForLocal = true;
                var localCount = 0;
                for (var symbolForLocal in symbolTable) {

                    if (symbolForLocal) {
                        localCount++;
                        var entryForLocal = symbolTable[symbolForLocal];
                        if (entryForLocal.kind === 'validation') {
                            // only emit expressions that were able to compile
                            if (firstForLocal) {
                                firstForLocal = false;
                            } else {
                                localFactory += emit(',');
                            }
                            // localFactory += emitln('local' + localCount + ':{');
                            localFactory += emitln('{');
                            localFactory += emitln('  name: "' + symbolForLocal + '",');
                            localFactory += emitln('  type: "' + entryForLocal.type + '"');
                            localFactory += emitln('}');
                        }
                    }
                }

                for (var symbolForLocalMsg in symbolTable) {

                    if (symbolForLocalMsg) {
                        localCount++;
                        var entryForLocalMsg = symbolTable[symbolForLocalMsg];
                        if (entryForLocalMsg.kind === 'validation') {
                            // only emit expressions that were able to compile
                            if (firstForLocal) {
                                firstForLocal = false;
                            } else {
                                localFactory += emit(',');
                            }
                            // localFactory += emitln('local' + localCount + ':{');
                            localFactory += emitln('{');
                            localFactory += emitln('  name: "' + symbolForLocalMsg + '_msg"');
                            localFactory += emitln('}');
                        }
                    }
                }
                localFactory += emitln('];');
                localFactory += emitln('return localVarArray;');
                localFactory += emitln('});');
                return localFactory;
            }

            function createValidationFactory(symbolTable) {
                var messageFactory = '';

                // generate the javascript source for validations
                messageFactory += emitln('define(function() {');
                // messageFactory += emitln('var variableFactory = {');
                messageFactory += emitln('var messageArray = [');
                var firstForVariableFactory = true;
                var messageCount = 0;
                for (var symbolForVariableFactory in symbolTable) {
                    if (symbolForVariableFactory) {
                        messageCount++;
                        var entry = symbolTable[symbolForVariableFactory];
                        if (entry.kind === 'validation') {
                            // only emit validations that were able to compile
                            if (firstForVariableFactory) {
                                firstForVariableFactory = false;
                            } else {
                                messageFactory += emit(',');
                            }
                            // messageFactory += emitln('  variableFactory' + messageCount + ':{');
                            messageFactory += emitln('  {');
                            messageFactory += emitln('  name: "' + symbolForVariableFactory + '_msg",');
                            messageFactory += emitln('  bindings: ["' + symbolForVariableFactory + '"],');
                            messageFactory += emitln('  level: "' + entry.level + '",');
                            messageFactory += emitln('  failureIf: false,');
                            messageFactory += emitln('  message: "' + entry.message + '"');
                            messageFactory += emitln('}');
                        }
                    }
                }
                // messageFactory += emitln('}');
                // messageFactory += emitln('return variableFactory;');
                messageFactory += emitln('];');
                messageFactory += emitln('return messageArray;');
                messageFactory += emitln('});');
                return messageFactory;
            }

            function createExpression(symbolTable) {
                // generate the javascript source for expressions (variables)
                var edges = extractNetworkEdges(symbolTable);
                var dependencyOrderedSymbols = tsort(edges).reverse();
                var expressionFactory = '';
                expressionFactory += emitln('define(function() {');
                // expressionFactory += emitln('var expression = {');
                expressionFactory += emitln('var expressionArray = [');
                var firstForExpression = true;
                var expressionCount = 0;
                //for (var symbolForExpression in symbolTable) {
                dependencyOrderedSymbols.forEach(function(symbolForExpression) {
                    if (symbolForExpression) {
                        expressionCount++;
                        var entryForExpression = symbolTable[symbolForExpression];
                        if ((entryForExpression && entryForExpression.kind === 'validation' && entryForExpression.targetCode !== undefined)) {
                            // only emit expressions/fields that were able to compile
                            if (firstForExpression) {
                                firstForExpression = false;
                            } else {
                                expressionFactory += emit(',');
                            }
                            // expressionFactory += emitln('expression' + expressionCount + ':{');
                            expressionFactory += emitln('{');
                            expressionFactory += emitln('  name: "' + symbolForExpression + '",');
                            expressionFactory += emitln('  bindings: [' + emitList(entryForExpression.bindings, true) + '],');
                            expressionFactory += emitln('  expressionFunction: ');
                            expressionFactory += emitln('    function( ' + emitList(entryForExpression.bindings, false) + ') {');
                            if (entryForExpression.targetCode.indexOf('if(') !== -1) {
                                expressionFactory += emitln('      ' + entryForExpression.targetCode + ',');
                            } else {
                                expressionFactory += emitln('      if' + setTargetCode(entryForExpression) + '{');
                                expressionFactory += emitln('           this.result(false);');
                                expressionFactory += emitln('        }else{');
                                expressionFactory += emitln('      this.result(true);}');
                                expressionFactory += emitln('    },');
                            }
                            expressionFactory += emitln('  shortNamesInExists: [' + emitList(entryForExpression.existsList, true) + ']');
                            expressionFactory += emitln('}');
                        }
                    }
                });
                // expressionFactory += emitln('}');
                // expressionFactory += emitln('return expression;');
                expressionFactory += emitln('];');
                expressionFactory += emitln('return expressionArray;');
                expressionFactory += emitln('});');
                return expressionFactory;
            }


            function setTargetCode(entryForExpression) {

                var targetCode = '';
                if (entryForExpression.targetCode.indexOf('(') === 0) {
                    targetCode = entryForExpression.targetCode;
                } else {
                    targetCode = '(' + entryForExpression.targetCode + ')';
                }

                return targetCode;
            }

            self.getAndUploadScriptFilesInCM = function(freshScriptFileDatas) {
                var that = self;
                var defer = $q.defer();
                //ConfirmationModalFactory.open('Updating show rule, please wait...');
                that.getSriptFilesObjectId()
                    .then(function(finalOutPut) {
                        that.doScriptUploadInCm(freshScriptFileDatas, finalOutPut.scriptFileObject)
                            .then(function(status) {
                                defer.resolve(status);
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });
                    }, function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });


                return defer.promise;
            };

            self.getSriptFilesObjectId = function() {
                var scriptFileObject = {};
                var finalOutPut = {};
                var lastModifiedObject = [];
                var defer = $q.defer();
                var count = 0;
                $http.get(restApiEndpoint + '/scripts').success(function(data) {

                    angular.forEach(data, function(scriptData) {
                        var fileName = scriptData.name;
                        scriptFileObject[fileName] = scriptData.objectId;
                        lastModifiedObject.push(scriptData.lastModificationDate);
                        count++;
                        if (count === 4) {
                            finalOutPut['scriptFileObject'] = scriptFileObject;
                            finalOutPut['lastModifiedObject'] = lastModifiedObject;
                            defer.resolve(finalOutPut);
                        }
                    });

                    if (data.length < 4) {
                        finalOutPut['scriptFileObject'] = scriptFileObject;
                        finalOutPut['lastModifiedObject'] = lastModifiedObject;
                        defer.resolve(finalOutPut);
                    }

                }).error(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(data);
                });

                return defer.promise;
            };


            self.deleteScriptFilesFromCM = function(objectId) {
                var associatebExpressionApi = restApiEndpoint + '/scripts/' + objectId;
                var defer = $q.defer();
                if (objectId !== undefined && objectId !== null && objectId !== '') {

                    $http({
                            method: 'DELETE',
                            url: associatebExpressionApi,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        }).success(function() {
                            defer.resolve();
                        })
                        .error(function(reason) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.reject(reason);
                        });
                } else {
                    //ConfirmationModalFactory.close();
                    defer.resolve();
                }
                return defer.promise;
            };

            self.uploadFileInCM = function(fileName, scriptFileData) {
                var file = [];
                var updateItem = {};
                var defer = $q.defer();
                file.push(new Blob([scriptFileData], {
                    type: 'application/javascript'
                }));
                updateItem = {
                    'name': fileName + '.js'
                };
                var metadata = JSON.stringify({
                    'properties': updateItem
                });
                file.push(new Blob([metadata], {
                    type: 'application/json'
                }));
                $upload.upload({
                    url: restApiEndpoint + '/scripts',
                    headers: {
                        'Content-Type': undefined,
                        'Authorization': $auth.getApiToken()
                    },
                    fileName: [fileName, 'metadata'],
                    fileFormDataName: ['file', 'metadata'],
                    file: file
                }).success(function(data, status) {

                    if (status === 200) {
                        defer.resolve(data);

                    } else {
                        defer.reject(data);
                    }
                }).error(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(data);
                });

                return defer.promise;
            };

            self.doScriptUploadInCm = function(outObj, scriptFileObject) {
                var defer = $q.defer();
                var scriptFileCount = 0;
                var totalScriptFileCount = 4;
                var that = self;
                angular.forEach(outObj, function(scriptFileData, fileName) {

                    var scriptFileName = '';
                    if (scriptFileObject !== undefined && scriptFileObject !== null) {
                        var objectId = scriptFileObject[fileName + '.js'];
                        if (objectId) {
                            scriptFileName = objectId; // really objectId not file name
                        }
                    }

                    if (scriptFileName === '') {
                        // previous version of this file missing, create a new one
                        that.uploadFileInCM(fileName, scriptFileData)
                            .then(function(data) {
                                scriptFileCount++;
                                if (scriptFileCount === totalScriptFileCount) {
                                    // var status = 'Build Success';
                                    defer.resolve(data);
                                }
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });
                    } else {
                        // we found the previous version, delete it first, then add the new version
                        that.deleteScriptFilesFromCM(scriptFileName)
                            .then(function() {
                                that.uploadFileInCM(fileName, scriptFileData)
                                    .then(function(data) {
                                        scriptFileCount++;
                                        if (scriptFileCount === totalScriptFileCount) {
                                            // var status = 'Build Success';
                                            defer.resolve(data);
                                        }
                                    }, function(reason) {
                                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                        defer.reject(reason);
                                    });
                            }, function(reason) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                defer.reject(reason);
                            });
                    }
                });


                return defer.promise;
            };

            function relop(n) {
                return n.type !== '!' && '< > = <= >= != INCLUDES'.indexOf(n.type) >= 0;
            }

            function binop(n) {
                return relop(n) || mathop(n) || boolop(n) || n.type === 'THEN/ELSE';
            }

            function unaryop(n) {
                return n.type === 'ULOGICNOT' || n.type === 'UMINUS';
            }

            function mathop(n) {
                return n && n.type &&
                    '+ - * / ^'.indexOf(n.type) >= 0;
            }

            function boolop(n) {
                return '&& ||'.indexOf(n.type) >= 0;
            }

            function listop(n) {
                return n.type === 'ELEMENT' || n.type === 'ARG';
            }

            /*PONVT-1320 remove spaces, breaks and unnecessary formatting html tags in the provided expression*/
            self.unescapeText = function(escapedHTML) {
                return escapedHTML.replace(/&nbsp;/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/[<]br[^>]*[>]/g, '').replace(/&amp;/g, '&').replace(/<[^>]+>/gm, '');
            };

            self.getNameWithPlaceholder = function(word, dispName) {
                /*regex patteren to match last occuraence of the word in string */
                var pat = new RegExp('(\\b' + word + '\\b)(?!.*\\b\\1\\b)', 'i');
                var nameWithPlaceHolder = dispName;
                var inputString = '<input id=' + word + 'Id' + ' type="text" class="textWithoutBorder"  placeholder=' + word + ' onkeypress="this.style.width = ((this.value.length + 1) * 8) + \'px\';"  >';
                var inputStringAlongWidth = setWidth(inputString);
                nameWithPlaceHolder = nameWithPlaceHolder.replace(pat, inputStringAlongWidth);

                return nameWithPlaceHolder;
            };

            function setWidth(inputString) {
                var inputStringAlongWidth = inputString;
                if (inputStringAlongWidth.indexOf('width:') === -1) {
                    var inputElement = $document[0].createElement('input');
                    inputElement.innerHTML = inputStringAlongWidth;
                    var firstChildElement = inputElement.firstChild;
                    if (firstChildElement.placeholder) {
                        var placeholderLength = firstChildElement.placeholder.length;
                        var width = ((placeholderLength + 1) * 8) + 'px';
                        inputStringAlongWidth = insertAt(inputStringAlongWidth, inputStringAlongWidth.length - 1, 'style=' + '"width:' + width + '"');
                    }
                }
                return inputStringAlongWidth;
            }

            function insertAt(src, index, str) {
                return src.substr(0, index) + str + src.substr(index);
            }

            function generateNestedFunction(node, nodeIsRoot, entry, symbols, out) {
                var that = self;
                var myOut = '';
                if (node.left.type === '.') {
                    if (needsMathObject[node.left.right.left.left]) {
                        // recurse left to gather earlier function chain terms
                        myOut = myOut + generateNestedFunction(node.left, nodeIsRoot, entry, symbols, out, needsMathObject);
                    } else {
                        // revert back to chaining, instead of nested style
                        myOut = myOut + that.generateTargetCode(node.left, false, entry, symbols, myOut);
                    }
                } else if (node.left.type === 'SYMBOL') {
                    myOut = node.left.left;
                }
                var funcName = node.right.left.left;
                var mathObj = '';
                if (needsMathObject[funcName] === true) {
                    // insert the Javascript Math object as a prefix
                    mathObj = 'Math.';
                }

                myOut = ' ' + mathObj + node.right.left.left + '(' + myOut;

                for (var argNode = node.right.right; argNode; argNode = argNode.right) {
                    if (argNode.type === 'ARG') {
                        // create target code for this argument
                        myOut += ', ';
                        myOut = that.generateTargetCode(argNode.left, false, entry, symbols, myOut);
                    }
                }
                myOut += ')';
                return myOut;
            }

            self.getNewlyAddedRuleObject = function(ruleIdFromParam, validationRulesList) {
                var defer = $q.defer();
                var that = self;
                var doesRuleExistInGrid = false;
                var ruleId = '';
                if (ruleIdFromParam !== null && ruleIdFromParam !== '') { //from create or edit rule screen
                    var semiColon = ruleIdFromParam.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end

                    if (semiColon !== -1) {
                        ruleId = ruleIdFromParam.slice(0, semiColon);
                    } else {
                        ruleId = ruleIdFromParam;
                    }

                    //angular.forEach doesn't support break; use the native for loop
                    for (var i = 0, j = validationRulesList.length; i < j; i++) {
                        if (validationRulesList[i].objectId === ruleIdFromParam) {
                            doesRuleExistInGrid = true;
                            break;
                        }
                    }

                    // if the newly added condition haven't got pulled in by cm yet we need to add it by the way as shown below
                    if (!doesRuleExistInGrid) {
                        that.getValidationRuleById(ruleId)
                            .then(function(data) {
                                defer.resolve(data.data);

                            }, function(reason) {
                                $log.error(reason);
                            });

                    } else {
                        defer.resolve('');

                    }
                }

                return defer.promise;


            };

            self.getLastModifiedWhenCmNotReturned = function(objectId) {

                var finalOutPut = {};
                var lastModifiedObject = [];
                var defer = $q.defer();
                $http.get(restApiEndpoint + '/scripts/' + objectId).success(function(data) {
                    if (data != null) {
                        lastModifiedObject.push(data.lastModificationDate);
                        finalOutPut['lastModifiedObject'] = lastModifiedObject;
                        defer.resolve(finalOutPut);
                    } else {
                        defer.resolve(finalOutPut);
                    }

                }).error(function(data) {
                    defer.reject(data);
                });

                return defer.promise;

            };

            self.formatLastModified = function(finalOutput) {
                var lastCompiledDate = '';

                var lastModifiedArray = finalOutput.lastModifiedObject;
                if (lastModifiedArray !== undefined && lastModifiedArray !== '') {
                    var sorted = lastModifiedArray.sort(function(date1, date2) {
                        return date1 - date2;
                    });
                    lastCompiledDate = moment(sorted[0]).format('MMM DD YYYY hh:mma'); // moment format ref.: http://momentjs.com/docs/#/displaying/format/

                }

                return lastCompiledDate;
            };

            self.validateRule = function(ruleName, expression, errorText) {
                ruleName = angular.isDefined(ruleName) ? ruleName : '';
                expression = angular.isDefined(expression) ? this.unescapeText(expression).trim() : '';
                errorText = angular.isDefined(errorText) ? this.unescapeText(errorText).trim() : '';
                if ((ruleName === '') || (expression.trim() === '') || (errorText.trim() === '')) {
                    return false;
                } else {
                    return true;
                }
            };

            self.getLastCompiledDate = function(objectId) {
                var lastCompiled = '';
                var that = self;
                var defer = $q.defer();
                that.getSriptFilesObjectId().then(function(finalOutput) {
                    if (Object.keys(finalOutput).length === 0 && objectId !== undefined) {
                        var semiColon = objectId.lastIndexOf(';'); //cm returned id might include version like ";1.0" at the end

                        if (semiColon !== -1) {
                            objectId = objectId.slice(0, semiColon);
                        }
                        that.getLastModifiedWhenCmNotReturned(objectId).then(function(data) {
                            //finalOutput = data;
                            lastCompiled = that.formatLastModified(data);
                            defer.resolve(lastCompiled);
                        }, function() {
                            lastCompiled = '';
                            defer.reject(lastCompiled);
                        });
                    } else {
                        lastCompiled = that.formatLastModified(finalOutput);
                        defer.resolve(lastCompiled);
                    }
                }, function() {
                    lastCompiled = '';
                    defer.reject(lastCompiled);
                });

                return defer.promise;
            };
            self.getValidationMetaData = function() {
                return $http.get(restApiEndpoint + '/types/rulesExpression');
            };

            self.createFreshSymbolTable = function() {
                var that = self;
                var newSymbolTable = {};
                var defer = $q.defer();
                angular.forEach(that.symbols, function(value, key) {
                    if ((value.kind === 'reserved' || value.kind === 'function') && (value.source === undefined || value.source === '')) {
                        newSymbolTable[key] = value;
                    } else {
                        delete that.symbols[key];
                    }

                    if (Object.keys(that.symbols).length === Object.keys(newSymbolTable).length) {
                        defer.resolve(that.symbols);
                    }
                });

                return defer.promise;
            };


        }
        return new ValidationRuleDataService();
    });