'use strict';

angular.module('p2AdvanceApp')
    .factory('ConfirmationModalFactory', ['$modal', '$log', '$q', '$timeout', '$rootScope', function($modal, $log, $q, $timeout, $rootScope) {

        var modalScope = $rootScope.$new();   
        var confirmationModalSetup = {
            templateUrl: 'views/ui-framework/confirmation-modal.html',
            controller: 'ConfirmationModalCtrl',
            keyboard: false,
            backdrop: 'static',
            scope: modalScope
        };

        var modalInstance;

        var opened;

        var closeModalAfterDelay = function(delay, callAfterDelay) {
            $timeout(function() {
                modalInstance.close(callAfterDelay);
            }, delay);
        };

        // Public API here
        return {

            open: function(title, detail, delay, afterDelay, windowClass) {

                try {

                    var defer = $q.defer();
                    var hasDelay = _.isNumber(delay);

                    if (hasDelay) {
                        modalScope.showOKButton = false;
                    } else if (delay === 'none') {
                        modalScope.showOKButton = true;
                    }

                    if (opened) {

                        modalScope.title = _.isUndefined(title) ? ' ' : title;
                        modalScope.detail = _.isUndefined(detail) ? ' ' : detail;

                        if (hasDelay) {
                            closeModalAfterDelay(delay, afterDelay);
                        }

                        //$log.info('Try to open a modal while other modal is opened');
                        return;

                    } else {

                        modalScope.title = _.isUndefined(title) ? ' ' : title;
                        modalScope.detail = _.isUndefined(detail) ? ' ' : detail;
                        confirmationModalSetup.windowClass = windowClass;

                        modalInstance = $modal.open(confirmationModalSetup);

                        modalInstance.opened.then(function() {
                            defer.resolve(true);

                            if (hasDelay) {
                                closeModalAfterDelay(delay, afterDelay);
                            }

                        });

                        modalInstance.result.then(
                            // close modal
                            function(afterClose) {
                                opened = false;
                                if (typeof afterClose === 'function') {
                                    $timeout(afterClose, 300);
                                }
                            },
                            // dismiss modal
                            function() {
                                opened = false;
                            });
                    }

                    opened = defer.promise;
                } catch (e) {
                    $log.error(e);
                }

            },

            close: function(afterClose) {
                try {

                    if (!opened && typeof afterClose === 'function') {
                        afterClose();
                        return;
                    } else if (!opened) {
                        return;
                    }

                    opened.then(function() {
                        modalInstance.close(afterClose);
                    }, function(reason) {
                        $log.error(reason);
                    });

                } catch (e) {
                    $log.error(e);
                }

            },

            dismiss: function() {
                try {

                    if (!opened) {
                        return;
                    }

                    modalInstance.dismiss();

                } catch (e) {
                    $log.error(e);
                }

            }

        };
    }]);