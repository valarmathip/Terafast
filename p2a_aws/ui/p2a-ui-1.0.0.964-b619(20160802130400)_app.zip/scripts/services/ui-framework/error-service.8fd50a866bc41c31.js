'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.ErrorService
 * @description
 * # ErrorService
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
  .factory('ErrorService', function() {
    // Service logic

    function getError() {
      return new Error();
    }

    function getStack(e) {
      return (e.stack) ? e.stack : 'N/A';
    }

    function getCause(e) {
      return (e.cause) ? e.cause : 'N/A';
    }

    // Public API here
    return {

      AppException : function(message) {
        this.name = 'AppException';
        this.message = message;
        this.prototype = getError();
        this.prototype.constructor = this;
        this.cause = getCause(this.prototype);
        this.stack = getStack(this.prototype);
      },

      UIFrameworkException : function(message) {
        this.name = 'UIFrameworkException';
        this.message = message;
        this.prototype = getError();
        this.prototype.constructor = this;
        this.cause = getCause(this.prototype);
        this.stack = getStack(this.prototype);
      }

    };

  });