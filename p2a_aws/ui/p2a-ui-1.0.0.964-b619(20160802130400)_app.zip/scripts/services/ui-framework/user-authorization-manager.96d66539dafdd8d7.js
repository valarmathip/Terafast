'use strict';

/**
 * @ngdoc factory
 * @name p2AdvanceApp.userAuthorizationManager
 * @description
 * # userAuthorizationManager
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
  .factory('userAuthorizationManager', function ($log, 
                                                 $rootScope, 
                                                 $q, 
                                                 $auth, 
                                                 $http, 
                                                 moment, 
                                                 Permission,
                                                 ConfirmationModalFactory, 
                                                 ENV, 
                                                 $injector,
                                                 $state) {

    var rawRolePermissions;

    var permissions = [];

    var roles = [];

    var systemRoles = [];

    var sysRoleNames = [];

    var routesRolesPermissionsMap = [];

    var skipRouterValidation = false;
    var skipUIValidation     = false;
    var skipHTTPValidation   = false;

    //var numOpenAccessErrors = 0;

    // Initilize Routes Permission listeners
    $rootScope.$on('$stateChangeStart',
      function (event, toState, toParams, fromState, fromParams) {
        if (toState.$$finishAuthorize || skipRouterValidation) {
          return;
        }

        // If there are permissions set then prevent default and attempt to authorize
        var permissions;
        if (routesRolesPermissionsMap[toState.name]) {
          permissions = routesRolesPermissionsMap[toState.name];
        } else {
          $log.info('No role restricted access for state : ' + toState.name);
        }

        if (permissions) {
          event.preventDefault();
          toState = angular.extend({'$$finishAuthorize': true}, toState);

          if ($rootScope.$broadcast('$stateChangePermissionStart', toState, toParams).defaultPrevented) {
            return;
          }

          Permission.authorize(permissions, toParams).then(function () {
            // If authorized, use call state.go without triggering the event.
            // Then trigger $stateChangeSuccess manually to resume the rest of the process
            // Note: This is a pseudo-hacky fix which should be fixed in future ui-router versions
            if (!$rootScope.$broadcast('$stateChangeStart', toState, toParams, fromState, fromParams).defaultPrevented) {
              $rootScope.$broadcast('$stateChangePermissionAccepted', toState, toParams);

              $state.go(toState.name, toParams, {notify: false}).then(function() {
                $rootScope
                  .$broadcast('$stateChangeSuccess', toState, toParams, fromState, fromParams);
              });
            }
          }, function () {
            if (!$rootScope.$broadcast('$stateChangeStart', toState, toParams, fromState, fromParams).defaultPrevented) {
              $rootScope.$broadcast('$stateChangePermissionDenied', toState, toParams);

              var redirectTo = permissions.redirectTo;
              //var result;

              if (angular.isFunction(redirectTo)) {
                redirectTo = redirectTo();

                $q.when(redirectTo).then(function (newState) {
                  if (newState) {
                    $state.go(newState, toParams);
                  }
                });

              } else {
                if (redirectTo) {
                  $state.go(redirectTo, toParams);
                }
              }
            }
          });
        }
      });
    //

    $rootScope.$on('$stateChangePermissionDenied', function() {
        ConfirmationModalFactory.open('Access denied', 'You don\'t have permission to access this area of the P2A application.', ENV.modalErrorTimeout);
    });

    $rootScope.$on('$stateChangePermissionAccepted', function() {
        $log.info('User Role permissions has been accepted and the state changes successfully');
    });

    $rootScope.$on('auth:user_roles_refreshed', function(){

        $injector.invoke(function (userAuthorizationManager) {
            userAuthorizationManager.loadUserRolesPermissions()
                .then(function() {
                    // Load the Permission Route / Role Definitions
                    userAuthorizationManager.loadDefinitionRoutesRoles();
                    userAuthorizationManager.loadRoutesRolesPermissionsMap()
                        .success(function(data){
                            routesRolesPermissionsMap = data;
                            $rootScope.$broadcast('permissionsChanged');
                        });
                },
                function(){
                    $log.error('Error loadUserRolesPermissions');
                });
        });

    });

    function setRawRolePermissions(data) {
        rawRolePermissions = data;
    }

    function setSystemRoles(data) {
        systemRoles = data;
        setSysRoleNames(data);
    }

    function setSysRoleNames(data) {
         angular.forEach(data, function(role){
            sysRoleNames.push(role.name);
         });
    }

    function getSysRoleNames() {
        return sysRoleNames;
    }

    function parseRolePermissions(rolesPermissionData) {
        var roles = [];
        for (var i=0,j=rolesPermissionData.length; i<j; i++) {
            var newRole = {};
            if (rolesPermissionData[i].isRoleActive) {
                newRole.name         = rolesPermissionData[i].name;
                newRole.description  = rolesPermissionData[i].description;
                newRole.creationDate = new moment(rolesPermissionData[i].creationDate);
                newRole.isRoleActive = rolesPermissionData[i].isRoleActive;
                roles.push(newRole);
                if (rolesPermissionData[i].permissions && rolesPermissionData[i].permissions.length > 0) {
                    updatePermissions(rolesPermissionData[i].permissions);
                }
            }
        }
        return roles; 
    }

    function getPermissionByURL(method, fullEntity, params) {
        var verb      = getPathVerb(method);
        var entity    = getEntity(fullEntity);
        var attribute = getAttribute(params);
        attribute = (attribute) ? '.' + attribute : '';
        return entity + '.' + verb + attribute;
    }

    // Original Implementarion to extract permission from the path
    //
    // function getPermissionId(permission) {
    //     var verb      = getPathVerb(permission);
    //     var entity    = getEntity(permission); 
    //     var attribute = getAttribute(permission);
    //     attribute = (attribute) ? '.' + attribute : '';
    //     return entity + '.' + verb + attribute;
    // }

    function getPathVerb(method) {
        if (method === 'GET') {
            return 'read';
        } else if (method === 'POST') {
            return 'create';
        } else if (method === 'PATCH') {
            return 'update';
        }
    }

    function getEntity(fullEntity) {
        // from a string like /v1/Document, will return document
        // from a string like /cm/templates, will return template
        return fullEntity[0].substring(4).toLowerCase().slice(0, fullEntity[0].lastIndexOf('s') - 4);
    }

    function getAttribute(params) {
        if (params && params.docType) {
            return params.docType.toLowerCase();
        } else if (params && params.planType)  {
            return params.planType.toLowerCase();
        } else {
            return false;
        }
    }

    function getPermissionId(permission) {
        return permission.substring(0, permission.indexOf(';'));
    }

    function existPermission(permissionId) {
        var exist = false;
        for (var i=0, j=permissions.length; i<j; i++) {
            // Please don't remove this code in case we need to 
            // return to the wild card approach
            // Allow to match an hierarchy  i.e.
            // document.read will return valid for any permission
            // with that prexif, 
            // document.read.sbc
            // document.read.sob
            // document.read.scob
            // document.read.gen
            // var regex = new RegExp('^' + permissionId);
            // if (permissions[i].id.match(regex)) {
            //     exist = true;
            //     break;
            // }
            if (permissions[i].id === permissionId) {
                exist = true;
                break;
            }
        }
        return exist;
    }

    /**
     * Permission String:
     *                     "entity.unlock.me;POST;/unlock;(planType:\"Custom\") AND (lockedBy:\"$username\");unlock"
     *     Explanation as:  permission;     method;path;   criteria;                                         entityName
     *
     * Pre-assume:
     *     1. The criteria express only include 'AND', 'OR', 'NOT' logic,
     *     2. Bracket are supported
     *     3. The Value is in the double quota
     *     4. * means this is no criteria
     *
     * Need to Improve:
     *     Criteria have to be parsed in very comparation
     */
    function existPermissionWithCriteria(requiredPermissionId, entityStatus) {
        var exist = false;
        for (var i=0, j=permissions.length; i<j; i++) {
            if (permissions[i].id === requiredPermissionId && criteriaSatisfied(permissions[i], entityStatus)) {
                exist = true;
                break;
            }
        }

        return exist;
    }

    function parseCriteriaToArray(str) {
        /* jshint maxcomplexity:50 */
        function splitEndString (evaStr, delimer) {
            var pos = evaStr.indexOf(delimer);
            if(pos<0) {
                return false;
            }

            var sub1 = evaStr.substring(0, pos);
            var sub2 = evaStr.substring(pos);

            sub1 = sub1.trim();
            sub1 = subStrAfterDubleQuote + sub1;
            subStrAfterDubleQuote = '';
            sub2 = sub2.trim();

            if(sub1.length>0) {
                retArray.push(sub1.trim());
            }
            if(sub2.length) {
                retArray.push(sub2.trim());
            }

            return true;
        }

        var retArray = [];
        var openBracket = '(';
        var closeBracket = ')';
        var opAnd = 'AND';
        var opOr = 'OR';
        var opNot = 'NOT';

        var i = 0;
        var subStr = '';
        var subStrAfterDubleQuote = '';
        var isInDoubleQuote = false;

        for(;i<str.length; ++i) {
            var leavingDoubleQuote = false;
            var c = str.charAt(i);
            if(c === '"') {
                isInDoubleQuote = !isInDoubleQuote;
                if(!isInDoubleQuote) { // leveing  double quote
                    leavingDoubleQuote = true;
                }
            }

            subStr += c;

            if(leavingDoubleQuote) {
                subStrAfterDubleQuote = subStr;
                subStr = '';
                leavingDoubleQuote = false;
            }

            if(!isInDoubleQuote) {
                if (subStr.indexOf(openBracket) >= 0) {
                    var start = 0;
                    var end = 1;
                    var subStr1 = subStr.substring(start, end);
                    subStr1 = subStr1.trim();
                    if(subStr1.length > 0) {
                        retArray.push(subStr1.trim());
                    }
                    subStr = subStr.substring(end);
                } else if (splitEndString(subStr, closeBracket) ||
                           splitEndString(subStr, opAnd)  ||
                           splitEndString(subStr, opOr)  ||
                           splitEndString(subStr, opNot)
                ) {
                    subStr = '';
                }
            }

        }

        if(subStr.length>0 || subStrAfterDubleQuote.length>0) {
            retArray.push(subStrAfterDubleQuote + subStr);
        }

        return retArray;
    }

    function criteriaSatisfied(userPermission, entityStatus) {
        /* jshint maxcomplexity:50 */
        if(userPermission.criteria === '*') {
            return true;
        }

//        Keep this for unit test
//        var tmp = '((A OR B) AND (C OR D) AND NOT E)';
//        var tmp = '((planType:\"SLQ AND Custom\" OR lockedBy:\"$username\") AND (planType:\"Custom AND Standard\" OR lockedBy:\"NOT locked $username\") AND NOT lockedBy:\"$username\")';
//        var tmp = 'planType:"Custom"';
//        var tmp = 'planType:"Custom" AND lockedBy:"$username"';
//        var tmp = 'planType:Custom';
//        var slqtmp = parseCriteriaToArray(tmp);
//        $log.log(slqtmp);
//        $log.log(slqtmp.join(' '));

        //$log.log('1. ' + userPermission.criteria);
        var criteriaArray = parseCriteriaToArray(userPermission.criteria);
        //$log.log('2. ' + criteriaArray);
        //$log.log('   ' + criteriaArray.join(' '));

        var criteriaResult = [];

        for(var i=0; i<criteriaArray.length; ++i) {
            var criteriaItem = criteriaArray[i].trim();
            switch(criteriaItem.toLowerCase()) {
                case 'and':
                    criteriaResult.push('&&');
                    break;
                case 'or':
                    criteriaResult.push('||');
                    break;
                case 'not':
                    criteriaResult.push('!');
                    break;
                case '(':
                    criteriaResult.push('(');
                    break;
                case ')':
                    criteriaResult.push(')');
                    break;
                default: {
                    //$log.log(criteriaItem);
                    var keyValue = criteriaItem.split(':');
                    var key = keyValue[0].trim();
                    var value = keyValue[1].trim();
                    if(value.charAt(0) === '"') {
                        value = value.substring(1);
                    }
                    if(value.charAt(value.length-1) === '"') {
                        value = value.substring(0, value.length-1);
                    }
                    if(value.indexOf('$') === 0) { // replace $userName to current user
                        value = getRuntimeValue(value);
                    }
                    var entityStatusValue = $injector.invoke(function($parse){
                        return $parse(key)(entityStatus);
                    });

                    //$log.log(key + ' --> ' + value + ' === ' + entityStatusValue + ', name: ' + entityStatus.name);

                    criteriaResult.push(entityStatusValue === value);
                    break;
                }
            }
        }

        //$log.log('3. ' + criteriaResult.join(' '));
        /*jshint evil:true */
        var result = eval(criteriaResult.join(' '));
        //$log.log('4. result = ' + result);

        return result;
    }

    function getRuntimeValue(valueString) {
        var retValue = null;

        switch(valueString) {
                case '$username':
                    retValue = $auth.getUserEmail();
                    break;
        }

        return retValue;
    }

    function hasRole(roleName) {
        var exist = false;
        for (var i=0, j=roles.length; i<j; i++) {
            if (roles[i].name === roleName && roles[i].isRoleActive) {
                exist = true;
                break;
            }
        }
        return exist;
    }

    function createPermission(permissionId, rawPermission) {
        var permSplit = rawPermission.split(';');
        return {
            id : permissionId,
            metho: permSplit[1].trim(),
            path: permSplit[2].trim(),
            criteria: permSplit[3].trim(),
            entity: permSplit[4].trim(),
            access : rawPermission.substring(rawPermission.indexOf(';') + 1)
        };
    }

    function updatePermissions(rawPermissions) {
        for (var i=0, j=rawPermissions.length; i<j; i++) {
            for (var p=0, k=rawPermissions[i].permissionAccessList.length; p<k; p++){
                var rawPermission = rawPermissions[i].permissionAccessList[p];
                var permissionId  = getPermissionId(rawPermission);
                if (!existPermission(permissionId)) {
                    permissions.push(createPermission(permissionId, rawPermission));
                }
            }
        }
    }

    return {

        skipRoleRoutesValidation : function(skip){
           skipRouterValidation = skip;
        },

        skipPermissionUIValidation : function(skip) {
          skipUIValidation = skip;
        },

        skipPermissionHTTPValidation : function(skip) {
          skipHTTPValidation = skip;
        },

        skipAllRoleAndPermissions : function(skip) {
            skipRouterValidation = skip;
            skipUIValidation     = skip;
            skipHTTPValidation   = skip;
        },

        getUserRolesNames : function() {
            return $auth.getUserRolesNames(); 
        },

        loadUserRolesPermissions : function() {
            var defer = $q.defer();
            var rawRolePermissions = $auth.getUserRolesAndPermissions();

            this.loadSystemRoles()
                .success(function(data) {
                    setSystemRoles(data);
                    setRawRolePermissions(rawRolePermissions);
                    roles = parseRolePermissions(rawRolePermissions);
                    defer.resolve();
                })
                .error(function(){
                    defer.reject();
                });

            return defer.promise;    
        },

        loadSystemRoles : function() {
            return $http.get('data/system-roles-list.json');
        },

        loadDefinitionRoutesRoles : function() {
            // To define many roles which share one validator callback, 
            // use defineManyRoles(<array>, <validator function>)
            Permission.defineManyRoles(getSysRoleNames(), function (stateParams, roleName) {
                return hasRole(roleName);
            });
        },

        loadRoutesRolesPermissionsMap : function() {
            return $http.get('data/routes-roles-permissions-map.json');
        },

        getSystemRoles : function() {
            return systemRoles;
        }, 

    	hasPermission : function(permissionId) {
            return skipUIValidation || existPermission(permissionId);
    	},

        hasPermissionWithCriteria: function(requiredPermissionId, entityStatus) {
            return skipUIValidation || existPermissionWithCriteria(requiredPermissionId, entityStatus);
        },

    	isAuthorized : function(method, url, params) {
            var entity = url.match(/\/v1\/\w+/g) || url.match(/\/cm\/\w+/g);
            if (entity) {
                var permissionId = getPermissionByURL(method, entity, params);
                var authorized = existPermission(permissionId);
                $log.info('method : ' + method + ', url : ' + url + ' permissionId : ' + permissionId + ', isAuthorized => ' + authorized);
                return skipHTTPValidation || authorized; 
                // To activate this feature, we need to be sure all CRUD permission for /cm/ and /v1/ 
                // paths are mapping.  If not will cause masive blocks. 
            } else {
                $log.info('not cm request method : ' + method + ', url : ' + url);
                return true;
            }
    		
    	}
    };

  });
