'use strict';

angular.module('p2AdvanceApp')
    .factory('WorkflowDataFactory', ['$http', '$timeout', 'ConfirmationModalFactory', 'ENV_WORKFLOW_MANAGEMENT', 'ENV', '$q',
        function($http, $timeout, ConfirmationModalFactory, ENV_WORKFLOW_MANAGEMENT, ENV, $q) {

            var restApiEndpoint = ENV_WORKFLOW_MANAGEMENT.apiEndpoint + ENV_WORKFLOW_MANAGEMENT.contextPath;
            var AUTH_KEY = ENV_WORKFLOW_MANAGEMENT.authKey;
            var isContractor = (ENV.name === 'contractor');

            /**
             * Return list of cases
             * @param filterQuery
             * @returns {*}
             */
            function getCases(filterQuery) {
                var defer = $q.defer();
                filterQuery = (filterQuery) ? '?' + filterQuery : '';
                var api = restApiEndpoint + '/cases' + filterQuery;
                $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                }).success(function(response) {
                    defer.resolve(response);
                }).error(function(response) {
                    defer.reject(response);
                });
                return defer.promise;
            }

            /**
             * Return list of cases
             * @param filterQuery
             * @returns {*}
             */
            function getTasks(filterQuery) {
                var defer = $q.defer();
                filterQuery = (filterQuery) ? '?' + filterQuery : '';
                var api = restApiEndpoint + '/tasks' + filterQuery;
                $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                }).success(function(response) {
                    defer.resolve(response);
                }).error(function(response) {
                    defer.reject(response);
                });
                return defer.promise;
            }

            function getCaseDetails(caseId) {
                var api = restApiEndpoint + '/cases/' + caseId;
                return $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                });
            }

            function getTaskDetails(taskId) {
                var api = restApiEndpoint + '/tasks/' + taskId;
                return $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                });
            }

            /**
             * Return cases filters
             * @returns {*}
             */
            function getCaseListFilterMeta() {
                var filterUrl = restApiEndpoint + '/cases/filters';
                return $http({
                    method: 'GET',
                    url: filterUrl,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                });
            }

            /**
             * Return tasks filters
             * @returns {*}
             */
            function getTaskListFilterMeta() {
                var filterUrl = restApiEndpoint + '/tasks/filters';
                return $http({
                    method: 'GET',
                    url: filterUrl,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                });
            }

            /**
             * Return task summary form
             * @returns {*}
             */
            function getTaskSummaryForm(caseId, taskId) {
                var api = restApiEndpoint + '/cases/' + caseId + '/tasks/' + taskId + '/form';
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                }).success(function(response) {
                    defer.resolve(response);
                }).error(function(response) {
                    defer.reject(response);
                });
                return defer.promise;
            }

            /**
             * Get a collection of Tasks for a given Case
             * @returns {*}
             */
            function getCaseTasksCollection(caseId) {
                var api = restApiEndpoint + '/cases/' + caseId + '/tasks';
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    url: api,
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                }).success(function(response) {
                    defer.resolve(response);
                }).error(function(response) {
                    defer.reject(response);
                });
                return defer.promise;
            }


            /**
             * Get the process diagram for case
             * @returns {*}
             */
            function getCaseProcessDiagram(caseId) {
                var api = restApiEndpoint + '/cases/' + caseId + '/diagram';
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    url: api,
                    // responseType: 'arraybuffer',
                    transformRequest: function(data, headersGetter) {
                        var headers = headersGetter();
                        if (isContractor) {
                            headers['Authorization'] = AUTH_KEY;
                        }
                        return headers;
                    }
                }).success(function(response) {
                    defer.resolve(response);
                }).error(function(response) {
                    defer.reject(response);
                });
                return defer.promise;
            }

            return {
                getCases: getCases,
                getTasks: getTasks,
                getCaseDetails: getCaseDetails,
                getTaskDetails: getTaskDetails,
                getCaseListFilterMeta: getCaseListFilterMeta,
                getTaskListFilterMeta: getTaskListFilterMeta,
                getTaskSummaryForm: getTaskSummaryForm,
                getCaseTasksCollection: getCaseTasksCollection,
                getCaseProcessDiagram: getCaseProcessDiagram

            };
        }
    ]);
