'use strict';

angular.module('p2AdvanceApp')
  .factory('WorkflowFilterService', [
    function () {
      return {
        /**
         * Create case query based on filters and search string
         * @param searchQuery
         * @param filterQuery
         * @returns {*}
         */
        getCaseFilterQuery: function (searchQuery, filterQuery) {
          var query = {};
          _.forEach(filterQuery, function (filter, filterName) {
            if (!query[filterName]) {
              query[filterName] = [];
            }
            query[filterName].push(filter);
          });

          _.forEach(query, function (filters, filterName) {
            query[filterName] = filters.join(',');
          });
          // TODO add searchQuery somehow
          // TODO Better to use $httpParamSerializer for parameters serializaion,
          // TODO But current angular version doesn't support it,
          // TODO that's why we use jQuery.params
          return $.param(query);
        },

        /**
         * Create workflow query based on filters and search string
         * @param searchQuery
         * @param filterQuery
         * @returns {*}
         */
        getTaskFilterQuery: function (searchQuery, filterQuery) {
          var query = {};
          _.forEach(filterQuery, function (filter, filterName) {
            if (!query[filterName]) {
              query[filterName] = [];
            }
            query[filterName].push(filter);
          });

          _.forEach(query, function (filters, filterName) {
            query[filterName] = filters.join(',');
          });
          // TODO add searchQuery somehow
          // TODO Better to use $httpParamSerializer for parameters serializaion,
          // TODO But current angular version doesn't support it,
          // TODO that's why we use jQuery.params
          return $.param(query);
        }
      };
    }
  ]);
