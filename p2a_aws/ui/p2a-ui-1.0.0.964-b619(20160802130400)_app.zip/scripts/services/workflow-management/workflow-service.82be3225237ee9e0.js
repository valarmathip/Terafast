'use strict';

angular.module('p2AdvanceApp')
  .factory('WorkflowService', ['$q', '$http', 'ENV_WORKFLOW_MANAGEMENT', //'ENV',
    function ($q, $http, ENV_WORKFLOW_MANAGEMENT) {

      var restApiEndpoint = ENV_WORKFLOW_MANAGEMENT.apiEndpoint + ENV_WORKFLOW_MANAGEMENT.contextPath;
      // var AUTH_KEY = ENV_WORKFLOW_MANAGEMENT.authKey;
      // var isContractor = (ENV.name === 'contractor');


      /**
       * Execute action
       * @param caseId
       * @param taskId
       * @private
       */
      function _executeAction(caseId, taskId, postData) {
        var api = restApiEndpoint + '/cases/' + caseId + '/tasks/' + taskId;
        return $http({
          method: 'POST',
          url: api,
          data: JSON.stringify(postData)
          // commented for some issues with the payload
          // ,transformRequest: function (data, headersGetter) {
          //   var headers = headersGetter();
          //   if (isContractor) {
          //     headers['Authorization'] = AUTH_KEY;
          //   }
          //   return headers;
          // }
        });

      }

      return {
        ///**
        // * Complete Task
        // * @param taskId
        // * @returns {*}
        // */
        //completeTask: function (caseId, taskId) {
        //  var api = restApiEndpoint + '/cases/' + caseId + '/tasks/' + taskId;
        //  var defer = $q.defer();
        //
        //  var postData = {
        //    'action': 'complete',
        //    'assignee': 'user@domain.com',
        //    'variables': [
        //      {
        //        'name': 'reviewer_Decision',
        //        'scope': 'global',
        //        'type': 'string',
        //        'value': 'Overrideplan approved'
        //      }
        //    ]
        //  };
        //
        //  $http({
        //    method: 'POST',
        //    url: api,
        //    data: JSON.stringify(postData),
        //    transformRequest: function (data, headersGetter) {
        //      var headers = headersGetter();
        //      headers['Authorization'] = AUTH_KEY;
        //      return data;
        //    }
        //    //headers: {
        //    //  'Authorization': AUTH_KEY
        //    //}
        //  }).success(function (response) {
        //    defer.resolve(response);
        //  }).error(function (response) {
        //    defer.reject(response);
        //  });
        //  return defer.promise;
        //},

        /**
         * Accept task
         * @param caseId
         * @param taskId
           * @returns {*}
           */
        acceptTask: function (caseId, taskId) {
          return _executeAction(caseId, taskId, {
            'action': 'complete',
            // 'assignee': 'user@domain.com',
            'variables': [
              {
                'name': 'reviewer_Decision',
                'scope': 'global',
                'type': 'string',
                'value': 'Overrideplan approved'
              }
            ]
          });
        },

        /**
         * Reject task
         * @param caseId
         * @param taskId
           * @returns {*}
           */
        rejectTask: function (caseId, taskId) {
          return _executeAction(caseId, taskId, {
            'action': 'complete',
            // 'assignee': 'user@domain.com',
            'variables': [
              {
                'name': 'reviewer_Decision',
                'scope': 'global',
                'type': 'string',
                'value': 'Overrideplan rejected'
              }
            ]
          });
        },
        routeToL1: function (caseId, taskId) {
          return _executeAction(caseId, taskId, {
            'action': 'complete',
            'variables': [
              {
                'name': 'reviewer_Decision',
                'scope': 'global',
                'type': 'string',
                'value': 'Route to L1 work'
              }
            ]
          });
        },
        routeToL2: function (caseId, taskId) {
          return _executeAction(caseId, taskId, {
            'action': 'complete',
            'variables': [
              {
                'name': 'reviewer_Decision',
                'scope': 'global',
                'type': 'string',
                'value': 'Route to L2 work'
              }
            ]
          });

        }
      };
    }
  ]);
