'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.AccountMgmtSvc
 * @description
 * # AccountMgmtSvc
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('AccountMgmtSvc', function($http, $q, $location, ENV_ACCOUNT_MANAGEMENT, PPMENV, $log) {
        var amApi = ENV_ACCOUNT_MANAGEMENT.apiEndpoint + ENV_ACCOUNT_MANAGEMENT.contextPath;
        return {
            getAccountById: function(accountId, associationExpansionLevel, objectType) {
                var objectTypePath = '/accounts/';
                if (objectType === 'group') {
                    objectTypePath = '/groups/';
                } else if (!objectType || objectType !== 'account') {
                    $log.error('Specified objectType does not support!');
                }

                var fieldUrl = amApi + objectTypePath + accountId;

                if (!associationExpansionLevel) {
                    associationExpansionLevel = 0;
                }
                fieldUrl += '?associationExpansionLevel=' + associationExpansionLevel;

                return $http({
                        method: 'GET',
                        url: fieldUrl
                    })
                    .then(function(response) {
                        return response.data; // we only care about the data part
                    });
            },

            getAccountListViaSearchApi: function(searchQuery, associationExpansionLevel, queryIsSerialized) {
                var serializedQuery = typeof(queryIsSerialized) !== 'undefined' ? queryIsSerialized : false; // Added queryIsSerialized for DOGHR-2509 - searchParams from account-listing page passed in serialized.

                var fieldUrl = PPMENV.getPpmSearchUrl();

                if (!searchQuery) {
                    searchQuery = 'TYPE:"account"&start=0&rows=20&sort=accountName asc&properties=name, groups, groupParentId, accountName, renewalStartDate, renewalEndDate, accountStatus, marketSegment, lastModificationDate, lastModifiedBy, createdBy';
                }

                if (!serializedQuery) {
                  fieldUrl += '?q=' + encodeURI(searchQuery);
                } else {
                  fieldUrl += '?' + searchQuery;
                }

                if (fieldUrl.indexOf('associationExpansionLevel') === -1) {
                    fieldUrl += '&associationExpansionLevel' + '=' + (associationExpansionLevel ? associationExpansionLevel : 0);
                }

                return $http({
                        method: 'GET',
                        url: fieldUrl
                    })
                    .then(function(response) {
                        return response.data;
                    });
            }
        };
    });
