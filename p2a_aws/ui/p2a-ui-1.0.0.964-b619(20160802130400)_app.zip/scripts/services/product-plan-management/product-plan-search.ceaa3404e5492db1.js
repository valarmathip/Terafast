'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.ProductPlanMgmtSvc
 * @description
 * # ProductPlanMgmtSvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
   .factory('ProductPlanSearch', function($http, $q, $log, ENV_MEDIA_MANAGEMENT) {
	// Public API here
	return {
		getSearchList: function(serachQuery) {
			var defer = $q.defer();
			var fieldUrl = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint+serachQuery;
			$log.log('fieldUrl:'+fieldUrl);
			$http({
				method: 'GET',
				url: fieldUrl,
				aync:false
			}).success(function(data) {
				if (!data.error) {
					defer.resolve(data); // According Hasan request, now backend return data, or error.
				} else {
					defer.reject(data.message);
				}
			}).error(function(reason) {
				defer.reject(reason);
			});
			return defer.promise;
		}
	};
      // Private Variables and Function
});