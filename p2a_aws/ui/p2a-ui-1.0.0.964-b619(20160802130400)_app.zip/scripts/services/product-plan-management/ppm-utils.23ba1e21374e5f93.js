'use strict';

angular.module('p2AdvanceApp')
    .factory('ppmUtils', function() {

        // API
        var PpmUtils = {
            /******************************************************************************
             * Convert json string date/time
             ******************************************************************************/
            jsonStringToDate: function(string) {
                var R_ISO8601_STR = /^(\d{4})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/;
                //                    1        2       3         4           5         6          7          8   9    10      11
                var match;
                /*jshint -W084 */
                if (match = string.match(R_ISO8601_STR)) {
                    var date = new Date(0),
                        tzHour = 0,
                        tzMin = 0,
                        dateSetter = match[8] ? date.setUTCFullYear : date.setFullYear,
                        timeSetter = match[8] ? date.setUTCHours : date.setHours;
                    if (match[9]) {
                        tzHour = parseInt(match[9] + match[10], 10);
                        tzMin = parseInt(match[9] + match[11], 10);
                    }
                    dateSetter.call(date, parseInt(match[1], 10), parseInt(match[2], 10) - 1, parseInt(match[3], 10));
                    var h = parseInt(match[4] || 0, 10) - tzHour;
                    var m = parseInt(match[5] || 0, 10) - tzMin;
                    var s = parseInt(match[6] || 0, 10);
                    var ms = Math.round(parseFloat('0.' + (match[7] || 0)) * 1000);
                    timeSetter.call(date, h, m, s, ms);
                    return date;
                }
                return string;
            },
            /******************************************************************************
             * Convert json string or number to date/time
             *-----------------------------------------------------------------------------
             * Note: Following function need the underscore lib
             ******************************************************************************/
            jsonOrNumberToDate: function(date) {
                var NUMBER_STRING = /^\-?\d+$/;

                if (angular.isString(date)) {
                    date = NUMBER_STRING.test(date) ? parseInt(date, 10) : this.jsonStringToDate(date);
                }
                if (angular.isNumber(date)) {
                    date = new Date(date);
                }
                if (!angular.isDate(date) || !_.isFinite(date.getTime())) {
                    throw 'Not a valid date, Only valid for data/time json string or number';
                }

                return date;
            },
            /*****************************************************************************
             * Check if array contain a string, ignore case
             *****************************************************************************/
            arryContainStringIgnoreCase: function(array, strValue) {
                var found = false;
                angular.forEach(array, function(item) {
                    if (item.toString().toLowerCase() === strValue.toString().toLowerCase()) {
                        found = true;
                        return false;
                    }
                });

                return found;
            },
            /*****************************************************************************
             * Return a array containing the pages that showing in pagination widget
             *****************************************************************************/
            getViewPagesRange: function(curPage, totalPages) {
                var startPage = curPage - 2;
                var endPage = curPage + 2;
                if (curPage < 3) {
                    switch (curPage) {
                        case 1:
                            endPage = curPage + 4;
                            break;
                        case 2:
                            endPage = curPage + 3;
                            break;
                        default:
                            endPage = curPage + 2;
                    }

                }
                if (totalPages - curPage < 2) {
                    switch (totalPages - curPage) {
                        case 0:
                            startPage = curPage - 4;
                            break;
                        case 1:
                            startPage = curPage - 3;
                            break;
                        default:
                            startPage = curPage - 2;
                    }
                }

                if (startPage < 1) {
                    startPage = 1;
                }
                if (endPage > totalPages) {
                    endPage = totalPages;
                }

                var pageRange = [];
                for (var i = startPage; i <= endPage; i++) {
                    pageRange.push(i);
                }

                return pageRange;
            }, // end of getViewPagesRange
            /*****************************************************************************
             * Return digit number in word
             *****************************************************************************/
            /*jshint maxcomplexity:false */
            numberInWords: function(num) {
                if (parseInt(num, 10) === 0) {
                    return 'zero only';
                }

                var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
                var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

                if ((num = num.toString()).length > 9) {
                    return 'overflow';
                }
                var n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                if (!n) {
                    return;
                }
                var str = '';
                str += (n[1] !== 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
                str += (n[2] !== 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
                str += (n[3] !== 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
                str += (n[4] !== 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
                str += (n[5] !== 0) ? ((str !== '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
                return str;
            },
            /*****************************************************************************
             * Return string without any space
             *****************************************************************************/
            removeAllSpace: function(str) {
                if (!str) {
                    return str;
                }
                return str.replace(/ /g, '');
            },
            removeVersionFromId: function(objectId) {
                return objectId.substring(0, objectId.indexOf(';') > 0 ? objectId.indexOf(';') : objectId.length); // remove version part
            },
            transferPathToObject: function(path, value, context) {
                return transferPathToObject(path, value, context);
            },
            isUuid: isUuid,
            // Url encoding
            encodeUriQuery: encodeUriQuery,
            encodeUriSegment: encodeUriSegment,
            paramSerializer: paramSerializer,
            buildUrl: buildUrl

        }; // end of return object

        function transferPathToObject(path, value, context) {
            recursTranferPathToObject(path, value, context);
            return context;
        }

        function recursTranferPathToObject(path, value, context) {
            //console.log('------------- context = ' + angular.toJson(context, true));
            var result = findVariableNameAndType(path);
            //console.log('name: ' + result.rootName + ', remain: ' + result.remainPart + ', type:' + result.type);

            var indexOrPropertyName = getIndexOrPrepertyName(result.rootName);

            if (!result.remainPart) {
                if (angular.isArray(context)) {
                    context[indexOrPropertyName] = value;
                } else {
                    context[indexOrPropertyName] = value;
                }
            } else {
                if (result.type === 'object') {
                    if (!context[indexOrPropertyName]) {
                        context[indexOrPropertyName] = {};
                    }
                } else {
                    if (!context[indexOrPropertyName]) {
                        context[indexOrPropertyName] = [];
                    }
                }
            }

            if (result.remainPart && result.remainPart.length > 0) {
                return recursTranferPathToObject(result.remainPart, value, context[indexOrPropertyName]);
            }

        }

        function getIndexOrPrepertyName(str) {
            var indexOrPropertyName = str;
            var groups = str.match(/^(\d+)\]$/);
            if (groups && groups[1]) {
                indexOrPropertyName = Number(groups[1]);
            }

            return indexOrPropertyName;
        }

        function findVariableNameAndType(path) {
            var result = {};
            var isLast = true;
            for (var i = 0; i < path.length; i++) {
                var curChar = path.charAt(i);
                if (curChar === '.' || curChar === '[') {
                    isLast = false;
                    result.rootName = path.substring(0, i);
                    result.type = curChar === '.' ? 'object' : 'array';
                    result.remainPart = path.substring(i + 1);

                    break;
                }
            }

            if (isLast) {
                result.rootName = path;
                result.type = 'unknow';
                result.remainPart = null;
            }

            return result;
        }

        var uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        /*
         * Test if the string is a uuid
         */
        function isUuid(str) {
            return angular.isString(str) && uuidPattern.test(str);
        }

        ///////////////////////////////////////////////////////////////////////////////////////
        //  URL query string encoding
        ///////////////////////////////////////////////////////////////////////////////////////
        function buildUrl(url, serializedParams) {
            if (serializedParams.length > 0) {
                url += ((url.indexOf('?') === -1) ? '?' : '&') + serializedParams;
            }
            return url;
        }

        // Serialize and ecode the params
        function paramSerializer(params) {
            if (!params) {
                return '';
            }
            var parts = [];
            forEachSorted(params, function(value, key) {
                if (value === null || angular.isUndefined(value)) {
                    return;
                }
                if (angular.isArray(value)) {
                    angular.forEach(value, function(v) {
                        parts.push(encodeUriQuery(key) + '=' + encodeUriQuery(serializeValue(v)));
                    });
                } else {
                    parts.push(encodeUriQuery(key) + '=' + encodeUriQuery(serializeValue(value)));
                }
            });

            return parts.join('&');
        }

        // private
        function serializeValue(v) {
            if (angular.isObject(v)) {
                return angular.isDate(v) ? v.toISOString() : angular.toJson(v);
            }
            return v;
        }
        // private
        function forEachSorted(obj, iterator, context) {
            var keys = Object.keys(obj).sort();
            for (var i = 0; i < keys.length; i++) {
                iterator.call(context, obj[keys[i]], keys[i]);
            }
            return keys;
        }

        /**
         * We need our custom method because encodeURIComponent is too aggressive and doesn't follow
         * http://www.ietf.org/rfc/rfc3986.txt with regards to the character set (pchar) allowed in path
         * segments:
         *    segment       = *pchar
         *    pchar         = unreserved / pct-encoded / sub-delims / ":" / "@"
         *    pct-encoded   = "%" HEXDIG HEXDIG
         *    unreserved    = ALPHA / DIGIT / "-" / "." / "_" / "~"
         *    sub-delims    = "!" / "$" / "&" / "'" / "(" / ")"
         *                     / "*" / "+" / "," / ";" / "="
         */
        function encodeUriSegment(val) {
            return encodeUriQuery(val, true).
            replace(/%26/gi, '&').
            replace(/%3D/gi, '=').
            replace(/%2B/gi, '+');
        }

        /**
         * This method is intended for encoding *key* or *value* parts of query component. We need a custom
         * method because encodeURIComponent is too aggressive and encodes stuff that doesn't have to be
         * encoded per http://tools.ietf.org/html/rfc3986:
         *    query       = *( pchar / "/" / "?" )
         *    pchar         = unreserved / pct-encoded / sub-delims / ":" / "@"
         *    unreserved    = ALPHA / DIGIT / "-" / "." / "_" / "~"
         *    pct-encoded   = "%" HEXDIG HEXDIG
         *    sub-delims    = "!" / "$" / "&" / "'" / "(" / ")"
         *                     / "*" / "+" / "," / ";" / "="
         */
        function encodeUriQuery(val, pctEncodeSpaces) {
            return encodeURIComponent(val).
            replace(/%40/gi, '@').
            replace(/%3A/gi, ':').
            replace(/%24/g, '$').
            replace(/%2C/gi, ',').
            replace(/%3B/gi, ';').
            replace(/%20/g, (pctEncodeSpaces ? '%20' : '+'));
        }
        // End of URL query string encoding


        return PpmUtils;

    }); // end of ppmUtil