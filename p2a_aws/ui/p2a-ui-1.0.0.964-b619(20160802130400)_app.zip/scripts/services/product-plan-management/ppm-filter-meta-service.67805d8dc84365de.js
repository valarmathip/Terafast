'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.FilterSvc
 * @description
 * # FilterSvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('PPMFilterMetaSvc', function() {
        var initArr = [];
        var filterObj = {};
        var accountFilters = {
          'accountStatus': {
            'Account Status': ['Prospect', 'Active', 'Terminated']
          },
          'renewalStartDate': {
            'Renewal Start Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months', 'Date Range']
          },
          'renewalEndDate': {
            'Renewal End Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months', 'Date Range']
          },
          'marketSegment': 'Account Market Segment'
        };

        var productFilters = {
            'productClasses': 'Product',
            'productTypes': 'Product Type',
            'planStatus': 'Plan Status',
            'planType': 'Plan Type',
            'grandfatheredPlan': {
                'Grandfathered': ['Yes', 'No']
            },
            'productRegulatoryApproval': 'Plan Regulatory Approval',
            'hixMetalLevel': 'HIX Metal Level',
            'effectiveDate': {
                'Effective Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months', 'Date Range']
            },
            'endDate': {
                'Plan End Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
            },
            'planDueDate': {
                'Due Date': ['This week', 'Next week', 'This Month', 'Next Month', 'Next 3 Months', 'Past Due Date', 'Date Range']
            },
            'fundingArrangements': 'Funding Arrangements',
            'marketSegments': 'Market Segment'
        };

        var planFilters = {
            'planYear': {
                'Plan Year': ['Current Year + 1', 'Current Year', 'Current Year - 1', 'text']
            },
            'numProviderTiers': {
                'Number of Tiers': ['1', '2', '3', '4', '5', '6', '7', '8']
            }
        };

        var userInformationFilters = {
            'lastModifiedBy': {
                'Modified By': ['Me']
            },
            'createdBy': {
                'Created By': ['Me']
            },
            'lastModificationDate': {
                'Modified Within': ['Last Day', 'Last 7 Days', 'Last 15 Days', 'Last 30 Days', 'Last 60 Days', 'Date Range']
            }
        };

        var productListFilters = {
            'Product': {
                'productClasses': 'Product'
            },
            'Product Type': {
                'productTypes': 'Product Type'
            },
            'Product Status': {
                'productStatus': 'Product Status'
            },
            'Product Family': {
                'productFamilies': 'Product Family'
            },
            'Effective Start Date': {
                'effectiveDate': {
                    'Effective Start Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months', 'Date Range']
                }
            },
            'Product End Date': {
                'endDate': {
                    'Product End Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
                }
            },
            'Funding Arrangement': {
                'fundingArrangements': 'Funding Arrangements'
            },
            'Market Segment': {
                'marketSegments': 'Market Segments'
            },
            'Distribution Channel': {
                'distributionChannels': 'Distribution Channels'
            },
            'Provider Tiers': {
                'providerTierNames': 'Provider Tiers'
            },
            'Product Regulatory Approval': {
                'productRegulatoryApproval': 'Product Regulatory Approval'
            },
            'Product Regulatory Date': {
                'productRegulatoryDate': {
                    'Product Regulatory Date': ['Last Day', 'Last 7 Days', 'Last 15 Days', 'Last 30 Days', 'Last 60 Days', 'Date Range']
                }
            },
            'Member Funding': {
                'memberFundings': 'Member Fundings'
            },
            'Line Of Business': {
                'lineOfBusiness': 'Line Of Business'
            },
            'Applicable Coverage Tiers': {
                'applicableCoverageTiers': 'Applicable Coverage Tiers'
            },
            'Modified By': {
                'lastModifiedBy': {
                    'Modified By': ['Me']
                }
            },
            'Created By': {
                'createdBy': {
                    'Created By': ['Me']
                }
            },
            'Modified Within': {
                'lastModificationDate': {
                    'Modified Within': ['Last Day', 'Last 7 Days', 'Last 15 Days', 'Last 30 Days', 'Last 60 Days', 'Date Range']
                }
            },
            'Product Due Date': {
                'productDueDate': {
                    'Product Due Date': ['This week', 'Next week', 'This Month', 'Next Month', 'Next 3 Months', 'Past Due Date', 'Date Range']
                }
            }
        };

        var serviceFilters = {
            'Product': {
                'productClasses': 'Product'
            },
            'Service Category': {
                'category': 'Service Category'
            },
            'Service Sub Category': {
                'subCategory': 'Service Sub Category'
            },
            'Service Level': {
                'level': 'Service Level'
            }
        };

        var offeringFilters = {
            'productClasses': 'Product',
            'productTypes': 'Product Type',
            'hixMetalLevelOffering': 'HIX Metal Level',
            'effectiveDate': {
                'Effective Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months', 'Date Range']
            },
            'endDate': {
                'Plan End Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
            },
            'marketSegment': 'Market Segment',
            'fundingArrangement': 'Funding Arrangements'
        };
        return {
            initializeArr: function() {
                initArr = [];
                filterObj = {
                    'Product Filters': productFilters,
                    'Plan Filters': planFilters,
                    'User Information Filters': userInformationFilters
                };
                initArr.push(filterObj);
                return initArr;
            },
            /**
             * @ngdoc method
             * @name initializeOfferArr
             * @methodOf p2AdvanceApp.FilterSvc
             * @description
             * Get filters for offerings listing page
             *
             * @param {object} Colection of filter bindings
             * @returns {Array} Array of Filter names and values
             */
            initializeOfferArr: function() {
                initArr = [];
                filterObj = {
                    'Offering Filters': offeringFilters,
                    'User Information Filters': userInformationFilters
                };
                initArr.push(filterObj);
                return initArr;
            },
            initializeAccountArr: function() {
              initArr = [];
              filterObj = {
                'Account Filters': accountFilters,
                'User Information Filters': userInformationFilters
              };
              initArr.push(filterObj);
              return initArr;
            },
            getServiceFilters: function() {
                initArr = [];
                initArr.push(serviceFilters);
                return initArr;
            },
            updateFilterMetaData: function(filtersMeta) {
                var filters = [];
                var self = this;
                var serviceProp = filtersMeta[0].properties; //Contains service related 'category,level,subcatagory ' Filter information
                var initArr = self.getServiceFilters();
                var filterArray = self.assignPropertiesToFiltersGroups(initArr, serviceProp, []);
                angular.forEach(filterArray, function(filterGroups) {
                    angular.forEach(filterGroups, function(item) {
                        filters.push(item[0]);
                    });
                });
                return filters;
            },
            iteratePlanArr: function(planFilters, planProp, aspectDefProp) {
                var self = this;
                var resultArr = [];
                var filterCategory = {};

                angular.forEach(planFilters, function(planFilterVal, planFilterKey) {
                    filterCategory = self.associateFilterValues(planFilterVal, planFilterKey, planProp, aspectDefProp);
                    resultArr.push(filterCategory);
                });
                return resultArr;
            },

            associateFilterValues: function(planFilterVal, planFilterKey, planProp, aspectDefProp) {
                var self = this;
                var filterCategory = {};
                if (planFilterKey in planProp && 'items' in planProp[planFilterKey]) {
                    filterCategory = self.pushAttrObjToArr(planProp[planFilterKey]['items']['enum'], planProp, planFilterVal, planFilterKey);
                } else if (planFilterKey in planProp && 'enum' in planProp[planFilterKey]) {
                    filterCategory = self.pushAttrObjToArr(planProp[planFilterKey]['enum'], planProp, planFilterVal, planFilterKey);
                } else if (planFilterKey in aspectDefProp && 'items' in aspectDefProp[planFilterKey]) {
                    filterCategory = self.pushAttrObjToArr(aspectDefProp[planFilterKey]['items']['enum'], aspectDefProp, planFilterVal, planFilterKey);
                } else if (planFilterKey in aspectDefProp && 'enum' in aspectDefProp[planFilterKey]) {
                    filterCategory = self.pushAttrObjToArr(aspectDefProp[planFilterKey]['enum'], aspectDefProp, planFilterVal, planFilterKey);
                } else {
                    filterCategory = self.pushToEnumlessProp(planFilterKey, planFilterVal);
                }
                return filterCategory;
            },

            pushAttrObjToArr: function(iterableArr, properties, planFilterVal, planFilterKey) {
                var objArr = [];
                var filterCategory = {};
                iterableArr = iterableArr.sort();
                angular.forEach(iterableArr, function(arrVal) {
                    var attrObj = planFilterVal + arrVal;
                    attrObj = {};
                    attrObj['AttributeId'] = properties[planFilterKey]['name'];
                    attrObj['AttributeName'] = planFilterVal;
                    attrObj['AttributeValue'] = arrVal;
                    attrObj['DisplayValue'] = arrVal;
                    objArr.push(attrObj);
                });
                filterCategory[planFilterVal] = objArr;
                return filterCategory;
            },

            pushToEnumlessProp: function(planFilterKey, planFilterVal) {
                var objArr = [];
                var filterCategory = {};

                angular.forEach(planFilterVal, function(filterVal, filterKey) {
                    angular.forEach(filterVal, function(filterData) {
                        var attrObj = planFilterKey + filterData;
                        attrObj = {};
                        attrObj['AttributeId'] = planFilterKey;
                        attrObj['AttributeName'] = filterKey;
                        attrObj['AttributeValue'] = filterData;
                        attrObj['DisplayValue'] = filterData;
                        objArr.push(attrObj);
                    });
                    filterCategory[filterKey] = objArr;
                });
                return filterCategory;
            },

            assignPropertiesToFiltersGroups: function(initArr, planProp, aspectDefProp) {
                var self = this;
                var resArr = [];
                var filtersGroups = [];
                angular.forEach(initArr, function(filter) {
                    angular.forEach(filter, function(filterGroup, filterName) {
                        var filterObj = {};
                        resArr = self.iteratePlanArr(filterGroup, planProp, aspectDefProp);
                        filterObj[filterName] = resArr;
                        filtersGroups.push(filterObj);
                    });
                });
                return filtersGroups;
            },
            updateProductListFilters: function(filtersMeta) {
                var filters = [];
                var productListProp = filtersMeta;
                var initArr = this.productFiltersMeta();
                var filterArray = this.assignPropertiesToFiltersGroups(initArr, productListProp, []);
                angular.forEach(filterArray, function(filterGroups) {
                    angular.forEach(filterGroups, function(item) {
                        filters.push(item[0]);
                    });
                });
                return filters;
            },
            productFiltersMeta: function() {
                var initArr = [];
                initArr.push(productListFilters);
                return initArr;
            }
        };
    });
