'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.ValidationCostShareSvc
 * @description
 * # ValidationCostShareSvc
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .service('ValidationCostShareSvc', function($log) {

        var validation = {
            validateMemberCostSharesOfAllServices: function() {
                $log.log('validateCostSharesOfAllServices');
                return validateMemberCostSharesOfAllServices();
            },
            validateMemberCostSharesOfSingleService: function(serviceIndex) {
                $log.log('validateCostSharesOfSingleService');
                return validateMemberCostSharesOfSingleService(serviceIndex);
            },
            // Set/Get
            associatedServices: function(value) {
                return arguments.length ? associatedServices(value) : associatedServices();
            }
        };

        var model = {};
        model.associatedServices = null;

        function validateMemberCostSharesOfAllServices() {
            var result = false;
            for (var i = 0; i < model.associatedServices.length; i++) {
                if (!result) {
                    result = validateMemberCostSharesOfSingleService(i);
                }
            }
            return result;
        }

        function validateMemberCostSharesOfSingleService(serviceIndex) {
            var result = false;
            var service = model.associatedServices[serviceIndex];


            if (service && service.planSvcJointProps && service.planSvcJointProps.costShares) {
                angular.forEach(service.planSvcJointProps.costShares, function(tierInfo) {
                    if (!result) {
                        result = validateMemberCostSharesOfSingleTier(tierInfo);
                    }
                });
            }
            if (result) {
                $log.log('Warning: Single tier cost share validation not passed.');
            }
            return result;
        }

        function validateMemberCostSharesOfSingleTier(tierInfo) {
            var flag = false;
            angular.forEach(tierInfo, function(csInfo, costshareType) {
                if (!flag) {
                    flag = validateSingleCostShareType(csInfo, costshareType);
                }
            });
            return flag;
        }

        function validateSingleCostShareType(csInfo, costshareType) {
            var flag = false;
            angular.forEach(csInfo, function(levelInfo) {
                if (!flag) {
                    if (levelInfo.selectedValue < 0) {
                        if ((costshareType === 'Copay') || (costshareType === 'Co-insurance') || (costshareType === 'Deductible')) {
                            flag = true;
                        }
                    } else if (levelInfo.selectedValue > 100 && costshareType === 'Co-insurance') {
                        flag = true;
                    }
                }
            });
            return flag;
        }

        function associatedServices(value) {
            if (arguments.length) {
                model.associatedServices = value;
            }
            return model.associatedServices;
        }

        return validation;

    });