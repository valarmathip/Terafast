'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.PPMENV
 * @description
 * # PPMENV
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('PPMENV', function($location, ENV, $log) {
        var PPMCONST = ENV.PPMCONST;
        // Public API here
        return {
            getPpmSearchApiEndpoint: function() {
                if (PPMCONST.URL.ppmSearchService.apiEndpoint && PPMCONST.URL.ppmSearchService.apiEndpoint.length > 0) {
                    return PPMCONST.URL.ppmSearchService.apiEndpoint;
                } else {
                    return this.getHost() + this.getPort();
                }
            },
            getPpmSearchUrl: function() {
                return this.getPpmSearchApiEndpoint() + '/' + PPMCONST.URL.ppmSearchService.contextPath;
            },
            getPpmApiEndpoint: function() {
                if (PPMCONST.URL.ppmService.apiEndpoint && PPMCONST.URL.ppmService.apiEndpoint.length > 0) {
                    return PPMCONST.URL.ppmService.apiEndpoint;
                } else {
                    return this.getHost() + this.getPort();
                }
            },
            getCmApiEndpoint: function() {
                if (PPMCONST.URL.cmService.apiEndpoint && PPMCONST.URL.cmService.apiEndpoint.length > 0) {
                    return PPMCONST.URL.cmService.apiEndpoint;
                } else {
                    return this.getHost() + this.getPort();
                }
            },
            getCmUrl: function() {
                return this.getCmApiEndpoint() + '/' + PPMCONST.URL.cmService.contextPath;
            },
            getPort: function() {
                // return ':8080';
                return ($location.port()) ? (':' + $location.port()) : '';
            },
            getHost: function() {
                // return 'http://192.168.2.120'
                return $location.protocol() + '://' + $location.host();
            },
            getContextPath: function() {
                return '/' + PPMCONST.URL.ppmService.contextPath;
            },
            getPpmUrl: function() {
                return this.getPpmApiEndpoint() + this.getContextPath();
            },
            getWorkflowApiEndpoint: function() {
                if (PPMCONST.URL.workflowService.apiEndpoint && PPMCONST.URL.workflowService.apiEndpoint.length > 0) {
                    return PPMCONST.URL.workflowService.apiEndpoint;
                } else {
                    return this.getHost() + this.getPort();
                }
            },
            getWorkflowUrl: function() {
                return this.getWorkflowApiEndpoint() + '/' + PPMCONST.URL.workflowService.contextPath;
            },

            getProductDetailMetaInfoURI: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') { // Use data means that we are in development mode, using mock data
                    path += '/product-details-fields-meta-data.json';
                } else {
                    path += '/screens/product';
                }
                return path;
            },
            getDocumentDetailMetaInfoURI: function() {
                var path;
                if (PPMCONST.URL.ppmService.contextPath === 'data') { // Use data means that we are in development mode
                    path = this.getPpmApiEndpoint() + this.getContextPath() + '/document-details-fields-meta-data.json';
                } else {
                    //path = this.getPpmApiEndpoint() + this.getContextPath() + '/documentMetadata';
                    path = this.getHost() + this.getPort() + '/data/document-details-fields-meta-data.json'; // TODO: this is not from backend
                }
                return path;
            },
            getProductDetail: function(id) {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/product-details.json';
                } else {
                    path += '/products/' + id;
                }
                return path;
            },
            getCreateProduct: function() {
                var path = this.getPpmUrl() + '/products';
                return path;
            },
            getProductList: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/product-list.json';
                } else {
                    path = this.getPpmSearchUrl();
                }
                return path;
            },
            getServiceDefinitionMetaInfoURI: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/service-definition-fields-meta-data.json';
                } else {
                    path += '/screens/service';
                }
                return path;
            },
            getServiceDefinition: function() {
                var path;
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    // var path = 'http://127.0.0.1:9000/data/service-definition.json';
                    path = this.getPpmApiEndpoint() + this.getContextPath() + '/service-definition.json';
                } else {
                    path = this.getPpmApiEndpoint() + this.getContextPath() + '/service-definition.json'; // TODO: SLQ: Note not backend data
                }
                return path;
            },
            getCreateService: function() {
                var path = this.getPpmUrl() + '/services';
                return path;
            },
            getPlanDetailMetaInfoURI: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') { // Use data means that we are in development mode
                    path += '/plan-details-fields-meta-data.json';
                } else {
                    path += '/screens/metadata/plan'; //  '/screens/plan';
                }
                return path;
            },
            getCreatePlan: function() {
                var path = this.getPpmUrl() + '/plans';
                return path;
            },
            getPlanList: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/plan-list.json';
                } else {
                    path = this.getPpmSearchUrl();
                }
                return path;
            },
            getPlanListFilterMeta: function() {
                var path;
                path = this.getHost() + this.getPort() + '/app/data' + '/ppm-plan-filter-meta-data.json'; // TODO: need to move to backend
                return path;
            },
            getDocumentFilterMeta: function() {
                var path;
                path = this.getHost() + this.getPort() + '/data' + '/documents-details-field-meta-data.json'; // TODO: need to move to backend
                return path;
            },
            getTemplateListFilterMeta: function() {
                var path;
                path = this.getHost() + this.getPort() + '/app/data' + '/template-filter-meta-data.json';
                return path;
            },
            getDocumentListFilterMeta: function() {
                var path;
                path = this.getHost() + this.getPort() + '/app/data' + '/document-filter-meta-data.json';
                return path;
            },
            getServiceList: function(productId) {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/service-list.json';
                } else {
                    path += '/services/?prodId=' + productId;
                }

                return path;
            },
            getAdditionalServiceList: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/service-list.json';
                } else {
                    path = this.getPpmSearchUrl();
                }
                return path;
            },
            getServiceListFilterMeta: function() {
                var path;
                path = this.getHost() + this.getPort() + '/app/data' + '/ppm-service-filter-meta-data.json';
                return path;
            },
            getServiceAddNewListFilterMeta: function() {
                var path;
                path = this.getHost() + this.getPort() + '/app/data' + '/ppm-service-add-new-filter-meta-data.json';
                return path;
            },
            getPlanDetail: function(id) {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path += '/plan-details.json';
                } else {
                    path += '/plans/' + id;
                }
                return path;
            },
            getCmPlanUrl: function() {
                var path = this.getCmUrl();
                path += '/plans';

                return path;
            },
            getCmProductUrl: function() {
                var path = this.getCmUrl();
                path += '/product';
                return path;
            },

            getPpmEntityUrl: function(objectType) {
                var path = this.getPpmUrl();

                switch (objectType) {
                    case 'offering':
                        path += '/offerings';
                        break;
                    case 'plan':
                        path += '/plans';
                        break;
                    case 'product':
                        path += '/products';
                        break;
                    default:
                        $log.error('The specified entity type ' + objectType + ' does not exist');
                        break;
                }

                return path;
            },

            getCmEntityUrl: function(objectType) {
                var path = this.getCmUrl();

                // Note this is cm entity path, this is no 's' at the end
                switch (objectType) {
                    case 'offering':
                        path += '/offering';
                        break;
                    case 'plan':
                        path += '/plan';
                        break;
                    case 'product':
                        path += '/product';
                        break;
                    default:
                        $log.error('The specified entity type ' + objectType + ' does not exist');
                        break;
                }
                return path;
            },
            getPlanServiceUrl: function(planId) {
                if (!planId) {
                    $log.error('The parameter planId for function getPlanServiceUrl must specified!');
                }
                var path = this.getPpmUrl();
                path += '/plans/' + encodeURI(planId) + '/planservices';

                return path;
            },
            getProductServiceUrl: function(productId) {
                if (!productId) {
                    $log.error('The parameter productId for function getProductServiceUrl must specified!');
                }
                var path = this.getPpmUrl();
                path += '/products/' + encodeURI(productId) + '/productservices';

                return path;
            },
            getPpmVersionUrl: function() {
                var path = this.getPpmUrl() + '/version';
                return path;
            },
            getPpmPlanValidateUrl: function() {
                var path = this.getPpmUrl() + '/validate/plans';
                //path = this.getHost() + this.getPort() + '/app/data' + '/validation-report.json';// save for local testing
                return path;
            },
            getCostShareMetaInfoURI: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') { // Use data means that we are in development mode
                    path += '/cost-share-fields-meta-data.json';
                } else {
                    path += '/screens/planservice';
                }
                return path;
            },
            getProductCostShareMetaInfoURI: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') { // Use data means that we are in development mode
                    path += '/product-cost-share-fields-meta-data.json';
                } else {
                    path += '/screens/productservice';
                }
                return path;
            },
            getValidationHistoryURI: function(id) {
                var path = this.getPpmSearchUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path = this.getPpmUrl();
                    path += '/validation-history.json';
                } else {
                    path += encodeURI('?q=TYPE:"auditLog" AND =objectRef:"' + id + '"');
                }
                return path;
            },
            getAuditLogURI: function() {
                var path = this.getCmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') { // Use data means that we are in development mode
                    path = this.getPpmUrl();
                    path += '/validation-history.json';
                } else {
                    path += '/auditLogs';
                }
                return path;
            },
            getLockURI: function(objectType) {
                var path = this.getPpmUrl();

                path += '/lock';
                switch (objectType) {
                    case 'offering':
                        path += '/offerings'; // SLQ current this api is not defined
                        break;
                    case 'plan': // jshint ignore:line
                    default:
                        path += '/plans';
                }

                return path;
            },
            getUnlockURI: function(objectType) {
                var path = this.getPpmUrl();

                path += '/unlock';
                switch (objectType) {
                    case 'offering':
                        path += '/offerings'; // SLQ current this api is not defined
                        break;
                    case 'product':
                        path += '/products'; // SLQ current this api is not defined
                        break;
                    case 'plan': // jshint ignore:line
                    default:
                        path += '/plans';
                }
                return path;
            },
            getLockPlanURI: function() {
                var path = this.getPpmUrl();

                path += '/lock/plans';

                return path;
            },
            getUnlockPlanURI: function() {
                var path = this.getPpmUrl();

                path += '/unlock/plans';

                return path;
            },
            getLockProductURI: function() {
                var path = this.getPpmUrl();

                path += '/lock/products';

                return path;
            },
            getUnlockProductURI: function() {
                var path = this.getPpmUrl();

                path += '/unlock/products';

                return path;
            },
            getCmReportTemplatesUrl: function() {
                var path = this.getCmUrl();
                path += '/reportTemplates';
                return path;
            },
            getReportsMockData: function() {
                var path;
                path = this.getHost() + this.getPort() + '/app/data' + '/data-structure.json';
                return path;
            },
            getRequestOverrideURI: function() {
                var path = this.getWorkflowUrl();
                path += '/cases';
                return path;
            },
            getWorkflowParameter: function() {
                var path = this.getPpmUrl();
                if (PPMCONST.URL.ppmService.contextPath === 'data') {
                    path = this.getHost() + this.getPort() + '/app/data/workflow-data.json';
                } else {
                    path += '/workflowParameters/workflowParameter';
                }
                return path;
            },
            getOfferingURI: function() {
                return this.getPpmUrl() + '/offerings';
            },
            getOfferingDetailFieldMetaInfoURI: function() {
                return this.getPpmUrl() + '/screens/offering';
            },
            getPlanVersionHistoryURI: function() {
                // return this.getCmUrl() + '/plans';
                return this.getHost() + this.getPort() + '/app/data/plan-version-history.json';
            }
        };

        // private variable and function

    });