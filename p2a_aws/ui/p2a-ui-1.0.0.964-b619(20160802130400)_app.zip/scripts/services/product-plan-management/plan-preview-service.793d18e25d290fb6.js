'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.planPreviewSvc
 * @description
 * # planPreviewSvc
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .service('planPreviewSvc', function(ProductPlanMgmtSvc, dialogFactorySvc) {
        return {
            previewPlan: function(planId) {
                var dlgUrl = 'views/product-plan-management/plan-summary.html';
                var controller = 'PlanSummaryDialogCtrl';
                var content = {
                    planDetails: function() {
                        return ProductPlanMgmtSvc.getPlanDetails(planId, 2).then(function(data) {
                            return data;
                        });
                    },
                    planDetailFieldsMetaData: function() {
                        return ProductPlanMgmtSvc.getPlanDetailFieldMetaInfo().then(function(data) {
                            return data;
                        });
                    },
                    planServiceFieldsMetaData: function() {
                        return ProductPlanMgmtSvc.getCostShareFieldMetaInfo().then(function(data) {
                            return data;
                        });
                    }
                };
                var options = {
                    size: 'lg'
                };
                dialogFactorySvc.openModalDialog(dlgUrl, controller, content, options);
            }
        };
    });