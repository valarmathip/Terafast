'use strict';

angular.module('p2AdvanceApp')
    .factory('PlanLockSvc', function($q, $filter, $timeout, $log,
        // p2a defined
        ProductPlanMgmtSvc, CostShareFacadeSvc, QueryDialog, ENV, $auth, userAuthorizationManager) {
        // api
        var planLockSvc = {
            // return promise
            getPlanLockStatus: function(planId) {
                var associationExpansionLevel = 0;
                var properties = ['isLocked', 'lockedBy', 'lockedAt'];
                // Note we use the cm api, instead of search api, because search api could have latency
                return ProductPlanMgmtSvc.getPlanViaCm(planId, associationExpansionLevel, properties);
            },
            getProductLockStatus: function(productId) {
                var associationExpansionLevel = 0;
                var properties = ['isLocked', 'lockedBy', 'lockedAt'];
                // Note we use the cm api, instead of search api, because search api could have latency
                return ProductPlanMgmtSvc.getProductViaCm(productId, associationExpansionLevel, properties);
            },
            // return promise
            isPlanUnlockedOrLockedByMe: function(planId) {
                return planLockSvc.getPlanLockStatus(planId)
                    .then(function(lockStatus) {
                        var meId = $auth.getUserEmail();
                        if (lockStatus.isLocked && lockStatus.lockedBy.toLowerCase() !== meId.toLowerCase()) {
                            var msg = 'The plan is locked by ' + lockStatus.lockedBy + ' at ' + $filter('date')(lockStatus.lockedAt, 'MMM dd yyyy h:mm:ss a') + '!';
                            QueryDialog.open('Warning', msg, 'warning', 'ppm-modal-dialog-warning');
                            return $q.reject(msg);
                        } else { // not locked or locked by me
                            return lockStatus;
                        }
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            isProductUnlockedOrLockedByMe: function(productId) {
                return planLockSvc.getProductLockStatus(productId)
                    .then(function(lockStatus) {
                        var meId = $auth.getUserEmail();
                        if (lockStatus.isLocked && lockStatus.lockedBy.toLowerCase() !== meId.toLowerCase()) {
                            var msg = 'The product is locked by ' + lockStatus.lockedBy + ' at ' + $filter('date')(lockStatus.lockedAt, 'MMM dd yyyy h:mm:ss a') + '!';
                            QueryDialog.open('Warning', msg, 'warning', 'ppm-modal-dialog-warning');
                            return $q.reject(msg);
                        } else { // not locked or locked by me
                            return lockStatus;
                        }
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            lockProductForEdit: function(productId) {
                return planLockSvc.isProductUnlockedOrLockedByMe(productId)
                    .then(function(lockStatus) {
                        if (lockStatus && !lockStatus.isLocked) { // Plan not locked
                            return planLockSvc.lockProduct(productId)
                                .then(function(lockedInfo) {
                                    return lockedInfo; // just make it is clear, in fact lockPlan will return promise include lockedInfo
                                });
                        } else { // Plan is already locked by me
                            return lockStatus;
                        }
                    }); // reject mean lock by some body else, do not handle
            },
            // return promise
            lockPlanForEdit: function(planId) {
                return planLockSvc.isPlanUnlockedOrLockedByMe(planId)
                    .then(function(lockStatus) {
                        if (lockStatus && !lockStatus.isLocked) { // Plan not locked
                            return planLockSvc.lockPlan(planId)
                                .then(function(lockedInfo) {
                                    return lockedInfo; // just make it is clear, in fact lockPlan will return promise include lockedInfo
                                });
                        } else { // Plan is already locked by me
                            return lockStatus;
                        }
                    }); // reject mean lock by some body else, do not handle
            },
            // SLQ TODO: we created some general code here for unlock and unlock, and I think some of the code in plan list
            // and product list could be replace by this codes.
            lockEntityForEdit: function(objectId, objectType) {
                return planLockSvc.isEntityUnlockedOrLockedByMe(objectId, objectType)
                    .then(function(lockStatus) {
                        if (lockStatus && !lockStatus.isLocked) { // Plan not locked
                            return planLockSvc.lockEntity(objectId, objectType)
                                .then(function(lockedInfo) {
                                    return lockedInfo; // just make it is clear, in fact lockPlan will return promise include lockedInfo
                                });
                        } else { // Plan is already locked by me
                            return lockStatus;
                        }
                    }); // reject mean lock by some body else, do not handle
            },
            isEntityUnlockedOrLockedByMe: function(objectId, objectType) {
                return planLockSvc.getEntityLockStatus(objectId, objectType)
                    .then(function(lockStatus) {
                        var meId = $auth.getUserEmail();
                        if (lockStatus.isLocked && lockStatus.lockedBy.toLowerCase() !== meId.toLowerCase()) {
                            var msg = 'The plan is locked by ' + lockStatus.lockedBy + ' at ' + $filter('date')(lockStatus.lockedAt, 'MMM dd yyyy h:mm:ss a') + '!';
                            QueryDialog.open('Warning', msg, 'warning', 'ppm-modal-dialog-warning');
                            return $q.reject(msg);
                        } else { // not locked or locked by me
                            return lockStatus;
                        }
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            // return promise
            // in the future, getPlanLockStatus, getProductLockStatus could be replaced by this one
            getEntityLockStatus: function(objectId, objectType) {
                var associationExpansionLevel = 0;
                var properties = ['isLocked', 'lockedBy', 'lockedAt'];
                // note we use the cm api, instead of search api, because search api could have latency
                return ProductPlanMgmtSvc.getEntityViaCm(objectId, objectType, associationExpansionLevel, properties);
            },
            isLockedByMe: function(lockStatus) {
                var meId = $auth.getUserEmail();
                return !!lockStatus.isLocked && lockStatus.lockedBy.toLowerCase() === meId.toLowerCase(); // not case sensitive
            },
            refreshLockStatus: function(entityList, objectId, lockStatus) {
                function findEntityFromEntityListById(objId) {
                    for (var i = 0; i < entityList.length; i++) {
                        if (objId === entityList[i].objectId) {
                            return entityList[i];
                        }
                    }

                    return null;
                }

                var entity = findEntityFromEntityListById(objectId);

                if (entity) {
                    if (lockStatus === null) {
                        delete entity.isLocked; // = undefined;
                        delete entity.lockedBy; // = undefined;
                        delete entity.lockedAt; // = undefined;

                    } else {
                        entity.isLocked = lockStatus.isLocked;
                        entity.lockedBy = lockStatus.lockedBy;
                        entity.lockedAt = lockStatus.lockedAt; // This could be a little difference between backend really lock time
                    }
                }
            },
            isLockShown: function(entity) {
                var itemShow = !entity.isLocked;
                itemShow = itemShow && hasLockPermission(entity);

                return itemShow;
            },
            isUnlockShown: function(entity) {
                var itemShow = !!entity.isLocked;
                itemShow = itemShow && hasUnlockPermission(entity);

                return itemShow;
            },
            // return promise
            lockEntity: function(objectId, objectType) {
                return ProductPlanMgmtSvc.lockEntity(objectId, objectType)
                    .then(function(lockStatus) {
                        return lockStatus;
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            // return promise
            unlockEntity: function(objectId, objectType) {
                return ProductPlanMgmtSvc.unlockEntity(objectId, objectType)
                    .then(function(unlockStatus) {
                        return unlockStatus;
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            // return promise
            lockPlan: function(planId) {
                return ProductPlanMgmtSvc.lockPlan(planId)
                    .then(function(lockStatus) {
                        return lockStatus;
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            // return promise
            unlockPlan: function(planId) {
                return ProductPlanMgmtSvc.unlockPlan(planId)
                    .then(function(unlockStatus) {
                        return unlockStatus;
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            lockProduct: function(productId) {
                return ProductPlanMgmtSvc.lockProduct(productId)
                    .then(function(lockStatus) {
                        return lockStatus;
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            // return promise
            unlockProduct: function(productId) {
                return ProductPlanMgmtSvc.unlockProduct(productId)
                    .then(function(unlockStatus) {
                        return unlockStatus;
                    }, function(reason) {
                        showErrorMessage(reason);
                        return $q.reject(reason); // must reject, otherwise, the successful handler will get called
                    });
            },
            // return promise
            queryIfUserNeedToUnlockPlan: function(planId) {
                $log.log('>>>>>>>>>>> queryIfUserNeedToUnlockPlan');
                return planLockSvc.getPlanLockStatus(planId)
                    .then(function(lockInfo) {
                        if (lockInfo && lockInfo.isLocked) {
                            return QueryDialog.open('Lock/Unlock', '<p>Do you want to Unlock the plan?</p>', 'question', 'ppm-modal-dialog-question')
                                .result.then(function( /*data*/ ) {
                                        $log.log('closed');
                                        // unlock
                                        return planLockSvc.unlockPlan(lockInfo.objectId);
                                        // return data;
                                    },
                                    function(reason) {
                                        $log.log('canceled');
                                        // keep locking
                                        return reason;
                                    });
                        }
                    });
            },

            // In the future, if possible, this will be used as replacement of queryIfUserNeedToUnlockPlan, queryIfUserNeedToUnlockProduct
            // return promise
            queryIfUserNeedToUnlockEntity: function(objectId, objectType) {
                return planLockSvc.getEntityLockStatus(objectId, objectType)
                    .then(function(lockInfo) {
                        if (lockInfo && lockInfo.isLocked) {
                            return QueryDialog.open('Lock/Unlock', '<p>Do you want to Unlock the ' + objectType + '?</p>', 'question', 'ppm-modal-dialog-question')
                                .result.then(function( /*data*/ ) {
                                        $log.log('closed');
                                        // unlock
                                        return planLockSvc.unlockEntity(lockInfo.objectId, objectType);
                                        // return data;
                                    },
                                    function(reason) {
                                        $log.log('canceled');
                                        // keep locking
                                        return reason;
                                    });
                        }
                    });
            }
        };

        // private variable and function
        function showErrorMessage(reason) {
            if (!reason) {
                return;
            }
            $log.log(JSON.stringify(reason));
            var msg = (reason && reason.errorDetails) ? reason.errorDetails : 'No error info available.';
            QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
        }

        /**
            lock/unlock permission
            moved from plan-list-hover-menu.js
         */
        // Since the lock status is a aspect, and if at last this judgement is not related to plan and product, we can move this into a service.
        function hasLockPermission(entity) {
            var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.lock', entity);
            // HRSuperAdmin has the all.create permisison
            hasPerm = hasPerm || userAuthorizationManager.hasPermissionWithCriteria('all.create', entity);

            return hasPerm;
        }

        function hasUnlockPermission(entity) {
            // This just test if 'ME' can unlock the current plan
            var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.unlock.me', entity);
            hasPerm = hasPerm || hasUnlockOthersPermission(entity);

            return hasPerm;
        }

        function hasUnlockOthersPermission(entity) {
            // NOTE: Current only the 'OrganizationAdmin' role has this permission, so we use this
            // permission to determine if user is organization admin user
            var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.unlock', entity); // do not to check criteria
            // HRSuperAdmin has the all.create permisison
            hasPerm = hasPerm || userAuthorizationManager.hasPermissionWithCriteria('all.create', entity); // do not to check criteria

            return hasPerm;
        }
        /* end of lock/unlock permission */

        return planLockSvc;
    });