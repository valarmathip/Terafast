'use strict';

/**
    Event: 
        ppm.offering.list.hover.menu.lock.status.changed: the event is *emit* when the plan locked status changed
 */
angular.module('p2AdvanceApp')
    .factory('OfferingListHoverMenuSvc', function($state, $log,
        // p2a defined
        PlanLockSvc, ProductPlanMgmtSvc, userAuthorizationManager
    ) {


        var offeringListHoverMenuSvc = {
            getHoverMenu: function(scope) {
                return hoverMenu.bind(scope)();
            }
        };

        function hoverMenu() {
            /*jshint validthis:true*/
            var contextScope = this;

            function editOffer(guid) {
                $state.go('home.ppm.offering.edit', {
                    offeringId: guid // SLQ: stateParamenter need to be confirmed with Haiyan
                });
            }

            function copyOffering(offeringId) {
                ProductPlanMgmtSvc.createOfferingFromOffering({}, offeringId)
                    .then(function(newOfferingId) {
                        editOffer(newOfferingId);
                    });
            }

            function generateOfferingDocuments(guid) {
                $state.go('home.media-management.generateDocumentByDataSourceId', {
                    businessEntity: 'offering',
                    dataSourceId: guid
                });
            }

            function lockOffering(offering) {
                PlanLockSvc.lockEntity(offering.objectId, offering.objectType)
                    .then(function(lockStatus) {
                            // notify related plan-list to refresh lock status
                            notifyLockStatusChanged(lockStatus, offering.objectId);
                        },
                        function( /*reason*/ ) {
                            // Important: This function is necessary, just used as resolve the promise, otherwise, the return status could be 401, and will cause the page reload.
                        });
            }

            function unlockOffering(offering) {
                PlanLockSvc.unlockEntity(offering.objectId, offering.objectType)
                    .then(function() {
                            // clear lock status
                            notifyLockStatusChanged(null, offering.objectId);
                        },
                        function( /*reason*/ ) {
                            // Important: This function is necessary, just used as resolve the promise, otherwise, the return status could be 401, and will cause the page reload.
                        });
            }

            function notifyLockStatusChanged(lockStatus, offeringId) {
                contextScope.$emit('ppm.offering.list.hover.menu.lock.status.changed', lockStatus, offeringId);
            }

            function hasUpdatePermissionOnThisOffering(offering) {
                var itemShow = userAuthorizationManager.hasPermission('all.update'); // super user
                itemShow = itemShow || userAuthorizationManager.hasPermissionWithCriteria('offering.update', offering); // has all plan update permissions

                itemShow = itemShow && (!offering.isLocked || PlanLockSvc.isLockedByMe(offering));

                return itemShow;
            }

            var hoverItems = [{ // index: 0
                label: 'Edit This Offering',
                icon: 'fa-pencil',
                isShown: function(offering) {
                    return hasUpdatePermissionOnThisOffering(offering);
                },
                action: function(offering) {
                    editOffer(offering.objectId);
                }
            }, { // index: 1
                label: 'Create new Offering from this Offering',
                icon: 'fa-share-square-o',
                isShown: function() {
                    return true; // note permission will override this one, maybe because it is after isShown be called
                },
                action: function(offering) {
                    copyOffering(offering.objectId);
                },
                permission: '|offering.create,|all.create' // Note: offering.create is not defined yet
            }, { // index: 2
                label: 'Generate Document(s)',
                icon: 'fa-files-o',
                isShown: function() {
                    return true;
                },
                action: function(offering) {
                    generateOfferingDocuments(offering.objectId);
                },
                permission: '|document.create,|all.create'
            }, { // index: 3
                label: 'Lock the Offering',
                icon: 'fa-lock',
                isShown: function(offering) {
                    return PlanLockSvc.isLockShown(offering);
                },
                action: function(offering) {
                    lockOffering(offering);
                }
            }, { // index: 4
                label: 'Unlock the Offering',
                icon: 'fa-unlock',
                isShown: function(offering) {
                    return PlanLockSvc.isUnlockShown(offering);
                },
                action: function(offering) {
                    unlockOffering(offering);
                }
            }];

            return hoverItems;
        }

        return offeringListHoverMenuSvc;
    });