'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.PpmOfferingSummaryDialogSvc
 * @description
 * # PpmOfferingSummaryDialogService
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
	.service('PpmOfferingSummaryDialogSvc', function(ProductPlanMgmtSvc, dialogFactorySvc) {
		var ppmOfferingSummaryDialogSvc = {
			showOfferingSummaryDialog: showOfferingSummaryDialog
		};

		function showOfferingSummaryDialog(offeringId) {
			var dlgUrl = 'views/product-plan-management/offering-summary.html';
			var controller = 'OfferingSummaryDialogCtrl';
			var data = {
				offeringDetails: function() {
					return ProductPlanMgmtSvc.getEntityViaPpm(offeringId, 'offering', 1, '').then(function(data) {
						return data;
					});
				},
				offeringDetailFieldsMetaData: function() {
					return ProductPlanMgmtSvc.getOfferingDetailFieldMetaInfo().then(function(data) {
						return data;
					});
				}
			};
			var options = {
				size: 'lg'
			};
			dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
		}

		return ppmOfferingSummaryDialogSvc;
	});