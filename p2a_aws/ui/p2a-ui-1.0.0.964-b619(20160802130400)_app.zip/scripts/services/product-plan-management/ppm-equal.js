'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.PpmEquals
 * @description
 * # PpmEquals
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('PpmEqual', function($parse, $filter, ENV, $log) {
        var debug = false; // (ENV.name === 'local');
        //$log = console;


        var prefix = 'value';
        var arrayCfg = 'arrCfg';
        // var config; // config put will cause all equal instance share one configure

        /**
            Provided config:
            1. sortAndCompare: sort the array and then compare them (use angularjs orderBy filter)
            2. comparator: custom define how the 2 object/primitive value equal. the is define a parent level and compare all propeties of parent.
            3. customEqual: provoid compare method

            configObj = {
                sortAndCompare: {expression: null},
                comparator: function(o1, o2){}, // all its direct children will use this to compare
                customEqual: function(o1, o2, propertyName, level){}
            }

            config: {
                'value.a.arrCfg.b.d.e.f': configObj,
                'value.a.arrCfg.*.*.*.f': configObj2,
                'value.a.arrCfg.**.f': configObj2,
            }
         */
        var defaultConfig = {};

        /**
         * Compare is performed on deep copy of provided object
         */
        function ppmEqual(configPara) {
            var config = angular.extend({}, defaultConfig, configPara);
            var p1, p2;

            // api
            /* jshint validthis: true */
            this.equals = function(o1, o2) {
                p1 = angular.copy(o1);
                p2 = angular.copy(o2);
                var result = equals.apply(this, [p1, p2, prefix, 0]);
                p1 = p2 = null;
                return result;
            };
            // the api for custom function that try to recursive call equals (SLQ need test)
            /* jshint validthis: true */
            this.internalEquals = function(o1, o2, propertyName, level) {
                equals.apply(this, [o1, o2, propertyName, level]);
            };

            /*jshint maxcomplexity:50 */
            function equals(o1, o2, propertyName, level) {
                // use custome comparator first, if it is available
                var comparator = getParentCompartor(propertyName);
                if (comparator) {
                    var isComparatorEquals = comparator.apply(this, [o1, o2, propertyName, level]);
                    if (!isComparatorEquals) {
                        printDebugValue(level, propertyName, p1, p2, 'not equal');
                    }
                    return isComparatorEquals;
                }

                // use the custom method to test if it available
                var preferConfig = getCustomConfig(propertyName);
                if (preferConfig) {
                    if (preferConfig.sortAndCompare) {
                        var isSortAndCompareEqual = sortAndCompareEqual.apply(this, [o1, o2, propertyName, level, preferConfig.sortAndCompare.expression]);
                        if (!isSortAndCompareEqual) {
                            printDebugValue(level, propertyName, p1, p2, 'not equal');
                        }
                        return isSortAndCompareEqual;
                    } else if (preferConfig.customEqual) {
                        var isCustomEquals = preferConfig.customEqual.apply(this, [o1, o2, propertyName, level]);
                        if (!isCustomEquals) {
                            printDebugValue(level, propertyName, p1, p2, 'not equal');
                        }
                        return isCustomEquals;
                    }
                }

                if (o1 === o2) {
                    return true;
                }

                if (o1 === null || o2 === null) {
                    printDebugValue(level, propertyName, p1, p2, 'one or both them is null');
                    return false;
                }
                if (o1 !== o1 && o2 !== o2) {
                    return true; // NaN === NaN
                }

                var t1 = typeof o1,
                    t2 = typeof o2,
                    length, key, keySet;

                if (t1 === t2) { // same type of object
                    if (t1 === 'object') {
                        if (isArray(o1)) { // array, typeof array also return "Object"
                            if (!isArray(o2)) {
                                printDebugValue(level, propertyName, p1, p2, 'second is not an Array');
                                return false;
                            }
                            if ((length = o1.length) === o2.length) {
                                return defaultArrayEqaul.apply(this, [o1, o2, length, propertyName, level]);
                            }
                        } else if (isDate(o1)) {
                            if (!isDate(o2)) {
                                printDebugValue(level, propertyName, p1, p2, 'second is not a Date');
                                return false;
                            }
                            return equals.apply(this, [o1.getTime(), o2.getTime(), propertyName, level + 1]);
                        } else if (isRegExp(o1)) {
                            return isRegExp(o2) ? o1.toString() === o2.toString() : false;
                        } else { // suppose to be object
                            if (isScope(o1) || isScope(o2) || isWindow(o1) || isWindow(o2) ||
                                isArray(o2) || isDate(o2) || isRegExp(o2)) {
                                return false;
                            }

                            keySet = createMap();
                            for (key in o1) {
                                if (!o1.hasOwnProperty(key)) { // this is requested by jsHint. Works fine now, because all our property is direct property not inherited property
                                    continue;
                                }
                                if (key.charAt(0) === '$' || isFunction(o1[key])) {
                                    continue;
                                }
                                var keyStr = propertyName + '.' + key;
                                if (!equals.apply(this, [o1[key], o2[key], keyStr, level + 1])) {
                                    return false;
                                }
                                keySet[key] = true;
                            }
                            for (key in o2) {
                                if (!o2.hasOwnProperty(key)) {
                                    continue;
                                }
                                if (!(key in keySet) &&
                                    key.charAt(0) !== '$' &&
                                    isDefined(o2[key]) &&
                                    !isFunction(o2[key])) {
                                    var attrName = propertyName + '.' + key;
                                    printDebugValue(level, attrName, p1, p2, 'not exist in other one');
                                    return false;
                                }
                            }
                            return true;
                        }
                    }
                }

                printDebugValue(level, propertyName, p1, p2, 'not equal');
                return false;
            } // end of equals


            // pre-condition: two arrays length is the same length
            function defaultArrayEqaul(array1, array2, length, propertyName, level) {
                var key;
                for (key = 0; key < length; key++) {
                    var arrEltStr = propertyName + '[' + key + ']';
                    if (!equals.apply(this, [array1[key], array2[key], arrEltStr, level + 1])) {
                        // printDebugValue(level, arrEltStr, p1, p2, 'Array element not equal (duplicated)'); 
                        return false;
                    }
                }
                return true;
            }

            function sortAndCompareEqual(array1, array2, propertyName, level, expression) {
                log('compared in sortAndCompareEqual');
                if (!isArray(array1) || !isArray(array2)) {
                    throw new Error('Custom configuration is not for array comparation');
                }

                if (array1.length !== array2.length) {
                    return false;
                }

                if (!expression) {
                    expression = angular.identity;
                }
                array1 = $filter('orderBy')(array1, expression);
                array2 = $filter('orderBy')(array2, expression);

                return defaultArrayEqaul.apply(this, [array1, array2, array1.length, propertyName, level]);
            }

            function renormalizePropertyName(propertyName) {
                log('*** propertyName ' + propertyName);
                var renormalizedProperty = propertyName.replace(/\[\d*\]/, '.' + arrayCfg);
                log('*** parsed renormalizedProperty string: ' + renormalizedProperty);

                return renormalizedProperty;
            }

            function getCustomConfig(propertyName) {
                log('-------------------');
                var renormalizedProperty = renormalizePropertyName(propertyName);
                var customConfig = config[renormalizedProperty];
                log('*** parsed preferConfig value: ' + angular.toJson(customConfig, true));
                if (!customConfig) { // try to find regEx config
                    customConfig = getCustomConfigFromRegex(renormalizedProperty);
                }

                return customConfig;
            }

            function getCustomConfigFromRegex(renormalizedProperty) {
                var configKey, customConfig;
                for (configKey in config) {
                    if (config.hasOwnProperty(configKey)) {
                        if (configKey.indexOf('*') >= 0) { // contain the regex
                            var p = configKey.replace(/\.\*{2}/g, '\\..+').replace(/\.\*{1}/g, '\\.[^\.]+').replace(/\*{2}/g, '.*');
                            var reg = new RegExp('^' + p + '$', 'g');
                            log('@@@ regex pattern: ' + reg);
                            if (reg.test(renormalizedProperty)) {
                                customConfig = config[configKey];
                                log('@@@ regex preferConfig value: ' + angular.toJson(customConfig));
                                break;
                            }
                        }
                    }
                }

                return customConfig;
            }

            function getParentCompartor(propertyName) {
                log('-------------------');
                var renormalizedProperty = renormalizePropertyName(propertyName);
                var parentRenormalizedProperty = renormalizedProperty.substring(0, renormalizedProperty.lastIndexOf('.'));
                log('*** parsed parent renormalizedProperty string: ' + parentRenormalizedProperty);
                var customConfig = config[parentRenormalizedProperty];
                log('*** parsed parent preferConfig value: ' + angular.toJson(customConfig, true));

                return customConfig ? customConfig.comparator : null;
            }


        } // end of ppm Equal

        // public
        ppmEqual.arrayCfg = function() {
            return arrayCfg;
        };

        ppmEqual.prefix = function() {
            return prefix;
        };

        ppmEqual.isDate = function(value) {
            return isDate(value);
        };

        // Help function
        function log(msg) {
            if (debug) {
                $log.log(msg);
            }
        }

        function getValue(propertyName, obj) {
            var wrappedValue = {};
            wrappedValue[prefix] = obj;
            var compuAccessStr = propertyName.replace(/(\.([^\.\[]+))/g, '["$2"]'); // change value.a.b.c = value["a"]["b"]["c"], value.a["x"].b.c = value["a"]["x"]["b"]["c"]
            log('compuAccessStr = ' + compuAccessStr);
            var getter = $parse(compuAccessStr);

            return angular.toJson(getter(wrappedValue), true);
        }

        function printDebugValue(level, propertyName, v1, v2, reason) {
            if (debug) {
                log('>>>>>>>>>> L' + level + ' Property "' + propertyName + '": ' + reason + '!');
                log('          propertyName: ' + propertyName + ', value 1: ' + getValue(propertyName, v1) + ', value 2: ' + getValue(propertyName, v2));
            }
        }

        // private
        function createMap() {
            return Object.create(null);
        }

        var toString = Object.prototype.toString;

        function isArray(value) {
            // jshint undef:false
            return toString.call(value) === '[object Array]';
        }

        function isDate(value) {
            // jshint undef:false
            return toString.call(value) === '[object Date]';
        }

        function isScope(obj) {
            return obj && obj.$evalAsync && obj.$watch;
        }

        function isRegExp(value) {
            // jshint undef:false
            return toString.call(value) === '[object RegExp]';
        }

        function isWindow(obj) {
            return obj && obj.window === obj;
        }

        function isDefined(value) {
            return typeof value !== 'undefined';
        }

        function isFunction(value) {
            return typeof value === 'function';
        }

        /** Keep for future, otherwise, jsHint error
         
        function isString(value) {
            return typeof value === 'string';
        }

        function isBoolean(value) {
            return typeof value === 'boolean';
        }

        function isPromiseLike(obj) {
            return obj && isFunction(obj.then);
        }

        function isFormData(obj) {
            return toString.call(obj) === '[object FormData]';
        }

        function isBlob(obj) {
            return toString.call(obj) === '[object Blob]';
        }

        function isFile(obj) {
            return toString.call(obj) === '[object File]';
        }

        function isObject(value) {
            // http://jsperf.com/isobject4
            return value !== null && typeof value === 'object';
        }

        function isBlankObject(value) {
            return value !== null && typeof value === 'object' && !Object.getPrototypeOf(value);
        }
        */

        return ppmEqual;
    });