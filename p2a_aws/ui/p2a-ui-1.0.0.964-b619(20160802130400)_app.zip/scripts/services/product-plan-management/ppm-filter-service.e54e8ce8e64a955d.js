'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.FilterSvc
 * @description
 * # FilterSvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('PPMFilterSvc', function() {

        return {
            /**
             * filtersNeedToBeUpdateWithServiceList: String Array for the filter name
             * filterNameListFiledMapping: the filter name and field name of list element mapping, e.g.: Product -> productClasses, This is between filter and list
             * filterNameIdMapping: Mapping filter Name and its Id, e.g.: Product -> Product Type. This is not good design, because mapping is between inside of filer.
             */
            updateFilterMeta: function(filtersInScope, targetList,
                filtersNeedToBeUpdateWithServiceList,
                filterNameListFiledMapping,
                filterNameIdMapping) {

                angular.forEach(filtersNeedToBeUpdateWithServiceList, function(filter) {
                    var filterValues = getValues(filterNameListFiledMapping[filter], targetList);
                    var newValue = makeFilterFromValues(filterValues, filterNameIdMapping[filter], filter);

                    var oldValue = [];
                    setValueByKey(filtersInScope, filter, newValue, oldValue);
                    if (oldValue.length > 1 || oldValue.length === 0) {
                        throw 'more than one field or no fild found, found number = ' + oldValue.length;
                    }
                });
            },
            /**
             * Implement the filter functionality
             */
            filterItems: function(services, selectedFilters, filterComparators) {
                var result = [];
                angular.forEach(services, function(service) {
                    var passFilter = true;
                    angular.forEach(selectedFilters, function(filterValues, filterId) {
                        passFilter = passFilter && matchFilters(service, filterValues, filterComparators[filterId]);
                        if (!passFilter) {
                            return false;
                        }
                    });
                    if (passFilter) {
                        result.push(service);
                    }
                });

                return result;
            }

        };

        /**
         * Implement update filter available values
         */

        function getValues(fieldName, targetList) {
            var values = {};
            angular.forEach(targetList, function(service) {
                var modifier = service[fieldName];
                if (angular.isArray(modifier)) {
                    angular.forEach(modifier, function(modifierValue) {
                        values[modifierValue] = modifierValue;
                    });
                } else {
                    values[modifier] = modifier;
                }
            });

            return values;
        }

        function makeFilterFromValues(values, attrId, attrName) {
            var filterValues = [];

            angular.forEach(values, function(item) {
                filterValues.push({
                    'AttributeId': attrId,
                    'AttributeName': attrName,
                    'AttributeValue': item,
                    'DisplayValue': item
                });
            });

            return filterValues;
        }

        function setValueByKey(obj, criteria, newValue, oldValue) {
            angular.forEach(obj, function(item, key) {
                if (key.toString().toLowerCase() === criteria.toString().toLowerCase()) {
                    oldValue.push(item);
                    obj[key] = newValue;
                } else {
                    if (angular.isArray(item) || angular.isObject(item)) {
                        setValueByKey(item, criteria, newValue, oldValue);
                    }
                }
            });
        }

        /*** End of implement update filter available values ***/

        /*
         * matchFn's signature: matchFn(service, filterValue)
         * matchFn's name is the same as filter Id in filter meta data
         */
        function matchFilters(service, filterValues, matchFn) {
            var matched = false;
            angular.forEach(filterValues, function(filterValue) {
                if (matchFn.apply(undefined, [service, filterValue])) {
                    matched = true;
                    return false;
                }
            });

            return matched;
        }

    });