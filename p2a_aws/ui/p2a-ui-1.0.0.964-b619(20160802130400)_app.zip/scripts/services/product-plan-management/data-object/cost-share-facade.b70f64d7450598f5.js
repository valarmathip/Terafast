'use strict';

angular.module('p2AdvanceApp')
    .factory('CostShareFacadeSvc', function($rootScope, $filter, localStorageService, $window, $timeout,
        ProductPlanMgmtSvc, $q, ppmUtils, ConfirmationModalFactory, ENV, $log) {

        var facade = {
            // Always return promise
            getAssociatedIdsForEdit: function(planObjectId) {
                $log.log('getAssociatedIdsForEdit');
                return getAssociatedIdsForEdit(planObjectId);
                // SLQ in the future, the plan detail should not need load
                // return getPlanExpandableL3(planObjectId).then(function(planLevel3) {
                //     return parseAssociatedIdsForEdit(planLevel3);
                // });
            },
            populatePlanLinkedServiceIfNotLoaded: function(plan) {
                return populatePlanLinkedServiceIfNotLoaded(plan);
            },
            populateCurrentServiceCostSharesIfNotDoneAllready: function(service) {
                return populateCurrentServiceCostSharesIfNotDoneAllready(service);
            },
            // Always return promise
            // SLQ seems not used in the future
            // getAssociatedIdsForCreateNew: function(productObjId) {
            //     $log.log('getAssociatedIdsForCreateNew');
            //     return getProductExpandableL3(productObjId).then(function(data) {
            //         return parseAssociatedIdsForCreateNew(data);
            //     });
            // },
            updatePlanWithCostShares: function(planId) {
                return readCostShareFromPlan(planId);
            },
            // Not used by any one
            // return promise
            savePlanServiceCostShare: function(planId, metadata) {
                return savePlanServiceCostShare(planId, metadata)
                    .then(function() {
                        return reloadPlanCostShareAfterSave(planId);
                    });
            },
            loadTierCostShareFromProduct: function(planId, serviceId, linkedPlanServiceId, tierName) {
                loadTierCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName);
            },
            loadSingleTierCostShareFromProduct: function(planId, serviceId, linkedPlanServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus) {
                loadSingleTierCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus);
            },
            loadSingleLevelCostShareFromProduct: function(planId, serviceId, linkedPlanServiceId, tierName, costshareType, level, preCertStatus, moopStatus, deductibleStatus) {
                loadSingleLevelCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName, costshareType, level, preCertStatus, moopStatus, deductibleStatus);
            },
            loadServiceCostShareFromProduct: function(planId, serviceId, linkedPlanServiceId) {
                loadServiceCostShareFromProduct(planId, serviceId, linkedPlanServiceId);
            },
            // Always return promise
            updateEditPlanService: function(associatedService, planId, metadata) {
                return saveCurrentPlanService(associatedService, planId, metadata)
                    .then(function() {
                        return reloadPlanCostShareAfterSave(planId);
                    });
            },
            // Return promise
            updateCachedPlanL3PropertyAndPlanCostShares: function(planId, simplifiedSendPlan) {
                return updateCachedPlanL3PropertyAndPlanCostShares(planId, simplifiedSendPlan);
            },
            // return promise
            updateCachedPlanL3ForLinkedPlanService: function(planId, postPlan, assoSvcList) {
                return updateCachedPlanL3ForLinkedPlanService(planId, postPlan, assoSvcList);
            },
            // Always return promise
            getProductExpandableL3: function(productObjId, expLevel) {
                return getProductExpandableL3(productObjId, expLevel);
            },
            // Always return promise
            getPlanExpandableL3: function(planObjectId) {
                return getPlanExpandableL3(planObjectId);
            },
            // Set/Get
            PlanExpandable3: function(value) {
                return arguments.length ? PlanExpandable3(value) : PlanExpandable3();
            },
            // Set/Get
            productExpandable3: function(value) {
                return arguments.length ? productExpandable3(value) : productExpandable3();
            },
            // Set/Get
            associatedServices: function(value) {
                return arguments.length ? associatedServices(value) : associatedServices();
            },
            clearCache: function() {
                clearCache();
            }
        };

        // Always return promise
        // SLQ This one will be replace by level 3
        // function getPlanExpandable2(planObjectId) {
        //     if (!needReloadPlanDetailLevel3 && model.PlanExpandable3) { // SLQ needReloadPlanDetailLevel3 always is true, unless we found a way to remove cache
        //         $log.log('plan details expandable level 2 already exist');
        //         var defer = $q.defer();
        //         defer.resolve(model.PlanExpandable3);
        //         return defer.promise;
        //     } else {
        //         return ProductPlanMgmtSvc.getPlanDetails(planObjectId, 2).then(function(data) {
        //             model.PlanExpandable3 = data; // keep it in service
        //             saveModel(); // SLQ tmp for dev test
        //             return data;
        //         });
        //     }
        // }

        // Note this function currently load plan at level 1
        // Always return promise
        function getPlanExpandableL3(planObjectId) {
            $log.log('>>>>>>>> getPlanExpandableL3');
            // SLQ Yes, level 2 and level 3 is put the same place
            if (!needReloadPlanDetailLevel3 && model.PlanExpandable3) { // SLQ needReloadPlanDetailLevel3 always is true, unless we found a way to remove cache
                $log.log('plan details expandable level 3 already exist');
                var defer = $q.defer();
                defer.resolve(model.PlanExpandable3);
                return defer.promise;
            } else {
                $log.log('plan details expandable level 3 is been loading from backend');
                var associationExpansionLevel = 1; // SLQPartialLoad
                return ProductPlanMgmtSvc.getPlanDetails(planObjectId, associationExpansionLevel)
                    .then(function(data) {
                        model.PlanExpandable3 = data; // keep it in service
                        // saveModel(); // SLQ tmp for dev test
                        return data;
                    });
            }
        }

        /**
            Plan linked service is loaded with plan level 1, its located
            plan.linkedPlanServices.linkedService[0], for the level 1, this
            only the uuid instead of real object
         */
        // return promise
        function populatePlanLinkedServiceIfNotLoaded(plan) {

            return ProductPlanMgmtSvc.getPlanAssociatedServices(plan.objectId)
                .then(function(serviceList) {
                    $log.log('loaded service is : ' + serviceList.length);
                    var planServiceMap = {};

                    angular.forEach(plan.linkedPlanServices, function(linkedPlanSvc) {
                        var service = linkedPlanSvc.linkedService[0];
                        if (isUuid(service)) {
                            planServiceMap[service] = linkedPlanSvc;
                        }
                    });

                    while (serviceList.length > 0) {
                        var svc = serviceList.shift();
                        var linkedPlanService = planServiceMap[svc.objectId];
                        if (linkedPlanService) {
                            linkedPlanService.linkedService[0] = svc;
                        }
                    }

                    return plan;
                });

            // function loadOneServiceById(serviceId, planLinkedServiceList) {
            //     return ProductPlanMgmtSvc.getServiceById(serviceId)
            //         .then(function(service) {
            //             // planService.linkedService[0] = loaded service
            //             planLinkedServiceList[0] = service;
            //             // no necessary to return valid value
            //         });
            // }

            // var linkedPlanServiceList = plan.linkedPlanServices;
            // var promises = [];

            // angular.forEach(linkedPlanServiceList, function(planService) {
            //     var service = planService.linkedService[0];
            //     if (isUuid(service)) { // mean service is only an id
            //         promises.push(loadOneServiceById(service, planService.linkedService));
            //     }
            // });

            // return $q.all(promises)
            //     .then(function() {
            //         return plan;
            //     });
        }

        /**
            Note: planserviceCostShares is loaded with plan level 1, but only the uuid, not the object itself.
            plan.linkedPlanServices[#].planserviceCostShares[#].

            But there is a situation, that the plan service do not have any cost share associated, and in this
            case, the plan.linkedPlanServices[#].planserviceCostShares = undefined/null
            ==========
            If the cost share does not loaded, it will check if the PlanL3 has this information,
            if not, it will load plansercie of the service from backend and update PlanL3, also
            associatedServices costShares part.
            ==========
            fireEvent CostShareFacadeSvc.associatedServices.OneCostShares.Loaded
         */
        // return promise
        function populateCurrentServiceCostSharesIfNotDoneAllready(service) {
            if (!service.planSvcJointProps.costShares) {
                // check if the PlanL3 already have this service cost share
                var serviceId = service.objectId;
                var linkedPlanSvc = getLinkedPlanServiceByServiceIdFromPlanL3(serviceId);
                var planServiceCostSharesList = linkedPlanSvc.planserviceCostShares;


                return $q.when(isArrayContentAlreadyLoadedOrNoCostShares(planServiceCostSharesList))
                    .then(function(alreadyLoadedOrNoCostShares) {
                        if (alreadyLoadedOrNoCostShares) {
                            return linkedPlanSvc; // remember the second return linkedPlanSvc; is in another promise
                        } else {
                            // load linkedPlanService
                            var planServiceId = service.planSvcJointProps.linkedPlanServiceId;
                            var associationExpansionLevel = 1;
                            var planId = PlanExpandable3().objectId;
                            return ProductPlanMgmtSvc.getPlanService(planId, planServiceId, associationExpansionLevel)
                                .then(function(linkendPlanService) {
                                    // update planL3 linkedPlanService Costshare
                                    linkedPlanSvc.planserviceCostShares = linkendPlanService.planserviceCostShares;
                                    return linkedPlanSvc;
                                });
                        }
                    })
                    .then(function(linkendPlanService) {
                        var costShareStruct = createOneServiceCostShareListStructure(linkendPlanService);
                        fireEvent('CostShareFacadeSvc.associatedServices.OneCostShares.Loaded', costShareStruct);
                        return costShareStruct;
                    });
            }
        }

        /**
            Get the planService of the service from PlanL3 by give service id
         */
        function getLinkedPlanServiceByServiceIdFromPlanL3(serviceId) {
            var planL3 = PlanExpandable3();
            var linkedPlanServicesList = planL3.linkedPlanServices;
            var i;
            for (i = 0; i < linkedPlanServicesList.length; ++i) {
                var linkedPlanSvc = linkedPlanServicesList[i];
                if (linkedPlanSvc.linkedService[0].objectId === serviceId) { // find the service in the linkedPlanServices
                    return linkedPlanSvc;
                }
            }

            return null;
        }

        /**
            Check if the content of array is only the uuid or it already has the content.
            if one of them is not loaded, we treat all of them are not loaded
         */
        function isArrayContentAlreadyLoadedOrNoCostShares(list) {
            if (list) {
                for (var i = 0; i < list.length; ++i) {
                    var item = list[i];
                    if (isUuid(item)) {
                        return false;
                    }
                }
            }

            return true;
        }

        /**
            change the linkedPlanService's planserviceCostShares from array to
            tiers, costshareType, level structure

            see addCostShareIntoStruct function
         */
        // SLQ kind of similar to the function parseCostShareStructMapFromPlan
        function createOneServiceCostShareListStructure(linkedPlanService) {
            var costShareStruct = {};
            var costSahreList = linkedPlanService['planserviceCostShares'];
            angular.forEach(costSahreList, function(costShare) {
                if (!isUuid(costShare)) {
                    addCostShareIntoStruct('plan', costShare, costShareStruct, 0);
                }
            });

            return costShareStruct;
        }

        var uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        /*
         * Test if the string is a uuid
         */
        function isUuid(str) {
            return angular.isString(str) && uuidPattern.test(str);
        }

        /*
            return {service.id --> {service (+ lanSvcJointProps)}, ...}
        */
        // SLQ this function return value has been changed, and different from its sibling funciton parseAssociatedIdsForCreateNew
        function parseAssociatedIdsForEdit(planDetailLevel3) {
            var associatedServiceIds = {};
            var linkedPlanServicesList = planDetailLevel3.linkedPlanServices;
            angular.forEach(linkedPlanServicesList, function(linkedServices /*, index*/ ) {
                if (linkedServices && linkedServices.linkedService && linkedServices.linkedService.length > 0) {
                    var objectId = linkedServices.linkedService[0].objectId; // service Id
                    var planSvcJointProps = {
                        linkedPlanServiceId: linkedServices.objectId, // necessary for update planservice object
                        isServiceCovered: linkedServices.isServiceCovered,
                        limitsAndExceptions: linkedServices.limitsAndExceptions ? linkedServices.limitsAndExceptions : [''],
                        isPreCertificationRequired: linkedServices.isPreCertificationRequired,
                        applyToMOOP: linkedServices.applyToMOOP,
                        applyToDeductibles: linkedServices.applyToDeductibles,
                        isCarvedOut: linkedServices.isCarvedOut,
                        vendorName: linkedServices.vendorName,
                        vendorPhone: linkedServices.vendorPhone,
                        vendorWebsite: linkedServices.vendorWebsite,
                        category: linkedServices.linkedService[0].category,
                        subCategory: linkedServices.linkedService[0].subCategory,
                        level: linkedServices.linkedService[0].level
                    };
                    angular.forEach(linkedServices, function(value, property) {
                        if (property.indexOf('udfplanservice_') === 0) {
                            planSvcJointProps[property] = value;
                        }
                    });
                    objectId = ppmUtils.removeVersionFromId(objectId);
                    var svc = linkedServices.linkedService[0];
                    svc.planSvcJointProps = planSvcJointProps;
                    associatedServiceIds[objectId] = svc;
                }
            });

            return associatedServiceIds;
        }

        // Always return promise
        // SLQ will be replaced by level 3
        // function getProductExpandable2(productObjId) {
        //     if (!needReloadProductDetailLevel3 && !!model.productExpandable3) { // SLQ needReloadProductDetailLevel3 always is true, unless we found a way to remove cache
        //         $log.log('plan details expandable level 2 already exist');
        //         var defer = $q.defer();
        //         defer.resolve(model.productExpandable3);
        //         return defer.promise;
        //     } else {
        //         return ProductPlanMgmtSvc.getProductDetails(productObjId, 2).then(function(data) {
        //             model.productExpandable3 = data; // keep this value in service
        //             saveModel(); // SLQ tmp for dev test
        //             return data;
        //         });
        //     }
        // }

        // Note this function currelty load product at level 1
        // Always return promise
        function getProductExpandableL3(productObjId, expLevel) {
            $log.log('>>>>>>>> getProductExpandableL3');
            if (!needReloadProductDetailLevel3 && !!model.productExpandable3) { // SLQ needReloadProductDetailLevel3 always is true, unless we found a way to remove cache
                $log.log('Product details expandable level 3 already exist');
                var defer = $q.defer();
                defer.resolve(model.productExpandable3);
                return defer.promise;
            } else {
                $log.log('Product details expandable level 3 is been loading from backend');
                var associationExpansionLevel = (expLevel && expLevel >= -1) ? expLevel : 1; // changed default level to 1, before level 3
                return ProductPlanMgmtSvc.getProductDetails(productObjId, associationExpansionLevel).then(function(data) {
                    model.productExpandable3 = data; // keep this value in service
                    // saveModel(); // SLQ tmp for dev test
                    return data;
                });
            }
        }

        // SLQ seems not used in the future
        // function parseAssociatedIdsForCreateNew(productDetailLevel3) {
        //     var associatedServiceIds = {};
        //     var productServicesList = productDetailLevel3.productservices;
        //     angular.forEach(productServicesList, function(productServices /*, index*/ ) {
        //         if (productServices && productServices.prodservice && productServices.prodservice.length > 0) {
        //             var objectId = productServices.prodservice[0].objectId;
        //             var planSvcJointProps = {
        //                 isServiceCovered: productServices.isCovered,
        //                 // Following one property does not exist in the productService joint properties
        //                 limitsAndExceptions: productServices.limitsAndExceptions ? productServices.limitsAndExceptions : [''],
        //                 isPreCertificationRequired: productServices.isPreCertificationRequired,
        //                 // Following properties does not exist in the productService joint properties
        //                 applyToMOOP: !!productServices.applyToMOOP,
        //                 applyToDeductibles: !!productServices.applyToDeductibles,
        //                 isCarvedOut: !!productServices.isCarvedOut,
        //                 vendorName: productServices.vendorName,
        //                 vendorPhone: productServices.vendorPhone,
        //                 vendorWebsite: productServices.vendorWebsite
        //             };
        //             objectId = ppmUtils.removeVersionFromId(objectId);
        //             associatedServiceIds[objectId] = planSvcJointProps;
        //         }
        //     });

        //     return associatedServiceIds;
        // }

        // Always return promise
        function initCostShareStructMapFromProduct(productObjId, criteria, serviceId) {
            return getProductExpandableL3(productObjId).then(function(prodL3) {
                // SLQ check if the selected service has L3 cost share information
                // In fact, we olny need the current service related cost share, because
                // when create plan from product, all plan service cost share a already setup
                // and here only restore the selected service's cost share if it is
                // removed by uncovered

                function getProductServiceIndexByServiceId(productServiceList, serviceObjectId) {
                    if (productServiceList) {
                        for (var i = 0; i < productServiceList.length; ++i) {
                            var productSvc = productServiceList[i];
                            if (serviceObjectId === productSvc.serviceId) { // in productService Object, service objectId is serviceId
                                return i;
                            }
                        }
                    }

                    return -1;
                }

                function isProductServiceIncludeCostSharesDetails(costShareList) {
                    if (!costShareList) {
                        return false;
                    }

                    for (var i = 0; i < costShareList.length; ++i) {
                        var costShare = costShareList[i];
                        if (isUuid(costShare)) {
                            return false;
                        }
                    }

                    return true;
                }

                function loadProductServiceAssociatedCostShareIfNotLoaded() {
                    if (serviceId) { // if service Id provided
                        var svcIndex = getProductServiceIndexByServiceId(prodL3.productservices, serviceId);
                        if (svcIndex >= 0) {
                            var prodSvc = prodL3.productservices[svcIndex];
                            if (prodSvc.costshares && !isProductServiceIncludeCostSharesDetails(prodSvc.costshares)) {
                                // load cost share for this product
                                var associationExpansionLevel = 1;
                                return ProductPlanMgmtSvc.getProductServices(productObjId, prodSvc.objectId, associationExpansionLevel)
                                    .then(function(productService) {
                                        prodL3.productservices[svcIndex] = productService;

                                        return prodL3;
                                    });
                            }
                        }
                    }

                    return prodL3;
                }

                return $q.when(loadProductServiceAssociatedCostShareIfNotLoaded())
                    .then(function(prodL3) {
                        return parseCostShareDataFromProduct(prodL3, criteria);
                    });
            });
        }

        function isTierIncluded(tierNames) {
            var tierNamesMap = {};
            if (angular.isArray(tierNames)) {
                angular.forEach(tierNames, function(name) {
                    tierNamesMap[name] = name;
                });
            } else {
                tierNamesMap = tierNames; // Assume it is already a map/object
            }

            return function() {
                var obj = this;
                if (obj.providerTier in tierNamesMap) {
                    return true;
                }

                return false;
            };
        }

        function removeSomeProperties(propertiesRemoved) {
            return function() {
                var obj = this;
                angular.forEach(propertiesRemoved, function(property) { // propertiesRemoved being null will skip loop
                    $log.log('The property ' + property + ' will be deleted, its value is ' + obj[property]);
                    delete obj[property];
                });
            };
        }

        // cost share front structure level
        var structOrder = ['providerTier', 'costShareType', 'costShareLevel'];
        var propertiesRemovedFromProductCopy = ['versionSeriesId', 'objectId', 'nodeRef', 'name'];
        /**
         * Group the cost shares in the the order defined by structOrder.
         * and then put them into a map mapped by serviceId
         */
        function parseCostShareDataFromProduct(prodL3, criteria) {
            var productServiceList = prodL3.productservices;

            var costShareStruct = {};
            angular.forEach(productServiceList, function(productService) {
                var serviceId = productService.serviceId;
                var costShareList = productService['costshares'];
                angular.forEach(costShareList, function(costShare) {
                    if (!costShareStruct[serviceId]) {
                        costShareStruct[serviceId] = {};
                    }
                    addCostShareIntoStruct('product', costShare, costShareStruct[serviceId], 0, removeSomeProperties(propertiesRemovedFromProductCopy), criteria);
                });
            });

            return costShareStruct;
        }

        // kind of similar createOneServiceCostShareListStructure
        function parseCostShareStructMapFromPlan(planL3) {
            var linkendPlanServiceList = planL3.linkedPlanServices;

            var costShareStructMap = {};
            angular.forEach(linkendPlanServiceList, function(linkendPlanService) {
                var serviceId = linkendPlanService['planServiceId']; // Yes, it is service objectId, because in Alfresco, duplicated property name is not allowed
                var costSahreList = linkendPlanService['planserviceCostShares'];
                angular.forEach(costSahreList, function(costShare) {
                    if (!isUuid(costShare)) { // SLQ In future, if partial loaded implemented, this place costShare always is a uuid ONLY
                        if (!costShareStructMap[serviceId]) {
                            costShareStructMap[serviceId] = {};
                        }
                        addCostShareIntoStruct('plan', costShare, costShareStructMap[serviceId], 0);
                    }
                });
            });

            return costShareStructMap;
        }

        /**
           [costShareObject, ....] {providerTier:*, costShareType:*, costShareLevel: *}
            ===>
            CostShares{
                TierName: {
                    TypeName: {
                        Level: {
                            costShareObject
                        }
                    }
                }
            }
         */
        // recursive call
        function addCostShareIntoStruct(objectType, costShare, struct, structLevel, operation, criteria) {
            if (structLevel === 0 && criteria && !criteria.apply(costShare)) { // only check at top recusive loop
                return;
            }

            var structLevelName = costShare[structOrder[structLevel]];

            if (structLevel < 2) {
                if (!struct[structLevelName]) {
                    struct[structLevelName] = {};
                }
                addCostShareIntoStruct(objectType, costShare, struct[structLevelName], structLevel + 1, operation, criteria);
            } else {
                var copyOfCostShare = angular.copy(costShare);

                // DOGHR-1932: cost share from product, should use default value, instead of selectedValue
                if (objectType === 'product') {
                    copyOfCostShare.selectedValue = copyOfCostShare['default'];
                }

                // remove the properties that belong to product cost-share
                if (operation) {
                    operation.apply(copyOfCostShare);
                }

                // DOGHR-2325 If API has no rangeSurroundingTexts key, add it as default value
                if (!costShare.hasOwnProperty('rangeSurroundingTexts')) {
                    copyOfCostShare.rangeSurroundingTexts = [''];
                }

                struct[structLevelName] = copyOfCostShare;
            }
        }

        // return one service's cost shares (in a list/array)
        function readCostShareFromStruct(costShareStruct) {
            var resultList = [];
            readCostShareFromStructRecursive(costShareStruct, resultList, 0);
            return resultList;
        }

        /**
            CostShares{
                TierName: {
                    TypeName: {
                        Level: {
                            costShareObject
                        }
                    }
                }
            }
            ===>
            [costShareObject, ....]
        */
        function readCostShareFromStructRecursive(struct, resultList, level) {
            if (level < 3) {
                angular.forEach(struct, function(subStruct) {
                    readCostShareFromStructRecursive(subStruct, resultList, level + 1);
                });
            } else {
                resultList.push(struct);
            }
        }

        // This function is not used
        // Always return promise
        // function saveCreatedCostShares(costShareStructMap, planId) {
        function saveCreatedCostShares(viewServiceList, planId, metadata) {
            // var planUpdated = getSaveObject(costShareStructMap, planId);

            var linkedPlanServices = [];
            angular.forEach(viewServiceList, function(service) {
                linkedPlanServices.push(getPlanServiceObject(service, planId, metadata));
            });

            var planUpdated = null;
            if (linkedPlanServices.length > 0) {
                planUpdated = {
                    'linkedPlanServices': linkedPlanServices
                };
            }

            $log.log('The object send to backend');
            $log.log(angular.toJson(planUpdated, true));

            function showErrorInfo() {
                var msgtitle = 'Failed';
                var msg = 'Update Plan Service Cost Share Failed.';
                $log.log(msgtitle + ' --> ' + msg);
                ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
            }

            function showSuccessInfo() {
                var msgtitle = 'Success';
                var msg = 'Update Plan Service Cost Share Success.';
                $log.log(msgtitle + ' --> ' + msg);
                ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
            }

            return ProductPlanMgmtSvc.updatePlan(planUpdated, planId).then(function(data) {
                if (data.status && data.status !== '200') { // Remember that gateway will return the error info
                    showErrorInfo();
                } else {
                    showSuccessInfo();
                    if (!needReloadPlanDetailLevel3) { // update changed part loaded data if not auto reload
                        updatedPlanL3LinkedServiceList(planUpdated.linkedPlanServices);
                    }
                }
            }, function() {
                showErrorInfo();
            });
        }

        // This function is not used, and not tested
        // need return promise
        function updatedPlanL3LinkedServiceList(newLinkedServices) {
            var promises = [];

            angular.forEach(newLinkedServices, function(newLinkedService) {
                promises.push(updatedPlanL3LinkedService(newLinkedService /*, planId*/ )); // this function is not used, therefore, we do not update it
            });

            return $q.all(promises);
        }

        // Return promise, rquired
        function updatedPlanL3LinkedService(newLinkedService, planId) {
            var linkedPlanServiceList = model.PlanExpandable3.linkedPlanServices;
            var promises = [];

            angular.forEach(linkedPlanServiceList, function(service) {
                if (service.objectId === newLinkedService.objectId) { // find the match service
                    updateOnePlanService(newLinkedService, service);
                    promises.push(updateOnePlanServiceCostShareObjectId(service, planId)); // only update plan cost-share objectId if it is new
                }
            });

            return $q.all(promises);
        }

        function updateOnePlanService(sourceSvc, destSvc) {
            var skippedProperties = {
                'linkedService': true // this one should not changed here
            };

            // if use smart save, this part could need to rewrite, cannot just assign to place old value in linked service.
            angular.forEach(sourceSvc, function(value, key) {
                if (!(key in skippedProperties)) {
                    destSvc[key] = sourceSvc[key]; // copy the property
                }
            });
        }

        // return promise or undefined value if no new cost-share added, required
        function updateOnePlanServiceCostShareObjectId(destSvc, planId) {
            // find if new cost share added
            function isContainedNewCostshare() {
                var isContained = false;
                angular.forEach(destSvc.planserviceCostShares, function(costShare) {
                    if (costShare.objectId === null || angular.isUndefined(costShare.objectId)) { // newly added cost share
                        isContained = true;
                    }
                });

                return isContained;
            }
            // find and update Id from backend cost-share list
            function updateCostShareIdFromBackendCsList(costShare, backendCsList) {
                var numFound = 0;

                angular.forEach(backendCsList, function(becs) {
                    if (costShare.providerTier === becs.providerTier &&
                        costShare.costShareType === becs.costShareType &&
                        costShare.costShareLevel === becs.costShareLevel) {
                        costShare.objectId = becs.objectId;
                        ++numFound;
                    }
                });

                if (numFound > 1) {
                    $log.error('cost-share-facade.js: the combination of "providerTier", "costShareType", "costShareLevel" should be unique!');
                }
            }

            if (isContainedNewCostshare()) {
                var planserviceId = destSvc.objectId;
                var associationExpansionLevel = 1;
                var properties = ['planserviceCostShares', 'providerTier', 'costShareType', 'costShareLevel'];
                return ProductPlanMgmtSvc.getPlanService(planId, planserviceId, associationExpansionLevel, properties)
                    .then(function(planService) {
                        var backendCsList = planService.planserviceCostShares;

                        angular.forEach(destSvc.planserviceCostShares, function(costShare) {
                            if (costShare.objectId === null || angular.isUndefined(costShare.objectId)) { // newly added cost share
                                updateCostShareIdFromBackendCsList(costShare, backendCsList);
                            }
                        });
                    });
            }
        }

        function updateCachedPlanL3ForLinkedPlanService(planId, postPlan, assoServices) {
            function isNewlinkedPlanServiceAdded(postPlanWithLinkedPlanServices) {
                var result = false;

                var linkedPlanServices = postPlanWithLinkedPlanServices.linkedPlanServices;
                angular.forEach(linkedPlanServices, function(planService) {
                    if (angular.isUndefined(planService.objectId) || planService.objectId === null) { // no id, new plan service
                        result = true;
                    }
                });

                return result;
            }

            function findAssociatedServiceRemovingJointProperty(serviceList, serviceId) {
                var svc;
                angular.forEach(serviceList, function(svcItem) {
                    if (svcItem.objectId === serviceId) {
                        svc = angular.copy(svcItem);
                    }
                });

                delete svc.planSvcJointProps;

                return svc;
            }

            // loadedJointPlanServices is for get new plan service Id
            // postJointPlanServices is used as source of new data, include newly added plan services
            function updateCachedPlanWithLinkedPlanServices(planObjectId, postJointPlanServices, loadedJointPlanServices) {
                if (!model.PlanExpandable3.linkedPlanServices) { // in case that at very first, there no service associated to plan
                    model.PlanExpandable3.linkedPlanServices = [];
                }

                var cachedLinkedPlanServices = model.PlanExpandable3.linkedPlanServices;


                // if has new plan, need to update post data with new plan objectId
                // then copy update cached linkedPlanService with post data,
                // must make sure the new one is copied into cached linkedPlanService
                // and then removed one should be removed.
                var loadedMap = {}; // planServiceId (service objectId) --> planService objectId (joint objecit id)
                if (hasNew) {
                    angular.forEach(loadedJointPlanServices, function(ps) {
                        if (ps.planId !== planObjectId) {
                            $log.error('cost-share-facade.js: updateCachedPlanWithLinkedPlanServices loaded plan objectId should be the same!');
                        }
                        loadedMap[ps.planServiceId] = ps.objectId;
                    });
                }
                var postMap = {};
                angular.forEach(postJointPlanServices, function(ps) {
                    // Same as hasNew === true
                    if (angular.isUndefined(ps.objectId) || ps.objectId === null) { // this is new added plan service
                        if (ps.planId !== planObjectId) {
                            $log.error('cost-share-facade.js: updateCachedPlanWithLinkedPlanServices posted plan objectId should be the same!');
                        }
                        ps.objectId = loadedMap[ps.planServiceId]; // Copy linkedPlanService Id (joint object Id)
                        if (!ps.objectId) {
                            $log.error('cost-share-facade.js: updateCachedPlanWithLinkedPlanServices new plan service objectId should be set correctly!');
                        }
                        ps.frontPlanServiceNeedToReloaded = true; // This is a special to indicated this plan service and its cost share should be reloaded
                        // addits related services
                        ps.linkedService = [];
                        ps.linkedService.push(findAssociatedServiceRemovingJointProperty(assoServices, ps.planServiceId));
                        cachedLinkedPlanServices.push(ps); // Add new created plan service into cached plan service list and mark it as need to reloaded
                    }
                    postMap[ps.objectId] = ps;
                });
                var i = cachedLinkedPlanServices.length - 1;
                for (; i >= 0; --i) {
                    var cachedPs = cachedLinkedPlanServices[i];
                    var postPs = postMap[cachedPs.objectId];
                    if (!postPs) { // this cached ps is deleted
                        cachedLinkedPlanServices.splice(i, 1); // remove element from array
                    } else {
                        // Copy the properties
                        cachedPs.isServiceCovered = postPs.isServiceCovered; // this is the only property that could be changed
                    }
                }
            }

            // return promise
            function loadLinkedPlanServices(planObjectId) {
                if (hasNew) {
                    var associationExpansionLevel = 1;
                    var properties = ['linkedPlanServices', 'planServiceId', 'planId'];
                    return ProductPlanMgmtSvc.getPlanViaCm(planObjectId, associationExpansionLevel, properties)
                        .then(function(data) {
                            return data.linkedPlanServices;
                        });
                }

                return $q.when(); // if no new added, this promise return underfined
            }

            var hasNew = isNewlinkedPlanServiceAdded(postPlan);

            return loadLinkedPlanServices(planId)
                .then(function(loadedPlanServiceList) {
                    updateCachedPlanWithLinkedPlanServices(planId, postPlan.linkedPlanServices, loadedPlanServiceList);
                });

        }

        // This function is to update plan property and ist planCostShares compostion property
        // return a promise
        function updateCachedPlanL3PropertyAndPlanCostShares(planId, simplifiedSendPlan) {
            // check if there is any new cost share added
            function isNewCostShareAdded(postSimpleData) {
                var result = false;
                if (postSimpleData.planCostShares && postSimpleData.planCostShares.length > 0) {
                    angular.forEach(postSimpleData.planCostShares, function(cs) {
                        if (angular.isUndefined(cs.objectId) || cs.objectId === null) { // no id, new cost share
                            result = true;
                        }
                    });
                }

                return result;
            }

            // pre-assumption: there is no new added list in it, that means all list has objectId.
            // but there could include cost share in old list, that need to be removed
            // remember newCslist is simplified list, cannot instead of oldCsList, just copy its value to old list
            function updateCostSharesValue(newCsList, oldCsList) {
                var newCsMap = {};
                angular.forEach(newCsList, function(newCs) {
                    newCsMap[newCs.objectId] = newCs;
                });

                var i = oldCsList.length - 1;
                for (; i >= 0; --i) { // could remove item from list, so start from end
                    var oldCs = oldCsList[i];
                    if (oldCs.objectId in newCsMap) { // update cost share property value
                        angular.forEach(newCsMap[oldCs.objectId], function(value, key) {
                            oldCs[key] = value;
                        });
                    } else { // this cost share is removed
                        oldCsList.splice(i, 1); // remove this element from array
                    }
                }
            }

            // Plan details include 2 part we should to care about:
            // 1. plan property
            // 2. plan cost shares
            //
            function updatePlanPlanL3(simplifiedSendPlan, costShareList) {
                var planL3 = model.PlanExpandable3;

                angular.forEach(simplifiedSendPlan, function(value, key) {
                    if (key === 'planCostShares') {
                        if (!hasNew) { //  update cost shares (in clude those that are removed cost share)
                            updateCostSharesValue(simplifiedSendPlan.planCostShares, planL3.planCostShares);
                        } else { // just replace cost share with new one
                            planL3[key] = costShareList;
                        }
                    } else {
                        planL3[key] = value; // update value in plan detail
                    }
                });
            }

            // return promose
            function loadPlanCostshares() {
                if (hasNew) {
                    // load plan cost shares
                    var associationExpansionLevel = 1;
                    return ProductPlanMgmtSvc.getPlanDetails(planId, associationExpansionLevel)
                        .then(function(data) {
                            return data.planCostShares;
                        });
                }

                return $q.when(); // if no new added, this promise return underfined
            }

            var hasNew = isNewCostShareAdded(simplifiedSendPlan);

            return loadPlanCostshares()
                .then(function(csList) {
                    updatePlanPlanL3(simplifiedSendPlan, csList);
                });
        }



        /**
         * Add the cost share struct from id map into view Service list,
         * Also fire event
         */
        function updateServiceListWithCostShare(serviceList, costShareStructMap, isInitLoad) { // add 3rd parameter just in case this funciton is used in updating situation
            angular.forEach(serviceList, function(service) {
                var serviceId = ppmUtils.removeVersionFromId(service.objectId);
                if (!service.planSvcJointProps) {
                    service.planSvcJointProps = {};
                }
                service.planSvcJointProps.costShares = costShareStructMap[serviceId];
            });
            fireEvent('CostShareFacadeSvc.associatedServices.changed', {
                associatedSvcs: model.associatedServices, // SLQ why this is null
                isInitLoad: isInitLoad
            });
        }

        /**
         * copy the cost shares from product and added them into linkedPlanServices.planserviceCostShares
         * This function also save the new added to backend
         *
         * Not used, keep it for reference
         */
        // return promise
        function copyCostShareFromProduct(productId, planId) { /* jshint ignore:line */
            return getPlanExpandableL3(planId).then(function(plan) {
                var tierNames = plan.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames));
            }).then(function(costShareStructMap) {
                // get cost share info from product and then update my local view list
                updateServiceListWithCostShare(model.associatedServices, costShareStructMap, true);
                // saveModel(); // SLQ temp
            });
        }

        // not used by any one
        // return promise
        function savePlanServiceCostShare(planId, metadata) {
            $log.log('savePlanServiceCostShare called');
            // var costShareStructMap2 = getCostshareStructMapFromViewServiceList(model.associatedServices);
            var locPlanId = ppmUtils.removeVersionFromId(planId);
            // saveCreatedCostShares(costShareStructMap2, locPlanId);
            return saveCreatedCostShares(model.associatedServices, locPlanId, metadata);
        }

        function loadTierCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName) {
            getPlanExpandableL3(planId).then(function(plan) {
                var productId = plan.linkedProducts[0].objectId; // always user the first linked product
                var tierNames = plan.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.planSvcJointProps.linkedPlanServiceId !== linkedPlanServiceId) {
                            throw 'Logic error in the plan service cost share model';
                        }
                        if (!service.planSvcJointProps.costShares) {
                            service.planSvcJointProps.costShares = {};
                        }
                        // service is in the product
                        if (costShareStructMap[serviceId] !== undefined) {
                            var newCostShares = costShareStructMap[serviceId][tierName];
                            // tier is in the product/service
                            if (newCostShares !== undefined) {
                                service.planSvcJointProps.costShares[tierName] = newCostShares;
                            } else { // tier is not in the product/service
                                service.planSvcJointProps.costShares[tierName] = addCostSharesByTier(tierName);
                            }
                        } else { // service is not in the product
                            service.planSvcJointProps.costShares[tierName] = addCostSharesByTier(tierName);
                        }

                    }
                });

                fireEvent('CostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
                fireEvent('CostShareFacadeSvc.tierCostShares.loaded');
            });
        }

        function loadSingleTierCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus) {
            getPlanExpandableL3(planId).then(function(plan) {
                var productId = plan.linkedProducts[0].objectId; // always user the first linked product
                var tierNames = plan.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.planSvcJointProps.linkedPlanServiceId !== linkedPlanServiceId) {
                            throw 'Logic error in the plan service cost share model';
                        }
                        if (!service.planSvcJointProps.costShares) {
                            service.planSvcJointProps.costShares = {};
                            service.planSvcJointProps.costShares[tierName] = {};
                        }
                        var newCostShareByType;
                        // service is in the product
                        if (costShareStructMap[serviceId] !== undefined) {
                            // tier is in the product/service
                            if (costShareStructMap[serviceId][tierName] !== undefined) {
                                newCostShareByType = costShareStructMap[serviceId][tierName][costshareType];
                                // cost share type is in the product/service/tier
                                if (newCostShareByType !== undefined) {
                                    service.planSvcJointProps.costShares[tierName][costshareType] = newCostShareByType;

                                }
                            }
                        }
                        // not found, manually add one
                        if (newCostShareByType === undefined) {
                            service.planSvcJointProps.costShares[tierName][costshareType] = addCostSharesByType(tierName, costshareType);
                        }
                        service.planSvcJointProps.costShares[tierName][costshareType]['Primary']['preCertificationRqrd'] = preCertStatus;
                        service.planSvcJointProps.costShares[tierName][costshareType]['Primary']['applyToMaxOutPocket'] = moopStatus;
                        service.planSvcJointProps.costShares[tierName][costshareType]['Primary']['applyToDeduct'] = deductibleStatus;

                    }
                });
                fireEvent('CostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
                fireEvent('CostShareFacadeSvc.tierCostShares.loaded');
            });
        }

        function loadSingleLevelCostShareFromProduct(planId, serviceId, linkedPlanServiceId, tierName, costshareType, level, preCertStatus, moopStatus, deductibleStatus) {
            $log.log('loadSingleLevelCostShareFromProduct is called');
            getPlanExpandableL3(planId).then(function(plan) {
                var productId = plan.linkedProducts[0].objectId; // always user the first linked product
                var tierNames = plan.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.planSvcJointProps.linkedPlanServiceId !== linkedPlanServiceId) {
                            throw 'Logic error in the plan service cost share model';
                        }
                        if (!service.planSvcJointProps.costShares) {
                            service.planSvcJointProps.costShares = {};
                            service.planSvcJointProps.costShares[tierName] = {};
                            service.planSvcJointProps.costShares[tierName][costshareType] = {};
                        }

                        var newCostShareByLevel;
                        // service is in the product
                        if ((costShareStructMap[serviceId] !== undefined) && (costShareStructMap[serviceId][tierName] !== undefined) && (costShareStructMap[serviceId][tierName][costshareType] !== undefined)) {
                            newCostShareByLevel = costShareStructMap[serviceId][tierName][costshareType][level];
                            if (newCostShareByLevel !== undefined) {
                                service.planSvcJointProps.costShares[tierName][costshareType][level] = newCostShareByLevel;
                            }
                        }
                        // not found, manually add one
                        if (newCostShareByLevel === undefined) {
                            service.planSvcJointProps.costShares[tierName][costshareType][level] = addSingleCostShareByLevel(tierName, costshareType, level);
                        }
                        service.planSvcJointProps.costShares[tierName][costshareType][level]['preCertificationRqrd'] = preCertStatus;
                        service.planSvcJointProps.costShares[tierName][costshareType][level]['applyToMaxOutPocket'] = moopStatus;
                        service.planSvcJointProps.costShares[tierName][costshareType][level]['applyToDeduct'] = deductibleStatus;
                    }
                });

                fireEvent('CostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
                fireEvent('CostShareFacadeSvc.tierCostShares.loaded');
            });
        }

        function addCostSharesByTier(tierName) {
            var result = {};
            var costshareTypeArray = ['Copay', 'Co-insurance', 'Deductible', 'Limits and Exceptions'];

            angular.forEach(costshareTypeArray, function(csName) {
                result[csName] = {};
                result[csName]['Primary'] = addSingleCostShareByLevel(tierName, csName, 'Primary');
            });

            return result;
        }

        function addCostSharesByType(tierName, costshareType) {
            var result = {};
            result['Primary'] = addSingleCostShareByLevel(tierName, costshareType, 'Primary');

            return result;
        }

        function addSingleCostShareByLevel(tierName, costshareType, level) {
            var levelInfo = {
                'rangeSurroundingTexts': [''],
                'rangeTexts': [''],
                'preCertificationRqrd': undefined,
                'applyToDeduct': undefined,
                'applyToMaxOutPocket': undefined,
                'costShareLevel': level,
                'costShareType': costshareType,
                'quantityBasis': undefined,
                'splitByTier': undefined,
                'selectedValue': 0,
                'providerTier': tierName,
                'format': '$',
                'isSlider': false
            };
            if (costshareType === 'Co-insurance') {
                levelInfo.format = '%';
            } else if (costshareType === 'Limits and Exceptions') {
                levelInfo.format = 'Visits';
            }
            return levelInfo;
        }

        function loadServiceCostShareFromProduct(planId, serviceId, linkedPlanServiceId) {
            getPlanExpandableL3(planId).then(function(plan) {
                var productId = plan.linkedProducts[0].objectId; // always user the first linked product
                var tierNames = plan.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.planSvcJointProps.linkedPlanServiceId !== linkedPlanServiceId) {
                            throw 'Logic error in the plan service cost share model';
                        }
                        service.planSvcJointProps.costShares = costShareStructMap[serviceId];
                    }
                });

                fireEvent('CostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
            });
        }

        // promise
        function reloadPlanCostShareAfterSave(planId) {
            return getPlanExpandableL3(planId)
                .then(function(planL3) {
                    return parseCostShareStructMapFromPlan(planL3);
                })
                .then(function(costSharesStructMap) {
                    return updateServiceListWithCostShare(model.associatedServices, costSharesStructMap, false);
                });

        }

        // Promise
        function readCostShareFromPlan(planId) {
            return getPlanExpandableL3(planId)
                .then(function(planL3) {
                    return parseCostShareStructMapFromPlan(planL3);
                })
                .then(function(costSharesStructMap) {
                    createAssociatedServicesFromPlan(planId) // SLQ this is temp solution
                        .then(function(assSvcs) {
                            model.associatedServices = $filter('orderBy')(assSvcs, ['serviceName']);
                            updateServiceListWithCostShare(model.associatedServices, costSharesStructMap, true);
                            // saveModel(); // SLQ temp
                        });
                });
        }

        function createAssociatedServicesFromPlan(planId) {
            // This is the same as service-list.js
            function transferInput(data) {
                var transferedData = [];

                angular.forEach(data, function(item /*, index*/ ) {
                    var transferedItem = {};
                    angular.forEach(item, function(value, key) {
                        // if (key === 'subCategory') {
                        //     transferedItem['location'] = angular.copy(value);
                        // } else {
                        transferedItem[key] = angular.copy(value); // TODO: if it is really flated data, no deep copy necessary.
                        // }
                    });

                    transferedData.push(transferedItem);
                });

                return transferedData;
            }

            return getAssociatedIdsForEdit(planId)
                .then(function(idsWithServices) {
                    return transferInput(idsWithServices);
                });
        }

        // return servcieId --> services map
        function getAssociatedIdsForEdit(planObjectId) {
            // SLQ in the future, the plan detail should not need load
            return getPlanExpandableL3(planObjectId)
                .then(function(plan) {
                    return populatePlanLinkedServiceIfNotLoaded(plan);
                })
                .then(function(planLevel3) {
                    return parseAssociatedIdsForEdit(planLevel3);
                });
        }

        // Alway return promise
        function saveCurrentPlanService(associatedService, planId, metadata) {
            var planService = getPlanServiceObject(associatedService, planId, metadata);
            var planServiceId = planService['objectId'];
            $log.log(angular.toJson(planService, true));

            return ProductPlanMgmtSvc.updatePlanService(planService, planServiceId, planId)
                .then(function() {
                    if (!needReloadPlanDetailLevel3) { // update changed part in loaded data if not auto reload
                        return updatedPlanL3LinkedService(planService, planId);
                    }
                });
        }

        function getPlanServiceObject(associatedService, planId, metadata) {
            var planService = {};
            var jointProps = associatedService.planSvcJointProps;
            // Object identification Info
            planService['planId'] = planId; // plan id
            planService['planServiceId'] = associatedService['objectId']; // service id
            planService['objectId'] = jointProps['linkedPlanServiceId']; // planService id
            // Properties
            populatePropertiesFormJointProps(jointProps, planService, metadata);
            // Cost share
            var costShareStruct = associatedService.planSvcJointProps.costShares;
            populatePlanServiceCostShare(costShareStruct, planService);

            return planService;
        }

        // Extract the value from joint properties and put them into planServive
        function populatePropertiesFormJointProps(jointProps, planService, metadata) {
            planService['isServiceCovered'] = jointProps['isServiceCovered'];
            planService['limitsAndExceptions'] = angular.copy(jointProps['limitsAndExceptions']);
            planService['isPreCertificationRequired'] = jointProps['isPreCertificationRequired'];
            planService['applyToMOOP'] = jointProps['applyToMOOP'];
            planService['applyToDeductibles'] = jointProps['applyToDeductibles'];
            planService['isCarvedOut'] = jointProps['isCarvedOut'];
            // DOGHR-2325 Ensure API does not receive empty string for limitsAndExceptions
            if (jointProps.hasOwnProperty('limitsAndExceptions') && jointProps['limitsAndExceptions'][0].length > 0) {
                planService['limitsAndExceptions'] = angular.copy(jointProps['limitsAndExceptions']);
            }
            if (planService['isCarvedOut']) {
                planService['vendorName'] = jointProps['vendorName'];
                planService['vendorPhone'] = jointProps['vendorPhone'];
                planService['vendorWebsite'] = jointProps['vendorWebsite'];
            } else {
                planService['vendorName'] = null;
                planService['vendorPhone'] = null;
                planService['vendorWebsite'] = null;
            }

            // UDF output transform
            angular.forEach(jointProps, function(fieldValue, fieldName) {
                if (fieldName.indexOf('udfplanservice_') === 0) {
                    angular.forEach(metadata, function(item) {
                        if (item.nameId === fieldName) {
                            var originValue = jointProps[fieldName];
                            if (item.type === 'radioButton') {
                                if (originValue === null || originValue === undefined) {
                                    planService[fieldName] = null;
                                } else if (originValue.toString().toLowerCase() === 'yes') {
                                    planService[fieldName] = true;
                                } else if (originValue.toString().toLowerCase() === 'no') {
                                    planService[fieldName] = false;
                                }
                            } else if ((item.type === 'textInput' || item.type === 'textArea') && (originValue === '')) {
                                planService[fieldName] = null;
                            } else {
                                planService[fieldName] = originValue;
                            }
                        }
                    });
                }
            });
        }

        function populatePlanServiceCostShare(costShareStruct, planService) {
            var costShareList = readCostShareFromStruct(costShareStruct);
            var costSahreListLoc = angular.copy(costShareList);
            // SLQ I think there could be some data transfer needed, such as remove some property only for display purpose
            planService['planserviceCostShares'] = transformCostshareInfo(costSahreListLoc);
        }

        // persistence
        // function saveModel() {
        //     $log.log('p2aCostShareModel saved into local');
        //     localStorageService.set('p2aCostShareModel', model);
        // }

        // function restoreModel() {
        //     $log.log('p2aCostShareModel restored from local');
        //     var modelLoc = localStorageService.get('p2aCostShareModel');
        //     if (!!modelLoc) {
        //         model = modelLoc;
        //     }
        //     return model;
        // }
        // SLQ need to put a good place
        // restoreModel();

        // $window.onbeforeunload = function() {
        //     saveModel();
        // };

        // SLQ: need to check when is good time to remove this p2aCostShareModel
        // $scope.$on('$destroy', function( /*event*/ ) {
        //     $log.log('Plan clear from local');
        //     localStorageService.remove('plan');
        // });


        function fireEvent(event, args) {
            // default $broadcast event and handler could be happen in in same cycle
            $timeout(function() {
                if (!args) {
                    $rootScope.$broadcast(event);
                } else {
                    $rootScope.$broadcast(event, args);
                }
            });
        }

        function PlanExpandable3(value) {
            if (arguments.length) {
                model.PlanExpandable3 = value;
            }
            return model.PlanExpandable3;
        }

        function productExpandable3(value) {
            if (arguments.length) {
                model.productExpandable3 = value;
            }
            return model.productExpandable3;
        }

        function associatedServices(value) {
            if (arguments.length) {
                model.associatedServices = value;
                // saveModel();
            }
            return model.associatedServices;
        }

        function transformCostshareInfo(data) {
            angular.forEach(data, function(costshare) {
                // costshare.selectedValue = (costshare.selectedValue === null) ? null : parseInt(costshare.selectedValue, 10);
                // Allow decimals for cost share values DOGHR-1825
                //

                costshare.selectedValue = (costshare.selectedValue === null) ? null : parseFloat(costshare.selectedValue);
                delete costshare.slider;
                delete costshare.isSlider;

                // DOGHR-2325 Ensure API does not receive empty string for rangeSurroundingTexts
                if (costshare.hasOwnProperty('rangeSurroundingTexts') && costshare.rangeSurroundingTexts[0].length <= 0) {
                    delete costshare.rangeSurroundingTexts;
                }
            });

            return data;
        }

        /**
         * Clear the cache
         */
        function clearCache() {
            $log.log('>>>>>>>> clear the plan edit cache...');
            model = {};
        }

        var model = {};
        model.PlanExpandable3 = null;
        model.productExpandable3 = null;
        // view list model
        model.associatedServices = null;

        var needReloadPlanDetailLevel3 = false;
        var needReloadProductDetailLevel3 = false;

        return facade;

        /*********************************************
        Event:
            CostShareFacadeSvc.associatedServices.changed:                  fired when content of associatedServices changed
            CostShareFacadeSvc.associatedServices.OneCostShares.Loaded:     fired when the planserviceCostShares of linkedPlanService of give service is loaded
            CostShareFacadeSvc.tierCostShares.loaded:                       fired when tier cost shares is loaded

        **********************************************/
    });