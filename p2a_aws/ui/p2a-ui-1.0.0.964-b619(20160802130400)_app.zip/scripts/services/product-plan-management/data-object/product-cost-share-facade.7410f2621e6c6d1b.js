'use strict';

angular.module('p2AdvanceApp')
    .factory('ProductCostShareFacadeSvc', function($rootScope, $filter, $timeout,
        ProductPlanMgmtSvc, $q, ppmUtils, ConfirmationModalFactory, ENV, $log) {

        var facade = {
            getAssociatedIdsForProductEdit: function(productObjectId) {
                return getAssociatedIdsForProductEdit(productObjectId);
            },
            populateProductLinkedServiceIfNotLoaded: function(product) {
                return populateProductLinkedServiceIfNotLoaded(product);
            },
            updateCachedProductL3ForLinkedProductService: function(productId, postProduct, assoSvcList) {
                return updateCachedProductL3ForLinkedProductService(productId, postProduct, assoSvcList);
            },
            updateCachedProductL3PropertyAndPlanCostShares: function(productId, simplifiedSendPlan) {
                return updateCachedProductL3PropertyAndPlanCostShares(productId, simplifiedSendPlan);
            },
            // Always return promise
            getProductExpandableL3: function(productObjId, expLevel) {
                return getProductExpandableL3(productObjId, expLevel);
            },
            productExpandable3: function(value) {
                return arguments.length ? productExpandable3(value) : productExpandable3();
            },
            // Set/Get
            associatedServices: function(value) {
                return arguments.length ? associatedServices(value) : associatedServices();
            },
            populateCurrentProductServiceCostSharesIfNotDoneAllready: function(service) {
                return populateCurrentProductServiceCostSharesIfNotDoneAllready(service);
            },
            updateProductWithCostShares: function(productId) {
                return readCostShareFromProduct(productId);
            },
            loadTierCostShare: function(productId, serviceId, linkedProductServiceId, tierName) {
                loadTierCostShare(productId, serviceId, linkedProductServiceId, tierName);
            },
            loadServiceCostShareOfProduct: function(productId, serviceId, linkedProductServiceId) {
                loadServiceCostShareOfProduct(productId, serviceId, linkedProductServiceId);
            },
            updateEditProductService: function(associatedService, productId, metadata) {
                return saveCurrentProductService(associatedService, productId, metadata)
                    .then(function() {
                        return reloadProductCostShareAfterSave(productId);
                    });
            },
            loadSingleTierCostShareFromProduct: function(productId, serviceId, linkedProductServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus) {
                loadSingleTierCostShareFromProduct(productId, serviceId, linkedProductServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus);
            },
            loadSingleLevelCostShareFromProduct: function(productId, serviceId, linkedProductServiceId, tierName, costshareType, level, preCertStatus, moopStatus, deductibleStatus) {
                loadSingleLevelCostShareFromProduct(productId, serviceId, linkedProductServiceId, tierName, costshareType, level, preCertStatus, moopStatus, deductibleStatus);
            },
            clearCache: function() {
                clearCache();
            }
        };



        function populateProductLinkedServiceIfNotLoaded(product) {
            return ProductPlanMgmtSvc.getProductAssociatedServices(product.objectId)
                .then(function(serviceList) {
                    $log.log('loaded service is : ' + serviceList.length);
                    var productServiceMap = {};

                    angular.forEach(product.productservices, function(linkedProductSvc) {
                        var service = linkedProductSvc.prodservice[0];
                        if (isUuid(service)) {
                            productServiceMap[service] = linkedProductSvc;
                        }
                    });

                    while (serviceList.length > 0) {
                        var svc = serviceList.shift();
                        var linkedProductService = productServiceMap[svc.objectId];
                        if (linkedProductService) {
                            linkedProductService.prodservice[0] = svc;
                        }
                    }
                    return product;
                });
        }

        var uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        /*
         * Test if the string is a uuid
         */
        function isUuid(str) {
            return angular.isString(str) && uuidPattern.test(str);
        }

        /*
            return {service.id --> {service (+ lanSvcJointProps)}, ...}
        */
        // SLQ this function return value has been changed, and different from its sibling funciton parseAssociatedIdsForCreateNew
        function parseAssociatedIdsForProductEdit(productDetailLevel3) {
            var associatedServiceIds = {};
            var linkedProductServicesList = productDetailLevel3.productservices;
            angular.forEach(linkedProductServicesList, function(linkedServices /*, index*/ ) {
                if (linkedServices && linkedServices.prodservice && linkedServices.prodservice.length > 0) {
                    var objectId = linkedServices.prodservice[0].objectId; // service Id
                    var productSvcJointProps = {
                        linkedProductServiceId: linkedServices.objectId, // necessary for update productservice object
                        isCovered: linkedServices.isCovered,
                        serviceException: linkedServices.serviceException ? linkedServices.serviceException : '',
                        preCertificationRequired: linkedServices.preCertificationRequired,
                        category: linkedServices.prodservice[0].category,
                        subCategory: linkedServices.prodservice[0].subCategory,
                        level: linkedServices.prodservice[0].level,
                        isApplyToMOOP: linkedServices.isApplyToMOOP,
                        isApplyToDeductibles: linkedServices.isApplyToDeductibles
                    };

                    /*For the udf properties*/
                    angular.forEach(linkedServices, function(value, property) {
                        if (property.indexOf('udfproductservice_') === 0) {
                            productSvcJointProps[property] = value;
                        }
                    });
                    objectId = ppmUtils.removeVersionFromId(objectId);
                    var svc = linkedServices.prodservice[0];
                    svc.productSvcJointProps = productSvcJointProps;
                    associatedServiceIds[objectId] = svc;
                }
            });

            return associatedServiceIds;
        }

        // Note this function currelty load product at level 1
        // Always return promise
        function getProductExpandableL3(productObjId, expLevel) {
            if (!needReloadProductDetailLevel3 && !!model.productExpandable3) { // SLQ needReloadProductDetailLevel3 always is true, unless we found a way to remove cache
                $log.log('Product details expandable level 3 already exist');
                var defer = $q.defer();
                defer.resolve(model.productExpandable3);
                return defer.promise;
            } else {
                $log.log('Product details expandable level 3 is been loading from backend');
                var associationExpansionLevel = (expLevel && expLevel >= -1) ? expLevel : 1; // changed default level to 1, before level 3
                return ProductPlanMgmtSvc.getProductDetails(productObjId, associationExpansionLevel).then(function(data) {
                    model.productExpandable3 = data; // keep this value in service
                    return data;
                });
            }
        }



        function updateCachedProductL3ForLinkedProductService(productId, postProduct, assoServices) {
            function isNewlinkedProductServiceAdded(postProductWithLinkedProductServices) {
                var result = false;

                var linkedProductServices = postProductWithLinkedProductServices.productservices;
                angular.forEach(linkedProductServices, function(productService) {
                    if (angular.isUndefined(productService.objectId) || productService.objectId === null) { // no id, new product service
                        result = true;
                    }
                });
                return result;
            }

            function findAssociatedServiceRemovingJointProperty(serviceList, serviceId) {
                var svc;
                angular.forEach(serviceList, function(svcItem) {
                    if (svcItem.objectId === serviceId) {
                        svc = angular.copy(svcItem);
                    }
                });

                delete svc.productSvcJointProps;
                return svc;
            }


            function updateCachedProductWithLinkedProductServices(productObjectId, postJointProductServices, loadedJointProductServices) {
                if (!model.productExpandable3.productservices) {
                    model.productExpandable3.productservices = [];
                }

                var cachedLinkedProductServices = model.productExpandable3.productservices;



                var loadedMap = {};
                if (hasNew) {
                    angular.forEach(loadedJointProductServices, function(ps) {
                        if (ps.productId !== productObjectId) {
                            $log.error('cost-share-facade.js: updateCachedProductWithLinkedProductServices loaded product objectId should be the same!');
                        }
                        loadedMap[ps.serviceId] = ps.objectId;
                    });
                }
                var postMap = {};
                angular.forEach(postJointProductServices, function(ps) {
                    // Same as hasNew === true
                    if (angular.isUndefined(ps.objectId) || ps.objectId === null) { // this is new added product service
                        if (ps.productId !== productObjectId) {
                            $log.error('cost-share-facade.js: updateCachedProductWithLinkedProductServices posted product objectId should be the same!');
                        }
                        ps.objectId = loadedMap[ps.serviceId]; // Copy linkedProductService Id (joint object Id)
                        if (!ps.objectId) {
                            $log.error('cost-share-facade.js: updateCachedProductWithLinkedProductServices new product service objectId should be set correctly!');
                        }
                        ps.frontPlanServiceNeedToReloaded = true; // This is a special to indicated this product service and its cost share should be reloaded
                        // addits related services
                        ps.prodservice = [];
                        ps.prodservice.push(findAssociatedServiceRemovingJointProperty(assoServices, ps.serviceId));
                        cachedLinkedProductServices.push(ps); // Add new created product service into cached product service list and mark it as need to reloaded
                    }
                    postMap[ps.objectId] = ps;
                });
                var i = cachedLinkedProductServices.length - 1;
                for (; i >= 0; --i) {
                    var cachedPs = cachedLinkedProductServices[i];
                    var postPs = postMap[cachedPs.objectId];
                    if (!postPs) { // this cached ps is deleted
                        cachedLinkedProductServices.splice(i, 1); // remove element from array
                    } else {
                        // Copy the properties
                        cachedPs.isCovered = postPs.isCovered; // this is the only property that could be changed
                    }
                }
            }

            // return promise
            function loadLinkedProductServices(productObjectId) {
                if (hasNew) {
                    var associationExpansionLevel = 1;
                    var properties = ['productservices', 'serviceId', 'productId'];
                    return ProductPlanMgmtSvc.getProductViaCm(productObjectId, associationExpansionLevel, properties)
                        .then(function(data) {
                            return data.productservices;
                        });
                }

                return $q.when(); // if no new added, this promise return underfined
            }

            var hasNew = isNewlinkedProductServiceAdded(postProduct);

            return loadLinkedProductServices(productId)
                .then(function(loadedProductServiceList) {
                    updateCachedProductWithLinkedProductServices(productId, postProduct.productservices, loadedProductServiceList);
                });
        }

        function populateCurrentProductServiceCostSharesIfNotDoneAllready(service) {
            if (!service.productSvcJointProps.costShares) {
                // check if the productL3 already have this service cost share
                var serviceId = service.objectId;
                var linkedProductSvc = getLinkedProductServiceByServiceIdFromProductL3(serviceId);
                var productServiceCostSharesList = linkedProductSvc.costshares;


                return $q.when(isArrayContentAlreadyLoadedOrNoCostShares(productServiceCostSharesList))
                    .then(function(alreadyLoadedOrNoCostShares) {
                        if (alreadyLoadedOrNoCostShares) {
                            return linkedProductSvc; // remember the second return linkedProductSvc; is in another promise
                        } else {
                            // load linkedProductSvc
                            var productServiceId = service.productSvcJointProps.linkedProductServiceId;
                            var associationExpansionLevel = 1;
                            var productId = productExpandable3().objectId;
                            return ProductPlanMgmtSvc.getProductServices(productId, productServiceId, associationExpansionLevel)
                                .then(function(linkendProductService) {
                                    // update productL3 linkedProductService Costshare
                                    linkedProductSvc.costshares = linkendProductService.costshares;
                                    return linkedProductSvc;
                                });
                        }
                    })
                    .then(function(linkedProductSvc) {
                        var costShareStruct = createOneServiceCostShareListStructure(linkedProductSvc);
                        fireEvent('ProductCostShareFacadeSvc.associatedServices.OneCostShares.Loaded', costShareStruct);
                        return costShareStruct;
                    });
            }
        }

        function readCostShareFromProduct(productId) {
            return getProductExpandableL3(productId)
                .then(function(productL3) {
                    return parseCostShareStructMapFromProduct(productL3);
                })
                .then(function(costSharesStructMap) {
                    createAssociatedServicesFromProduct(productId) // SLQ this is temp solution
                        .then(function(assSvcs) {
                            model.associatedServices = $filter('orderBy')(assSvcs, ['serviceName']);
                            updateProductServiceListWithCostShare(model.associatedServices, costSharesStructMap, true);
                            // saveModel(); // SLQ temp
                        });
                });
        }

        function loadTierCostShare(productId, serviceId, linkedProductServiceId, tierName) {
            getProductExpandableL3(productId).then(function(product) {
                var productId = product.objectId; // always user the first linked product
                var tierNames = product.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.productSvcJointProps.linkedProductServiceId !== linkedProductServiceId) {
                            throw 'Logic error in the product service cost share model';
                        }
                        if (!service.productSvcJointProps.costShares) {
                            service.productSvcJointProps.costShares = {};
                        }
                        // service is in the product
                        if (costShareStructMap[serviceId] !== undefined) {
                            var newCostShares = costShareStructMap[serviceId][tierName];
                            // tier is in the product/service
                            if (newCostShares !== undefined) {
                                service.productSvcJointProps.costShares[tierName] = newCostShares;
                            } else { // tier is not in the product/service
                                service.productSvcJointProps.costShares[tierName] = addCostSharesByTier(tierName);
                            }
                        } else { // service is not in the product
                            service.productSvcJointProps.costShares[tierName] = addCostSharesByTier(tierName);
                        }

                    }
                });

                fireEvent('ProductCostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
                fireEvent('ProductCostShareFacadeSvc.tierCostShares.loaded');
            });
        }

        function loadServiceCostShareOfProduct(productId, serviceId, linkedProductServiceId) {
            getProductExpandableL3(productId).then(function(product) {
                var productId = product.objectId; // always user the first linked product
                var tierNames = product.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.productSvcJointProps.linkedProductServiceId !== linkedProductServiceId) {
                            throw 'Logic error in the product service cost share model';
                        }
                        service.productSvcJointProps.costShares = costShareStructMap[serviceId];
                    }
                });

                fireEvent('ProductCostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
            });
        }

        /**
           Get the productService of the service from ProductL3 by give service id
        */
        function getLinkedProductServiceByServiceIdFromProductL3(serviceId) {
            var productL3 = productExpandable3();
            var linkedProductServicesList = productL3.productservices;
            var i;
            for (i = 0; i < linkedProductServicesList.length; ++i) {
                var linkedProductSvc = linkedProductServicesList[i];
                if (linkedProductSvc.prodservice[0].objectId === serviceId) { // find the service in the linkedPlanServices
                    return linkedProductSvc;
                }
            }

            return null;
        }

        // kind of similar createOneServiceCostShareListStructure
        function parseCostShareStructMapFromProduct(productL3) {
            var linkendProductServiceList = productL3.productservices;

            var costShareStructMap = {};
            angular.forEach(linkendProductServiceList, function(linkendProductService) {
                var serviceId = linkendProductService['serviceId']; // Yes, it is service objectId, because in Alfresco, duplicated property name is not allowed
                var costSahreList = linkendProductService['costshares'];
                angular.forEach(costSahreList, function(costShare) {
                    if (!isUuid(costShare)) { // SLQ In future, if partial loaded implemented, this place costShare always is a uuid ONLY
                        if (!costShareStructMap[serviceId]) {
                            costShareStructMap[serviceId] = {};
                        }
                        addCostShareIntoStruct('product', costShare, costShareStructMap[serviceId], 0);
                    }
                });
            });

            return costShareStructMap;
        }

        /**
         * Add the cost share struct from id map into view product Service list, 
         * Also fire event
         */
        function updateProductServiceListWithCostShare(serviceList, costShareStructMap, isInitLoad) { // add 3rd parameter just in case this funciton is used in updating situation
            angular.forEach(serviceList, function(service) {
                var serviceId = ppmUtils.removeVersionFromId(service.objectId);
                if (!service.productSvcJointProps) {
                    service.productSvcJointProps = {};
                }
                service.productSvcJointProps.costShares = costShareStructMap[serviceId];
            });
            fireEvent('ProductCostShareFacadeSvc.associatedServices.changed', {
                associatedSvcs: model.associatedServices, // SLQ why this is null
                isInitLoad: isInitLoad
            });
        }

        function createAssociatedServicesFromProduct(productId) {
            // This is the same as service-list.js
            function transferInput(data) {
                var transferedData = [];

                angular.forEach(data, function(item /*, index*/ ) {
                    var transferedItem = {};
                    angular.forEach(item, function(value, key) {
                        // if (key === 'subCategory') {
                        //     transferedItem['location'] = angular.copy(value);
                        // } else {
                        transferedItem[key] = angular.copy(value); // TODO: if it is really flated data, no deep copy necessary.
                        // }
                    });

                    transferedData.push(transferedItem);
                });

                return transferedData;
            }

            return getAssociatedIdsForProductEdit(productId)
                .then(function(idsWithServices) {
                    return transferInput(idsWithServices);
                });
        }

        function isArrayContentAlreadyLoadedOrNoCostShares(list) {
            if (list) {
                for (var i = 0; i < list.length; ++i) {
                    var item = list[i];
                    if (isUuid(item)) {
                        return false;
                    }
                }
            }

            return true;
        }

        function createOneServiceCostShareListStructure(linkedProductService) {
            var costShareStruct = {};
            var costSahreList = linkedProductService['costshares'];
            angular.forEach(costSahreList, function(costShare) {
                if (!isUuid(costShare)) {
                    addCostShareIntoStruct('product', costShare, costShareStruct, 0);
                }
            });

            return costShareStruct;
        }

        function getAssociatedIdsForProductEdit(productObjectId) {
            return getProductExpandableL3(productObjectId)
                .then(function(product) {
                    return populateProductLinkedServiceIfNotLoaded(product);
                })
                .then(function(productLevel3) {
                    return parseAssociatedIdsForProductEdit(productLevel3);
                });
        }

        function initCostShareStructMapFromProduct(productObjId, criteria, serviceId) {
            return getProductExpandableL3(productObjId).then(function(prodL3) {
                // SLQ check if the selected service has L3 cost share information
                // In fact, we olny need the current service related cost share, because
                // when create product from product, all product service cost share a already setup
                // and here only restore the selected service's cost share if it is 
                // removed by uncovered

                function getProductServiceIndexByServiceId(productServiceList, serviceObjectId) {
                    if (productServiceList) {
                        for (var i = 0; i < productServiceList.length; ++i) {
                            var productSvc = productServiceList[i];
                            if (serviceObjectId === productSvc.serviceId) { // in productService Object, service objectId is serviceId
                                return i;
                            }
                        }
                    }

                    return -1;
                }

                function isProductServiceIncludeCostSharesDetails(costShareList) {
                    if (!costShareList) {
                        return false;
                    }

                    for (var i = 0; i < costShareList.length; ++i) {
                        var costShare = costShareList[i];
                        if (isUuid(costShare)) {
                            return false;
                        }
                    }

                    return true;
                }

                function loadProductServiceAssociatedCostShareIfNotLoaded() {
                    if (serviceId) { // if service Id provided
                        var svcIndex = getProductServiceIndexByServiceId(prodL3.productservices, serviceId);
                        if (svcIndex >= 0) {
                            var prodSvc = prodL3.productservices[svcIndex];
                            if (prodSvc.costshares && !isProductServiceIncludeCostSharesDetails(prodSvc.costshares)) {
                                // load cost share for this product
                                var associationExpansionLevel = 1;
                                return ProductPlanMgmtSvc.getProductServices(productObjId, prodSvc.objectId, associationExpansionLevel)
                                    .then(function(productService) {
                                        prodL3.productservices[svcIndex] = productService;

                                        return prodL3;
                                    });
                            }
                        }
                    }

                    return prodL3;
                }

                return $q.when(loadProductServiceAssociatedCostShareIfNotLoaded())
                    .then(function(prodL3) {
                        return parseCostShareDataFromProduct(prodL3, criteria);
                    });
            });
        }

        function fireEvent(event, args) {
            // default $broadcast event and handler could be happen in in same cycle
            $timeout(function() {
                if (!args) {
                    $rootScope.$broadcast(event);
                } else {
                    $rootScope.$broadcast(event, args);
                }
            });
        }

        function isTierIncluded(tierNames) {
            var tierNamesMap = {};
            if (angular.isArray(tierNames)) {
                angular.forEach(tierNames, function(name) {
                    tierNamesMap[name] = name;
                });
            } else {
                tierNamesMap = tierNames; // Assume it is already a map/object
            }

            return function() {
                var obj = this;
                if (obj.providerTier in tierNamesMap) {
                    return true;
                }

                return false;
            };
        }

        function addCostSharesByTier(tierName) {
            var result = {};
            var costshareTypeArray = ['Copay', 'Co-insurance', 'Deductible', 'Limits and Exceptions'];

            angular.forEach(costshareTypeArray, function(csName) {
                result[csName] = {};
                result[csName]['Primary'] = addSingleCostShareByLevel(tierName, csName, 'Primary');
            });

            return result;
        }

        // cost share front structure level
        var structOrder = ['providerTier', 'costShareType', 'costShareLevel'];
        var propertiesRemovedFromProductCopy = ['versionSeriesId', 'objectId', 'nodeRef', 'name'];

        function addCostShareIntoStruct(objectType, costShare, struct, structLevel, operation, criteria) {
            if (structLevel === 0 && criteria && !criteria.apply(costShare)) { // only check at top recusive loop
                return;
            }

            var structLevelName = costShare[structOrder[structLevel]];

            if (structLevel < 2) {
                if (!struct[structLevelName]) {
                    struct[structLevelName] = {};
                }
                addCostShareIntoStruct(objectType, costShare, struct[structLevelName], structLevel + 1, operation, criteria);
            } else {
                var copyOfCostShare = angular.copy(costShare);

                // DOGHR-1932: cost share from product, should use default value, instead of selectedValue
                /*if (objectType === 'product') {
                    copyOfCostShare.selectedValue = copyOfCostShare['default'];
                }*/

                // remove the properties that belong to product cost-share
                if (operation) {
                    operation.apply(copyOfCostShare);
                }

                struct[structLevelName] = copyOfCostShare;
            }
        }

        function productExpandable3(value) {
            if (arguments.length) {
                model.productExpandable3 = value;
            }
            return model.productExpandable3;
        }

        function associatedServices(value) {
            if (arguments.length) {
                model.associatedServices = value;
                // saveModel();
            }
            return model.associatedServices;
        }

        function parseCostShareDataFromProduct(prodL3, criteria) {
            var productServiceList = prodL3.productservices;

            var costShareStruct = {};
            angular.forEach(productServiceList, function(productService) {
                var serviceId = productService.serviceId;
                var costShareList = productService['costshares'];
                angular.forEach(costShareList, function(costShare) {
                    if (!costShareStruct[serviceId]) {
                        costShareStruct[serviceId] = {};
                    }
                    addCostShareIntoStruct('product', costShare, costShareStruct[serviceId], 0, removeSomeProperties(propertiesRemovedFromProductCopy), criteria);
                });
            });

            return costShareStruct;
        }

        function addSingleCostShareByLevel(tierName, costshareType, level) {
            var levelInfo = {
                'rangeSurroundingTexts': [''],
                'rangeTexts': [''],
                'preCertificationRqrd': undefined,
                'applyToDeduct': undefined,
                'applyToMaxOutPocket': undefined,
                'costShareLevel': level,
                'costShareType': costshareType,
                'quantityBasis': undefined,
                'splitByTier': undefined,
                'selectedValue': 0,
                'providerTier': tierName,
                'format': '$',
                'isSlider': false
            };
            if (costshareType === 'Co-insurance') {
                levelInfo.format = '%';
            } else if (costshareType === 'Limits and Exceptions') {
                levelInfo.format = 'Visits';
            }
            return levelInfo;
        }

        function saveCurrentProductService(associatedService, productId, metadata) {
            var productService = getProductServiceObject(associatedService, productId, metadata);
            var productServiceId = productService['objectId'];
            $log.log(angular.toJson(productService, true));

            return ProductPlanMgmtSvc.updateProductService(productId, productService, productServiceId)
                .then(function() {
                    if (!needReloadProductDetailLevel3) { // update changed part in loaded data if not auto reload
                        return updatedProductL3LinkedService(productService);
                    }
                });
        }

        function getProductServiceObject(associatedService, productId, metadata) {
            var productService = {};
            var jointProps = associatedService.productSvcJointProps;
            // Object identification Info
            productService['productId'] = productId; // productId
            productService['serviceId'] = associatedService['objectId']; // service id
            productService['objectId'] = jointProps['linkedProductServiceId']; // productService id
            // Properties
            populatePropertiesFormJointProps(jointProps, productService, metadata);
            // Cost share
            var costShareStruct = associatedService.productSvcJointProps.costShares;
            populateProductServiceCostShare(costShareStruct, productService);

            return productService;
        }

        function populatePropertiesFormJointProps(jointProps, productService, metadata) {
            productService['isCovered'] = jointProps['isCovered'];
            productService['serviceException'] = angular.copy(jointProps['serviceException']);
            productService['preCertificationRequired'] = jointProps['preCertificationRequired'];
            productService['isApplyToMOOP'] = jointProps['isApplyToMOOP'];
            productService['isApplyToDeductibles'] = jointProps['isApplyToDeductibles'];
            $log.log(angular.toJson(metadata, true));

            /*For the udf properties*/
            //UDF output transform
            angular.forEach(jointProps, function(fieldValue, fieldName) {
                if (fieldName.indexOf('udfproductservice_') === 0) {
                    angular.forEach(metadata, function(item) {
                        if (item.nameId === fieldName) {
                            var originValue = jointProps[fieldName];
                            if (item.type === 'radioButton') {                                
                                if (originValue === null || originValue === undefined) {
                                    productService[fieldName] = null;
                                } else if (originValue.toString().toLowerCase() === 'yes') {
                                    productService[fieldName] = true;
                                } else if (originValue.toString().toLowerCase() === 'no') {
                                    productService[fieldName] = false;
                                }
                            } else if ((item.type === 'textInput' || item.type === 'textArea') && (originValue === '')) {
                                productService[fieldName] = null;
                            } else {
                                productService[fieldName] = jointProps[fieldName];
                            }
                        }
                    });
                }
            });
        }

        function populateProductServiceCostShare(costShareStruct, productService) {
            var costShareList = readCostShareFromStruct(costShareStruct);
            costShareList = removeNullFromRangeValues(costShareList);
            var costSahreListLoc = angular.copy(costShareList);
            // SLQ I think there could be some data transfer needed, such as remove some property only for display purpose
            productService['costshares'] = transformCostshareInfo(costSahreListLoc);
        }

        function removeNullFromRangeValues(costShareList) {
            angular.forEach(costShareList, function(costshare) {
                delete costshare.inputTypes;
                if (!costshare.isRangeValidationEnforced) {
                    costshare.isRangeValidationEnforced = false;
                }
                if (!costshare.severityLevel) {
                    costshare.severityLevel = 'Warning';
                }
                if (costshare.rangeValues) {
                    costshare.rangeValues = costshare.rangeValues.filter(function(n) {
                        return n !== null && n !== '' && n !== undefined;
                    });
                }
            });
            return costShareList;
        }

        function readCostShareFromStruct(costShareStruct) {
            var resultList = [];
            readCostShareFromStructRecursive(costShareStruct, resultList, 0);
            return resultList;
        }

        function readCostShareFromStructRecursive(struct, resultList, level) {
            if (level < 3) {
                angular.forEach(struct, function(subStruct) {
                    readCostShareFromStructRecursive(subStruct, resultList, level + 1);
                });
            } else {
                resultList.push(struct);
            }
        }

        function transformCostshareInfo(data) {
            angular.forEach(data, function(costshare) {
                // costshare.selectedValue = (costshare.selectedValue === null) ? null : parseInt(costshare.selectedValue, 10);
                // Allow decimals for cost share values DOGHR-1825
                // 
                costshare.selectedValue = (costshare.selectedValue === null) ? null : parseFloat(costshare.selectedValue);
                delete costshare.slider;
                delete costshare.isSlider;
            });
            return data;
        }

        function removeSomeProperties(propertiesRemoved) {
            return function() {
                var obj = this;
                angular.forEach(propertiesRemoved, function(property) { // propertiesRemoved being null will skip loop
                    $log.log('The property ' + property + ' will be deleted, its value is ' + obj[property]);
                    delete obj[property];
                });
            };
        }

        // Return promise, rquired
        function updatedProductL3LinkedService(newLinkedService) {
            var linkedProductServiceList = model.productExpandable3.productservices;
            var promises = [];

            angular.forEach(linkedProductServiceList, function(service) {
                if (service.objectId === newLinkedService.objectId) { // find the match service
                    updateOneProductService(newLinkedService, service);
                    promises.push(updateOneProductServiceCostShareObjectId(service)); // only update product cost-share objectId if it is new
                }
            });

            return $q.all(promises);
        }

        function updateOneProductServiceCostShareObjectId(destSvc) {
            // find if new cost share added
            function isContainedNewCostshare() {
                var isContained = false;
                angular.forEach(destSvc.costshares, function(costShare) {
                    if (costShare.objectId === null || angular.isUndefined(costShare.objectId)) { // newly added cost share
                        isContained = true;
                    }
                });

                return isContained;
            }
            // find and update Id from backend cost-share list
            function updateCostShareIdFromBackendCsList(costShare, backendCsList) {
                var numFound = 0;

                angular.forEach(backendCsList, function(becs) {
                    if (costShare.providerTier === becs.providerTier &&
                        costShare.costShareType === becs.costShareType &&
                        costShare.costShareLevel === becs.costShareLevel) {
                        costShare.objectId = becs.objectId;
                        ++numFound;
                    }
                });

                if (numFound > 1) {
                    $log.error('product-cost-share-facade.js: the combination of "providerTier", "costShareType", "costShareLevel" should be unique!');
                }
            }

            if (isContainedNewCostshare()) {
                var productserviceId = destSvc.objectId;
                var associationExpansionLevel = 1;
                var properties = ['costshares', 'providerTier', 'costShareType', 'costShareLevel'];
                var productId = productExpandable3().objectId;
                return ProductPlanMgmtSvc.getProductServices(productId, productserviceId, associationExpansionLevel, properties)
                    .then(function(productService) {
                        var backendCsList = productService.costshares;

                        angular.forEach(destSvc.costshares, function(costShare) {
                            if (costShare.objectId === null || angular.isUndefined(costShare.objectId)) { // newly added cost share
                                updateCostShareIdFromBackendCsList(costShare, backendCsList);
                            }
                        });
                    });
            }
        }

        function reloadProductCostShareAfterSave(productId) {
            return getProductExpandableL3(productId)
                .then(function(productL3) {
                    return parseCostShareStructMapFromProduct(productL3);
                })
                .then(function(costSharesStructMap) {
                    return updateProductServiceListWithCostShare(model.associatedServices, costSharesStructMap, false);
                });

        }

        function updateOneProductService(sourceSvc, destSvc) {
            var skippedProperties = {
                'linkedService': true // this one should not changed here
            };

            // if use smart save, this part could need to rewrite, cannot just assign to place old value in linked service.
            angular.forEach(sourceSvc, function(value, key) {
                if (!(key in skippedProperties)) {
                    destSvc[key] = sourceSvc[key]; // copy the property
                }
            });
        }

        function loadSingleTierCostShareFromProduct(productId, serviceId, linkedProductServiceId, tierName, costshareType, preCertStatus, moopStatus, deductibleStatus) {
            getProductExpandableL3(productId).then(function(product) {
                var productId = product.objectId;
                var tierNames = product.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.productSvcJointProps.linkedProductServiceId !== linkedProductServiceId) {
                            throw 'Logic error in the product service cost share model';
                        }
                        if (!service.productSvcJointProps.costShares) {
                            service.productSvcJointProps.costShares = {};
                            service.productSvcJointProps.costShares[tierName] = {};
                        }
                        var newCostShareByType;
                        // service is in the product
                        if (costShareStructMap[serviceId] !== undefined) {
                            // tier is in the product/service
                            if (costShareStructMap[serviceId][tierName] !== undefined) {
                                newCostShareByType = costShareStructMap[serviceId][tierName][costshareType];
                                // cost share type is in the product/service/tier
                                if (newCostShareByType !== undefined) {
                                    service.productSvcJointProps.costShares[tierName][costshareType] = newCostShareByType;

                                }
                            }
                        }
                        // not found, manually add one
                        if (newCostShareByType === undefined) {
                            service.productSvcJointProps.costShares[tierName][costshareType] = addCostSharesByType(tierName, costshareType);
                        }
                        service.productSvcJointProps.costShares[tierName][costshareType]['Primary']['preCertificationRqrd'] = preCertStatus;
                        service.productSvcJointProps.costShares[tierName][costshareType]['Primary']['applyToMaxOutPocket'] = moopStatus;
                        service.productSvcJointProps.costShares[tierName][costshareType]['Primary']['applyToDeduct'] = deductibleStatus;

                    }
                });
                fireEvent('ProductCostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
                fireEvent('ProductCostShareFacadeSvc.tierCostShares.loaded');
            });
        }

        function addCostSharesByType(tierName, costshareType) {
            var result = {};
            result['Primary'] = addSingleCostShareByLevel(tierName, costshareType, 'Primary');

            return result;
        }

        function updateCachedProductL3PropertyAndPlanCostShares(productId, simplifiedSendPlan) {
            // check if there is any new cost share added
            function isNewCostShareAdded(postSimpleData) {
                var result = false;
                if (postSimpleData.globalcostshares && postSimpleData.globalcostshares.length > 0) {
                    angular.forEach(postSimpleData.globalcostshares, function(cs) {
                        if (angular.isUndefined(cs.objectId) || cs.objectId === null) { // no id, new cost share
                            result = true;
                        }
                    });
                }

                return result;
            }

            function updateCostSharesValue(newCsList, oldCsList) {
                var newCsMap = {};
                angular.forEach(newCsList, function(newCs) {
                    newCsMap[newCs.objectId] = newCs;
                });

                var i = oldCsList.length - 1;
                for (; i >= 0; --i) { // could remove item from list, so start from end 
                    var oldCs = oldCsList[i];
                    if (oldCs.objectId in newCsMap) { // update cost share property value
                        angular.forEach(newCsMap[oldCs.objectId], function(value, key) {
                            oldCs[key] = value;
                        });
                    } else { // this cost share is removed
                        oldCsList.splice(i, 1); // remove this element from array
                    }
                }
            }

            function updateProductProductL3(simplifiedSendPlan, costShareList) {
                var productL3 = model.productExpandable3;

                angular.forEach(simplifiedSendPlan, function(value, key) {
                    if (key === 'globalcostshares') {
                        if (!hasNew) { //  update cost shares (in clude those that are removed cost share)
                            updateCostSharesValue(simplifiedSendPlan.globalcostshares, productL3.globalcostshares);
                        } else { // just replace cost share with new one
                            productL3[key] = costShareList;
                        }
                    } else {
                        productL3[key] = value; // update value in product detail
                    }
                });
            }

            function loadProductCostshares() {
                if (hasNew) {
                    // load product cost shares
                    var associationExpansionLevel = 1;
                    return ProductPlanMgmtSvc.getProductDetails(productId, associationExpansionLevel)
                        .then(function(data) {
                            return data.globalcostshares;
                        });
                }

                return $q.when(); // if no new added, this promise return underfined
            }
            var hasNew = isNewCostShareAdded(simplifiedSendPlan);

            return loadProductCostshares()
                .then(function(csList) {
                    updateProductProductL3(simplifiedSendPlan, csList);
                });
        }

        function loadSingleLevelCostShareFromProduct(productId, serviceId, linkedProductServiceId, tierName, costshareType, level, preCertStatus, moopStatus, deductibleStatus) {
            $log.log('loadSingleLevelCostShareFromProduct is called');
            getProductExpandableL3(productId).then(function(product) {
                var productId = product.objectId; // always user the first linked product
                var tierNames = product.providerTierNames;
                return initCostShareStructMapFromProduct(productId, isTierIncluded(tierNames), serviceId);
            }).then(function(costShareStructMap) {
                angular.forEach(model.associatedServices, function(service) {
                    if (service.objectId === serviceId) {
                        if (service.productSvcJointProps.linkedProductServiceId !== linkedProductServiceId) {
                            throw 'Logic error in the product service cost share model';
                        }
                        if (!service.productSvcJointProps.costShares) {
                            service.productSvcJointProps.costShares = {};
                            service.productSvcJointProps.costShares[tierName] = {};
                            service.productSvcJointProps.costShares[tierName][costshareType] = {};
                        }

                        var newCostShareByLevel;
                        // service is in the product
                        if ((costShareStructMap[serviceId] !== undefined) && (costShareStructMap[serviceId][tierName] !== undefined) && (costShareStructMap[serviceId][tierName][costshareType] !== undefined)) {
                            newCostShareByLevel = costShareStructMap[serviceId][tierName][costshareType][level];
                            if (newCostShareByLevel !== undefined) {
                                service.productSvcJointProps.costShares[tierName][costshareType][level] = newCostShareByLevel;
                            }
                        }
                        // not found, manually add one
                        if (newCostShareByLevel === undefined) {
                            service.productSvcJointProps.costShares[tierName][costshareType][level] = addSingleCostShareByLevel(tierName, costshareType, level);
                        }
                        service.productSvcJointProps.costShares[tierName][costshareType][level]['preCertificationRqrd'] = preCertStatus;
                        service.productSvcJointProps.costShares[tierName][costshareType][level]['applyToMaxOutPocket'] = moopStatus;
                        service.productSvcJointProps.costShares[tierName][costshareType][level]['applyToDeduct'] = deductibleStatus;
                    }
                });

                fireEvent('ProductCostShareFacadeSvc.associatedServices.changed', {
                    associatedSvcs: model.associatedServices
                });
                fireEvent('ProductCostShareFacadeSvc.tierCostShares.loaded');
            });
        }


        /**
         * Clear the cache
         */
        function clearCache() {
            $log.log('>>>>>>>> clear the product edit cache...');
            model = {};
        }

        var model = {};
        model.productExpandable3 = null;
        model.associatedServices = null;
        var needReloadProductDetailLevel3 = false;
        return facade;
    });