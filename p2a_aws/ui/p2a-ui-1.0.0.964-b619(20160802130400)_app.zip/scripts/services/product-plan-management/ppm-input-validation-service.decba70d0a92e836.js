'use strict';

angular.module('p2AdvanceApp')
    .factory('PpmInputValidationSvc', function($timeout, ENV) {


        var ppmInputValidationSvc = {
            skipKeyStroke: skipKeyStroke,
            ValidationErrorMsg: function(attachedElement) {
                return new ValidationErrorMsg(attachedElement);
            }
        };

        function skipKeyStroke(event) {
            // Ctrl + a
            if (event.ctrlKey) {
                return true;
            }
            // IE, event.key return name/string of key, so remove it
            var key = event.keyCode || event.which;
            // If the keys include the CTRL, SHIFT, ALT, or META keys, or the arrow keys, Home, End do nothing.
            // This lets us support copy and paste too
            if (key === 91 || (15 < key && key < 19) || (35 <= key && key <= 40)) {
                return true;
            }

            return false;
        }

        function ValidationErrorMsg(attachedElement) {
            this.removeTimer = null;
            this.element = attachedElement;
        }

        ValidationErrorMsg.prototype.removeErrorElement = function() {
            var errEle = this.element.siblings('.ppm-char-restrict-error-msg');
            if (errEle.length !== 0) {
                errEle.remove();
                if (this.element.removeTimer) {
                    $timeout.cancel(this.removeTimer);
                    this.element.removeTimer = null;
                }
            }
        };

        ValidationErrorMsg.prototype.drawErrorElement = function(msg) {
            var errEle = this.element.siblings('.ppm-char-restrict-error-msg');
            if (errEle.length === 0) {
                errEle = $('<span class="ppm-char-restrict-error-msg"></span>');
                this.element.after(errEle);
            }
            errEle.html(msg);
            if (this.removeTimer) {
                $timeout.cancel(this.removeTimer);
                this.removeTimer = null;
            }
            this.removeTimer = $timeout(function() {
                this.removeErrorElement();
            }.bind(this), ENV.modalErrorTimeout * 2);
        };

        return ppmInputValidationSvc;
    });