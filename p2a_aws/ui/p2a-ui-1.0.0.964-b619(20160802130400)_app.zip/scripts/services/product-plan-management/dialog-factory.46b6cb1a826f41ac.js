'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.dialogFactorySvc
 * @description
 * # dialogFactorySvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('dialogFactorySvc', function($modal) {

        // Public API here
        return {
            /**
             *  Open a modal dialog.
             *  @param dlgUrl dialog template url
             *  @param controller controller/model view
             *  @param data the data that is used to initialize the dialog
             *  @param options all other options to config the dialog
             *
             *  @returns dialog instance
             */
            openModalDialog: function(dlgUrl, controller, resolve, options) {
                var openOption = angular.extend({}, options);

                openOption.templateUrl = dlgUrl;
                openOption.controller = controller;
                openOption.backdrop = 'static';
                openOption.resolve = resolve;
                // {
                //    data: function() {
                //       return data;
                //    }
                // };

                return $modal.open(openOption);
            }
        };

        // Private Part

    });