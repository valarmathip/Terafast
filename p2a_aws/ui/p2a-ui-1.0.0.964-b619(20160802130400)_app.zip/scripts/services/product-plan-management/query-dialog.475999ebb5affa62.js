'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.QueryDialog
 * @description
 * # QueryDialog
 * Factory in the p2AdvanceApp.
 * Note: This is refactored from warning model dialog.
 */
angular.module('p2AdvanceApp')
    .factory('QueryDialog', function(dialogFactorySvc) {

        // Public API here
        var queryDialog = {
            open: function(title, message, icon, dialogType, contentTplUrl, options) {
                if (!title) {
                    title = 'Warning'; // the default tile
                }
                if (!message) {
                    throw new Error('The message parameter in function open of QueryDialog have to be set!');
                }

                // Available: question, warning, minus, default (no icon), see the warning-model-dialog.html
                icon = icon || 'default';
                // Available: ppm-modal-dialog-default, ppm-modal-dialog-warning, ppm-modal-dialog-error, ppm-modal-dialog-question
                dialogType = dialogType || 'ppm-modal-dialog-default';
                contentTplUrl = contentTplUrl || 'views/product-plan-management/template/dialog/modal-dialog-content-default.html';

                var dlgUrl = 'views/product-plan-management/template/dialog/warning-modal-dialog.html';
                var controller = 'WarningModalDialogCtrl';

                var data = {
                    Message: function() {
                        return message;
                    },
                    Title: function() {
                        return title;
                    },
                    Icon: function() {
                        return icon;
                    },
                    DialogType: function() {
                        return dialogType;
                    },
                    ContentTplUrl: function() {
                        return contentTplUrl;
                    }
                };

                var optionsSetting = {
                    size: 'md'
                };
                optionsSetting = angular.extend(optionsSetting, options);

                var modalInstance = dialogFactorySvc.openModalDialog(dlgUrl, controller, data, optionsSetting);

                return modalInstance;
            }

        };

        // Private Part


        return queryDialog;

    });