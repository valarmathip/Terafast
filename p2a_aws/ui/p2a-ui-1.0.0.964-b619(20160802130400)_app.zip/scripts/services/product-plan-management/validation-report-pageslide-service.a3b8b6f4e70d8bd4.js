'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.ValidationReportPageslideSvc
 * @description
 * # ValidationReportPageslideSvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('ValidationReportPageslideSvc', function($compile, $rootScope, $log) {
        var service = {
            // return promise
            openPageslide: function(position, validationResult, contextScope) {
                var str = '<div id="validation-report-pageslide-ppm" ng-controller="ValidationReportPageslideCtrl"></div>';

                var manualScope;
                if (arguments.length === 3) {
                    manualScope = contextScope.$new(); // in this case, manual scope will be destroyed when context scope is destroyed
                } else if (arguments.length === 2) {
                    manualScope = $rootScope.$new();
                    $log.warn('We suggest you provide the contextScope as the third parameter, so that when context scope is destroy the pageslide will also be closed');
                } else {
                    throw (new Error('Usage: openPageslide(position, validationResult, contextScope)'));
                }

                var manualElement = $compile(str)(manualScope);

                // init the pageslideScope
                var pageslideScope = manualElement.scope();
                pageslideScope.vResult = validationResult;
                pageslideScope.position = position;
                pageslideScope.initFileName();
                pageslideScope.manualElement = manualElement; // keep for remove
                pageslideScope.manualScope = manualScope; // keep for destroy

                return pageslideScope.open();
            },

            openHistoryPageslide: function(position, data, contextScope) {
                var str = '<div id="validation-history-pageslide-ppm" ng-controller="ValidationHistoryPageslideCtrl"></div>';

                var manualScope;
                if (arguments.length === 3) {
                    manualScope = contextScope.$new(); // in this case, manual scope will be destroyed when context scope is destroyed
                } else if (arguments.length === 2) {
                    manualScope = $rootScope.$new();
                    $log.warn('We suggest you provide the contextScope as the third parameter, so that when context scope is destroy the pageslide will also be closed');
                } else {
                    throw (new Error('Usage: openPageslide(position, data, contextScope)'));
                }

                var manualElement = $compile(str)(manualScope);

                // init the pageslideScope
                var pageslideScope = manualElement.scope();
                pageslideScope.vResult = data.validationHistory;
                pageslideScope.position = position;
                pageslideScope.initFileName(data.planName);
                pageslideScope.manualElement = manualElement; // keep for remove
                pageslideScope.manualScope = manualScope; // keep for destroy

                return pageslideScope.open();
            }
        };

        return service;
    });