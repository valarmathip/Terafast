'use strict';

angular.module('p2AdvanceApp')
    .factory('PpmPlanSummaryDialogSvc', function(ProductPlanMgmtSvc, dialogFactorySvc) {


        var ppmPlanSummaryDialogSvc = {
            showPlanSummaryDialog: showPlanSummaryDialog
        };

        function showPlanSummaryDialog(planId) {
            var dlgUrl = 'views/product-plan-management/plan-summary.html';
            var controller = 'PlanSummaryDialogCtrl';
            var data = {
                planDetails: function() {
                    return ProductPlanMgmtSvc.getPlanDetails(planId, 2).then(function(data) {
                        return data;
                    });
                },
                planDetailFieldsMetaData: function() {
                    return ProductPlanMgmtSvc.getPlanDetailFieldMetaInfo().then(function(data) {
                        return data;
                    });
                },
                planServiceFieldsMetaData: function() {
                    return ProductPlanMgmtSvc.getCostShareFieldMetaInfo().then(function(data) {
                        return data;
                    });
                }
            };
            var options = {
                size: 'lg'
            };
            dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
        }


        return ppmPlanSummaryDialogSvc;

    });