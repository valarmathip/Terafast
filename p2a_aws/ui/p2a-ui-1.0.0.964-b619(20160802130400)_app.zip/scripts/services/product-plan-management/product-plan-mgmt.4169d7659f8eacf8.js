'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.ProductPlanMgmtSvc
 * @description
 * # ProductPlanMgmtSvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('ProductPlanMgmtSvc', function($http, $q, PPMENV, ConfirmationModalFactory, ENV, ppmUtils, $log) {

        return {
            getProductDetailFieldMetaInfo: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getProductDetailMetaInfoURI();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).
                success(function(data) {
                    if (data.error === false) {
                        var metaData = {};
                        metaData.productFieldsMetaData = data.productFieldsMetaData;
                        metaData.coverageTiersMapping = data.coverageTiersMapping;
                        defer.resolve(metaData);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },

            getDocumentDetailFieldMetaInfo: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getDocumentDetailMetaInfoURI();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).
                success(function(data) {
                    if (data.error === false) {
                        var metaData = {};
                        metaData.documentFieldsMetaData = data.documentFieldsMetaData;
                        defer.resolve(metaData);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },

            getProductDetails: function(objectId, associationExpansionLevel) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Getting Product Details, please wait...')
                var fieldUrl = PPMENV.getProductDetail(objectId);

                if (!!associationExpansionLevel) {
                    fieldUrl += '?associationExpansionLevel=' + encodeURI(associationExpansionLevel);
                }

                return $http({
                        method: 'GET',
                        url: fieldUrl
                    })
                    .then(function(response) {
                            var data = response.data;
                            if (!data.error) {
                                return data; // According Hasan request, now backend return data, or error.
                            } else {
                                return $q.reject(data.message);
                            }
                        },
                        function(reason) {
                            $log.log('Failed in loading product detail' + reason);
                            return $q.reject(reason);
                        })['finally'](function() { // this is exact is .finally();
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    });
            },

            getProductList: function(filterQuery) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getProductList() + filterQuery;
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of products, please wait...')
                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getServiceDefinition: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getServiceDefinition();

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (data.error === false) {
                            defer.resolve(data.attributes);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getServiceDefinitionFieldMetaInfo: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getServiceDefinitionMetaInfoURI();

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (data.error === false) {
                            var metaData = {};
                            metaData.fieldsMetaData = data.fieldsMetaData;
                            metaData.optionsMetaData = data.optionsMetaData;
                            defer.resolve(metaData);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            createProduct: function(postData) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getCreateProduct();

                $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: JSON.stringify(postData)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;

            },

            updateProduct: function(patchData, objectId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getCreateProduct() + '/' + objectId;

                $http({
                        method: 'PATCH',
                        url: fieldUrl,
                        data: JSON.stringify(patchData)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;

            },

            createService: function(postData) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getCreateService();

                $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: JSON.stringify(postData)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;

            },

            getPlanDetailFieldMetaInfo: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getPlanDetailMetaInfoURI();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).
                success(function(data) {
                    if (data.error === false) {
                        var metaData = {};
                        metaData.productFieldsMetaData = data.productFieldsMetaData;
                        metaData.planFieldsMetaData = data.planFieldsMetaData;
                        metaData.coverageTiersMapping = data.coverageTiersMapping;
                        defer.resolve(metaData);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },

            createPlanFromProduct: function(postData, productId) {
                return $http({
                    method: 'POST',
                    url: PPMENV.getCreatePlan() + '/fromProduct/' + productId,
                    data: JSON.stringify(postData)
                }).then(function(response) {
                    return response.data; // we only care about the data
                });
            },

            createPlanFromPlan: function(postData, planId) {
                return $http({
                    method: 'POST',
                    url: PPMENV.getCreatePlan() + '/' + planId + '/copy',
                    data: JSON.stringify(postData)
                }).then(function(response) {
                    return response.data; // we only care about the data
                });
            },


            updatePlan: function(patchData, objectId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getCreatePlan() + '/' + objectId;

                $http({
                        method: 'PATCH',
                        url: fieldUrl,
                        data: JSON.stringify(patchData)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getPlanList: function(filterQuery) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getPlanList() + filterQuery;
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of plans, please wait...')
                $http({
                    method: 'GET',
                    url: fieldUrl
                }).success(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    //if (!data.error) { // According Hasan request, now backend return data, or error.
                    defer.resolve(data);
                    //} else {
                    //defer.reject(data.message);
                    //}
                }).error(function(reason) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(reason);
                });
                return defer.promise;
            },

            getPlanListFilterMeta: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getPlanListFilterMeta();

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getPlans: function() {
                var defer = $q.defer();
                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/cm/types/plan';

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            /**
             * @ngdoc method
             * @name getOfferings
             * @methodOf p2AdvanceApp.ProductPlanMgmtSvc
             * @description
             * Get the JSON schema for offerings
             *
             * @param {string} Gateway url
             * @returns {Array} JSON schema for offerings
             */
            getOfferings: function() {
                var defer = $q.defer();
                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/cm/types/offering';

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) {
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },
            getAspectDefinitions: function() {
                var defer = $q.defer();
                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/cm/types/aspectDefinitions';

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getDocumentFilterMeta: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getDocumentFilterMeta();
                $http({
                    method: 'GET',
                    url: fieldUrl
                }).success(function(data) {
                    if (!data.error) { // According Hasan request, now backend return data, or error.
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });
                return defer.promise;
            },

            getPlanDetails: function(objectId, associationExpansionLevel) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Getting Plan Details, please wait...')
                var defer = $q.defer();
                var fieldUrl = PPMENV.getPlanDetail(objectId);

                if (!!associationExpansionLevel) {
                    fieldUrl += '?associationExpansionLevel=' + encodeURI(associationExpansionLevel);
                }

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.resolve(data); // According Hasan request, now backend return data, or error.
                        } else {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                        $log.log('Failed in loading plan details');
                        defer.reject(reason);
                    });
                return defer.promise;
            },

            getPlanViaCm: function(planId, associationExpansionLevel, properties) { // http://10.22.136.10:8080/cm/plans/297d907c-2315-4f6f-9ad6-e9b250f5b13f?associationExpansionLevel=1&properties=linkedPlanServices, planServiceId, planId
                var url = PPMENV.getCmPlanUrl();
                url += '/' + planId;

                if (angular.isUndefined(associationExpansionLevel) || associationExpansionLevel === null) {
                    associationExpansionLevel = 0; // default value
                }
                url += '?associationExpansionLevel=' + associationExpansionLevel;

                if (properties && properties.length > 0) {
                    url += '&properties=' + encodeURI(properties.toString());
                }

                return $http({
                    method: 'GET',
                    url: url
                }).then(function(response) {
                    return response.data;
                });

            },

            getEntityViaCm: function(objectId, objectType, associationExpansionLevel, properties) {
                var url = PPMENV.getCmEntityUrl(objectType);
                url += '/' + objectId;

                if (angular.isUndefined(associationExpansionLevel) || associationExpansionLevel === null) {
                    associationExpansionLevel = 0; // default value
                }
                url += '?associationExpansionLevel=' + associationExpansionLevel;

                if (properties && properties.length > 0) {
                    url += '&properties=' + encodeURI(properties.toString());
                }

                return $http({
                    method: 'GET',
                    url: url
                }).then(function(response) {
                    return response.data;
                });
            },

            getEntityViaPpm: function(objectId, objectType, associationExpansionLevel, properties) {
                var url = PPMENV.getPpmEntityUrl(objectType);
                url += '/' + objectId;

                if (angular.isUndefined(associationExpansionLevel) || associationExpansionLevel === null) {
                    associationExpansionLevel = 0; // default value
                }
                url += '?associationExpansionLevel=' + associationExpansionLevel;

                if (properties && properties.length > 0) {
                    url += '&properties=' + encodeURI(properties.toString());
                }

                return $http({
                    method: 'GET',
                    url: url
                }).then(function(response) {
                    return response.data;
                });
            },

            getServiceList: function(productId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getServiceList(productId);

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getPlanAssociatedServices: function(planId) {
                var url = PPMENV.getPlanDetail(planId) + '/services';

                return $http({
                        method: 'GET',
                        url: url
                    })
                    .then(function(response) {
                        return response.data;
                    });
            },

            getServiceById: function(serviceId) {
                var serviceUrl = PPMENV.getCreateService(); // this is exactly get service url
                serviceUrl += '/' + encodeURI(serviceId);

                return $http({
                        method: 'GET',
                        url: serviceUrl
                    })
                    .then(function(response) {
                        return response.data;
                    });
            },

            getAdditionalServiceList: function(filterQuery) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getAdditionalServiceList() + filterQuery;
                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });
                return defer.promise;
            },

            getServiceListFilterMeta: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getServiceListFilterMeta();

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            getServiceAddNewListFilterMeta: function() {
                var defer = $q.defer();
                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/cm/types/service';
                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            // Seems this function is not used by any one(June 1, 2016)
            associatePlanService: function(planServices, planId) {
                var defer = $q.defer();
                var url = PPMENV.getPlanServiceUrl(planId);

                $http({
                        method: 'POST',
                        url: url,
                        data: JSON.stringify(planServices)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            updatePlanService: function(planService, planServiceId, planId) {
                var defer = $q.defer();
                var url = PPMENV.getPlanServiceUrl(planId);

                if (planServiceId) {
                    url += '/' + encodeURI(planServiceId);
                }

                $http({
                        method: 'PATCH',
                        url: url,
                        data: JSON.stringify(planService)
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            updateProductService: function(productId, productService, productServiceId) {
                var defer = $q.defer();
                var url = PPMENV.getProductServiceUrl(productId);

                if (productServiceId) {
                    url += '/' + encodeURI(productServiceId);
                }

                $http({
                        method: 'PATCH',
                        url: url,
                        data: JSON.stringify(productService)
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            // This not work: http://10.22.136.10:8080/cm/planservices/eca7c160-5ea0-49e7-8ea6-b8b08da54e00/?associationExpansionLevel=1&properties=planserviceCostShares, costShareLevel, costShareType, providerTier
            // http://10.22.136.10:8080/plans/<planId>/planservices/eca7c160-5ea0-49e7-8ea6-b8b08da54e00/?associationExpansionLevel=1&properties=planserviceCostShares, costShareLevel, costShareType, providerTier
            getPlanService: function(planId, planServiceId, associationExpansionLevel, properties) {
                var url = PPMENV.getPlanServiceUrl(planId);
                url += '/' + planServiceId;

                if (angular.isUndefined(associationExpansionLevel) || associationExpansionLevel === null) {
                    associationExpansionLevel = 0; // default value
                }
                url += '?associationExpansionLevel=' + associationExpansionLevel;

                if (properties && properties.length > 0) {
                    $log.error('The retrieve by properties is not support in PPM, and following properties will be ignored by backend');
                    $log.error(angular.toJson(properties, true));
                    url += '&properties=' + encodeURI(properties.toString());
                }

                return $http({
                    method: 'GET',
                    url: url
                }).then(function(response) {
                    return response.data;
                });
            },

            getProductServices: function(productId, productServiceId, associationExpansionLevel, properties) {
                var url = PPMENV.getProductServiceUrl(productId);
                url += '/' + productServiceId;

                if (angular.isUndefined(associationExpansionLevel) || associationExpansionLevel === null) {
                    associationExpansionLevel = 0; // default value
                }
                url += '?associationExpansionLevel=' + associationExpansionLevel;

                if (properties && properties.length > 0) {
                    $log.error('The retrieve by properties is not support in PPM, and following properties will be ignored by backend');
                    $log.error(angular.toJson(properties, true));
                    url += '&properties=' + encodeURI(properties.toString());
                }

                return $http({
                    method: 'GET',
                    url: url
                }).then(function(response) {
                    return response.data;
                });
            },

            // SLQ function getProductServiceViaCm are exactly the same as function getProductServices, so remove it.
            // getProductServiceViaCm: function(productServiceId, associationExpansionLevel, properties) {
            //     var url = PPMENV.getProductServiceUrl();
            //     url += '/' + productServiceId;

            //     if (angular.isUndefined(associationExpansionLevel) || associationExpansionLevel === null) {
            //         associationExpansionLevel = 0; // default value
            //     }
            //     url += '?associationExpansionLevel=' + associationExpansionLevel;

            //     if (properties && properties.length > 0) {
            //         url += '&properties=' + encodeURI(properties.toString());
            //     }

            //     return $http({
            //         method: 'GET',
            //         url: url
            //     }).then(function(response) {
            //         return response.data;
            //     });

            // },

            getPpmVersion: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getPpmVersionUrl();

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) {
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            uiBuildInfo: function() {
                var url = PPMENV.getHost() + PPMENV.getPort() + '/app/p2aui_build_number.txt';

                var config = {
                    method: 'GET',
                    url: url
                };

                return $http(config).then(function(data) {
                        if (data.data && data.data.indexOf('p2a-ui') === 0) {
                            return data.data;
                        } else {
                            return 'No UI build Info';
                        }
                    },
                    function( /*reason*/ ) {
                        return 'No UI build Info';
                    });
            },

            validatePlan: function(planId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getPpmPlanValidateUrl();
                var cmScriptFileCount = 4;
                if (planId) {
                    fieldUrl += '/' + encodeURI(planId);
                }

                var config = {
                    method: 'GET',
                    url: fieldUrl
                };

                $http.get(PPMENV.getCmUrl() + '/scripts').success(function(data) {
                    if (data !== null && data !== '' && data.length === cmScriptFileCount) {
                        $http(config).success(function(data) {
                                /*Data structure:
                                {
                                   'plan': {simple plan object},
                                   'errors': ['Error: Plan Year is not between the range'],
                                   'warnings': [],
                                }*/
                                if (!data.error) {
                                    defer.resolve(data);
                                } else {
                                    defer.reject(data.message);
                                }
                            })
                            .error(function(reason) {
                                //ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                                defer.reject(reason);
                            });
                    } else {
                        var msgtitle = 'Unable to Validate the Plan';
                        var msg = 'Your plan cannot be validated until your organization\'s validation rules are compiled.The validation rules must be compiled because they are new or obsolete.';
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                        defer.reject();
                    }

                }).error(function(data) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(data);
                });

                return defer.promise;
            },
            subGridToggle: function(data, row) {
                var previous = [];
                angular.forEach(data.grid.rows, function(item) {
                    if (item.isExpanded) {
                        previous.push({
                            'ObjectId': item.entity.objectId
                        });
                    }
                });
                data.expandable.collapseAllRows();
                angular.forEach(previous, function(item) {
                    angular.forEach(data.grid.rows, function(rows) {
                        if (item.ObjectId === rows.entity.objectId) {
                            data.expandable.toggleRowExpansion(rows.entity);
                        }
                    });
                });
                data.expandable.toggleRowExpansion(row.entity);
                return data;
            },
            getCostShareFieldMetaInfo: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getCostShareMetaInfoURI();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).
                success(function(data) {
                    if (!data.error) {
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },
            getProductCostShareFieldMetaInfo: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getProductCostShareMetaInfoURI();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).
                success(function(data) {
                    if (!data.error) {
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },
            getValidationHistory: function(planId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getValidationHistoryURI(planId);

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) {
                            defer.resolve(data.response.docs);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },
            sendAuditLog: function(record) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getAuditLogURI();

                $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: JSON.stringify(record)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            lockEntity: function(objectId, objectType) {
                var fieldUrl = PPMENV.getLockURI(objectType) + '/' + objectId;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            unlockEntity: function(objectId, objectType) {
                var fieldUrl = PPMENV.getUnlockURI(objectType) + '/' + objectId;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            lockPlan: function(planId) {
                var fieldUrl = PPMENV.getLockPlanURI() + '/' + planId;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            unlockPlan: function(planId) {
                var fieldUrl = PPMENV.getUnlockPlanURI() + '/' + planId;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            lockProduct: function(productId) {
                var fieldUrl = PPMENV.getLockProductURI() + '/' + productId;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            unlockProduct: function(productId) {
                var fieldUrl = PPMENV.getUnlockProductURI() + '/' + productId;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            createProductFromProduct: function(productId) {
                return $http({
                    method: 'POST',
                    url: PPMENV.getCreateProduct() + '/' + productId + '/copy'
                }).then(function(response) {
                    return response.data;
                });
            },
            getReportTemplates: function() {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getCmReportTemplatesUrl();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).success(function(data) {
                    if (!data.error) {
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },
            getReportPlanDetails: function(selectedPlans, selectedTemplates, timezone) {

                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/reports/generate?planIds=' + selectedPlans + '&reportTemplateId=' + selectedTemplates + '&timeZone=' + timezone;

                return $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: ''
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });

            },
            /*getReportPlanDetails: function(selectedPlans, selectedTemplates) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getReportsMockData();

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).success(function(data) {
                    if (!data.error) {
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },*/
            exportExcel: function(selectedPlans, selectedTemplates) {
                var defer = $q.defer();
                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/reports/exportExcel?planIds=' + selectedPlans + '&reportTemplateId=' + selectedTemplates;

                $http({
                    method: 'GET',
                    url: fieldUrl
                }).success(function(data) {
                    if (!data.error) {
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                }).error(function(reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },
            getOverrideData: function() {
                var fieldUrl = PPMENV.getWorkflowParameter();

                return $http({
                    method: 'GET',
                    url: fieldUrl
                });
            },
            getProductListFilterMeta: function() {
                var defer = $q.defer();
                var fieldUrl = ENV.apiGatewayEndpoint + '/gateway/cm/types/product';

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) { // According Hasan request, now backend return data, or error.
                            defer.resolve(data);
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },
            sendOverrideRequest: function(postData) {
                var fieldUrl = PPMENV.getRequestOverrideURI();
                return $http({
                    method: 'POST',
                    url: fieldUrl,
                    data: JSON.stringify(postData),
                    skipInterceptorError: true
                });
            },
            getPlanComparisonReportDetails: function(planIdJson) {

                return $http({
                        method: 'POST',
                        url: ENV.apiGatewayEndpoint + '/gateway/reports/planComparison',
                        data: planIdJson
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            getOfferintListViaSearchApi: function(searchQuery, associationExpansionLevel) {
                var fieldUrl = PPMENV.getPpmSearchUrl();

                if (!searchQuery) {
                    searchQuery = ppmUtils.paramSerializer({
                        q: 'TYPE:"offering"',
                        start: 0,
                        rows: 20,
                        sort: 'lastModificationDate desc'
                    });
                }
                // We add properties to narrow the data we fetched from back end
                if (searchQuery.indexOf('properties') === -1) {
                    searchQuery += '&' + ppmUtils.paramSerializer({
                        properties: 'name, effectiveDate, endDate, lastModificationDate, benefitYear, lockedAt, lockedBy, isLocked'
                    });
                }

                fieldUrl = ppmUtils.buildUrl(fieldUrl, searchQuery);

                if (fieldUrl.indexOf('associationExpansionLevel') === -1) {
                    fieldUrl += '&' + ppmUtils.paramSerializer({
                        associationExpansionLevel: associationExpansionLevel ? associationExpansionLevel : 0
                    });
                }

                return $http({
                        method: 'GET',
                        url: fieldUrl
                    })
                    .then(function(response) {
                        return response.data;
                    });
            },
            createOfferingFromOffering: function(postData, offeringId) {
                // return $q.when(); // wait for backend done
                return $http({
                    method: 'POST',
                    url: PPMENV.getOfferingURI() + '/' + offeringId + '/copy',
                    data: JSON.stringify(postData)
                }).then(function(response) {
                    return response.data; // we only care about the data
                });
            },
            getOfferingDetailFieldMetaInfo: function() {
                var fieldUrl = PPMENV.getOfferingDetailFieldMetaInfoURI();

                return $http({
                        method: 'GET',
                        url: fieldUrl
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            },
            createOffering: function(patchData) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getOfferingURI();

                $http({
                        method: 'POST',
                        url: fieldUrl,
                        data: JSON.stringify(patchData)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },
            updateOffering: function(patchData, objectId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getOfferingURI() + '/' + objectId;

                $http({
                        method: 'PATCH',
                        url: fieldUrl,
                        data: JSON.stringify(patchData)
                    }).success(function(data) {
                        defer.resolve(data);
                    })
                    .error(function(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },
            getOfferingDetails: function(objectId) {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getOfferingURI() + '/' + objectId;

                $http({
                        method: 'GET',
                        url: fieldUrl
                    }).success(function(data) {
                        if (!data.error) {
                            defer.resolve(data); // According Hasan request, now backend return data, or error.
                        } else {
                            defer.reject(data.message);
                        }
                    })
                    .error(function(reason) {
                        $log.log('Failed in loading offering details');
                        defer.reject(reason);
                    });
                return defer.promise;
            },
            getProductViaCm: function(productId, associationExpansionLevel, properties) { // http://10.22.136.10:8080/cm/plans/297d907c-2315-4f6f-9ad6-e9b250f5b13f?associationExpansionLevel=1&properties=linkedPlanServices, planServiceId, planId
                var url = PPMENV.getCmProductUrl();
                url += '/' + productId;
                url += '?associationExpansionLevel=' + associationExpansionLevel;
                if (properties && properties.length > 0) {
                    url += '&properties=' + encodeURI(properties.toString());
                }
                return $http({
                    method: 'GET',
                    url: url
                }).then(function(response) {
                    return response.data;
                });
            },
            getProductAssociatedServices: function(productId) {
                var url = PPMENV.getProductDetail(productId) + '/services';
                return $http({
                        method: 'GET',
                        url: url
                    })
                    .then(function(response) {
                        return response.data;
                    });
            },
            getPlanVersionHistory: function(planId) { /* jshint ignore:line */
                var fieldUrl = PPMENV.getPlanVersionHistoryURI(); // + '/' + planId + '/versions';
                return $http({
                        method: 'GET',
                        url: fieldUrl
                    })
                    .then(function(response) {
                        return response.data;
                    }, function(reason) {
                        return $q.reject(reason.data);
                    });
            }
        };
    });
