'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.PlanVersioningPageslideSvc
 * @description
 * # PlanVersioningPageslideSvc
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .service('PlanVersioningPageslideSvc', function($compile, $rootScope, $log) {
        var service = {
            // return promise
            openPageslide: function(position, planVersioningHistoryResult, contextScope) {
                var str = '<div id="plan-versioning-pageslide-ppm" ng-controller="PlanVersioningHistoryPageslideCtrl"></div>';
                var manualScope;
                if (arguments.length === 3) {
                    manualScope = contextScope.$new(); // in this case, manual scope will be destroyed when context scope is destroyed
                } else if (arguments.length === 2) {
                    manualScope = $rootScope.$new();
                    $log.warn('We suggest you provide the contextScope as the third parameter, so that when context scope is destroy the pageslide will also be closed');
                } else {
                    throw (new Error('Usage: openPageslide(position, planVersioningHistoryResult, contextScope)'));
                }

                var manualElement = $compile(str)(manualScope);

                // init the pageslideScope
                var pageslideScope = manualElement.scope();
                pageslideScope.vResult = planVersioningHistoryResult;
                pageslideScope.position = position;
                pageslideScope.manualElement = manualElement; // keep for remove
                pageslideScope.manualScope = manualScope; // keep for destroy

                return pageslideScope.open();
            }
        };

        return service;
    });