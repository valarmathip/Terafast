'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.ValidationReportAsideSvc
 * @description
 * # ValidationReportAsideSvc
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('ValidationReportAsideSvc', function($aside, $timeout, $q, $log) {
        var service = {
            openAside: function(position, validationResult) {
                return doOpen(position, validationResult);
            }
        };

        var asideState = {
            open: false
        };

        function doOpen(position, validationResult) {
            if (!position) {
                position = 'right';
            }

            if (!validationResult) {
                validationResult = asideState.result ? asideState.result : null;
            }

            asideState = {
                open: true,
                position: position,
                result: validationResult
            };

            var result = $aside.open({
                templateUrl: 'views/product-plan-management/validation-report.html',
                placement: position,
                size: 'md',
                backdrop: false,
                controller: 'ValidationReportCtrl',
                resolve: {
                    position: function() {
                        return position;
                    },
                    validationResult: function() {
                        return validationResult;
                    }
                }
            }).result.then(success, failed);

            return result;
        }

        function success(data) {
            postClose(data);

            return data;
        }

        function failed(reason) {
            postClose(reason);

            return $q.reject(reason);
        }

        function postClose(msg) {
            asideState.open = false;
            if (msg && msg !== 'cancel') {
                $timeout(function() {
                    $log.log('Open aside on ' + msg);
                    doOpen(msg);
                });
            } else {
                asideState.result = null;
            }
        }

        return service;

    });