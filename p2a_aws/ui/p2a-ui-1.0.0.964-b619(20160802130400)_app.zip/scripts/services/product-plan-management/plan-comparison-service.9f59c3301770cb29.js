'use strict';

angular.module('p2AdvanceApp')
    .factory('PlanComparisonService', function() {

        function PlanComparisonService() {
            var self = this;
            self.constructPlanComparisonJson = function(basePlanJson, plansToCompare, selectedTemplate) {
                var planIds = [];
                var basePlanId = basePlanJson.objectId;
                angular.forEach(plansToCompare, function(item) {
                    if (item.objectId !== basePlanJson.objectId) {
                        planIds.push(item.objectId);
                    }
                });
                var planIdJson = {};
                planIdJson['planIds'] = planIds;
                planIdJson['reportTemplateId'] = selectedTemplate;
                planIdJson['basePlanId'] = basePlanId;
                planIdJson['timeZone'] = this.getTimeZone();
                return planIdJson;
            };

            self.getServicePropObj = function(servicePropObj, value) {
                angular.forEach(value, function(serviceProp) {
                    if (typeof serviceProp === 'object' && Object.keys(serviceProp).length) {
                        servicePropObj = angular.copy(serviceProp);
                    }
                });
                return servicePropObj;
            };

            self.getTimeZone = function() {
                var date = new Date().toString().match(/([A-Z]+[\+-][0-9]+)/)[1];
                return encodeURIComponent(date);
            };


        }
        return new PlanComparisonService();
    });