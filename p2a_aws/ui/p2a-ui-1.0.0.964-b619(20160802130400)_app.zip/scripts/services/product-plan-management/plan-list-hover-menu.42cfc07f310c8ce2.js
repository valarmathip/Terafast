'use strict';

/**
    Event: 
        ppm.plan.list.hover.menu.lock.status.changed: the event is *emit* when the plan locked status changed
        ppm.plan.list.hover.menu.plan.status.changed: the event is *emit* when the plan status changed

 */
angular.module('p2AdvanceApp')
    .factory('PlanListHoverMenuSvc', function($state, $auth, PlanLockSvc, ProductPlanMgmtSvc, userAuthorizationManager,
        ConfirmationModalFactory, ENV, QueryDialog, $log) {

        var planListHoverMenuSvc = {
            getHoverMenu: function(scope) {
                return hoverMenu.bind(scope)();
            }
        };

        function hoverMenu() {
            /*jshint validthis:true*/
            var contextScope = this;

            function hasUpdatePermissionOnThisPlan(row) {
                var planType = row.planType;

                var itemShow = userAuthorizationManager.hasPermission('all.update'); // super user
                itemShow = itemShow || userAuthorizationManager.hasPermission('plan.update'); // has all plan update permissions
                if (!itemShow) {
                    if (planType.toLowerCase() === 'custom') {
                        itemShow = userAuthorizationManager.hasPermission('plan.update.custom');
                    } else if (planType.toLowerCase() === 'standard') {
                        itemShow = userAuthorizationManager.hasPermission('plan.update.standard'); // plan.update.standard is not show in role, but is defined and could be a option in the future (backend requested)
                    }
                }

                itemShow = itemShow && (!row.isLocked || isLockedByMe(row));

                return itemShow;
            }

            function hasUpdateStatusPermission() {
                var itemShow = userAuthorizationManager.hasPermission('all.update'); // super user
                itemShow = itemShow || userAuthorizationManager.hasPermission('plan.update.status'); // has plan status update permissions

                return itemShow;
            }

            function isLockedByMe(row) {
                var meId = $auth.getUserEmail();
                return row.lockedBy.toLowerCase() === meId.toLowerCase(); // seems not case sensitive
            }

            // Since the lock status is a aspect, and if at last this judgement is not related to plan and product, we can move this into a service.
            function hasLockPermission(row) {
                var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.lock', row);
                // HRSuperAdmin has the all.create permisison
                hasPerm = hasPerm || userAuthorizationManager.hasPermissionWithCriteria('all.create', row);

                return hasPerm;
            }

            function hasUnlockPermission(row) {
                // This just test if 'ME' can unlock the current plan
                var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.unlock.me', row);
                hasPerm = hasPerm || hasUnlockOthersPermission(row);

                return hasPerm;
            }

            function hasUnlockOthersPermission(row) {
                // NOTE: Current only the 'OrganizationAdmin' role has this permission, so we use this
                // permission to determine if user is organization admin user
                var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.unlock', row); // do not to check criteria
                // HRSuperAdmin has the all.create permisison
                hasPerm = hasPerm || userAuthorizationManager.hasPermissionWithCriteria('all.create', row); // do not to check criteria

                return hasPerm;
            }

            function isLockShown(row) {
                var itemShow = !row.isLocked;
                itemShow = itemShow && hasLockPermission(row);

                return itemShow;
            }

            function isUnlockShown(row) {
                var itemShow = row.isLocked;
                itemShow = itemShow && hasUnlockPermission(row);

                return itemShow;
            }

            function notifyLockStatusChanged(lockStatus, planId) {
                contextScope.$emit('ppm.plan.list.hover.menu.lock.status.changed', lockStatus, planId);
            }

            function editPlan(guid) {
                $log.log('Edit plan guid = ' + guid);
                $state.go('home.ppm.plan.edit.plan-details', {
                    planId: guid
                });
            }

            function copyPlan(planId, planType) {
                $log.log('copy plan guid = ' + planId);

                var customPlanData = {};
                if (planType.toLowerCase() === 'custom') {
                    customPlanData.planType = 'Custom';
                } else if (planType.toLowerCase() === 'standard') {
                    customPlanData.planType = 'Standard';
                }

                ProductPlanMgmtSvc.createPlanFromPlan(customPlanData, planId)
                    .then(function(newPlanId) {
                        $log.log('Edit plan planId = ' + newPlanId);
                        $state.go('home.ppm.plan.edit.plan-details', {
                            planId: newPlanId
                        });
                    });
            }

            function setPlanApproved(plan) {
                // $log.log('Approve plan guid = ' + plan.objectId);
                setPlanStatus(plan, 'Approved');
            }

            function setPlanDraft(plan) {
                // $log.log('Draft plan guid = ' + plan.objectId);
                setPlanStatus(plan, 'Draft');
            }

            function setPlanStatus(plan, status) {
                var patchData = {
                    'planStatus': status // "Approved"
                };
                ProductPlanMgmtSvc.updatePlan(patchData, plan.objectId)
                    .then(function() {
                        var msgtitle = 'Success';
                        var msg = 'Update Plan Status to ' + status + ' Success.<br/>Plan name: ' + plan.name;
                        // $log.log(msgtitle + ' --> ' + msg);
                        // Notify plan list scope to update it 
                        contextScope.$emit('ppm.plan.list.hover.menu.plan.status.changed', plan.objectId, status);
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }, function() {
                        var msg = 'Update Plan Status to ' + status + ' Failed.<br/>Plan name: ' + plan.name;
                        // $log.log('Failed --> ' + msg);
                        QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
                    });
            }

            function canChangeStatus(currentStatus, menuItemLabel) {
                return (!currentStatus && menuItemLabel === 'Draft') || // if status is not set, can only set to draft.
                    ((currentStatus === 'Approved' || currentStatus === 'Draft' || currentStatus === 'Validation Failed') && (currentStatus !== menuItemLabel));
            }

            function generatePlanDocuments(planId) {
                $state.go('home.media-management.generateDocument', {
                    businessEntity: 'plan',
                    dataSourceId: planId
                });
            }

            var hoverItems = [{ // index: 0
                label: 'Edit Plan',
                icon: 'fa-pencil',
                isShown: function(row) {
                    return hasUpdatePermissionOnThisPlan(row);
                },
                action: function(row) {
                    editPlan(row.objectId);
                }
            }, { // index: 1
                label: 'Set Plan Approved',
                icon: 'fa-check-square-o',
                isShown: function(row) {
                    return hasUpdateStatusPermission(row) && !row.isLocked && canChangeStatus(row.planStatus, 'Approved');
                },
                action: function(row) {
                    setPlanApproved(row);
                }
            }, { // index: 2
                label: 'Set Plan Draft',
                icon: 'fa-pencil-square-o',
                isShown: function(row) {
                    return hasUpdateStatusPermission(row) && !row.isLocked && canChangeStatus(row.planStatus, 'Draft');
                },
                action: function(row) {
                    setPlanDraft(row);
                }
            }, { // index: 3
                label: 'Generate Plan Documents',
                icon: 'fa-files-o',
                isShown: function() {
                    return true;
                },
                action: function(row) {
                    generatePlanDocuments(row.objectId);
                },
                permission: '|all.create,|document.create'
            }, { // index: 4
                label: 'Create Standard Plan From This Plan',
                icon: 'fa-share-square-o',
                isShown: function() {
                    return true; // note permission will override this one, maybe because it is after isShown be called
                },
                action: function(row) {
                    copyPlan(row.objectId, 'standard');
                },
                permission: '|all.create,|plan.create,|plan.create.standard' // plan.create.standard is not show in role, but is defined and could be a option in the future (backend requested)
            }, { // index: 5
                label: 'Create Custom Plan From This Plan',
                icon: 'fa-share-square-o',
                isShown: function() {
                    return true;
                },
                action: function(row) {
                    copyPlan(row.objectId, 'custom');
                },
                permission: '|all.create,|plan.create,|plan.create.custom'
            }, { // index: 6
                label: 'Lock this Plan',
                icon: 'fa-lock',
                isShown: function(row) {
                    return isLockShown(row);
                },
                action: function(row) {
                    $log.log('lock it');
                    PlanLockSvc.lockPlan(row.objectId)
                        .then(function(lockStatus) {
                                // notify related plan-list to refresh lock status
                                notifyLockStatusChanged(lockStatus, row.objectId);
                            },
                            function( /*reason*/ ) {
                                // Important: This function is necessary, just used as resolve the promise, otherwise, the return status could be 401, and will cause the page reload.
                            });
                }
            }, { // index: 7
                label: 'Unlock this Plan',
                icon: 'fa-unlock',
                isShown: function(row) {
                    return isUnlockShown(row);
                },
                action: function(row) {
                    $log.log('unlock it');
                    PlanLockSvc.unlockPlan(row.objectId)
                        .then(function() {
                                // clear lock status
                                notifyLockStatusChanged(null, row.objectId);
                            },
                            function( /*reason*/ ) {
                                // Important: This function is necessary, just used as resolve the promise, otherwise, the return status could be 401, and will cause the page reload.
                            });
                }
            }];

            return hoverItems;
        }

        return planListHoverMenuSvc;
    });