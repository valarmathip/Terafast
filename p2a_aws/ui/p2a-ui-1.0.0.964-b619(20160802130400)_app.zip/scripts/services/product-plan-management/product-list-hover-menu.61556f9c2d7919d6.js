'use strict';

/**
    Event:
        ppm.product.list.hover.menu.lock.status.changed: the event is *emit* when the product locked status changed
        ppm.product.list.hover.menu.product.status.changed: the event is *emit* when the product status changed

 */
angular.module('p2AdvanceApp')
    .factory('ProductListHoverMenuSvc', function($state, $auth, PlanLockSvc, ProductPlanMgmtSvc, userAuthorizationManager,
        ConfirmationModalFactory, ENV, QueryDialog, $log, moment) {

        var productListHoverMenuSvc = {
            getHoverMenu: function(scope) {
                return hoverMenu.bind(scope)();
            }
        };

        function hoverMenu() {
            /*jshint validthis:true*/
            var contextScope = this;

            function hasUpdateStatusPermission() {
                var itemShow = userAuthorizationManager.hasPermission('all.update'); // super user
                itemShow = itemShow || userAuthorizationManager.hasPermission('product.update.status'); // has plan status update permissions.

                return itemShow;
            }

            // Since the lock status is a aspect, and if at last this judgement is not related to plan and product, we can move this into a service.
            function hasLockPermission(row) {
                var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.lock', row);
                // HRSuperAdmin has the all.create permisison
                hasPerm = hasPerm || userAuthorizationManager.hasPermissionWithCriteria('all.create', row);

                return hasPerm;
            }

            function hasUnlockPermission(row) {
                // This just test if 'ME' can unlock the current plan
                var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.unlock.me', row);
                hasPerm = hasPerm || hasUnlockOthersPermission(row);

                return hasPerm;
            }

            function hasUnlockOthersPermission(row) {
                // NOTE: Current only the 'OrganizationAdmin' role has this permission, so we use this
                // permission to determine if user is organization admin user
                var hasPerm = userAuthorizationManager.hasPermissionWithCriteria('entity.unlock', row); // do not to check criteria
                // HRSuperAdmin has the all.create permisison
                hasPerm = hasPerm || userAuthorizationManager.hasPermissionWithCriteria('all.create', row); // do not to check criteria

                return hasPerm;
            }

            function isLockShown(row) {
                var itemShow = !row.isLocked;
                itemShow = itemShow && hasLockPermission(row);

                return itemShow;
            }

            function isUnlockShown(row) {
                var itemShow = row.isLocked;
                itemShow = itemShow && hasUnlockPermission(row);

                return itemShow;
            }

            function notifyLockStatusChanged(lockStatus, productId) {
                contextScope.$emit('ppm.product.list.hover.menu.lock.status.changed', lockStatus, productId);
            }

            function editProduct(guid) {
                $log.log('Edit product guid = ' + guid);
                $state.go('home.ppm.product.edit.product-details', {
                    productId: guid
                });
            }

            function createPlanFromTheProduct(productId, planType) {

                var customPlanData = {};
                customPlanData.planDueDate = new Date();

                if (planType.toLowerCase() === 'custom') {
                    customPlanData.planType = 'Custom';
                } else if (planType.toLowerCase() === 'standard') {
                    customPlanData.planType = 'Standard';
                }

                ProductPlanMgmtSvc.createPlanFromProduct(customPlanData, productId)
                    .then(function(newPlanId) {
                        $log.log('Edit plan planId = ' + newPlanId);
                        $state.go('home.ppm.plan.edit.plan-details', {
                            planId: newPlanId
                        });
                    });
            }

            function createProductFromTheProduct(productId) {
                var associationExpLevel = -1;
                ProductPlanMgmtSvc.getProductDetails(productId, associationExpLevel).
                then(function(productDetails) {
                    var newProductDetails = productDetails;
                    var productNewName = productDetails.name + '-' + moment(new Date()).valueOf();
                    newProductDetails['name'] = productNewName;
                    newProductDetails['productStatus'] = 'Draft';
                    ProductPlanMgmtSvc.createProduct(newProductDetails).
                    then(function(newProductId) {
                        $log.log('Edit product productId = ' + newProductId);
                        $state.go('home.ppm.product.edit.product-details', {
                            productId: newProductId
                        });
                    });
                });
            }

            function setProductApproved(guid) {
                $log.log('Approve product guid = ' + guid);
                setProductStatus(guid, 'Approved');
            }

            function setProductStatus(productId, status) {
                var patchData = {
                    'productStatus': status // "Approved"
                };
                ProductPlanMgmtSvc.updateProduct(patchData, productId)
                    .then(function() {
                        var msgtitle = 'Success';
                        var msg = 'Update Product Status to ' + status + ' Success. Product id: ' + productId;
                        $log.log(msgtitle + ' --> ' + msg);
                        // Notify plan list scope to update it
                        contextScope.$emit('ppm.product.list.hover.menu.product.status.changed', productId, status);
                        ConfirmationModalFactory.open(msgtitle, msg, ENV.modalErrorTimeout);
                    }, function() {
                        var msg = 'Update Product Status to ' + status + ' Failed. Product id: ' + productId;
                        $log.log('Failed --> ' + msg);
                        QueryDialog.open('Error', msg, 'minus', 'ppm-modal-dialog-error');
                    });
            }

            function canChangeStatus(currentStatus, menuItemLabel) {
                return (!currentStatus && menuItemLabel === 'Draft') || // if status is not set, can only set to draft.
                    ((currentStatus === 'Approved' || currentStatus === 'Draft' || currentStatus === 'Validation Failed') && (currentStatus !== menuItemLabel));
            }

            function hasCreatePlanPermission(row) {
                var status = row.productStatus;
                if (status === 'Approved') {
                    return true;
                } else {
                    return false;
                }
            }

            var hoverItems = [{ // index: 0
                label: 'Edit Product',
                icon: 'fa-pencil',
                isShown: function(row) {
                    return !row.isLocked;
                },
                action: function(row) {
                    editProduct(row.objectId);
                },
                permission: '|all.create,|product.create'
            }, { // index: 1
                label: 'Set Product Approved',
                icon: 'fa-check-square-o',
                isShown: function(row) {
                    return hasUpdateStatusPermission(row) && !row.isLocked && canChangeStatus(row.productStatus, 'Approved');
                },
                action: function(row) {
                    setProductApproved(row.objectId);
                },
                permission: '|all.update,|product.update.status'
            }, { // index: 2
                label: 'Create Product From This Product',
                icon: 'fa-share-square-o',
                isShown: function() {
                    return true;
                },
                action: function(row) {
                    createProductFromTheProduct(row.objectId);
                },
                permission: '|all.create,|product.create'
            }, { // index: 3
                label: 'Create Standard Plan From This Product',
                icon: 'fa-share-square-o',
                isShown: function(row) {
                    return hasCreatePlanPermission(row) && !row.isLocked;
                },
                action: function(row) {
                    createPlanFromTheProduct(row.objectId, 'standard');
                },
                permission: '|all.create,|plan.create'
            }, { // index: 4
                label: 'Create Custom Plan From This Product',
                icon: 'fa-share-square-o',
                isShown: function(row) {
                    return hasCreatePlanPermission(row) && !row.isLocked;
                },
                action: function(row) {
                    createPlanFromTheProduct(row.objectId, 'custom');
                },
                permission: '|all.create,|plan.create.custom'
            }, { // index: 5
                label: 'Lock This Product',
                icon: 'fa-lock',
                isShown: function(row) {
                    return isLockShown(row);
                },
                action: function(row) {
                    $log.log('lock it');
                    PlanLockSvc.lockProduct(row.objectId)
                        .then(function(lockStatus) {
                                // notify related plan-list to refresh lock status
                                notifyLockStatusChanged(lockStatus, row.objectId);
                            },
                            function( /*reason*/ ) {
                                // Important: This function is necessary, just used as resolve the promise, otherwise, the return status could be 401, and will cause the page reload.
                            });
                }
            }, { // index: 6
                label: 'Unlock This Product',
                icon: 'fa-unlock',
                isShown: function(row) {
                    return isUnlockShown(row);
                },
                action: function(row) {
                    $log.log('unlock it');
                    PlanLockSvc.unlockProduct(row.objectId)
                        .then(function() {
                                // clear lock status
                                notifyLockStatusChanged(null, row.objectId);
                            },
                            function( /*reason*/ ) {
                                // Important: This function is necessary, just used as resolve the promise, otherwise, the return status could be 401, and will cause the page reload.
                            });
                }
            }];

            return hoverItems;
        }

        return productListHoverMenuSvc;
    });
