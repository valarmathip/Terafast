'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.PpmFullEqual
 * @description
 * # PpmFullEqual
 * Factory in the p2AdvanceApp.
 *
 * The new requirement need to figure out all changed property in the object (not the simply avoid saving procedure
 * that cause status changed to draft). This service will return true if the 2 objects are equal, or false, if not
 * equal. Besides, it will also return all unequal property name as its 3rd parameter.
 */
angular.module('p2AdvanceApp')
    .factory('PpmFullEqual', function($parse, $filter, ENV, $log) {
        var debug = false; // (ENV.name === 'local');
        //$log = console;


        var prefix = 'value';
        var arrayCfg = 'arrCfg';
        // var resultStr = 'isEqual';

        /**
            Provided config:
            1. sortAndCompare: sort the array and then compare them (use angularjs orderBy filter)
            2. comparator: custom define how the 2 object/primitive value equal. the is define a parent level and compare all propeties of parent.
            3. customEqual: provoid compare method

            configObj = {
                sortAndCompare: {expression: null},
                comparator: function(o1, o2){}, // all its direct children will use this to compare
                customEqual: function(o1, o2, propertyName, level){}
            }

            config: {
                'value.a.arrCfg.b.d.e.f': configObj,
                'value.a.arrCfg.*.*.*.f': configObj2,
                'value.a.arrCfg.**.f': configObj2,
            }
         */
        var defaultConfig = {};

        /**
         * Compare is performed on deep copy of provided object
         */
        function ppmFullEqual(configPara) {
            var config = angular.extend({}, defaultConfig, configPara);
            var p1, p2;
            var compareResult;

            // api
            /* jshint validthis: true */
            this.equals = function(o1, o2, comResult) {
                p1 = angular.copy(o1);
                p2 = angular.copy(o2);
                compareResult = comResult; // reference
                var result = equals.apply(this, [p1, p2, prefix, 0]);

                $log.log('----------------');
                $log.log('Nothing Changed: ' + result);
                //$log.log(angular.toJson(compareResult, true));
                printNonEqualValues(compareResult, p1, p2);
                $log.log(angular.toJson(compareResult, true));
                p1 = p2 = null;

                return result;
            };
            // the api for custom function that try to recursive call equals
            /* jshint validthis: true */
            this.internalEquals = function(o1, o2, propertyName, level) {
                equals.apply(this, [o1, o2, propertyName, level]);
            };

            this.internalUpdateResult = function(propertyName) {
                updateResult.apply(this, [propertyName]);
            };

            /*jshint maxcomplexity:50 */
            function equals(o1, o2, propertyName, level) {
                var isCustomEqual = customCompare.apply(this, [o1, o2, propertyName, level]);
                if (isCustomEqual !== undefined) { // means custom comparation found, and return result
                    return isCustomEqual;
                }

                if (o1 === o2) {
                    return true;
                }
                if (o1 === null || o2 === null) {
                    printDebugValue(level, propertyName, p1, p2, 'one or both them is null');
                    updateResult(propertyName);
                    return false;
                }
                if (o1 !== o1 && o2 !== o2) {
                    return true; // NaN === NaN
                }

                var t1 = typeof o1,
                    t2 = typeof o2,
                    length;

                if (t1 === t2) { // same type of object
                    if (t1 === 'object') {
                        if (isArray(o1)) { // array, typeof array also return "Object"
                            if (!isArray(o2)) {
                                printDebugValue(level, propertyName, p1, p2, 'second is not an Array');
                                updateResult(propertyName);
                                return false;
                            }
                            if ((length = o1.length) === o2.length) {
                                return defaultArrayEqaul.apply(this, [o1, o2, length, propertyName, level]);
                            }
                        } else if (isDate(o1)) {
                            if (!isDate(o2)) {
                                printDebugValue(level, propertyName, p1, p2, 'second is not a Date');
                                updateResult(propertyName);
                                return false;
                            }
                            return equals.apply(this, [o1.getTime(), o2.getTime(), propertyName, level + 1]);
                        } else if (isRegExp(o1)) {
                            var isRegexEqual = isRegExp(o2) ? o1.toString() === o2.toString() : false;
                            if (!isRegexEqual) {
                                updateResult(propertyName);
                            }
                            return isRegexEqual;
                        } else { // suppose to be object
                            return defaultObjectEqual.apply(this, [o1, o2, propertyName, level]);
                        } // end of object compare
                    }
                }

                printDebugValue(level, propertyName, p1, p2, 'not equal');
                updateResult(propertyName);
                return false;
            } // end of equals

            // only remember property that are not equals
            function updateResult(propertyName) {
                compareResult[propertyName] = true;
            }

            function customCompare(o1, o2, propertyName, level) {
                // use custome comparator first, if it is available
                var comparator = getParentCompartor(propertyName);
                if (comparator) {
                    var isComparatorEquals = comparator.apply(this, [o1, o2, propertyName, level]);
                    if (!isComparatorEquals) {
                        if (isLeafPropertyValue(o1) || isLeafPropertyValue(o2)) {
                            updateResult(propertyName);
                        }
                        printDebugValue(level, propertyName, p1, p2, 'not equal');
                    }
                    return isComparatorEquals;
                }

                // use the custom method to test if it available
                var preferConfig = getCustomConfig(propertyName);
                if (preferConfig) {
                    if (preferConfig.sortAndCompare) {
                        var isSortAndCompareEqual = sortAndCompareEqual.apply(this, [o1, o2, propertyName, level, preferConfig.sortAndCompare.expression]);
                        if (!isSortAndCompareEqual) {
                            printDebugValue(level, propertyName, p1, p2, 'not equal');
                        }
                        return isSortAndCompareEqual;
                    } else if (preferConfig.customEqual) {
                        var isCustomEquals = preferConfig.customEqual.apply(this, [o1, o2, propertyName, level]);
                        if (!isCustomEquals) {
                            if (isLeafPropertyValue(o1) || isLeafPropertyValue(o2)) {
                                updateResult(propertyName);
                            }
                            printDebugValue(level, propertyName, p1, p2, 'not equal');
                        }
                        return isCustomEquals;
                    }
                }
            }

            // pre-condition: two arrays length is the same length
            function defaultArrayEqaul(array1, array2, length, propertyName, level) {
                var isArrayEqual = true;
                var key;
                for (key = 0; key < length; key++) {
                    var arrEltStr = propertyName + '[' + key + ']';
                    if (!equals.apply(this, [array1[key], array2[key], arrEltStr, level + 1])) {
                        // printDebugValue(level, arrEltStr, p1, p2, 'Array element not equal (duplicated)'); 
                        isArrayEqual = false;
                        //return false;
                    }
                }
                return isArrayEqual;
                // return true;
            }

            function defaultObjectEqual(o1, o2, propertyName, level) {
                var key, keySet;
                if (isScope(o1) || isScope(o2) || isWindow(o1) || isWindow(o2) ||
                    isArray(o2) || isDate(o2) || isRegExp(o2)) {
                    updateResult(propertyName);
                    return false;
                }

                var isObjectEqual = true;
                keySet = createMap();
                for (key in o1) {
                    if (!o1.hasOwnProperty(key)) { // this is requested by jsHint. Works fine now, because all our property is direct property not inherited property
                        continue;
                    }
                    if (key.charAt(0) === '$' || isFunction(o1[key])) {
                        continue;
                    }
                    var keyStr = propertyName + '.' + key;
                    if (!equals.apply(this, [o1[key], o2[key], keyStr, level + 1])) {
                        isObjectEqual = false;
                    }
                    keySet[key] = true;
                }
                for (key in o2) {
                    if (!o2.hasOwnProperty(key)) {
                        continue;
                    }
                    if (!(key in keySet) &&
                        key.charAt(0) !== '$' &&
                        isDefined(o2[key]) &&
                        !isFunction(o2[key])) {
                        var attrName = propertyName + '.' + key;
                        printDebugValue(level, attrName, p1, p2, 'not exist in other one');
                        updateResult(attrName);
                        isObjectEqual = false;
                    }
                }
                return isObjectEqual;
            }

            function sortAndCompareEqual(array1, array2, propertyName, level, expression) {
                log('compared in sortAndCompareEqual');
                if (array1 === array2) { // include null === null
                    return true;
                }

                if (!array1 || !array2) {
                    updateResult(propertyName);
                    return false;
                }

                if (!isArray(array1) || !isArray(array2)) {
                    // throw new Error('Custom configuration is only for array comparation');
                    $log.error('Custom configuration is only for array comparation');
                    updateResult(propertyName);
                    return false;
                }

                if (array1.length !== array2.length) {
                    updateResult(propertyName);
                    return false;
                }

                if (!expression) {
                    expression = angular.identity;
                }
                angular.copy($filter('orderBy')(array1, expression), array1); // keep array object is self not change, just update it content
                angular.copy($filter('orderBy')(array2, expression), array2);

                return defaultArrayEqaul.apply(this, [array1, array2, array1.length, propertyName, level]);
            }

            function renormalizePropertyName(propertyName) {
                log('*** propertyName ' + propertyName);
                var renormalizedProperty = propertyName.replace(/\[\d*\]/, '.' + arrayCfg);
                log('*** parsed renormalizedProperty string: ' + renormalizedProperty);

                return renormalizedProperty;
            }

            function getCustomConfig(propertyName) {
                log('-------------------');
                var renormalizedProperty = renormalizePropertyName(propertyName);
                var customConfig = config[renormalizedProperty];
                log('*** parsed preferConfig value: ' + angular.toJson(customConfig, true));
                if (!customConfig) { // try to find regEx config
                    customConfig = getCustomConfigFromRegex(renormalizedProperty);
                }

                return customConfig;
            }

            function getCustomConfigFromRegex(renormalizedProperty) {
                var configKey, customConfig;
                for (configKey in config) {
                    if (config.hasOwnProperty(configKey)) {
                        if (configKey.indexOf('*') >= 0) { // contain the regex
                            var p = configKey.replace(/\.\*{2}/g, '\\..+').replace(/\.\*{1}/g, '\\.[^\.]+').replace(/\*{2}/g, '.*');
                            var reg = new RegExp('^' + p + '$', 'g');
                            log('@@@ regex pattern: ' + reg);
                            if (reg.test(renormalizedProperty)) {
                                customConfig = config[configKey];
                                log('@@@ regex preferConfig value: ' + angular.toJson(customConfig));
                                break;
                            }
                        }
                    }
                }

                return customConfig;
            }

            function getParentCompartor(propertyName) {
                log('-------------------');
                var renormalizedProperty = renormalizePropertyName(propertyName);
                var parentRenormalizedProperty = renormalizedProperty.substring(0, renormalizedProperty.lastIndexOf('.'));
                log('*** parsed parent renormalizedProperty string: ' + parentRenormalizedProperty);
                var customConfig = config[parentRenormalizedProperty];
                log('*** parsed parent preferConfig value: ' + angular.toJson(customConfig, true));

                return customConfig ? customConfig.comparator : null;
            }


        } // end of ppm Equal

        // public
        ppmFullEqual.arrayCfg = function() {
            return arrayCfg;
        };

        ppmFullEqual.prefix = function() {
            return prefix;
        };

        ppmFullEqual.isDate = function(value) {
            return isDate(value);
        };

        // Help function
        function log(msg) {
            if (debug) {
                $log.log(msg);
            }
        }

        function getValue(propertyName, obj) {
            var wrappedValue = {};
            wrappedValue[prefix] = obj;
            var compuAccessStr = propertyName.replace(/(\.([^\.\[]+))/g, '["$2"]'); // change value.a.b.c = value["a"]["b"]["c"], value.a["x"].b.c = value["a"]["x"]["b"]["c"]
            log('compuAccessStr = ' + compuAccessStr);
            var getter = $parse(compuAccessStr);

            return angular.toJson(getter(wrappedValue), true);
        }

        function printDebugValue(level, propertyName, v1, v2, reason) {
            if (debug) {
                log('>>>>>>>>>> L' + level + ' Property "' + propertyName + '": ' + reason + '!');
                log('          propertyName: ' + propertyName + ', value 1: ' + getValue(propertyName, v1) + ', value 2: ' + getValue(propertyName, v2));
            }
        }

        function printNonEqualValues(compareResult, o1, o2) {
            var i = 0;
            angular.forEach(compareResult, function(value, propertyName) {
                $log.log((++i) + '. propertyName: ' + propertyName + ': ');
                $log.log('value 1: ' + getValue(propertyName, o1));
                $log.log('value 2: ' + getValue(propertyName, o2));
            });
        }

        function isLeafPropertyValue(o) {
            // return isDate(o) || isString(o) || !isObject(o);
            return !isObject(o);
        }

        // private
        function createMap() {
            return Object.create(null);
        }

        var toString = Object.prototype.toString;

        function isArray(value) {
            // jshint undef:false
            return toString.call(value) === '[object Array]';
        }

        function isDate(value) {
            // jshint undef:false
            return toString.call(value) === '[object Date]';
        }

        function isScope(obj) {
            return obj && obj.$evalAsync && obj.$watch;
        }

        function isRegExp(value) {
            // jshint undef:false
            return toString.call(value) === '[object RegExp]';
        }

        function isWindow(obj) {
            return obj && obj.window === obj;
        }

        function isDefined(value) {
            return typeof value !== 'undefined';
        }

        function isFunction(value) {
            return typeof value === 'function';
        }

        function isObject(value) {
            // http://jsperf.com/isobject4
            return value !== null && typeof value === 'object';
        }

        /** Keep for future, otherwise, jsHint error
         
        function isBoolean(value) {
            return typeof value === 'boolean';
        }

        function isString(value) {
            return typeof value === 'string';
        }

        function isPromiseLike(obj) {
            return obj && isFunction(obj.then);
        }

        function isFormData(obj) {
            return toString.call(obj) === '[object FormData]';
        }

        function isBlob(obj) {
            return toString.call(obj) === '[object Blob]';
        }

        function isFile(obj) {
            return toString.call(obj) === '[object File]';
        }

        function isBlankObject(value) {
            return value !== null && typeof value === 'object' && !Object.getPrototypeOf(value);
        }
        */

        return ppmFullEqual;
    });