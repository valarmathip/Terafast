'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.SpinnerInterceptor
 * @description
 * # SpinnerInterceptor
 * Factory in the p2AdvanceApp.
 *
 * http://stackoverflow.com/questions/17838708/implementing-loading-spinner-using-httpinterceptor-and-angularjs-1-1-5
 */
angular.module('p2AdvanceApp')
    .factory('SpinnerInterceptor', function($q, SpinnerService) {

        return {
            request: function(config) {
                SpinnerService.show();

                return config || $q.when(config);
            },
            response: function(response) {
                SpinnerService.hide();

                return response || $q.when(response);
            },
            responseError: function(response) {
                SpinnerService.hide();

                return $q.reject(response);
            }
        };
    });