'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.httpRequestInterceptor
 * @description
 * # httpRequestInterceptor
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
  .factory('httpRequestInterceptor', function ($injector, moment) {
        return {
            request: function (config) {
                $injector.invoke(function ($auth) {
                    if (!$auth.isOpenSsoIdleModal()) {
                      $auth.refreshHttpRequestTimeout(new moment());
                    }
                });
                return config;
            }
        };
    });