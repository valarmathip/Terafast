'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.auth
 * @description
 * # auth
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('$auth', function(
        localStorageService,
        $location,
        $window,
        $document,
        $log,
        $http,
        ENV,
        ENV_MEDIA_MANAGEMENT,
        $state,
        $q,
        ConfirmationModalFactory,
        moment,
        ModalDialogFactory,
        QueryDialog,
        $timeout,
        $rootScope) {

        var fiveSecongs = 5000;

        //var events =  ['loginSuccess', 'loginFailure', 'logout', 'forbidden', 'authenticated', 'tokenRefreshed', 'userInfoRefreshed'];
        var resolveLocalStorageBoolean = function resolveLocalStorageBoolean(key) {
            return JSON.parse(localStorageService.get(key)) || false;
        };

        // Resolve the forceLogout status based on the status flag and if the
        // time between the last abrupt exit (close browser / close tab / refresh)
        // If the past time is bigger than 5segs, we are assuming the action was a close and forceLogout
        // Less than 5 segs is take as refresh and keep credentials
        var resolveForceLogout = function resolveForceLogout() {
            var forceLogout = localStorageService.get('forceLogout');
            var forceLogoutTimestamp;
            var forceLogoutStatus;
            var now = new moment();

            if (forceLogout) {
                forceLogoutTimestamp = new moment(forceLogout.timestamp);
                forceLogoutStatus = forceLogout.status || false;
                if (forceLogoutStatus && now.diff(forceLogoutTimestamp) > fiveSecongs) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        };

        var HOME_LANDING_PAGE_STATE = 'home.landing-page';
        var COMPANY_DEFAULT_LOGO_URL = 'images/client_logo.png';
        var userInfo;
        var ssoTimeoutPromise;
        var ssoTokenExpireTimeout;
        var lastHttpRequestDate;
        var maxAttemptsRefreshToken = 3;
        var refreshTokenAttempts = 0;
        var openSsoIdleModal = false;
        var authenticated = resolveLocalStorageBoolean('isAuthenticated');
        var processing = resolveLocalStorageBoolean('processing');
        var forceLogout = resolveForceLogout();
        var apiToken = localStorageService.get('apiToken');
        var deepLink = localStorageService.get('deepLink');
        var oneMinute = 60000;
        var oneSecond = 1000;

        localStorageService.remove('deepLink');

        return {

            config: {
                idpUrl: '/app/idp',
                apiUrl: '/gateway/token/exchange/open',
                apiUserInfo: '/gateway/cm/users/me',
                apiCompanyLogo: '/gateway/cm/logos/me',
                apiRefreshUrl: '/gateway/token/refresh',
                signOutUrl: '/app/logout',
                tokenValidationPath: '/app/auth/validate_token',
                storage: 'session'
            },

            isOpenSsoIdleModal: function isOpenSsoIdleModal() {
                return openSsoIdleModal;
            },

            setOpenSsoIdleModal: function setOpenSsoIdleModal(status) {
                openSsoIdleModal = status;
            },

            isAuthenticated: function isAuthenticated() {
                return authenticated;
            },

            isDeepLinkStoraged: function isDeepLinkStoraged() {
                return (localStorageService.get('deepLink')) ? true : false;
            },

            isProcessing: function isProcessing() {
                return processing;
            },

            isForceLogout: function isForceLogout() {
                return forceLogout;
            },

            setForceLogout: function setForceLogout(status) {
                var forceLogout = {
                    status: status,
                    timestamp: new moment().format()
                };
                localStorageService.set('forceLogout', forceLogout);
            },

            setProcessing: function setProcessing(status) {
                processing = status;
                localStorageService.set('processing', status);
            },

            getAuthStatus: function getAuthStatus() {
                return resolveLocalStorageBoolean('isAuthenticated');
            },

            setAuthStatus: function setAuthStatus(status) {
                authenticated = status;
                localStorageService.set('isAuthenticated', status);
            },

            removeAuthStatus: function removeAuthStatus() {
                authenticated = undefined;
                localStorageService.remove('isAuthenticated');
            },

            validateUser: function validateUser() {
                var defer = $q.defer();
                if (this.isAuthenticated()) {
                    this.setProcessing(false);
                    defer.resolve(true);
                } else if (this.isForceLogout()) {
                    this.setForceLogout(false);
                    this.setProcessing(true);
                    defer.reject(false);
                    this.redirectToIdpLogout();
                } else {
                    defer.reject(false);
                    this.redirectToIdpLogin();
                }
                return defer.promise;
            },

            redirectToIdpLogin: function redirectToIdpLogin() {
                var auth = this;
                // save current path
                auth.setDeepLink();
                // Remove credentials
                auth.invalidateCredentials()
                    .then(function() {
                        // Redirect to idp login url
                        auth.redirectToUrl(auth.getIdpUrl());
                    })
                    /*jshint -W024 */
                    .catch(function() {
                        $log.error('Error removing user credentials');
                    });
            },

            redirectToIdpLogout: function redirectToIdpLogout() {
                var auth = this;
                // Remove credentials

                auth.setProcessing(true);
                auth.invalidateCredentials()
                    .then(function() {
                        // Redirect to idp login url
                        auth.redirectToUrl(auth.getSignOutUrl());
                    })
                    /*jshint -W024 */
                    .catch(function() {
                        $log.error('Error removing user credentials');
                    });
            },

            redirectToUrl: function redirectToUrl(url) {
                $window.location.href = url;
            },

            redirectToState: function redirectToState(state) {
                $state.go(state);
            },

            invalidateCredentials: function invalidateCredentials() {
                var defer = $q.defer();

                if (ssoTimeoutPromise) {
                    $timeout.cancel(ssoTimeoutPromise);
                }

                if (ssoTokenExpireTimeout) {
                    $timeout.cancel(ssoTokenExpireTimeout);
                }

                if (this.removeAuth()) {
                    defer.resolve(true);
                } else {
                    defer.reject(false);
                }

                return defer.promise;
            },

            requestUserInfo: function requestUserInfo() {
                return $http({
                    method: 'GET',
                    url: ENV.apiGatewayEndpoint + this.config.apiUserInfo
                });
            },

            getCompanyLogo: function getCompanyLogo() {
                return $http({
                    method: 'GET',
                    url: ENV.apiGatewayEndpoint + this.config.apiCompanyLogo
                });
            },

            refreshToken: function refreshToken(lastHttpRequestDate) {
                return $http({
                    method: 'POST',
                    url: ENV.apiGatewayEndpoint + this.config.apiRefreshUrl,
                    data: {
                        timestamp: lastHttpRequestDate
                    }
                });
            },

            goToIdpLogin: function goToIdpLogin() {
                // Redirect to IDP login page will be called maxAttemptsRefreshToken times, after that, user will be redirec to logout page
                if (refreshTokenAttempts >= maxAttemptsRefreshToken) {
                    $log.info('Attempt to refresh API Token exceed, User wil be logged out ');
                    ConfirmationModalFactory.open('Error Message', 'Unauthorized Credentials', ENV.modalErrorTimeout, this.redirectToIdpLogout());
                } else {
                    refreshTokenAttempts++;
                    $log.info('Attempt to refresh API Token # ' + refreshTokenAttempts);
                    this.redirectToIdpLogin();
                }
            },

            setUserInfo: function setUserInfo(data) {
                userInfo = data;
            },

            removeUserInfo: function removeUserInfo() {
                userInfo = undefined;
            },

            isValidUserInfo: function isValidUserInfo() {
                return (userInfo && userInfo.user);
            },

            isValidRoleDefinitions: function isValidRoleDefinitions() {
                return (userInfo && userInfo.roleDefinitions);
            },

            getUserRolesAndPermissions: function getUserRolesAndPermissions() {
                return (this.isValidRoleDefinitions()) ? userInfo.roleDefinitions : [];
            },

            getUserEmail: function getUserEmail() {
                return (this.isValidUserInfo()) ? userInfo.user.username : '';
            },

            getUserRolesNames: function getUserRoles() {
                return (this.isValidUserInfo()) ? userInfo.user.roles : '';
            },

            getUserGroups: function getUserGroups() {
                return (this.isValidUserInfo()) ? userInfo.user.groups : '';
            },

            getUserOrganization: function getUserOrganizarion() {
                return (this.isValidUserInfo()) ? userInfo.user.organization : '';
            },

            getUserCompanyLogoUrl: function getUserCompanyLogoUrl() {
                return (this.isValidUserInfo() && userInfo.companyLogoUrl) ? userInfo.companyLogoUrl : COMPANY_DEFAULT_LOGO_URL;
            },

            setUserCompanyLogo : function setUserCompanyLogo(logoBase64Data) {
                userInfo.companyLogoUrl = logoBase64Data;
            },

            getUserFullName: function getUserFullName() {
                return (this.isValidUserInfo()) ? userInfo.user.firstName + ' ' + userInfo.user.lastName : 'Unknown';
            },

            getUserTimeOut: function getUserTimeOut() {
                return (this.isValidUserInfo()) ? userInfo.user.timeoutInSeconds * oneSecond : ENV.sessionLogoutTimeout;
            },

            getUserTimeOutWarning: function getUserTimeOutWarning() {
                return (this.isValidUserInfo()) ? userInfo.user.timeoutWarningInSeconds * oneSecond : ENV.sessionAlertTimeout;
            },

            getUserLogoutWaitingTime: function getUserLogoutWaitingTime() {
                return this.getUserTimeOut() - this.getUserTimeOutWarning();
            },

            getUserLogoutWaitingTimeSeconds: function getUserLogoutWaitingTimeSeconds() {
                return this.getUserLogoutWaitingTime() / oneSecond;
            },

            getUserAPITokenRefreshTime: function getUserAPITokenRefreshTime() {
                // refresh API Token 1min before expire
                return this.getUserTimeOut() - oneMinute;
            },

            getTokenExpirationDate: function getTokenExpirationDate() {
                return moment(userInfo.user.apiTokenTimestamp).add(userInfo.user.timeoutInSeconds, 's');
            },

            getTokenWarningDate: function getTokenWarningDate() {
                return moment(userInfo.user.apiTokenTimestamp).add(userInfo.user.timeoutWarningInSeconds, 's');
            },

            getTimeOutInSeconds: function getTimeOutInSeconds() {
                return userInfo.user.timeoutInSeconds;
            },

            getTimeoutWarningInSeconds: function getTimeoutWarningInSeconds() {
                return userInfo.user.timeoutWarningInSeconds;
            },

            isTokenExpired: function isTokenExpired() {
                return this.getTokenExpirationDate().isAfter(moment());
            },

            isTokenWarningTime: function isTokenWarningTime() {
                return moment().isBetween(this.getTokenWarningDate(), this.getTokenExpirationDate());
            },

            ssoRefreshToken: function ssoRefreshToken() {
                var defer = $q.defer();
                var auth = this;
                if (auth.isOpenSsoIdleModal()) {
                    defer.resolve();
                } else {
                    auth.refreshToken(auth.getLastHttpRequestDate().format())
                        .success(function(refreshData) {
                            if (refreshData.error) {
                                $log.error(JSON.stringify(refreshData));
                                defer.reject();
                                auth.redirectToIdpLogin();
                            } else {
                                if (auth.isValidToken(refreshData)) {
                                    auth.setAuthStatus(true);
                                    auth.setProcessing(true);
                                    auth.setApiToken(refreshData);
                                    auth.resolveUserInfo()
                                        .then(function(data) {
                                            auth.setProcessing(false);
                                            defer.resolve(data);
                                        })
                                        /*jshint -W024 */
                                        .catch(function(data, status) {
                                            $log.error('resolveUserInfo error', status, data);
                                            defer.reject();
                                        });
                                } else {
                                    $log.error(JSON.stringify('Invalid API Token'));
                                    ConfirmationModalFactory.open('Error Message', 'Error occurred when creating API Token.', ENV.modalErrorTimeout, function() {
                                        defer.reject();
                                        auth.redirectToIdpLogout();
                                    });
                                }
                            }
                        })
                        .error(function(error) {
                            $log.error(JSON.stringify(error));
                            defer.reject();
                            auth.redirectToIdpLogin();
                        });
                }

                return defer.promise;
            },

            setSsoTokenExpire: function setSsoTokenExpire() {
                var auth = this;
                if (ssoTokenExpireTimeout) {
                    $timeout.cancel(ssoTokenExpireTimeout);
                }
                return $timeout(function() {
                    auth.ssoRefreshToken();
                }, this.getUserAPITokenRefreshTime());
            },

            resolveUserInfo: function resolveUserInfo() {
                var defer = $q.defer();
                var auth = this;
                this.requestUserInfo()
                    .success(function (data) {
                        if (data && data.error) {
                            $log.error(JSON.stringify(data));
                            defer.reject(data);
                        } else {
                            auth.setUserInfo(data);
                            auth.getCompanyLogo()
                                .success(function(data) {
                                    auth.setUserCompanyLogo(data.image);
                                    if (auth.isValidUserInfo() && auth.isValidRoleDefinitions()) {
                                        // TODO Loading permissiong here until we can read from API
                                        $rootScope.$emit('auth:user_roles_refreshed');
                                        ssoTokenExpireTimeout = auth.setSsoTokenExpire();
                                        defer.resolve();
                                    } else {
                                        ConfirmationModalFactory.open('Error Message', 'Error occurred gathering user information.', ENV.modalErrorTimeout, function() {
                                            auth.removeUserInfo();
                                            defer.reject();
                                            auth.redirectToIdpLogout();
                                        });
                                    }
                                })
                                .error(function(error) {
                                    $log.error(JSON.stringify(error));
                                    $rootScope.$emit('auth:user_roles_refreshed');
                                    ssoTokenExpireTimeout = auth.setSsoTokenExpire();
                                    defer.resolve();
                                });
                        }
                    })
                    .error(function (error) {
                        $log.error(JSON.stringify(error));
                        defer.reject();
                        auth.redirectToIdpLogin();
                    });
                return defer.promise;
            },

            requestApiToken: function requestApiToken(openToken) {
                // return $http({
                //     method:  'POST',
                //     url: this.config.apiUrl,
                //     headers: { 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8' },
                //     data: $.param({ opentoken: openToken })
                // });
                return $.ajax({
                    type: 'post',
                    url: ENV.apiGatewayEndpoint + this.config.apiUrl,
                    data: 'opentoken=' + openToken + this.getTargetDomain()
                });
            },

            isValidToken: function isValidToken(apiToken) {
                return (apiToken.indexOf('Bearer') === 0);
            },

            getTargetDomain: function getTargetDomain() {
                var targetDomain = $location.host();
                var hrIndex = targetDomain.indexOf('.highroads.com');
                if (hrIndex > 0) {
                    targetDomain = '&spid=' + targetDomain.substring(0, hrIndex);
                } else {
                    targetDomain = '';
                }
                return targetDomain;
            },

            resolveApiToken: function resolveApiToken(openToken) {
                var defer = $q.defer();
                var auth = this;
                if (openToken) {
                    auth.setProcessing(true);
                    ConfirmationModalFactory.open('Authorization', 'Getting User Credentials', ENV.modalErrorTimeout);
                    this.requestApiToken(openToken)
                        .success(function(data) {
                            if (data.error) {
                                $log.error(JSON.stringify(data));
                                ConfirmationModalFactory.open('Error Message', 'Invalid Credentials', ENV.modalErrorTimeout, function() {
                                    defer.reject();
                                    auth.redirectToIdpLogout();
                                });
                            } else {
                                if (auth.isValidToken(data)) {
                                    ConfirmationModalFactory.close();
                                    auth.setAuthStatus(true);
                                    auth.setApiToken(data);
                                    auth.goToDeepLink();
                                    defer.resolve(auth.getApiToken());
                                } else {
                                    $log.error(JSON.stringify('Invalid API Token'));
                                    ConfirmationModalFactory.open('Error Message', 'Error occurred when creating API Token.', ENV.modalErrorTimeout, function() {
                                        defer.reject();
                                        auth.redirectToIdpLogout();
                                    });
                                }
                            }
                        })
                        .error(function(error) {
                            $log.error(JSON.stringify(error));
                            ConfirmationModalFactory.open('Error Message', 'Error occurred when creating API Token.', ENV.modalErrorTimeout, function() {
                                defer.reject();
                                auth.redirectToIdpLogout();
                            });
                        });
                } else {
                    ConfirmationModalFactory.open('Error Message', 'Error occurred when loading IDP Open Token.', ENV.modalErrorTimeout, function() {
                        defer.reject();
                        auth.redirectToIdpLogout();
                    });
                }
                return defer.promise;
            },

            getApiToken: function getApiToken() {
                return apiToken;
            },

            setApiToken: function setApiToken(token) {
                apiToken = token;
                this.storeApiToken(token);
            },

            goToDeepLink: function goToDeepLink() {
                if (deepLink) {
                    this.redirectToUrl(deepLink);
                } else {
                    this.redirectToState(HOME_LANDING_PAGE_STATE);
                }
            },

            removeApiToken: function removeApiToken() {
                apiToken = undefined;
                localStorageService.remove('apiToken');
            },

            removeAuth: function removeAuth() {
                var document = $document[0];
                apiToken = undefined;
                authenticated = undefined;
                userInfo = undefined;

                if (!_.isNull(document.all)) { // MSIE 6+
                    document.execCommand('ClearAuthenticationCache');
                }

                return localStorageService.remove('apiToken') && localStorageService.remove('isAuthenticated');
            },

            storeApiToken: function storeApiToken(apiToken) {
                localStorageService.set('apiToken', apiToken);
            },

            getIdpUrl: function getIdpUrl() {
                return this.config.idpUrl;
            },

            getSignOutUrl: function getSignOutUrl() {
                return this.config.signOutUrl;
            },

            getDeepLink: function getDeepLink() {
                return deepLink;
            },

            setDeepLink: function setDeepLink() {
                // no local variable needed
                localStorageService.set('deepLink', '/app' + $location.url());
            },

            removeDeepLink: function removeDeepLink() {
                deepLink = undefined;
                localStorageService.remove('deepLink');
            },

            setLastHttpRequestDate: function setLastHttpRequestDate(date) {
                lastHttpRequestDate = date;
            },

            getLastHttpRequestDate: function getLastHttpRequestDate() {
                return lastHttpRequestDate || new moment();
            },

            ssoIdleModal: function ssoIdleModal() {
                var auth = this;
                var dialogOptions = {
                    templateUrl: 'views/util/timeout-alert.html',
                    controller: 'TimeOutAlertCtrl'
                };
                auth.setOpenSsoIdleModal(true);
                ModalDialogFactory.showDialog(dialogOptions)
                    .then(function(result) {
                        auth.setOpenSsoIdleModal(false);
                        if (result === 'keepSignedIn') {
                            auth.refreshHttpRequestTimeout(new moment());
                        } else if (result === 'signOut') {
                            auth.redirectToIdpLogout();
                        }
                    }, function(result) {
                        auth.setOpenSsoIdleModal(false);
                        if (result === 'cancel') {
                            auth.refreshHttpRequestTimeout(new moment());
                            //auth.ssoRefreshToken();
                        } else {
                            auth.redirectToIdpLogout();
                        }
                    });
            },

            startSSOTimeout: function startSSOTimeout() {
                var auth = this;
                if (ssoTimeoutPromise) {
                    $timeout.cancel(ssoTimeoutPromise);
                }
                return $timeout(function() {
                    auth.ssoIdleModal();
                }, this.getUserTimeOutWarning());
            },

            refreshHttpRequestTimeout: function refreshHttpRequestTimeout(date) {
                if (this.isValidUserInfo()) {
                    this.setLastHttpRequestDate(date);
                    ssoTimeoutPromise = this.startSSOTimeout();
                }
            },

            initEvents: function initEvents() {

            // Current error format:
            // {
            //   "httpStatus": "(404) NOT_FOUND",
            //   "errorCode": "not.found",
            //   "errorMessage": "Resource not found",
            //   "errorId": "c96d8b06-3dbc-46d5-ab9c-e9734354efad",
            //   "errorDetails": "Object of type plan with Id 46375178-1798-4656-8c79-d1c14c4e2727x not found",
            //   "httpStatusCode": 404
            // }

            // Modified format:
            // {
            //   "httpStatus": "NOT_FOUND",
            //   "errorCode": "NOT_FOUND",
            //   "errorMessage": "Resource not found",
            //   "errorId": "7fa44821-a576-4e14-b42c-0b4bb28dd4d1",
            //   "errorDetails": "Object of type plan with Id 46375178-1798-4656-8c79-d1c14c4e2727x not found"
            // }

                var auth = this;

                var parseExceptionData = function(data) {
                    return {
                        'httpStatus': (data.status) ? data.status : data.httpStatus,
                        'errorCode': (data.status) ? data.status : data.errorCode,
                        'errorMessage': (data.error) ? data.error : data.errorMessage,
                        'errorId': (data.status) ? data.status : data.errorId,
                        'errorDetails': (data.message && data.exception) ? data.message + ', ' + data.exception : data.errorDetails
                    };
                };

                $rootScope.$on('auth:invalidateCredentials', function(event) {
                    event.stopPropagation();
                    $log.info('auth:invalidateCredentials');
                    ConfirmationModalFactory.open('Error Message', 'Invalid Credentials', ENV.modalErrorTimeout, function() {
                        auth.redirectToIdpLogout();
                    });
                });

                // http response code 0
                $rootScope.$on('ClientError:NoInternet', function(event, data) {
                    event.stopPropagation();
                    data = {
                        'httpStatus': 'No Internet',
                        'errorCode': '',
                        'errorMessage': 'No Internet',
                        'errorId': '',
                        'errorDetails': null
                    };
                    $log.info('ClientError:NoInternet, http error code ' + data.httpStatus);
                    return QueryDialog.open(data.httpStatus, data, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 400
                $rootScope.$on('auth:BadRequest', function(event, data) {
                    $log.info('auth:BadRequest, http error code ' + data.status);
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 401
                $rootScope.$on('auth:unauthorized', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('auth:unauthorized, http error code ' + dataMessage.httpStatus);
                    var modalInstance = QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                    modalInstance.result.then(function(){
                    }, function(){
                        auth.goToIdpLogin();
                    });
                    // ConfirmationModalFactory.open('Error Message', 'Authentication has failed',
                    //     ENV.modalErrorTimeout,
                    //     function() {
                    //         auth.goToIdpLogin();
                    //     }
                    // );
                });

                // http response code 403
                $rootScope.$on('auth:forbidden', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('auth:forbidden, http error code ' + dataMessage.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 404
                $rootScope.$on('ClientError:NotFound', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ClientError:NotFound, http error code ' + dataMessage.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 405
                $rootScope.$on('ClientError:MethodNotAllowed', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ClientError:MethodNotAllowed, http error code ' + dataMessage.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 408
                $rootScope.$on('ClientError:RequestTimeout', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ClientError:RequestTimeout, http error code ' + dataMessage.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 409
                $rootScope.$on('ClientError:Conflict', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ClientError:Conflict, http error code ' + dataMessage.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 413
                $rootScope.$on('ClientError:PayloadTooLarge', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ClientError:PayloadTooLarge, http error code ' + data.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 500
                $rootScope.$on('ServerError:InternalServerError', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ServerError:InternalServerError, http error code ' + dataMessage.status);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 501
                $rootScope.$on('ServerError:NotImplemented', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ServerError:InternalServerError, http error code ' + data.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

                // http response code 503
                $rootScope.$on('ServerError:ServiceUnavailable', function(event, data) {
                    event.stopPropagation();
                    var dataMessage = parseExceptionData(data);
                    $log.info('ServerError:ServiceUnavailable, http error code ' + dataMessage.httpStatus);
                    return QueryDialog.open(dataMessage.httpStatus, dataMessage, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');
                });

            }

        };

    });