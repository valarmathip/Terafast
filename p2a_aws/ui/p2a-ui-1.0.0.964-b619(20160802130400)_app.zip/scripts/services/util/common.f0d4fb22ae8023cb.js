'use strict';

angular.module('p2AdvanceApp')
    .service('Common', function Common($http, $q, $log, ConfirmationModalFactory, ENV_MEDIA_MANAGEMENT) {
        return {
            download: function(url, name, documentFormat) {
                var defer = $q.defer();
                $http({
                    method: 'GET',
                    url: url,
                    responseType: 'arraybuffer'
                }).success(function(data) {
                    var file = new Blob([data]);
                    if (documentFormat) {
                        if (documentFormat.toLowerCase() === 'pdf') {
                            name += '.pdf';
                        } else if (documentFormat.toLowerCase() === 'word') {
                            name += '.docx';
                        } else if (documentFormat.toLowerCase() === 'xlsx') {
                            name += '.xlsx';
                        }
                    }
                    saveAs(file, name);
                    defer.resolve(name);
                }).error(function() {
                    defer.reject();
                });
                return defer.promise;
            },

            downloadAndNotify: function(url, name, documentFormat) {
                this.download(url, name, documentFormat)
                    .then(function() {
                        // do nothing
                    })
                    /*jshint -W024 */
                    .catch(function() {
                        ConfirmationModalFactory.open('Download Failed', 'Please contact your administrator', ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
                    });
            }
        };
    });