'use strict';

angular.module('p2AdvanceApp')
    .service('PaginationService', function PaginationService($log) {
        return {

            /*jshint maxcomplexity:50 */
            goToPage: function(keyEvent, pageNumberObject, gridApi) {
                // IE, event.key return name/string of key, so remove it
                var keyCode = keyEvent.keyCode || keyEvent.which; // "event" is a global variable
                var target = $(keyEvent.currentTarget);
                var pageNumber = parseInt(target.val(), 10);
                if (!isNaN(pageNumber)) {
                    if (pageNumber > gridApi.pagination.getTotalPages()) {
                        pageNumberObject.pageNumber = gridApi.pagination.getTotalPages();
                    } else if (pageNumber < 1) {
                        pageNumberObject.pageNumber = 1;
                    }
                } else if (keyCode === 189 || keyCode === 109 || keyCode === 187 || keyCode === 107 || keyCode === 190 || keyCode === 110) {
                    //     -                                     +                                     .
                    target.val('');
                }

                if (keyCode === 13 && pageNumberObject.pageNumber) {
                    this.navPage(keyEvent, parseInt(pageNumberObject.pageNumber, 10), gridApi);
                    this.isGoToPageEnabled = true;
                    return true;
                }
            },

            navPage: function($event, delta, gridApi) {
                $event.preventDefault();
                $event.stopPropagation();
                if (delta === 'previous') {
                    gridApi.pagination.previousPage();
                } else if (delta === 'next') {
                    gridApi.pagination.nextPage();
                } else {
                    gridApi.pagination.seek(delta);
                }
            },

            viewPages: function(gridApi, ps) {
                var curPage = gridApi.pagination.getPage();
                var totalPages = gridApi.pagination.getTotalPages();
                var rangeSize = 10;
                var start;
                if (curPage <= totalPages) {
                    start = curPage;
                    if (start > totalPages - rangeSize) {
                        start = totalPages - rangeSize + 1;
                    }
                    for (var i = start; i < start + rangeSize; i++) {
                        if (i >= 1) {
                            ps.push(i);
                        }
                    }
                    return ps;
                }
            },

            setOrResetCheckList: function(row, checkList) {
                checkList[row.entity.objectId] = row.isSelected;
                return checkList;
            },

            setCheckList: function(gridApi, checkList) {
                var selectedRows = gridApi.selection.getSelectedRows();
                if (selectedRows.length > 0) {
                    angular.forEach(selectedRows, function(row) {
                        checkList[row.objectId] = true;
                    });
                } else {
                    angular.forEach(gridApi.grid.rows, function(row) {
                        angular.forEach(checkList, function(value, key) {
                            if (row.entity.objectId === key) {
                                delete checkList[key];
                            }
                        });
                    });
                }
                return checkList;
            },

            selectAllCell: function(selectAllChecker, gridApi, loadedOptions, checkList) {
                if (!selectAllChecker) {
                    gridApi.selection.selectAllRows();
                    selectAllChecker = true;
                } else {
                    gridApi.selection.clearSelectedRows();
                    selectAllChecker = false;
                }
                angular.forEach(loadedOptions, function(row) {
                    checkList[row.objectId] = selectAllChecker;
                });
                return [checkList, selectAllChecker];
            },

            selectCell: function(gridApi, row, gridOptions, checkList) {
                gridApi.selection.toggleRowSelection(gridOptions.data[0]);
                checkList[row.entity.objectId] = !(checkList[row.entity.objectId]);
                return checkList[row.entity.objectId];
            },

            resetPageNumber: function(gridApi, pageNumber) {
                if (gridApi.pagination.getPage() !== pageNumber) {
                    pageNumber = '';
                }
                return pageNumber;
            },
            isGoToPageEnabled: function() {
                return this.isGoToPageEnabled;
            },
            setGoToPageEnabled: function(booleanValue) {
                this.isGoToPageEnabled = booleanValue;
            },
            setSortColumns: function(sortColumns) {
                this.sortColumns = sortColumns;
            },
            getSortColumns: function() {
                return this.sortColumns;
            },
            // Deprecated
            getSortQuery: function(specifiedDefaultSortStr) {
                $log.warn('!!! Function getSortQuery() in pagination-service.js is Deprecated !!!');
                var filterQuery = '';
                var sortColumns = this.getSortColumns();
                if (sortColumns && sortColumns.length > 0) {
                    var isFirstRecord = true;
                    angular.forEach(this.getSortColumns(), function(sortColumn) {
                        if (isFirstRecord) {
                            isFirstRecord = false;
                            filterQuery += '&sort=' + sortColumn.field + ' ' + sortColumn.sort.direction;
                        } else {
                            filterQuery += ', ' + sortColumn.field + ' ' + sortColumn.sort.direction;
                        }

                    });

                } else if (specifiedDefaultSortStr && specifiedDefaultSortStr !== '') { // if there is no column sort defined, use the specifiedDefautSort
                    filterQuery = '&sort=' + specifiedDefaultSortStr;
                } else { // if no specified default sort, use general default sort order, it is the same as backend sort order
                    filterQuery = '&sort=lastModificationDate desc';
                }
                return filterQuery;
            },
            getSortParam: function(specifiedDefaultSortStr) {
                var sortParam = {};
                var sortColumns = this.getSortColumns();
                if (sortColumns && sortColumns.length > 0) {
                    var sorts = [];
                    angular.forEach(this.getSortColumns(), function(sortColumn) {
                        sorts.push(sortColumn.field + ' ' + sortColumn.sort.direction);
                    });
                    sortParam.sort = sorts.join(',');
                } else if (specifiedDefaultSortStr && specifiedDefaultSortStr !== '') { // if there is no column sort defined, use the specifiedDefautSort
                    sortParam.sort = specifiedDefaultSortStr;
                } else { // if no specified default sort, use general default sort order, it is the same as backend sort order
                    sortParam.sort = 'lastModificationDate desc';
                }
                return sortParam;
            }

        };
    });