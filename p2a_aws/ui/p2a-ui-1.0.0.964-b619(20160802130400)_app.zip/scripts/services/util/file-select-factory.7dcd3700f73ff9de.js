﻿'use strict';

angular.module('p2AdvanceApp')
    .factory('FileSelectFactory', function(ModalDialogFactory, $q) {
        // Public API here
        return {
            openModalDialog: function(type, valueselectorType) {
                valueselectorType = (valueselectorType === undefined) ? 'multiple' : valueselectorType;
                var dialogOptions = {
                    templateUrl: 'views/util/modal-dialog.html',
                    controller: 'ModalDailogCtrl',
                    size: 'lg',
                    resolve: {
                        fileSelectorType: function() {
                            return type;
                        },
                        fieldSelectorOption: function() {
                            return valueselectorType;
                        },
                        authorizedUserInfo: ['$auth', function($auth) {
                            return $auth.requestUserInfo();
                        }]
                    }

                };
                var defer = $q.defer();
                ModalDialogFactory.showDialog(dialogOptions).then(function(response) {
                    defer.resolve(response);
                });
                return defer.promise;

            }

        };

    });