'use strict';

angular.module('p2AdvanceApp')
    .service('DatePickerFilterService', function DatePickerFilterService() {
        return {

            getLength: function(fromDate, toDate) {
                var dateObjLength = 0;
                if (fromDate.length === toDate.length) {
                    dateObjLength = fromDate.length;
                } else if (fromDate.length < toDate.length) {
                    dateObjLength = fromDate.length;
                } else if (fromDate.length > toDate.length) {
                    dateObjLength = toDate.length;
                }
                return dateObjLength;
            },
            constructDatePairs: function(datePickerLength, fromDateObjs, toDateObjs, fromFilterId, toFilterId, allDateCollection) {
                for (var dateVal = 0; dateVal <= datePickerLength; dateVal++) {
                    var dateObj = 'date' + dateVal;
                    dateObj = {
                        'fromDate': {},
                        'toDate': {}
                    };
                    if (fromDateObjs[fromFilterId][dateVal] && toDateObjs[toFilterId][dateVal] && fromDateObjs[fromFilterId][dateVal] !== '' && toDateObjs[toFilterId][dateVal] !== '') {
                        dateObj['fromDate'][fromFilterId] = fromDateObjs[fromFilterId][dateVal];
                        dateObj['toDate'][toFilterId] = toDateObjs[toFilterId][dateVal];
                        allDateCollection.push(dateObj);
                    }
                }
                return allDateCollection;
            },
            getAllDateCollection: function(allDateCollection, fromDateObjs, toDateObjs) {
                var self = this;
                angular.forEach(fromDateObjs, function(fromDate, fromFilterId) {
                    angular.forEach(toDateObjs, function(toDate, toFilterId) {
                        if (fromFilterId === toFilterId && fromDate.length !== 0 && toDate.length !== 0) {
                            var datePickerLength = self.getLength(fromDate, toDate);
                            allDateCollection = self.constructDatePairs(datePickerLength, fromDateObjs, toDateObjs, fromFilterId, toFilterId, allDateCollection);
                        }                        
                    });
                });
                return allDateCollection;
            },            

            isDateRangeExist: function(selectedFiltersCollection, dateRange, isDateRangeExist) {
                if (selectedFiltersCollection && selectedFiltersCollection.length) {
                    for (var idx = 0; idx < selectedFiltersCollection.length; idx++) {
                        if (selectedFiltersCollection[idx] === dateRange) {
                            isDateRangeExist = true;
                        }
                    }
                }
                return isDateRangeExist;
            },

            pushDatePickerAttr: function(rangeAttr, selectedFilters) {
                var self = this;
                var isDateRangeExist = false;
                angular.forEach(rangeAttr, function(attr) {
                    angular.forEach(attr, function(dateRange, filterId) {
                        isDateRangeExist = self.isDateRangeExist(selectedFilters[filterId], dateRange, isDateRangeExist);
                        if (!selectedFilters[filterId]) {
                            selectedFilters[filterId] = [];
                            selectedFilters[filterId].push(dateRange);
                        } else if (selectedFilters[filterId] && !isDateRangeExist) {
                            selectedFilters[filterId].push(dateRange);
                        }
                    });
                });
                return selectedFilters;
            },

            removeSelectedValues: function(fromDate, toDate, selectedAttrId, attrRange) {
                fromDate[selectedAttrId] = [];
                toDate[selectedAttrId] = [];

                for (var rangeIdx = 0; rangeIdx < attrRange.length; rangeIdx++) {
                    if (attrRange[rangeIdx][selectedAttrId]) {
                        attrRange.splice(rangeIdx, 1);
                    }
                }
            },

            isValidDateExist: function(attr, fromDate, toDate) {
                var isValidDateExist = false;
                if (fromDate[attr]) {
                    for (var dateVal = 0; dateVal < fromDate[attr].length && toDate[attr].length; dateVal++) {
                        if (fromDate[attr][dateVal] && toDate[attr][dateVal]) {
                            isValidDateExist = true;
                        }
                    }
                }
                return isValidDateExist;
            }
        };
    });