'use strict';

angular.module('p2AdvanceApp')
    .service('FilterService', function FilterService($filter, moment, DatePickerFilterService, $log) {
        return {
            transformInput: function(data) { // PlanList no longer use this function by now.
                // array of docs
                var result = [];
                var mapping = {
                    'effectiveDate': 'effectiveDates',
                    'endDate': 'effectiveDates'
                };

                //var self = this;


                angular.forEach(data, function(item) {
                    var temp = {
                        'effectiveDates': {},
                        'globalCostShare': {}
                    };
                    angular.forEach(item, function(item2, key2) {
                        var found = false;
                        angular.forEach(mapping, function(item3, key3) {
                            if (key2 === key3) {
                                temp[item3][key2] = item2;
                                found = true;
                            }
                        });
                        if (!found) {
                            if (key2 === 'planCostShares') {
                                console.log('Fix for unit test issue');
                                // temp.globalCostShare = {
                                //    'copay': [],
                                //    'coinsurance': [],
                                //    'deductible': [],
                                //    'moop': []
                                // };
                                // var values = {};
                                // angular.forEach(item2, function(item3) {
                                //    if (item3.costShareType === 'Copay') {
                                //        values.value = item3.selectedValue;
                                //        values.valueType = item3.costShareType;
                                //        temp.globalCostShare.copay.push(values);
                                //    } else if (item3.costShareType === 'Co-insurance') {
                                //        values.value = item3.selectedValue;
                                //        values.valueType = item3.costShareType;
                                //        temp.globalCostShare.coinsurance.push(values);
                                //    } else if (self.endsWith(item3.costShareType, 'Deductible')) {
                                //        values.value = item3.selectedValue;
                                //        values.valueType = item3.costShareType;
                                //        temp.globalCostShare.deductible.push(values);
                                //    } else if (self.endsWith(item3.costShareType, 'MOOP')) {
                                //        values.value = item3.selectedValue;
                                //        values.valueType = item3.costShareType;
                                //        temp.globalCostShare.moop.push(values);
                                //    }
                                // });
                            } else {
                                temp[key2] = item2;
                            }
                        }
                    });
                    result.push(temp);
                });
                return result;
            },

            endsWith: function(str, suffix) {
                return str.indexOf(suffix, str.length - suffix.length) !== -1;
            },

            formatDate: function(item) {
                if (item !== '') {
                    return $filter('date')(item, 'yyyy-MM-dd');
                } else {
                    return '';
                }
            },

            calculateYear: function(filterValue) {
                var curYear = (new Date()).getFullYear();
                if (filterValue.toString().toLowerCase() === 'current year + 1') {
                    filterValue = (curYear + 1);
                } else if (filterValue.toString().toLowerCase() === 'current year') {
                    filterValue = curYear;

                } else if (filterValue.toString().toLowerCase() === 'current year - 1') {
                    filterValue = (curYear - 1);

                }
                return filterValue;
            },

            calculateDate: function(filterValue) {
                var date = new Date();
                var startDate, endDate;
                if (filterValue.toString().toLowerCase() === 'last 6 months') {
                    date.setMonth(date.getMonth() - 6);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';

                } else if (filterValue.toString().toLowerCase() === 'next 6 months') {
                    date.setMonth(date.getMonth() + 6);
                    filterValue = '[ "' + this.formatDate(new Date()) + '" TO "' + this.formatDate(date) + '" ]';

                } else if (filterValue.toString().toLowerCase() === 'last 12 months') {
                    date.setMonth(date.getMonth() - 12);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';

                } else if (filterValue.toString().toLowerCase() === 'next 12 months') {
                    date.setMonth(date.getMonth() + 12);
                    filterValue = '[ "' + this.formatDate(new Date()) + '" TO "' + this.formatDate(date) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'this month') {
                    startDate = moment([date.getFullYear(), date.getMonth()]).toDate();
                    endDate = moment(startDate).endOf('month').toDate();
                    filterValue = '[ "' + this.formatDate(startDate) + '" TO "' + this.formatDate(endDate) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'next month') {
                    startDate = moment([date.getFullYear(), date.getMonth() + 1]).toDate();
                    endDate = moment(startDate).endOf('month').toDate();
                    filterValue = '[ "' + this.formatDate(startDate) + '" TO "' + this.formatDate(endDate) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'next 3 months') {
                    startDate = moment([date.getFullYear(), date.getMonth() + 1]).toDate();
                    var startDate2 = moment([date.getFullYear(), date.getMonth() + 3]).toDate();
                    endDate = moment(startDate2).endOf('month').toDate();
                    filterValue = '[ "' + this.formatDate(startDate) + '" TO "' + this.formatDate(endDate) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'past due date') {
                    var oldDate = new Date(1970, 1, 1);
                    date.setDate(date.getDate() - 1);
                    filterValue = '[ "' + this.formatDate(oldDate) + '" TO "' + this.formatDate(date) + '" ]';
                }
                return filterValue;
            },
            calculateDay: function(filterValue) {
                var date = new Date();
                if (filterValue.toString().toLowerCase() === 'last day') {
                    date.setDate(date.getDate() - 1);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'last 7 days') {
                    date.setDate(date.getDate() - 7);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'last 15 days') {
                    date.setDate(date.getDate() - 15);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';

                } else if (filterValue.toString().toLowerCase() === 'last 30 days') {
                    date.setDate(date.getDate() - 30);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';

                } else if (filterValue.toString().toLowerCase() === 'last 60 days') {
                    date.setDate(date.getDate() - 60);
                    filterValue = '[ "' + this.formatDate(date) + '" TO "' + this.formatDate(new Date()) + '" ]';

                }
                return filterValue;
            },
            calculateWeek: function(filterValue) {
                var date = new Date(); // get current date
                var firstDay = date.getDate() - date.getDay(); // First day is the day of the month - the day of the week;
                var lastDay;

                if (filterValue.toString().toLowerCase() === 'this week') {
                    lastDay = firstDay + 6; // last day is the first day + 6
                    var firstDate = new Date().setDate(firstDay);
                    date.setDate(lastDay);
                    filterValue = '[ "' + this.formatDate(firstDate) + '" TO "' + this.formatDate(date) + '" ]';
                } else if (filterValue.toString().toLowerCase() === 'next week') {
                    var nextWeekDay0 = date.setDate(firstDay + 7);
                    var nextWeekDay6 = date.setDate(date.getDate() + 6);

                    filterValue = '[ "' + this.formatDate(nextWeekDay0) + '" TO "' + this.formatDate(nextWeekDay6) + '" ]';
                }
                return filterValue;
            },
            // Deprecated
            getFilterQuery: function(gridApi, serviceSearchQuery, gridData, selectedFilters, filterQuery, searchType, matchCase, dateFilterOption, fromDate, toDate, level, booleanValidationRule, userInformation) {
                $log.warn('!!! Function getFilterQuery() in filter-service.js is Deprecated !!!');
                var self = this;
                var curPage = (gridApi) ? gridApi.pagination.getPage() : 1;
                var typeName = serviceSearchQuery;
                var startIndex = (curPage === 1) ? 0 : (curPage - 1) * gridData.paginationPageSize;

                var fromToDateCollection = this.getDatePickerValues(fromDate, toDate);

                var isNOTRangeFilterValue = false;
                var filterIdClone;

                angular.forEach(selectedFilters, function(filterValues, filterId) {
                    var isFirstfilterValue = true;
                    var isRangeExist = false;
                    isNOTRangeFilterValue = false;
                    filterIdClone = filterId;
                    filterQuery += ' AND ';
                    var dateFilter = false;
                    if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'batchSubmittedDate' || filterId === 'creationDate' || filterId === 'lastModificationDate') {
                        dateFilter = true;
                    } else if (filterId === 'productRegulatoryDate' || filterId === 'productDueDate') {
                        dateFilter = true;
                    } else if (filterId === 'productTypes' && angular.isDefined(userInformation)) {
                        filterId = 'productType';
                    }

                    if (filterValues) {
                        filterQuery += ' ( ';
                        angular.forEach(filterValues, function(filterValue) {
                            if (filterValue.toString().toLowerCase() !== 'date range') {
                                filterValue = self.calculateDate(filterValue);
                                filterValue = self.calculateYear(filterValue);
                                filterValue = self.calculateDay(filterValue);
                                filterValue = self.calculateWeek(filterValue);

                                if (isFirstfilterValue) {
                                    if (dateFilter) {
                                        filterQuery += filterId + ': ' + filterValue;
                                    } else if ((filterId === 'lastModifiedBy' || filterId === 'createdBy') && angular.isDefined(userInformation)) {
                                        filterValue = userInformation;
                                        filterQuery += filterId + ': "' + filterValue + '"';
                                    } else {
                                        filterQuery += filterId + ': "' + filterValue + '"';
                                    }
                                    isFirstfilterValue = false;
                                    isNOTRangeFilterValue = true;
                                } else {
                                    if (dateFilter) {
                                        filterQuery += ' OR ' + filterId + ': ' + filterValue;
                                    } else if ((filterId === 'lastModifiedBy' || filterId === 'createdBy') && angular.isDefined(userInformation)) {
                                        filterValue = userInformation;
                                        filterQuery += filterId + ': "' + filterValue + '"';
                                    } else {
                                        filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
                                    }
                                    isNOTRangeFilterValue = true;
                                }
                            } else if (!isRangeExist) {
                                filterQuery = self.getFilterQueryForRange(filterQuery, isNOTRangeFilterValue, filterIdClone, fromToDateCollection);
                                isRangeExist = true;
                                isFirstfilterValue = false;
                            }
                        });
                        filterQuery += ' ) ';
                    }
                });
                /*if (dateFilterOption !== undefined && dateObject !== undefined && dateObject !== null && dateFilterOption !== null) {
                    filterQuery += ' AND (' + dateFilterOption + ': [ "' + dateObject.fromDate + '" TO "' + dateObject.toDate + '" ])';
                }*/
                filterQuery += self.getSearchQueryForName(typeName, matchCase, searchType, booleanValidationRule);
                if (!angular.isDefined(level)) {
                    filterQuery += ' &associationExpansionLevel=1 &start=' + startIndex + '&rows=' + gridData.paginationPageSize;
                } else {
                    filterQuery += ' &associationExpansionLevel=' + level + ' &start=' + startIndex + '&rows=' + gridData.paginationPageSize;
                }
                return filterQuery;
            },
            getFilterParams: function(gridApi, serviceSearchQuery, gridData, selectedFilters, filterQuery, searchType, matchCase, dateFilterOption, fromDate, toDate, level, booleanValidationRule, userInformation) {
                var filterParams = {};

                var self = this;
                var curPage = (gridApi) ? gridApi.pagination.getPage() : 1;
                var typeName = serviceSearchQuery;
                var startIndex = (curPage === 1) ? 0 : (curPage - 1) * gridData.paginationPageSize;

                var fromToDateCollection = this.getDatePickerValues(fromDate, toDate);

                var isNOTRangeFilterValue = false;
                var filterIdClone;

                angular.forEach(selectedFilters, function(filterValues, filterId) {
                    var isFirstfilterValue = true;
                    var isRangeExist = false;
                    isNOTRangeFilterValue = false;
                    filterIdClone = filterId;
                    filterQuery += ' AND ';
                    var dateFilter = false;
                    if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'batchSubmittedDate' || filterId === 'creationDate' || filterId === 'lastModificationDate') {
                        dateFilter = true;
                    } else if (filterId === 'productRegulatoryDate' || filterId === 'productDueDate') {
                        dateFilter = true;
                    } else if (filterId === 'productTypes' && angular.isDefined(userInformation)) {
                        filterId = 'productType';
                    }

                    if (filterValues) {
                        filterQuery += ' ( ';
                        angular.forEach(filterValues, function(filterValue) {
                            if (filterValue.toString().toLowerCase() !== 'date range') {
                                filterValue = self.calculateDate(filterValue);
                                filterValue = self.calculateYear(filterValue);
                                filterValue = self.calculateDay(filterValue);
                                filterValue = self.calculateWeek(filterValue);

                                if (isFirstfilterValue) {
                                    if (dateFilter) {
                                        filterQuery += filterId + ': ' + filterValue;
                                    } else if ((filterId === 'lastModifiedBy' || filterId === 'createdBy') && angular.isDefined(userInformation)) {
                                        filterValue = userInformation;
                                        filterQuery += filterId + ': "' + filterValue + '"';
                                    } else {
                                        filterQuery += filterId + ': "' + filterValue + '"';
                                    }
                                    isFirstfilterValue = false;
                                    isNOTRangeFilterValue = true;
                                } else {
                                    if (dateFilter) {
                                        filterQuery += ' OR ' + filterId + ': ' + filterValue;
                                    } else if ((filterId === 'lastModifiedBy' || filterId === 'createdBy') && angular.isDefined(userInformation)) {
                                        filterValue = userInformation;
                                        filterQuery += filterId + ': "' + filterValue + '"';
                                    } else {
                                        filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
                                    }
                                    isNOTRangeFilterValue = true;
                                }
                            } else if (!isRangeExist) {
                                filterQuery = self.getFilterQueryForRange(filterQuery, isNOTRangeFilterValue, filterIdClone, fromToDateCollection);
                                isRangeExist = true;
                                isFirstfilterValue = false;
                            }
                        });
                        filterQuery += ' ) ';
                    }
                });
                /*if (dateFilterOption !== undefined && dateObject !== undefined && dateObject !== null && dateFilterOption !== null) {
                    filterQuery += ' AND (' + dateFilterOption + ': [ "' + dateObject.fromDate + '" TO "' + dateObject.toDate + '" ])';
                }*/
                filterQuery += self.getSearchQueryForName(typeName, matchCase, searchType, booleanValidationRule);

                angular.extend(filterParams, {
                    q: filterQuery
                });

                if (!angular.isDefined(level)) {
                    level = 1;
                }

                angular.extend(filterParams, {
                    start: startIndex,
                    rows: gridData.paginationPageSize,
                    associationExpansionLevel: level
                });

                return filterParams;
            },
            getDatePickerValues: function(fromDate, toDate) {
                var allDateCollection = [];
                var fromDateObjs = fromDate;
                var toDateObjs = toDate;
                allDateCollection = DatePickerFilterService.getAllDateCollection(allDateCollection, fromDateObjs, toDateObjs);
                return allDateCollection;
            },
            /*getFilterQuery: function(gridApi, serviceSearchQuery, gridData, selectedFilters, filterQuery, searchType, matchCase, dateFilterOption, dateObject) {
                var self = this;
                var curPage = (gridApi) ? gridApi.pagination.getPage() : 1;
                var typeName = serviceSearchQuery;
                var startIndex = (curPage === 1) ? 0 : (curPage - 1) * gridData.paginationPageSize;

                angular.forEach(selectedFilters, function(filterValues, filterId) {
                    var isFirstfilterValue = true;
                    filterQuery += ' AND ';
            */
            /* Included to remove range caledar option when 'All' filter is selected */
            /*      if (filterValues.indexOf('range') !== -1) {
                        filterValues.splice(filterValues.indexOf('range'), 1);
                    }
                    if (filterValues) {
                        filterQuery += ' ( ';
                        angular.forEach(filterValues, function(filterValue) {
                            filterValue = self.calculateDate(filterValue);
                            filterValue = self.calculateYear(filterValue);
                            filterValue = self.calculateDay(filterValue);

                            if (isFirstfilterValue) {
                                if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'batchSubmittedDate') {
                                    filterQuery += filterId + ': ' + filterValue;
                                } else {
                                    filterQuery += filterId + ': "' + filterValue + '"';
                                }

                                isFirstfilterValue = false;
                            } else {
                                if (filterId === 'effectiveDate' || filterId === 'endDate' || filterId === 'batchSubmittedDate') {
                                    filterQuery += ' OR ' + filterId + ': ' + filterValue;
                                } else {
                                    filterQuery += ' OR ' + filterId + ': "' + filterValue + '"';
                                }

                            }
                        });
                        filterQuery += ' ) ';
                    }
                });
                if (dateFilterOption !== undefined && dateObject !== undefined && dateObject !== null && dateFilterOption !== null) {
                    filterQuery += ' AND (' + dateFilterOption + ': [ "' + dateObject.fromDate + '" TO "' + dateObject.toDate + '" ])';
                }
                filterQuery += self.getSearchQueryForName(typeName, matchCase, searchType);
                filterQuery += ' &associationExpansionLevel=1 &start=' + startIndex + '&rows=' + gridData.paginationPageSize;
                return filterQuery;
            },*/

            filterAndrefresh: function(loadedList, list) { // PlanList no longer use this function by now.
                var result = angular.copy(loadedList);
                list = this.refreshGridData(result, list);
                return list;
            },

            refreshGridData: function(data, list) {
                list = [];
                angular.forEach(data, function(item) {
                    this.push(item);
                }, list);
                return list;
            },

            queryData: function(selectedFilters, selectedId, objs, gridOptions) {
                if (!selectedId || selectedId.toString().trim().length === 0) {
                    throw 'Invalid Argument: selectedId is not valid';
                }
                if (objs.length === 0) {
                    if (selectedFilters[selectedId]) {
                        delete selectedFilters[selectedId];
                    }
                } else {
                    selectedFilters[selectedId] = objs;
                }
                gridOptions.paginationCurrentPage = 1;
                return selectedFilters;
            },

            updateFilterMeta: function(filtersNeedToBeUpdateWithList, loadedList, filtersGroups, listType) {
                var self = this;
                var attributesCollection = [];
                angular.forEach(filtersNeedToBeUpdateWithList, function(filterVal, filterKey) {
                    var filterValues = self.filterValuesFinder(filterKey, loadedList);
                    var newValue = self.filterValuesMaker(filterVal, filterKey, filterValues);
                    var oldValue = [];
                    attributesCollection = self.setValueByKey(filtersGroups, filterVal, filterKey, newValue, oldValue, attributesCollection, listType);
                    if (oldValue.length > 1 || oldValue.length === 0) {
                        throw 'more than one field found';
                    }
                });
                return attributesCollection;
            },

            filterValuesFinder: function(filterKey, loadedList) {
                var values = {};
                angular.forEach(loadedList, function(list) {
                    var creator = list[filterKey];
                    if (creator !== undefined && creator !== null && creator !== '') {
                        if (angular.isArray(creator)) {
                            angular.forEach(creator, function(creatorValue) {
                                values[creatorValue] = creatorValue;
                            });
                        } else {
                            values[creator] = creator;
                        }
                    }
                });
                return values;
            },
            // End of filterValuesFinder

            filterValuesMaker: function(filterVal, filterKey, values) {
                var filterValues = [];
                if (filterKey === 'createdBy') {
                    filterValues = [{
                        'AttributeId': filterKey,
                        'AttributeName': filterVal,
                        'AttributeValue': 'Myself ??',
                        'DisplayValue': 'Myself ??'
                    }];
                }
                angular.forEach(values, function(item) {
                    var attrObj = filterVal + filterKey + item;
                    attrObj = {};
                    attrObj['AttributeId'] = filterKey;
                    attrObj['AttributeName'] = filterVal;
                    attrObj['AttributeValue'] = item;
                    attrObj['DisplayValue'] = item;
                    filterValues.push(attrObj);
                });
                return filterValues;
            }, // End of filterValuesMaker

            setValueByKey: function(obj, criteria, criteriaKey, newValue, oldValue, attributesCollection, listType) {
                var self = this;
                var filterCriteriaKey = criteriaKey;
                var filterType = listType;
                angular.forEach(obj, function(item, key) {
                    if (key.toString().toLowerCase() === criteria.toString().toLowerCase()) {
                        oldValue.push(item);
                        obj[key] = newValue;
                        attributesCollection = self.checkFilterType(listType, newValue, criteriaKey, attributesCollection);
                    } else {
                        if (angular.isArray(item) || angular.isObject(item)) {
                            self.setValueByKey(item, criteria, filterCriteriaKey, newValue, oldValue, attributesCollection, filterType);
                        }
                    }
                });
                return attributesCollection;
            },

            checkFilterType: function(listType, newValue, criteriaKey, attributesCollection) {
                var self = this;
                if (listType === 'document' || listType === 'template') {
                    attributesCollection = self.matchFilterOptions(newValue, criteriaKey, attributesCollection);
                }
                return attributesCollection;
            },

            matchFilterOptions: function(customizedAttr, objKey, attributesCollection) {
                var attrColObj = {};
                if (objKey === 'createdBy') {
                    attrColObj['createdByAttributes'] = customizedAttr;
                    attributesCollection.push(attrColObj);
                } else if (objKey === 'numProviderTiers') {
                    attrColObj['productTiersAttributes'] = customizedAttr;
                    attributesCollection.push(attrColObj);
                }
                return attributesCollection;
            },
            getSearchQueryForName: function(searchQuery, matchCase, searchType, booleanValidationRule) {
                var searchQueryForName = '';

                if (angular.isDefined(searchQuery) && searchQuery.trim().length > 0 && angular.isUndefined(booleanValidationRule)) {
                    if (matchCase) {
                        searchQueryForName += ' AND =' + searchType + ':"' + searchQuery + '" ';
                    } else {
                        searchQueryForName += ' AND ' + searchType + ':"' + searchQuery + '" ';
                    }
                } else if (angular.isDefined(searchQuery) && searchQuery.trim().length > 0 && angular.isDefined(booleanValidationRule)) {
                    searchQuery = searchQuery.replace(/['"]+/g, '');
                    if (matchCase) {
                        searchQueryForName += ' AND ( =name: "' + searchQuery + '" OR =validationMessage: "' + searchQuery + '" OR =expression: "' + searchQuery + '" ) ';
                    } else {
                        searchQueryForName += ' AND ( name: "' + searchQuery + '" OR validationMessage: "' + searchQuery + '" OR expression: "' + searchQuery + '" ) ';
                    }
                }
                return searchQueryForName;
            },
            getFilterQueryDocGen: function(gridApi, serviceSearchQuery, gridData, selectedFilters, filterQuery, matchCase) {
                var self = this;
                var curPage = (gridApi) ? gridApi.pagination.getPage() : 1;
                var startIndex = (curPage === 1) ? 0 : (curPage - 1) * gridData.paginationPageSize;

                angular.forEach(selectedFilters, function(selectedIdToObjs) {

                    if (selectedIdToObjs.objs.length > 0) {
                        var isFirstfilterValue = true;
                        filterQuery += ' AND ';
                        filterQuery += ' ( ';
                        angular.forEach(selectedIdToObjs.objs, function(filterValue) {

                            filterValue = self.calculateDate(filterValue);
                            filterValue = self.calculateYear(filterValue);
                            filterValue = self.calculateDay(filterValue);

                            if (isFirstfilterValue) {
                                if (selectedIdToObjs.selectedId === 'effectiveDate' || selectedIdToObjs.selectedId === 'endDate' || selectedIdToObjs.selectedId === 'lastModificationDate') {
                                    filterQuery += selectedIdToObjs.selectedId + ': ' + filterValue;
                                } else {
                                    filterQuery += selectedIdToObjs.selectedId + ': "' + filterValue + '"';
                                }

                                isFirstfilterValue = false;
                            } else {
                                if (selectedIdToObjs.selectedId === 'effectiveDate' || selectedIdToObjs.selectedId === 'endDate' || selectedIdToObjs.selectedId === 'lastModificationDate') {
                                    filterQuery += ' OR ' + selectedIdToObjs.selectedId + ': ' + filterValue;
                                } else {
                                    filterQuery += ' OR ' + selectedIdToObjs.selectedId + ': "' + filterValue + '"';
                                }

                            }


                        });
                        filterQuery += ' ) ';
                    }
                });
                filterQuery += self.getSearchQueryForName(serviceSearchQuery, matchCase, 'name');
                filterQuery += '&associationExpansionLevel=1 &start=' + startIndex + '&rows=' + gridData.paginationPageSize;
                return filterQuery;

            },
            getFilterQueryBatchSummary: function(batchJobsObjectId, filterQuery, gridBatchJobs, gridApi) {
                var curPage = (gridApi) ? gridApi.pagination.getPage() : 1;
                var startIndex = (curPage === 1) ? 0 : (curPage - 1) * gridBatchJobs.paginationPageSize;
                filterQuery += ' AND ( ';
                var length = 1;
                angular.forEach(batchJobsObjectId, function(batchJob) {
                    if (batchJobsObjectId.length !== length) {
                        filterQuery += 'parentBatchJob : "' + batchJob + '" OR ';
                    } else {
                        filterQuery += 'parentBatchJob : "' + batchJob + '" )';
                    }
                    length += 1;
                });
                filterQuery += ' &associationExpansionLevel=-1 &start=' + startIndex + '&rows=' + gridBatchJobs.paginationPageSize;
                return filterQuery;
            },
            getFilterQueryBatchJobsOfOneBatch: function(batchObjectId, filterQuery, gridBatchJobs, gridApi) {
                var curPage = (gridApi) ? gridApi.pagination.getPage() : 1;
                var startIndex = (curPage === 1) ? 0 : (curPage - 1) * gridBatchJobs.paginationPageSize;
                filterQuery += ' AND ( ';
                filterQuery += '=parentBatch : "' + batchObjectId + '" )';
                filterQuery += ' &associationExpansionLevel=-1 &start=' + startIndex + '&rows=' + gridBatchJobs.paginationPageSize;
                return filterQuery;
            },

            getFilterQueryForRange: function(filterQuery, isNOTRangeFilterValue, filterIdClone, fromToDateCollection) {
                var self = this;
                angular.forEach(fromToDateCollection, function(dateObj) {
                    var formatFromDate, formatToDate, filterValue, filterTypeClone;
                    if (dateObj) {
                        angular.forEach(dateObj, function(dateVal, dateType) {
                            angular.forEach(dateVal, function(range, filterType) {
                                filterTypeClone = filterType;
                                if (dateType === 'fromDate') {
                                    formatFromDate = self.formatDate(range);
                                } else if (dateType === 'toDate') {
                                    formatToDate = self.formatDate(range);
                                }
                            });
                        });
                        filterValue = '[ "' + formatFromDate + '" TO "' + formatToDate + '" ]';
                        if (filterIdClone && filterIdClone === filterTypeClone && isNOTRangeFilterValue) {
                            filterQuery += ' OR ' + filterTypeClone + ': ' + filterValue;
                        } else if (filterIdClone === filterTypeClone) {
                            filterQuery += filterTypeClone + ':' + filterValue;
                        }
                    }
                });
                return filterQuery;
            }

        };
    });