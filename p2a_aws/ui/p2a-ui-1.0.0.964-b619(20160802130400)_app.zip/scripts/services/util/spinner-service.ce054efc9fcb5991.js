'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.SpinnerService
 * @description
 * # SpinnerService
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
    .factory('SpinnerService', function($rootScope, $log) {
        var numLoadings = 0;

        return {
            show: function() {
                numLoadings++;
                // Show loader
                $rootScope.$broadcast('ppm.spinner.show');
                $log.log('ppm.spinner.show  broadcasted');
                $log.log('total request =  ' + numLoadings);
            },
            hide: function() {
                if ((--numLoadings) === 0) {
                    // Hide loader
                    $rootScope.$broadcast('ppm.spinner.hide');
                    $log.log('ppm.spinner.hide  broadcasted');
                }

                $log.log('total request left =  ' + numLoadings);
            }
        };
    });