'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.APIInterceptor
 * @description
 * # APIInterceptor
 * Factory in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
  .factory('APIInterceptor', function ($injector, $rootScope, $q) {
    var START_HTTP_SERVER_ERRORS = 500;

    var ERR_ADDRESS_UNREACHABLE = 0;

    var httpCodeErrors = {
          0 : 'ServerError:NoInternet',
        // 4xx Client Error  
        400 : 'auth:BadRequest',
        401 : 'auth:unauthorized',
        403 : 'auth:forbidden',
        404 : 'ClientError:NotFound',
        405 : 'ClientError:MethodNotAllowed',
        408 : 'ClientError:RequestTimeout',
        409 : 'ClientError:Conflict',
        413 : 'ClientError:PayloadTooLarge',
        //  5xx Server Errors
        500 : 'ServerError:InternalServerError',
        501 : 'ServerError:NotImplemented',
        503 : 'ServerError:ServiceUnavailable'
    };

    function isServerError(status) {
      return (status >= START_HTTP_SERVER_ERRORS);
    }

    function isOffLine(status) {
      return status === ERR_ADDRESS_UNREACHABLE;
    }

    // Public API here
    return {
      request: function (config) {
          $injector.invoke(function ($auth) {
            if ($auth.isAuthenticated()) {
              config.headers.Authorization = $auth.getApiToken();
            }  
          });

          $injector.invoke(function (userAuthorizationManager, $state) {
            if (!userAuthorizationManager.isAuthorized(config.method, config.url, $state.params)) {
              // 401 auth:unauthorized
              $rootScope.$emit(httpCodeErrors[401], config.method);
            }
          });

          return config;
      },

      responseError : function(response) {
          if (response.status || isServerError(response.status) || isOffLine(response.status)) {
              if (!response.config.skipInterceptorError) {
                  $rootScope.$emit(httpCodeErrors[response.status], response.data);
              }
          }

          return $q.reject(response);
      }
    };
  });
