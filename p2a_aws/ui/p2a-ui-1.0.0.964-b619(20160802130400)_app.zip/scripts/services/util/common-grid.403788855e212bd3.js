'use strict';

angular.module('p2AdvanceApp')
    .factory('CommonGrid', function() {
        // overriding functions from core grid
        return {
            onRegisterApi : function(api) {
                if (api && api.selection && api.selection.selectAllVisibleRows) {
                    // "select all" and "deselect all" are intended only for items on current page
                    api.selection.raise.rowSelectionChangedBatch = function (rows) {
                        if(rows && rows.length > 0) {
                            var firstOnPage = (api.grid.options.paginationCurrentPage - 1) * api.grid.options.paginationPageSize;
                            var lastOnPage = (api.grid.options.paginationCurrentPage * api.grid.options.paginationPageSize) - 1;
                            rows.forEach(function (row) {
                                var inx = api.grid.rows.indexOf(row);
                                if((inx < firstOnPage) || (inx > lastOnPage)) {
                                    row.isSelected = !row.isSelected;
                                }
                            });
                        }
                    };
                    api.selection.raise.rowSelectionChanged = function() {
                        api.pagination.processSelectAll();
                    };
                    api.pagination.nextPage = function () {
                        if (!api.grid.options.enablePagination) {
                            return;
                        }
                        if (api.grid.options.totalItems > 0) {
                            api.grid.options.paginationCurrentPage = Math.min(
                                    api.grid.options.paginationCurrentPage + 1,
                                api.pagination.getTotalPages()
                            );
                        } else {
                            api.grid.options.paginationCurrentPage++;
                        }
                        api.pagination.processSelectAll();
                    };
                    api.pagination.previousPage = function () {
                        if (!api.grid.options.enablePagination) {
                            return;
                        }
                        api.grid.options.paginationCurrentPage = Math.max(api.grid.options.paginationCurrentPage - 1, 1);
                        api.pagination.processSelectAll();
                    };
                    api.pagination.seek = function (page) {
                        if (!api.grid.options.enablePagination) {
                            return;
                        }
                        if (!angular.isNumber(page) || page < 1) {
                            throw 'Invalid page number: ' + page;
                        }
                        api.grid.options.paginationCurrentPage = Math.min(page, api.pagination.getTotalPages());
                        api.pagination.processSelectAll();
                    };
                    api.pagination.processSelectAll = function() {
                        if (api.grid.rows.length < 1) {
                            api.grid.selection.selectAll = false;
                            return;
                        }
                        api.grid.selection.selectAll = true;
                        var firstOnPage = (api.grid.options.paginationCurrentPage - 1) * api.grid.options.paginationPageSize;
                        var lastOnPage = (api.grid.options.paginationCurrentPage * api.grid.options.paginationPageSize) - 1;
                        api.grid.rows.forEach(function (row, inx) {
                            if ((inx >= firstOnPage) && (inx <= lastOnPage) && !row.isSelected) {
                                api.grid.selection.selectAll = false;
                                return;
                            }
                        });
                    };
                }
            }
        };
    });