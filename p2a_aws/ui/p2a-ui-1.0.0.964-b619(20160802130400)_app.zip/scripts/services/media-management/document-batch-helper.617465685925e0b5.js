'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.DocumentBatchHelper
 * @description
 * # DocumentBatchHelper
 * Service in the p2AdvanceApp MediaManagement for document generation and batch business logic
 */
angular.module('p2AdvanceApp')
    .factory('DocumentBatchHelper',
    ['$http', '$q', '$log', 'DocumentDataFactory', 'BatchService', 
    function ($http, $q, $log, DocumentDataFactory, BatchService) {

        function DocumentBatchHelper() {
            var self = this;

            var generateSysPlanDocName = function (planName, planYear, documentType) {
                var sysGeneratedDocName = '';

                if (angular.isDefined(planYear) && planYear !== '') {
                    sysGeneratedDocName = planYear + '-' + planName + '-' + documentType;
                }
                else {
                    sysGeneratedDocName = planName + '-' + documentType;
                }

                return sysGeneratedDocName + '-' + Date.now();  //add ticks at the end, PONHR-1455
            };

            var generateSysUnitDocName = function (unitName, unitYear, documentType) {
                var sysGeneratedDocName = '';

                if (angular.isDefined(unitYear) && unitYear !== '') {
                    sysGeneratedDocName = unitYear + '-' + unitName + '-' + documentType;
                }
                else {
                    sysGeneratedDocName = unitName + '-' + documentType;
                }

                return sysGeneratedDocName + '-' + Date.now();  //add ticks at the end
            };


            /* remove batchJob, batchJobTask (if toDeleteBatchJobTasks is true), batchJobTaskDocument (if toDeleteTaskDocument is true) */
            var removeBatchJobById = function (batchJobObjectId, toDeleteBatchJobTasks, toDeleteTaskDocument) {
                var defer = $q.defer();

                BatchService.deleteBatchJob(batchJobObjectId)
                    .then(function () {
                        if (toDeleteBatchJobTasks) {
                            BatchService.getBatchJobDetails(batchJobObjectId)
                            .success(function (data) {
                                angular.forEach(data.batchJobTasks, function (batchJobTask) {
                                    BatchService.deleteBatchJobTask(batchJobTask.objectId)
                                    .then(function () {
                                        $log.info('BatchJobTask ' + batchJobTask.objectId + ' is deleted successfully.');

                                        if (toDeleteTaskDocument) {
                                            angular.forEach(batchJobTask.taskDocument, function (batchJobTaskDocument) {
                                                BatchService.deleteBatchJobTaskDocument(batchJobTaskDocument.objectId)
                                                .then(function () {
                                                    $log.info('BatchJobTaskDocument ' + batchJobTaskDocument.objectId + ' is deleted successfully.');
                                                    defer.resolve();

                                                }, function (reason) {
                                                    $log.error(reason);
                                                    defer.reject(reason);
                                                });
                                            });
                                        }
                                        else {
                                            defer.resolve();  // if just delete BatchJobTask, resolve it now
                                        }

                                    }, function (reason) {
                                        $log.error(reason);
                                        defer.reject(reason);
                                    });
                                });
                            })
                            .error(function (reason) {
                                $log.error(reason);
                                defer.reject(reason);
                            });
                        }
                        else {
                            defer.resolve();  // if just delete BatchJob, resolve it now
                        }

                    }, function (reason) {
                        $log.error(reason);
                        defer.reject(reason);
                    });

                return defer.promise;
            };

            var updateBatchJobSingleSource = function (scopeObject) {
                var defer = $q.defer();

                var currentBatchJobTaskBody = {};
                var docNameForEntity = '';
                var sourceTypes = '';
                var detailedSourceTypesAndNames = '';

                if (scopeObject.selectedPlans && scopeObject.selectedPlans.length > 0) {  //currently only support "Plan"
                    docNameForEntity = generateSysPlanDocName(scopeObject.selectedPlans[0].name, scopeObject.selectedPlans[0].planYear, scopeObject.selectedDocumentType.value);
                    sourceTypes = '1 Plan';  // for single source batch every batch job only contains one plan
                    detailedSourceTypesAndNames = scopeObject.selectedPlans[0].name + ' (Plan)';
                }

                // if this row's document name changed by the pencil icon before, use that name
                if (scopeObject.documentNameEdited && scopeObject.documentNameEdited.length > 0) {
                    for (var i = 0, j = scopeObject.documentNameEdited.length; i < j; i++) {
                        if (scopeObject.documentNameEdited[i].batchJobObjectId === scopeObject.currentBatchJobInEditing.batchJobObjectId) {
                            docNameForEntity = scopeObject.documentNameEdited[i].newDocName;
                            break;
                        }
                    }
                }

                if (scopeObject.selectedPlans && scopeObject.selectedPlans.length > 0) {  // if it is a Plan document
                    // if it is a single source with prefix such as "rx;"
                    if (scopeObject.selectedTemplate.templateSources &&
                        scopeObject.selectedTemplate.templateSources.length === 1 &&
                        scopeObject.selectedTemplate.templateSources[0].sourceIndicator !== 'NA') {

                        currentBatchJobTaskBody = {
                            documentName: docNameForEntity,
                            dataSourceNames: scopeObject.selectedPlans[0].name,
                            sourceTypes: sourceTypes,
                            fileFormat: scopeObject.selectedDocFormats.toString(),
                            generationType: 'Single',
                            documentAssociatons: [],
                            templateId: scopeObject.selectedTemplate.objectId,
                            templateName: scopeObject.selectedTemplate.name,
                            templateDocType: scopeObject.selectedDocumentType.value,
                            templateSources: {
                                baseSourceIndicator: 'Plan-' + scopeObject.selectedTemplate.templateSources[0].sourceIndicator,
                                dataSources: [
                                    {
                                        ID: scopeObject.selectedPlans[0].objectId,
                                        SourceType: 'Plan',
                                        SourceIndicator: scopeObject.selectedTemplate.templateSources[0].sourceIndicator
                                    }]
                            },
                            watermark: scopeObject.selectedWatermark.text,
                            dataSourceYear: scopeObject.selectedPlans[0].planYear,
                            isBatchJobMultiSource: scopeObject.currentBatch.isMultiSource,
                            sourceTypesAndNames: detailedSourceTypesAndNames
                        };
                    }
                    else {
                        currentBatchJobTaskBody = {
                            documentName: docNameForEntity,
                            dataSourceNames: scopeObject.selectedPlans[0].name,
                            sourceTypes: sourceTypes,
                            fileFormat: scopeObject.selectedDocFormats.toString(),
                            generationType: 'Single',
                            documentAssociatons: [],
                            templateId: scopeObject.selectedTemplate.objectId,
                            templateName: scopeObject.selectedTemplate.name,
                            templateDocType: scopeObject.selectedDocumentType.value,
                            templateSources: {
                                baseSourceIndicator: 'Plan-NA',
                                dataSources: [
                                    {
                                        ID: scopeObject.selectedPlans[0].objectId,
                                        SourceType: 'Plan',
                                        SourceIndicator: 'NA'
                                    }]
                            },
                            watermark: scopeObject.selectedWatermark.text,
                            dataSourceYear: scopeObject.selectedPlans[0].planYear,
                            isBatchJobMultiSource: scopeObject.currentBatch.isMultiSource,
                            sourceTypesAndNames: detailedSourceTypesAndNames
                        };
                    }
                }

                var batchJobTaskJsonData = {
                    batchJobTaskStatus: 'Pending',
                    batchJobTaskBody: JSON.stringify(currentBatchJobTaskBody)
                };

                if (scopeObject.currentBatchJobInEditing.batchJobTaskObjectId) {  // update the batchJobTask
                    BatchService.updateBatchJobTask(batchJobTaskJsonData, scopeObject.currentBatchJobInEditing.batchJobTaskObjectId)
                    .then(function () {
                        var batchJobTaskDocumentJsonData = {
                            batchJobTaskDocumentDocumentType: scopeObject.selectedDocumentType.value,
                            batchJobTaskDocumentTemplateId: scopeObject.selectedTemplate.objectId,
                            batchJobTaskDocumentDataSourceIds: scopeObject.selectedPlans[0].objectId,
                            batchJobTaskDocumentDataSourceType: 'Plan',
                            batchJobTaskDocumentWatermark: scopeObject.selectedWatermark.text
                        };

                        if (scopeObject.currentBatchJobInEditing.batchJobTaskDocumentObjectId) {
                            BatchService.updateBatchJobTaskDocument(batchJobTaskDocumentJsonData, scopeObject.currentBatchJobInEditing.batchJobTaskDocumentObjectId)
                            .then(function () {

                                defer.resolve();

                            }, function (reason) {
                                $log.error(reason);
                                defer.reject(reason);
                            });
                        }

                    }, function (reason) {
                        $log.error(reason);
                        defer.reject(reason);
                    });
                }

                return defer.promise;

            };

            var updateBatchJobMultiSource = function (scopeObject) {
                var defer = $q.defer();

                /*jshint maxcomplexity:16*/
                self.createMultiSourceDocName(scopeObject).then(function (genDocName) {
                    var dataSourceNames = []; //used in batchJobTaskBody json data
                    var dataSourceIds = []; //used in batchJobTaskBody json data
                    var docNameForEntity = genDocName;


                    var sourceTypes = '';
                    var detailedSourceTypesAndNames = '';

                    var planTypeCount = 0;
                    var productTypeCount = 0;
                    var accountTypeCount = 0;
                    var offeringTypeCount = 0;

                    var planNames = '';
                    var productNames = '';
                    var accountName = '';   //only one account can be selected
                    var offeringName = '';  //only one offering can be selected

                    angular.forEach(scopeObject.selectedSources, function (source) {
                        dataSourceNames.push(source.name);
                        dataSourceIds.push(source.objectId);

                        if (source.sourceType === 'Plan' && source.sourceIndicator && source.sourceIndicator !== '') {
                            planTypeCount++;
                            planNames += source.name + ' (Plan), ';
                        }
                        else if (source.sourceType === 'Product' && source.sourceIndicator && source.sourceIndicator !== '') {
                            productTypeCount++;
                            productNames += source.name + ' (Product), ';
                        }
                        else if (source.sourceType === 'Account') {
                            accountTypeCount++;
                            accountName += source.name + ' (Account), ';
                        }
                    });
                    // scopeObject.selectedSources don't contain Offering, so we add Offering separately
                    if (scopeObject.selectedOfferings && scopeObject.selectedOfferings.length > 0) {
                        offeringTypeCount++;
                        offeringName += scopeObject.selectedOfferings[0].name + ' (Offering), ';
                    }

                    if (accountTypeCount > 0) {
                        sourceTypes += accountTypeCount + ' Account, ';   //only one account can be selected at a time
                    }
                    if (offeringTypeCount > 0) {
                        sourceTypes += offeringTypeCount + ' Offering';   //only one offering can be selected at a time

                        if (planTypeCount > 0) {
                            sourceTypes += planTypeCount === 1 ? ' (' + planTypeCount + ' Plan), ' : ' (' + planTypeCount + ' Plans), ';
                        }
                        if (productTypeCount > 0) {
                            sourceTypes += productTypeCount === 1 ? ' (' + productTypeCount + ' Product), ' : ' (' + productTypeCount + ' Products), ';
                        }
                    }
                    else {
                        if (planTypeCount > 0) {
                            sourceTypes += planTypeCount === 1 ? planTypeCount + ' Plan, ' : planTypeCount + ' Plans, ';
                        }
                        if (productTypeCount > 0) {
                            sourceTypes += productTypeCount === 1 ? productTypeCount + ' Product, ' : productTypeCount + ' Products, ';
                        }
                    }

                    sourceTypes = sourceTypes.replace(/,\s*$/, '');  //replace last comma

                    detailedSourceTypesAndNames = accountName + offeringName + planNames + productNames;
                    detailedSourceTypesAndNames = detailedSourceTypesAndNames.replace(/,\s*$/, '');

                    var docGenPayload = self.buildMultiSourceDocumentJson(scopeObject, genDocName);

                    // if this row's document name changed by the pencil icon before, use that name
                    if (scopeObject.documentNameEdited && scopeObject.documentNameEdited.length > 0) {
                        for (var i = 0, j = scopeObject.documentNameEdited.length; i < j; i++) {
                            if (scopeObject.documentNameEdited[i].batchJobObjectId === scopeObject.currentBatchJobInEditing.batchJobObjectId) {
                                docNameForEntity = scopeObject.documentNameEdited[i].newDocName;
                                break;
                            }
                        }
                    }

                    var currentBatchJobTaskBody = {
                        documentName: docNameForEntity,
                        dataSourceNames: dataSourceNames.toString(),
                        sourceTypes: sourceTypes,
                        fileFormat: scopeObject.selectedDocFormats.toString(),
                        generationType: docGenPayload.generationType,
                        documentAssociatons: docGenPayload.associations,
                        templateId: scopeObject.selectedTemplate.objectId,
                        templateName: scopeObject.selectedTemplate.name,
                        templateDocType: scopeObject.selectedDocumentType.value,
                        templateSources: docGenPayload.templateSources,
                        watermark: scopeObject.selectedWatermark.text,
                        docTypes: scopeObject.selectedDocFormats.toString(),
                        isBatchJobMultiSource: scopeObject.isMultiSource,
                        sourceTypesAndNames: detailedSourceTypesAndNames
                    };

                    var batchJobTaskJsonData = {
                        batchJobTaskStatus: 'Pending',
                        batchJobTaskBody: JSON.stringify(currentBatchJobTaskBody)
                    };

                    if (scopeObject.currentBatchJobInEditing.batchJobTaskObjectId) {  // update the batchJobTask
                        BatchService.updateBatchJobTask(batchJobTaskJsonData, scopeObject.currentBatchJobInEditing.batchJobTaskObjectId)
                        .then(function () {
                            var batchJobTaskDocumentJsonData = {
                                batchJobTaskDocumentDocumentType: scopeObject.selectedDocumentType.value,
                                batchJobTaskDocumentTemplateId: scopeObject.selectedTemplate.objectId,
                                batchJobTaskDocumentDataSourceIds: dataSourceIds.toString(),   //a list of plan objectIds
                                batchJobTaskDocumentDataSourceType: 'Plan',
                                batchJobTaskDocumentWatermark: scopeObject.selectedWatermark.text
                            };

                            if (scopeObject.currentBatchJobInEditing.batchJobTaskDocumentObjectId) {
                                BatchService.updateBatchJobTaskDocument(batchJobTaskDocumentJsonData, scopeObject.currentBatchJobInEditing.batchJobTaskDocumentObjectId)
                                .then(function () {
                                    defer.resolve();
                                }, function (reason) {
                                    $log.error(reason);
                                    defer.reject(reason);
                                });
                            }

                        }, function (reason) {
                            $log.error(reason);
                            defer.reject(reason);
                        });
                    }

                });

                return defer.promise;
            };

            self.generateSysPlanDocName = function (planName, planYear, documentType) {
                return generateSysPlanDocName(planName, planYear, documentType);
            };

            self.generateSysUnitDocName = function (unitName, unitYear, documentType) {
                return generateSysUnitDocName(unitName, unitYear, documentType);
            };

            self.createMultiSourceDocName = function (scopeObject) {
                var defer = $q.defer();
                var baseSource = null;
                var basePlan = null;
                var otherPlanNames = [];
                var planYear = '';
                var docName = '';

                var sources = scopeObject.selectedTemplate.templateSources;
                for (var i = 0; i < sources.length; i++) {
                    if (sources[i].isBaseSource) {
                        baseSource = sources[i];
                        break;
                    }
                }

                var planSources = scopeObject.selectedSources;
                for (var j = 0; j < planSources.length; j++) {
                    if (planSources[j].sourceIndicator === baseSource.sourceIndicator) {
                        basePlan = planSources[j];
                        break;
                    }
                }

                DocumentDataFactory.getPlanById(basePlan.objectId)
                    .success(function (data) {
                        if (data.planYear !== null && angular.isDefined(data.planYear)) {  //data.planYear returned as "planYear": "2015" or "planYear": "2015, 2016", etc.
                            planYear = data.planYear;
                        }
                        // scopeObject.selectedSources already passed validation at this point
                        angular.forEach(scopeObject.selectedSources, function (source) {
                            if (!source.isBaseSource && source.sourceIndicator && source.sourceIndicator !== '') {
                                otherPlanNames.push(source.name);
                            }
                        });
                        /* docName format: planYear-basePlanName-<up to 3 other planNames>-docType-timestamp */
                        docName += planYear;
                        if (planYear.length > 0) {
                            docName += '-' + basePlan.name;
                        }
                        for (var i = 0; i < 3 && i < otherPlanNames.length; i++) {
                            docName += '-' + otherPlanNames[i].substring(0, 50);
                        }
                        docName += '-' + scopeObject.selectedDocumentType.value + '-' + Date.now();  // add ticks, PONHR-1455
                        defer.resolve(docName);

                    })
                    .error(function () {
                        defer.reject();
                    });

                return defer.promise;
            };

            /* main function to create BatchJob, BatchJobTask and all associations needed for single source batch */
            self.createBatchJobForSingleSource = function (entityType, entity, scopeObject) {

                var defer = $q.defer();

                if (!scopeObject) {
                    defer.reject('Invalid parameter.');
                }

                var currentBatchJobObjectId = '';
                var currentBatchJobTaskObjectId = '';
                var currentBatchJobTaskDocObjectId = '';
                var currentBatchJobJsonData = {};
                var currentBatchJobTaskJsonData = {};
                var currentBatchJobTaskBody = {};
                var currentBatchJobTaskDocumentJsonData = {};
                var docNameForEntity = '';
                var sourceTypes = '';
                var detailedSourceTypesAndNames = '';

                if (entityType === 'Plan') {  //currently only support "Plan"
                    docNameForEntity = generateSysPlanDocName(entity.name, entity.planYear, scopeObject.selectedDocumentType.value);
                    sourceTypes = '1 Plan';  // for single source batch every batch job only contains one plan
                    detailedSourceTypesAndNames = entity.name + ' (Plan)';
                }

                // make sure batch job name is unique in a batch
                var batchJobName = scopeObject.currentBatch.name + '_' + entityType + '_' + entity.name + '_' + scopeObject.selectedTemplate.name + '_' + scopeObject.selectedDocumentType.value + '_' +
                    scopeObject.selectedDocFormats.toString();

                currentBatchJobJsonData = {
                    name: 'batchJob_' + batchJobName,
                    batchJobStatus: 'Pending',
                    batchJobStatusDetails: '',
                    parentBatch: scopeObject.currentBatch.objectId
                };

                BatchService.createBatchJob(currentBatchJobJsonData)
                .then(function (data) {
                    currentBatchJobObjectId = data;

                    BatchService.createBatchAndBatchJobAssociation(scopeObject.currentBatch.objectId, currentBatchJobObjectId)
                        .then(function () {
                            if (entityType === 'Plan') {
                                // if it is a single source with prefix such as "rx;"
                                if (scopeObject.selectedTemplate && scopeObject.selectedTemplate.templateSources &&
                                        scopeObject.selectedTemplate.templateSources.length === 1) {

                                    if (scopeObject.selectedTemplate.templateSources[0].sourceIndicator !== 'NA') {
                                        currentBatchJobTaskBody = {
                                            documentName: docNameForEntity,
                                            dataSourceNames: entity.name,
                                            sourceTypes: sourceTypes,
                                            fileFormat: scopeObject.selectedDocFormats.toString(),
                                            generationType: 'Single',
                                            documentAssociatons: [],
                                            templateId: scopeObject.selectedTemplate.objectId,
                                            templateName: scopeObject.selectedTemplate.name,
                                            templateDocType: scopeObject.selectedDocumentType.value,
                                            templateSources: {
                                                baseSourceIndicator: 'Plan-' + scopeObject.selectedTemplate.templateSources[0].sourceIndicator,                                               
                                                dataSources: [
                                                    {
                                                        ID: entity.objectId,
                                                        SourceType: 'Plan',
                                                        SourceIndicator: scopeObject.selectedTemplate.templateSources[0].sourceIndicator
                                                    }]
                                            },
                                            watermark: scopeObject.selectedWatermark.text,
                                            dataSourceYear: entity.planYear,
                                            isBatchJobMultiSource: scopeObject.currentBatch.isMultiSource,
                                            sourceTypesAndNames: detailedSourceTypesAndNames
                                        };
                                    }
                                    else {
                                        currentBatchJobTaskBody = {
                                            documentName: docNameForEntity,
                                            dataSourceNames: entity.name,
                                            sourceTypes: sourceTypes,
                                            fileFormat: scopeObject.selectedDocFormats.toString(),
                                            generationType: 'Single',
                                            documentAssociatons: [],                                            
                                            templateId: scopeObject.selectedTemplate.objectId,
                                            templateName: scopeObject.selectedTemplate.name,
                                            templateDocType: scopeObject.selectedDocumentType.value,
                                            templateSources: {
                                                baseSourceIndicator: 'Plan-NA',
                                                dataSources: [
                                                    {
                                                        ID: entity.objectId,
                                                        SourceType: 'Plan',
                                                        SourceIndicator: 'NA'
                                                    }]
                                            },
                                            watermark: scopeObject.selectedWatermark.text,
                                            dataSourceYear: entity.planYear,
                                            isBatchJobMultiSource: scopeObject.currentBatch.isMultiSource,
                                            sourceTypesAndNames: detailedSourceTypesAndNames
                                        };
                                    }
                                }
                            }
                            
                            currentBatchJobTaskJsonData = {
                                parentBatchJob: currentBatchJobObjectId,
                                batchJobTaskStatus: 'Pending',
                                batchJobTaskMethod: 'POST',
                                batchJobTaskUri: '/docgen/api/v1/Document/GenerateDocument',
                                batchJobTaskBody: JSON.stringify(currentBatchJobTaskBody)
                            };

                            BatchService.createBatchJobTask(currentBatchJobTaskJsonData)
                            .then(function (data) {
                                currentBatchJobTaskObjectId = data;

                                BatchService.createBatchJobAndBatchJobTaskAssociation(currentBatchJobObjectId, currentBatchJobTaskObjectId)
                                    .then(function () {
                                        currentBatchJobTaskDocumentJsonData = {
                                            batchJobTaskDocumentDocumentType: scopeObject.selectedDocumentType.value,
                                            batchJobTaskDocumentTemplateId: scopeObject.selectedTemplate.objectId,
                                            batchJobTaskDocumentDataSourceIds: entity.objectId,
                                            batchJobTaskDocumentDataSourceType: entityType,
                                            batchJobTaskDocumentWatermark: scopeObject.selectedWatermark.text,
                                            batchJobTaskDocumentIsMultiSource: false
                                        };

                                        BatchService.createBatchJobTaskDocument(currentBatchJobTaskDocumentJsonData)
                                        .then(function (data) {
                                            currentBatchJobTaskDocObjectId = data;

                                            BatchService.createJobTaskAndJobTaskDocumentAssociation(currentBatchJobTaskObjectId, currentBatchJobTaskDocObjectId)
                                            .then(function () {
                                                var result = { 'objectId': currentBatchJobObjectId };
                                                defer.resolve(result);

                                            }, function (reason) {
                                                $log.error(reason + ' Create association between BatchJobTask ' + currentBatchJobTaskObjectId + ' and BatchJobTaskDocument ' + currentBatchJobTaskDocObjectId + ' failed.');
                                                // roll back the transaction
                                                removeBatchJobById(currentBatchJobObjectId, true, true).then(function () {
                                                    defer.resolve();
                                                }, function (reason) {
                                                    defer.reject(reason);
                                                });
                                            });

                                        }, function (reason) {
                                            $log.error(reason);

                                            removeBatchJobById(currentBatchJobObjectId, true, false).then(function () {
                                                defer.resolve();
                                            }, function (reason) {
                                                defer.reject(reason);
                                            });
                                        });

                                    }, function (reason) {
                                        $log.error(reason + ' Create association between BatchJob ' + currentBatchJobObjectId + ' and BatchJobTask ' + currentBatchJobTaskObjectId + ' failed.');

                                        removeBatchJobById(currentBatchJobObjectId, true, false).then(function () {
                                            defer.resolve();
                                        }, function (reason) {
                                            defer.reject(reason);
                                        });
                                    });

                            }, function (reason) {
                                $log.error(reason);
                                //remove batchJob when batchJobTask not created
                                removeBatchJobById(currentBatchJobObjectId, false, false).then(function () {
                                    defer.resolve();
                                }, function (reason) {
                                    defer.reject(reason);
                                });
                            });

                        }, function (reason) {
                            $log.error(reason);
                            //remove batchJob when batch and batchJob association not established
                            removeBatchJobById(currentBatchJobObjectId, false, false).then(function () {
                                defer.resolve();
                            }, function (reason) {
                                defer.reject(reason);
                            });
                        });

                }, function (reason) {
                    $log.error(reason);
                    defer.reject(reason);
                });

                return defer.promise;
            };

            /* main function to create BatchJob, BatchJobTask, BatchJobTaskDocument and all associations needed for multi source batch */
            self.createBatchJobForMultiSource = function (scopeObject) {

                var defer = $q.defer();

                if (!scopeObject) {
                    defer.reject('Invalid parameter.');
                }

                var currentBatchJobObjectId = '';
                var currentBatchJobTaskObjectId = '';
                var currentBatchJobTaskDocObjectId = '';
                var currentBatchJobJsonData = {};
                var currentBatchJobTaskJsonData = {};
                var currentBatchJobTaskBody = {};
                var currentBatchJobTaskDocJsonData = {};

                /*jshint maxcomplexity:12*/
                self.createMultiSourceDocName(scopeObject).then(function (genDocName) {
                    var dataSourceNames = []; //used in batchJobTaskBody json data
                    var dataSourceIds = [];

                    var sourceTypes = '';
                    var detailedSourceTypesAndNames = '';

                    var planTypeCount = 0;
                    var productTypeCount = 0;
                    var accountTypeCount = 0;
                    var offeringTypeCount = 0;

                    var planNames = '';
                    var productNames = '';
                    var accountName = '';   //only one account can be selected
                    var offeringName = '';  //only one offering can be selected

                    angular.forEach(scopeObject.selectedSources, function (source) {
                        dataSourceNames.push(source.name);
                        dataSourceIds.push(source.objectId);

                        if (source.sourceType === 'Plan' && source.sourceIndicator && source.sourceIndicator !== '') {
                            planTypeCount++;
                            planNames += source.name + ' (Plan), ';
                        }
                        else if (source.sourceType === 'Product' && source.sourceIndicator && source.sourceIndicator !== '') {
                            productTypeCount++;
                            productNames += source.name + ' (Product), ';
                        }
                        else if (source.sourceType === 'Account') {
                            accountTypeCount++;
                            accountName += source.name + ' (Account), ';
                        }
                    });
                    // scopeObject.selectedSources don't contain Offering, so we add Offering separately
                    if (scopeObject.selectedOfferings && scopeObject.selectedOfferings.length > 0) {
                        offeringTypeCount++;
                        offeringName += scopeObject.selectedOfferings[0].name + ' (Offering), ';
                    }

                    if (accountTypeCount > 0) {
                        sourceTypes += accountTypeCount + ' Account, ';   //only one account can be selected at a time
                    }
                    if (offeringTypeCount > 0) {
                        sourceTypes += offeringTypeCount + ' Offering';   //only one offering can be selected at a time

                        if (planTypeCount > 0) {
                            sourceTypes += planTypeCount === 1 ? ' (' + planTypeCount + ' Plan), ' : ' (' + planTypeCount + ' Plans), ';
                        }
                        if (productTypeCount > 0) {
                            sourceTypes += productTypeCount === 1 ? ' (' + productTypeCount + ' Product), ' : ' (' + productTypeCount + ' Products), ';
                        }
                    }
                    else {
                        if (planTypeCount > 0) {
                            sourceTypes += planTypeCount === 1 ? planTypeCount + ' Plan, ' : planTypeCount + ' Plans, ';
                        }
                        if (productTypeCount > 0) {
                            sourceTypes += productTypeCount === 1 ? productTypeCount + ' Product, ' : productTypeCount + ' Products, ';
                        }
                    }

                    sourceTypes = sourceTypes.replace(/,\s*$/, '');  //replace last comma

                    detailedSourceTypesAndNames = accountName + offeringName + planNames + productNames;
                    detailedSourceTypesAndNames = detailedSourceTypesAndNames.replace(/,\s*$/, '');

                    var docGenPayload = self.buildMultiSourceDocumentJson(scopeObject, genDocName);

                    currentBatchJobJsonData = {
                        name: 'batchJob_' + scopeObject.currentBatch.objectId + '_' + genDocName,  // make sure batch job name is unique in a batch
                        batchJobStatus: 'Pending',
                        batchJobStatusDetails: '',
                        parentBatch: scopeObject.currentBatch.objectId
                    };

                    BatchService.createBatchJob(currentBatchJobJsonData)
                    .then(function (data) {
                        currentBatchJobObjectId = data;

                        BatchService.createBatchAndBatchJobAssociation(scopeObject.currentBatch.objectId, currentBatchJobObjectId)
                            .then(function () {

                                currentBatchJobTaskBody = {
                                    documentName: genDocName,
                                    dataSourceNames: dataSourceNames.toString(),
                                    sourceTypes: sourceTypes,
                                    fileFormat: scopeObject.selectedDocFormats.toString(),
                                    generationType: docGenPayload.generationType,
                                    documentAssociatons: docGenPayload.associations,
                                    templateId: scopeObject.selectedTemplate.objectId,
                                    templateName: scopeObject.selectedTemplate.name,
                                    templateDocType: scopeObject.selectedDocumentType.value,
                                    templateSources: docGenPayload.templateSources,
                                    watermark: scopeObject.selectedWatermark.text,
                                    docTypes: scopeObject.selectedDocFormats.toString(),
                                    isBatchJobMultiSource: scopeObject.currentBatch.isMultiSource,
                                    sourceTypesAndNames: detailedSourceTypesAndNames
                                };

                                currentBatchJobTaskJsonData = {
                                    parentBatchJob: currentBatchJobObjectId,
                                    batchJobTaskStatus: 'Pending',
                                    batchJobTaskMethod: 'POST',
                                    batchJobTaskUri: '/docgen/api/v1/Document/GenerateDocument',
                                    batchJobTaskBody: JSON.stringify(currentBatchJobTaskBody)
                                };

                                BatchService.createBatchJobTask(currentBatchJobTaskJsonData)
                                .then(function (data) {
                                    currentBatchJobTaskObjectId = data;

                                    BatchService.createBatchJobAndBatchJobTaskAssociation(currentBatchJobObjectId, currentBatchJobTaskObjectId)
                                        .then(function () {
                                            currentBatchJobTaskDocJsonData = {
                                                batchJobTaskDocumentDocumentType: scopeObject.selectedDocumentType.value,
                                                batchJobTaskDocumentTemplateId: scopeObject.selectedTemplate.objectId,
                                                batchJobTaskDocumentDataSourceIds: dataSourceIds.toString(),   //a list of plan objectIds
                                                batchJobTaskDocumentDataSourceType: 'Plan',
                                                batchJobTaskDocumentWatermark: scopeObject.selectedWatermark.text,
                                                batchJobTaskDocumentIsMultiSource: true
                                            };

                                            BatchService.createBatchJobTaskDocument(currentBatchJobTaskDocJsonData)
                                            .then(function (data) {
                                                currentBatchJobTaskDocObjectId = data;

                                                BatchService.createJobTaskAndJobTaskDocumentAssociation(currentBatchJobTaskObjectId, currentBatchJobTaskDocObjectId)
                                                .then(function () {
                                                    var result = { 'objectId': currentBatchJobObjectId };
                                                    defer.resolve(result);

                                                }, function (reason) {
                                                    $log.error(reason + ' Create association between BatchJobTask ' + currentBatchJobTaskObjectId + ' and BatchJobTaskDocument ' + currentBatchJobTaskDocObjectId + ' failed.');
                                                    //remove batchJob when batchJobTask and batchJobTaskDocument association not established
                                                    removeBatchJobById(currentBatchJobObjectId, true, true).then(function () {
                                                        defer.resolve();
                                                    }, function (reason) {
                                                        defer.reject(reason);
                                                    });
                                                });

                                            }, function (reason) {
                                                $log.error(reason);

                                                removeBatchJobById(currentBatchJobObjectId, true, false).then(function () {
                                                    defer.resolve();
                                                }, function (reason) {
                                                    defer.reject(reason);
                                                });
                                            });

                                        }, function (reason) {
                                            $log.error(reason + ' Create association between BatchJob ' + currentBatchJobObjectId + ' and BatchJobTask ' + currentBatchJobTaskObjectId + ' failed.');
                                            //remove batchJob when batchJob and batchJobTask association not established
                                            removeBatchJobById(currentBatchJobObjectId, true, false).then(function () {
                                                defer.resolve();
                                            }, function (reason) {
                                                defer.reject(reason);
                                            });
                                        });

                                }, function (reason) {
                                    $log.error(reason);

                                    removeBatchJobById(currentBatchJobObjectId, false, false).then(function () {
                                        defer.resolve();
                                    }, function (reason) {
                                        defer.reject(reason);
                                    });
                                });

                            }, function (reason) {
                                $log.error(reason);

                                removeBatchJobById(currentBatchJobObjectId, false, false).then(function () {
                                    defer.resolve();
                                }, function (reason) {
                                    defer.reject(reason);
                                });
                            });

                    }, function (reason) {
                        $log.error(reason);
                        defer.reject(reason);
                    });

                });

                return defer.promise;
            };

            /** save the batchJob being edited, for both single source and multi source,
            only one row in the grid is updated at a time */
            self.saveBatchJobUpdates = function (scopeObject) {

                var defer = $q.defer();

                if (!scopeObject) {
                    defer.reject('Invalid parameter.');
                }

                var batchJson = { name: scopeObject.currentBatch.name, batchStatus: 'Draft' };

                BatchService.updateBatch(batchJson, scopeObject.currentBatch.objectId)
                .then(function () {
                    var batchJobJson = { batchJobStatus: 'Pending', batchJobStatusDetails: '' };

                    if (scopeObject.currentBatchJobInEditing && scopeObject.currentBatchJobInEditing.batchJobObjectId) {  // if we're editing a batchJob
                        BatchService.updateBatchJob(batchJobJson, scopeObject.currentBatchJobInEditing.batchJobObjectId)
                        .then(function () {
                            if (!scopeObject.isMultiSource) {  // single source
                                updateBatchJobSingleSource(scopeObject)
                                .then(function () {
                                    defer.resolve();
                                }, function (reason) {
                                    defer.reject(reason);
                                });
 
                            } else {   // multi source

                                updateBatchJobMultiSource(scopeObject)
                                .then(function () {
                                    defer.resolve();
                                }, function (reason) {
                                    defer.reject(reason);
                                });
                            }

                        }, function (reason) {
                            $log.error(reason);
                            defer.reject(reason);
                        });
                    }

                }, function (reason) {
                    $log.error(reason);
                    defer.reject(reason);
                });

                return defer.promise;
            };

            self.validateSourceIndicators = function (docDefinition, documentValidationNeeded) {
                var totalRequiredSources = 0;
                var duplicatedRequiredCount = 0;
                var duplicatedNotRequiredCount = 0;
                var planSourceTypeCount = 0;
                var taggedRequiredSources = [];
                var taggedNotRequiredSources = [];
                var isValid = true;

                angular.forEach(docDefinition.selectedTemplate.templateSources, function (source) {
                    if (source.isBaseSource || source.isRequiredSource) {
                        totalRequiredSources++;
                    }
                });

                angular.forEach(docDefinition.selectedSources, function (source) {
                    if (source.sourceType === 'Plan') {
                        planSourceTypeCount++;
                    }

                    if (source.sourceIndicator && source.sourceIndicator !== '') {
                        if (source.isBaseSource || source.isRequiredSource) {
                            if (taggedRequiredSources.length > 0) {
                                if (taggedRequiredSources.indexOf(source.sourceIndicator) === -1) {
                                    taggedRequiredSources.push(source.sourceIndicator);
                                } else {
                                    duplicatedRequiredCount++;
                                }
                            } else {
                                taggedRequiredSources.push(source.sourceIndicator);
                            }
                        }
                        else {
                            if (taggedNotRequiredSources.length > 0) {
                                if (taggedNotRequiredSources.indexOf(source.sourceIndicator) === -1) {
                                    taggedNotRequiredSources.push(source.sourceIndicator);
                                } else {
                                    duplicatedNotRequiredCount++;
                                }
                            } else {
                                taggedNotRequiredSources.push(source.sourceIndicator);
                            }
                        }
                    }
                });

                if (documentValidationNeeded) {
                    var errorMsg = '';

                    if (docDefinition.selectedSources.length < totalRequiredSources) {
                        errorMsg = 'At least ' + totalRequiredSources  + ' plans must be selected before all the required sources can be tagged.';
                        isValid = false;
                    }
                    else if (taggedRequiredSources.length !== totalRequiredSources) {
                        // If the template contains "PL_" but no plan is selected
                        if (planSourceTypeCount === 0 && (!docDefinition.selectedPlans || docDefinition.selectedPlans.length === 0)) {
                            errorMsg = 'Plan(s) must be selected.';
                        } else {
                            if (planSourceTypeCount < totalRequiredSources) {
                                errorMsg = 'At least ' + totalRequiredSources + ' plans must be selected before all the required sources can be tagged.';
                            } else {
                                errorMsg = '*Required source must be tagged.';                              
                            }
                        }

                        isValid = false;
                    }
                    else if (duplicatedRequiredCount > 0 || duplicatedNotRequiredCount > 0) {
                        errorMsg = 'Duplicated sources must not be tagged.';
                        isValid = false;
                    }

                    DocumentDataFactory.setTemplateSourceErrorMsg(errorMsg);
                }

                return isValid;
            };

            self.buildMultiSourceDocumentJson = function (docDefinition, multiSourceDocName) {
                var sourcesToSubmit = [];
                var baseSourceIndicator = '';
                var baseSourceType = '';
                var baseDataSourceId = '';
                var templateContainsOfferingControls = false;

                angular.forEach(docDefinition.selectedSources, function (source) {
                    var jsonObj = {};

                    if (source.sourceType === 'Account') {
                        jsonObj = { 'ID': source.objectId, 'SourceType': source.sourceType, 'SourceIndicator': 'NA', 'SourceName': source.name };
                        sourcesToSubmit.push(jsonObj);
                    }
                    else if (source.sourceType === 'Group') {
                        jsonObj = { 'ID': source.objectId, 'SourceType': source.sourceType, 'SourceIndicator': 'NA', 'SourceName': source.name };
                        sourcesToSubmit.push(jsonObj);
                    }
                    else if (source.sourceIndicator && source.sourceIndicator !== '' && source.sourceType !== 'Account' && source.sourceType !== 'Group') {
                        jsonObj = { 'ID': source.objectId, 'SourceType': source.sourceType, 'SourceIndicator': source.sourceIndicator, 'SourceName': source.name };
                        sourcesToSubmit.push(jsonObj);
                    }

                    if (source.isBaseSource && source.sourceIndicator !== null && source.sourceIndicator !== '') {  //only "Plan" can be base source indicator at this point
                        baseSourceIndicator = source.sourceIndicator;
                        baseSourceType = source.sourceType;
                        baseDataSourceId = source.objectId;
                    }
                });
                // check if the template contains "Offering" content controls
                for (var i = 0, j = docDefinition.selectedTemplate.templateSources.length; i < j; i++) {
                    if (docDefinition.selectedTemplate.templateSources[i].sourceType.toLowerCase() === 'offering') {
                        templateContainsOfferingControls = true;
                        break;
                    }
                }

                var generationType = 'MultiSource';

                if (docDefinition.selectedOfferings && docDefinition.selectedOfferings.length > 0 && templateContainsOfferingControls) {
                    // since offering is not listed in the selectedSources grid, we'll need to add here if template contains "Offering"
                    var jsonObj = {
                        'ID': docDefinition.selectedOfferings[0].objectId,
                        'SourceType': 'Offering',
                        'SourceIndicator': 'NA',
                        'SourceName': docDefinition.selectedOfferings[0].name
                    };

                    sourcesToSubmit.push(jsonObj);

                }

                var templateSources = {
                    baseSourceIndicator: baseSourceType + '-' + baseSourceIndicator,
                    dataSources: sourcesToSubmit
                };

                var associations = [];

                if (docDefinition.selectedOfferings && docDefinition.selectedOfferings.length > 0 && !templateContainsOfferingControls) {
                    associations = [{
                        ID: docDefinition.selectedOfferings[0].objectId,
                        SourceType: 'Offering'
                    }];
                }

                var docGenJson = {
                    documentName: multiSourceDocName,
                    fileFormat: docDefinition.selectedDocFormats.toString(),
                    generationType: generationType,
                    documentAssociatons: associations,
                    templateId: docDefinition.selectedTemplate.objectId,
                    templateSources: templateSources,
                    watermark: docDefinition.selectedWatermark.text
                };

                return docGenJson;
            };

        }

        return new DocumentBatchHelper();

    }]);