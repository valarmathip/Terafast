'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.BatchService
 * @description
 * # BatchService
 * Service in the p2AdvanceApp MediaManagement for Batch related Api calls
 */
angular.module('p2AdvanceApp')
    .factory('BatchService', ['$http', '$q', '$auth', 'ConfirmationModalFactory', 'ENV_MEDIA_MANAGEMENT', 'PPMENV', 'ENV', '$log', 'uiConfig', 
        function ($http, $q, $auth, ConfirmationModalFactory, ENV_MEDIA_MANAGEMENT, PPMENV, ENV, $log, uiConfig) {

        var restApiEndpoint = ENV_MEDIA_MANAGEMENT.restApiEndpoint;
        var restSearchApiEndpoint = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint;
        var currentBatch = null;
        var currentBatchJobInEdit = null;
        var batchPaneCollapsed = false;
        var batchJobDocNameEdited = [];

        function BatchService() {
            var self = this;
            self.getBatchList = function() {
                return $http.get(restSearchApiEndpoint + encodeURI('TYPE:"batch" &associationExpansionLevel=1 &start=0&rows=20&sort=lastModificationDate desc'));
            };
            self.getBatchFilters = function() {
                return $http.get(restApiEndpoint + '/types/batch');
            };
            self.getPaginationAPI = function(filterQuery) {
                var fieldUrl = PPMENV.getPpmSearchUrl() + encodeURI(filterQuery);
                return $http.get(fieldUrl);
            };
            self.getBatchSubmittedByUsers = function() {
                return $http.get(restApiEndpoint + '/batch');
            };
            self.getBatchById = function(batchId) {
                return $http.get(restApiEndpoint + '/batch/' + batchId);
            };
            self.getBatchJobById = function(batchJobId) {
                return $http.get(restApiEndpoint + '/batchJobs/' + batchJobId);
            };
            self.getBatchJobDetails = function(batchJobId) {
                return $http.get(restApiEndpoint + '/batchJobs/' + batchJobId + '?associationExpansionLevel=-1');
            };
            self.getBatchJobTaskById = function(batchJobTaskId) {
                return $http.get(restApiEndpoint + '/batchJobTasks/' + batchJobTaskId);
            };
            self.getBatchDetails = function(batchId) {
                return $http.get(restApiEndpoint + '/batch/' + batchId + '?associationExpansionLevel=-1');
            };
            self.getBatchJobsOfOneBatch = function(searchQuery) {
                var batchJobsApi = '';

                if (angular.isDefined(searchQuery) && searchQuery !== '') {
                    batchJobsApi = restSearchApiEndpoint + encodeURI(searchQuery);
                }

                return $http.get(batchJobsApi);
            };
            self.getBatchSummary = function(filterQuery) {
                var fieldUrl = PPMENV.getPpmSearchUrl() + encodeURI(filterQuery);
                return $http.get(fieldUrl);
            };
            self.submitBatch = function(batchIdsJson) {
                var batchSubmitApi = restApiEndpoint + '/batches/submit';
                var defer = $q.defer();

                $http.post(batchSubmitApi, batchIdsJson, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Submit Batch';
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Submit Batch';
                        // self.error.detail = response;
                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.reSubmitBatch = function(batchIdsJson, mode) {
                var batchReSubmitApi = restApiEndpoint + '/batches/resubmit?flag='+mode;
                var defer = $q.defer();

                $http.post(batchReSubmitApi, batchIdsJson, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Re-submit Batch';
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Re-submit Batch';
                        // self.error.detail = response;
                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.cancelBatch = function(batchIdsJson) {
                var batchCancelApi = restApiEndpoint + '/batches/cancel';
                var defer = $q.defer();

                $http.post(batchCancelApi, batchIdsJson, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Cancel Batch';
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.createBatch = function(batchJsonData) {
                var batchApi = restApiEndpoint + '/batch';
                var defer = $q.defer();

                $http({
                        method : 'POST',
                        url :  batchApi,
                        data : JSON.stringify(batchJsonData),
                        headers : {
                            'Content-Type': 'application/json'
                        } 
                 }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create a Batch';

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + batchJsonData.name + '" is already in use. Use a different name.';
                                } else if (response.developerMessage[0].indexOf('This property must be a valid file name') > -1) {
                                    self.error.detail = 'Characters &#34;, &#42;, &#92;, &#62;, &#60;, &#63;, &#47;, &#58;, | are not allowed in filenames.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // let the global exception handling show the error dialog
                        defer.reject(response);
                    });

                return defer.promise;

            };
            self.createBatchJob = function(batchJobJson) {
                var batchJobApi = restApiEndpoint + '/batchJobs';
                var defer = $q.defer();

                $http.post(batchJobApi, batchJobJson, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create a Batch Job';

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + batchJobJson.name + '" already exists. The same data source, template and format combination is already in use.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // let the global exception handling show the error dialog
                        defer.reject(response);
                    });

                return defer.promise;

            };
            self.createBatchJobTask = function(batchJobTaskJson) {
                var batchJobTaskApi = restApiEndpoint + '/batchJobTasks';
                var defer = $q.defer();

                $http.post(batchJobTaskApi, batchJobTaskJson, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create a Batch Job Task';

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + batchJobTaskJson.name + '" already exists. The same data source, template and format combination is already in use.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // let the global exception handling show the error dialog
                        defer.reject(response);
                    });

                return defer.promise;

            };
            self.createBatchJobTaskDocument = function(batchJobTaskDocumentJson) {
                var batchJobTaskDocumentApi = restApiEndpoint + '/batchJobTaskDocuments';
                var defer = $q.defer();

                $http.post(batchJobTaskDocumentApi, batchJobTaskDocumentJson, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create a Batch Job Task Document';

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + batchJobTaskDocumentJson.name + '" already exists. The same data source, template and format combination is already in use.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // let the global exception handling show the error dialog
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.createBatchAndBatchJobAssociation = function(batchId, batchJobId) {
                var associationApi = restApiEndpoint + '/batch/' + batchId + '/batchJobs/' + batchJobId;
                var defer = $q.defer();

                $http.post(associationApi, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create the association between Batch ' + batchId + ' and Batch Job ' + batchJobId;
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Create the association between Batch ' + batchId + ' and Batch Job ' + batchJobId;
                        // self.error.detail = response;
                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.createBatchJobAndBatchJobTaskAssociation = function(batchJobId, batchJobTaskId) {
                var associationApi = restApiEndpoint + '/batchJobs/' + batchJobId + '/batchJobTasks/' + batchJobTaskId;
                var defer = $q.defer();

                $http.post(associationApi, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create the association between BatchJob ' + batchJobId + 'and BatchJobTask ' + batchJobTaskId;
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Create the association between BatchJob ' + batchJobId + 'and BatchJobTask ' + batchJobTaskId;
                        // self.error.detail = response;
                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.createJobTaskAndJobTaskDocumentAssociation = function(batchJobTaskId, batchJobTaskDocumentId) {
                var associationApi = restApiEndpoint + '/batchJobTasks/' + batchJobTaskId + '/taskDocument/' + batchJobTaskDocumentId;
                var defer = $q.defer();

                $http.post(associationApi, {
                        'Content-Type': 'application/json'
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Create the association between BatchJobTask ' + batchJobTaskId + 'and BatchJobTaskDocument ' + batchJobTaskDocumentId;
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Create the association between BatchJobTask ' + batchJobTaskId + 'and BatchJobTaskDocument ' + batchJobTaskDocumentId;
                        // self.error.detail = response;
                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.deleteBatchJob = function(batchJobId) {
                var batchJobApi = restApiEndpoint + '/batchJobs/' + batchJobId;
                var defer = $q.defer();

                $http({
                        method: 'DELETE',
                        url: batchJobApi
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.NoContent) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Delete the BatchJob: ' + batchJobId;

                            if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                                self.error.detail = response.developerMessage[0];
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Delete the BatchJob: ' + batchJobId;

                        // if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                        //     self.error.detail = response.developerMessage[0];
                        // } else {
                        //     self.error.detail = response;
                        // }

                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.deleteBatchJobTask = function(batchJobTaskId) {
                var batchJobTaskApi = restApiEndpoint + '/batchJobTasks/' + batchJobTaskId;
                var defer = $q.defer();

                $http({
                        method: 'DELETE',
                        url: batchJobTaskApi
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.NoContent) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Delete the BatchJobTask: ' + batchJobTaskId;

                            if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                                self.error.detail = response.developerMessage[0];
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Delete the BatchJobTask: ' + batchJobTaskId;

                        // if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                        //     self.error.detail = response.developerMessage[0];
                        // } else {
                        //     self.error.detail = response;
                        // }

                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.deleteBatchJobTaskDocument = function(batchJobTaskDocumentId) {
                var batchJobTaskDocumentApi = restApiEndpoint + '/batchJobTaskDocuments/' + batchJobTaskDocumentId;
                var defer = $q.defer();

                $http({
                        method: 'DELETE',
                        url: batchJobTaskDocumentApi
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.NoContent) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to Delete the BatchJobTaskDocument: ' + batchJobTaskDocumentId;

                            if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                                self.error.detail = response.developerMessage[0];
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to Delete the BatchJobTaskDocument: ' + batchJobTaskDocumentId;

                        // if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                        //     self.error.detail = response.developerMessage[0];
                        // } else {
                        //     self.error.detail = response;
                        // }

                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.deleteBatchAndBatchJobAssociation = function(batchId, batchJobId) {
                var associationApi = restApiEndpoint + '/batch/' + batchId + '/batchJobs/' + batchJobId;
                var defer = $q.defer();

                $http({
                        method: 'DELETE',
                        url: associationApi
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.NoContent) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to delete the association between Batch ' + batchId + ' and BatchJob ' + batchJobId;
                            self.error.detail = response;
                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to delete the association between Batch ' + batchId + ' and BatchJob ' + batchJobId;
                        // self.error.detail = response;
                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.updateBatch = function(patchData, batchId) {
                var batchApi = restApiEndpoint + '/batch/' + batchId;
                var defer = $q.defer();

                $http({
                        method: 'PATCH',
                        url: batchApi,
                        data: JSON.stringify(patchData),
                        skipInterceptorError : true
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to update Batch';

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                                } else if (response.developerMessage[0].indexOf('This property must be a valid file name') > -1) {
                                    self.error.detail = 'Characters &#34;, &#42;, &#92;, &#62;, &#60;, &#63;, &#47;, &#58;, | are not allowed in filenames.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        self.error.subject = 'Unable to update Batch';

                        if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                            if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                            } else if (response.developerMessage[0].indexOf('This property must be a valid file name') > -1) {
                                self.error.detail = 'Characters &#34;, &#42;, &#92;, &#62;, &#60;, &#63;, &#47;, &#58;, | are not allowed in filenames.';
                            } else {
                                self.error.detail = response.developerMessage[0];
                            }
                        } else {
                            self.error.detail = response;
                        }

                        ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.updateBatchJob = function(patchData, batchJobId) {
                var batchJobApi = restApiEndpoint + '/batchJobs/' + batchJobId;
                var defer = $q.defer();

                $http({
                        method: 'PATCH',
                        url: batchJobApi,
                        data: JSON.stringify(patchData)
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to update BatchJob ' + batchJobId;

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to update BatchJob ' + batchJobId;

                        // if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                        //     if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                        //         self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                        //     } else {
                        //         self.error.detail = response.developerMessage[0];
                        //     }
                        // } else {
                        //     self.error.detail = response;
                        // }

                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.updateBatchJobTask = function(patchData, batchJobTaskId) {
                var batchJobTaskApi = restApiEndpoint + '/batchJobTasks/' + batchJobTaskId;
                var defer = $q.defer();

                $http({
                        method: 'PATCH',
                        url: batchJobTaskApi,
                        data: JSON.stringify(patchData)
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                             self.error.subject = 'Unable to update BatchJobTask ' + batchJobTaskId;

                             if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                 if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                     self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                                 } else {
                                     self.error.detail = response.developerMessage[0];
                                 }
                             } else {
                                 self.error.detail = response;
                             }

                             ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to update BatchJobTask ' + batchJobTaskId;

                        // if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                        //     if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                        //         self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                        //     } else {
                        //         self.error.detail = response.developerMessage[0];
                        //     }
                        // } else {
                        //     self.error.detail = response;
                        // }

                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.updateBatchJobTaskDocument = function(patchData, batchJobTaskDocumentId) {
                var batchJobTaskDocumentApi = restApiEndpoint + '/batchJobTaskDocuments/' + batchJobTaskDocumentId;
                var defer = $q.defer();

                $http({
                        method: 'PATCH',
                        url: batchJobTaskDocumentApi,
                        data: JSON.stringify(patchData)
                    }).success(function(response, status) {
                        if (status === uiConfig.OK || status === uiConfig.Created) {
                            defer.resolve(response);
                        } else {
                            self.error.subject = 'Unable to update BatchJobTaskDocument' + batchJobTaskDocumentId;

                            if (response.developerMessage !== null && response.developerMessage[0] !== null) {
                                if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                                    self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                                } else {
                                    self.error.detail = response.developerMessage[0];
                                }
                            } else {
                                self.error.detail = response;
                            }

                            ConfirmationModalFactory.close(self.showError);
                            defer.reject(response);
                        }
                    })
                    .error(function(response) {
                        // self.error.subject = 'Unable to update BatchJobTaskDocument' + batchJobTaskDocumentId;

                        // if (response.developerMessage !== null && response.developerMessage[0] !== '') {
                        //     if (response.developerMessage[0].indexOf('An object with this name already exists') > -1) {
                        //         self.error.detail = '"' + patchData.name + '" already exists. Use a different name.';
                        //     } else {
                        //         self.error.detail = response.developerMessage[0];
                        //     }
                        // } else {
                        //     self.error.detail = response;
                        // }

                        // ConfirmationModalFactory.close(self.showError);
                        defer.reject(response);
                    });

                return defer.promise;
            };
            self.removeBatch = function (batchId) {  // this is not to totally delete the job from CM
                var batchApi = restApiEndpoint + '/batch/' + batchId;
                var defer = $q.defer();

                $http({
                    method: 'PATCH',
                    url: batchApi,
                    data: JSON.stringify({ 'batchArchived': true })
                }).success(function (response, status) {
                    if (status === uiConfig.OK || status === uiConfig.Created) {
                        defer.resolve(response);
                    } else {
                        defer.reject(response);
                    }
                })
                .error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getCurrentBatch = function() {
                return currentBatch;
            };

            self.setCurrentBatch = function(data) {
                currentBatch = data;
            };

            self.getCurrentBatchJobInEdit = function() {
                return currentBatchJobInEdit;
            };

            self.setCurrentBatchJobInEdit = function(data) {
                currentBatchJobInEdit = data;
            };

            self.getBatchPaneCollapsed = function() {
                return batchPaneCollapsed;
            };

            self.setBatchPaneCollapsed = function(data) {
                batchPaneCollapsed = data;
            };

            self.getBatchJobDocNameEdited = function() {
                return batchJobDocNameEdited;
            };

            self.setBatchJobDocNameEdited = function(data) {
                batchJobDocNameEdited = data;
            };

            self.error = {
                subject: '',
                detail: ''
            };

            self.showError = function() {
                ConfirmationModalFactory.open(self.error.subject, self.error.detail, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
            };

            self.isEditBatchMultiSource = function(row) {
                var isMultiSource = false;

                if (row.batchJobs && row.batchJobs.length > 0) { // have to go all the way down to get taskDocument's batchJobTaskDocumentIsMultiSource
                    if (row.batchJobs[0].batchJobTasks && row.batchJobs[0].batchJobTasks.length > 0) {
                        if (row.batchJobs[0].batchJobTasks[0] && row.batchJobs[0].batchJobTasks[0].taskDocument.length > 0) {
                            isMultiSource = row.batchJobs[0].batchJobTasks[0].taskDocument[0].batchJobTaskDocumentIsMultiSource;
                        }
                    }
                }
                return isMultiSource;

            };

            self.integrationWithSubmitBatch = function(row) {
                var that = self;
                if (row && row.objectId) {
                    that.getBatchById(row.objectId)
                        .then(
                            // Sucess
                            function(batch) {
                                if (batch && batch.data && batch.data.batchStatus === 'Draft') {
                                    var batchIdsToBeSubmitted = [];
                                    batchIdsToBeSubmitted.push(row.objectId);
                                    that.submitBatch(batchIdsToBeSubmitted)
                                        .then(
                                            // Success    
                                            function(data) {
                                                row.status = data[0].value.replace('.', '');
                                                ConfirmationModalFactory.open('Message', 'Batch has been submitted.', ENV.modalErrorTimeout);
                                                that.getBatchJobDetails(row.objectId)
                                                    .success(function(data) {
                                                        var batchJobs = data.batchJobs;
                                                        // Updating Batch Job Status to Pending
                                                        angular.forEach(batchJobs, function(batchJob) { // update each batchJob Staus to Pending
                                                            that.updateBatchJob({
                                                                    'batchJobStatus': 'Pending'
                                                                }, batchJob.objectId)
                                                                .then(function() {
                                                                    // Updating Batch Job Task to Pending
                                                                    angular.forEach(batchJob.batchJobTasks, function(batchJobTask) { // update each batchJob Staus to Pending
                                                                        that.updateBatchJobTask({
                                                                                'batchJobTaskStatus': 'Pending'
                                                                            }, batchJobTask.objectId)
                                                                            .then(function() {
                                                                                $log.info('BatchJobTask ' + batchJobTask.objectId + ' status updated to Pending.');
                                                                            }, function(error) {
                                                                                $log.error('Error updating BatchJobTask status to Pending. ' + error.message);
                                                                            });
                                                                    });
                                                                }, function(error) {
                                                                    $log.error('Error updating BatchJob status to Pending. ' + error.message);
                                                                });
                                                        });
                                                    });
                                            },
                                            // Error
                                            function(error) {
                                                $log.error('Error Submitting batch' + error.message);
                                            });
                                } else {
                                    ConfirmationModalFactory.open('Error', 'Batch status (' + batch.data.batchStatus + ') is invalid to submit a Batch.', ENV.modalErrorTimeout);
                                }
                            },
                            // Error
                            function(error) {
                                $log.error('Error getBatchById batch' + error.message);
                            });
                } else {
                    ConfirmationModalFactory.open('Error', 'Error Submitting batch', ENV.modalErrorTimeout);
                    $log.error('Error Submitting batch');
                }
            };

            self.integrationWithReSubmitAllBatchJobs = function(row) {
                var that = self;
                if (row && row.objectId) {
                    that.getBatchById(row.objectId)
                        .then(
                            // Success
                            function(batch) {
                                if (batch && batch.data && (batch.data.batchStatus === 'Cancelled' ||
                                        batch.data.batchStatus === 'Failed' ||
                                        batch.data.batchStatus === 'Partially Successful' ||
                                        batch.data.batchStatus === 'Successful')) {

                                        var batchIdsToBeSubmitted = [];
                                        batchIdsToBeSubmitted.push(row.objectId);
                                        that.reSubmitBatch(batchIdsToBeSubmitted, 'resubmit_all')
                                            .then(
                                                // Success    
                                                function(data) {
                                                    row.status = data[0].value.replace('.', '');
                                                    ConfirmationModalFactory.open('Message', 'Batch has been re-submitted.', ENV.modalErrorTimeout);
                                                },
                                                // Error
                                                function(error) {
                                                    $log.error('Error Re-Submitting batch' + error.message);
                                                });
 
                                } else {
                                    ConfirmationModalFactory.open('Error', 'Batch status (' + batch.data.batchStatus + ') is invalid to re-submit a Batch.', ENV.modalErrorTimeout);
                                }
                            },
                            // Error
                            function(error) {
                                $log.error('Error getBatchById batch' + error.message);
                            });
                } else {
                    ConfirmationModalFactory.open('Error', 'Error Submitting batch', ENV.modalErrorTimeout);
                    $log.error('Error Submitting batch');
                }
            };

             self.integrationWithReSubmitFailedCancelledJobsBatch = function(row) {
                var that = self;
                if (row && row.objectId) {
                    that.getBatchById(row.objectId)
                        .then(
                            // Success
                            function(batch) {
                                if (batch && batch.data && (batch.data.batchStatus === 'Cancelled' ||
                                        batch.data.batchStatus === 'Failed' ||
                                        batch.data.batchStatus === 'Partially Successful')) {

                                        var batchIdsToBeSubmitted = [];
                                        batchIdsToBeSubmitted.push(row.objectId);
                                        that.reSubmitBatch(batchIdsToBeSubmitted, 'cancelfailed')
                                            .then(
                                                // Success    
                                                function(data) {
                                                    row.status = data[0].value.replace('.', '');
                                                    ConfirmationModalFactory.open('Message', 'Failed or Cancelled Batch jobs has been re-submitted.', ENV.modalErrorTimeout);
                                                },
                                                // Error
                                                function(error) {
                                                    $log.error('Error Re-Submitting Failed or Cancelled Batch jobs' + error.message);
                                                });
                                            
                                } else {
                                    ConfirmationModalFactory.open('Error', 'Batch status (' + batch.data.batchStatus + ') is invalid to re-submit a Batch.', ENV.modalErrorTimeout);
                                }
                            },
                            // Error
                            function(error) {
                                $log.error('Error getBatchById batch' + error.message);
                            });
                } else {
                    ConfirmationModalFactory.open('Error', 'Error Submitting batch', ENV.modalErrorTimeout);
                    $log.error('Error Submitting batch');
                }
            };


        }

        return new BatchService();

    }]);