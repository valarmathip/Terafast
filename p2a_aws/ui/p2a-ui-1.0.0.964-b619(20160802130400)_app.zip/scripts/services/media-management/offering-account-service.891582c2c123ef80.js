﻿'use strict';

angular.module('p2AdvanceApp')
    .factory('OfferingAccountService', ['$http', '$q', 'ENV_MEDIA_MANAGEMENT', 'PPMENV', function ($http, $q, ENV_MEDIA_MANAGEMENT, PPMENV) {

        var restApiEndpoint = ENV_MEDIA_MANAGEMENT.restApiEndpoint;
        var selectedOfferingPlans = [];

        return {
            getPlansByOfferingId: function (offeringId) {
                var offeringPlansApi = restApiEndpoint + '/offerings/' + offeringId + '?associationExpansionLevel=2';
                var defer = $q.defer();

                $http({
                    method: 'GET',
                    url: offeringPlansApi
                }).success(function (data) {
                    if (!data.error) {
                        defer.resolve(data);
                    } else {
                        defer.reject(data.message);
                    }
                })
                .error(function (reason) {
                    defer.reject(reason);
                });

                return defer.promise;
            },

            getAccountByAccountId: function (expansionLevel, accountId) {
                var accountApi = ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/accounts/' + accountId + '?associationExpansionLevel=' + expansionLevel;
                var defer = $q.defer();

                $http.get(encodeURI(accountApi)).success(function (response) {
                    defer.resolve(response);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            },

            getGroupByGroupId: function (expansionLevel, groupId) {
                var groupApi = ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/groups/' + groupId + '?associationExpansionLevel=' + expansionLevel;
                var defer = $q.defer();

                $http.get(encodeURI(groupApi)).success(function (response) {
                    defer.resolve(response);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            },

            getAccountList: function (expansionLevel) {
                var accountApi = ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/accounts?associationExpansionLevel=' + expansionLevel;
                var defer = $q.defer();

                $http.get(encodeURI(accountApi)).success(function (response) {
                    defer.resolve(response);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            },

            getOfferingsOfAccount: function (account) {
                var offerings = [];

                angular.forEach(account.accountofferings, function (accountoffering) {
                    if (accountoffering.offerings) {
                        for (var i = 0, j = accountoffering.offerings.length; i < j; i++) {
                            offerings.push(accountoffering.offerings[i]);
                        }
                    }
                });

                return offerings;
            },

            getSelectedOfferingPlans: function () {
                return selectedOfferingPlans;
            },

            setSelectedOfferingPlans: function (data) {
                selectedOfferingPlans = data;
            },

            getAccountSchema: function () {
                var accountSchemaApi = restApiEndpoint + '/types/account';
                var defer = $q.defer();

                $http.get(accountSchemaApi).success(function (response) {
                    defer.resolve(response[0].properties);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            },
            
            getAccountListViaSearchApi: function (searchQuery, associationExpansionLevel) {
                var fieldUrl = PPMENV.getPpmSearchUrl();
                var defer = $q.defer();

                if (!searchQuery) {
                    searchQuery = 'TYPE:"account"&start=0&rows=20&sort=accountName asc&properties=objectIds, name, groups, groupParentId, accountName, renewalStartDate, renewalEndDate, accountStatus, marketSegments';
                }
                fieldUrl += '?q=' + encodeURI(searchQuery);

                if (fieldUrl.indexOf('associationExpansionLevel') === -1) {
                    fieldUrl += '&associationExpansionLevel' + '=' + (associationExpansionLevel ? associationExpansionLevel : 0);
                }

                $http({
                    method: 'GET',
                    url: fieldUrl
                })
                    .success(function (data) {
                        defer.resolve(data);
                    })
                    .error(function (reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            },

            // currently there is no search Api available to get all accounts related to an offering
            getAccountsByOfferingId: function (acctLlist, offeringId) {
                var accountsByOfferingId = [];

                angular.forEach(acctLlist, function (account) {
                    if (account.accountofferings) {
                        for (var i = 0, j = account.accountofferings.length; i < j; i++) {
                            if (account.accountofferings[i].offerings && account.accountofferings[i].offerings.length > 0) {
                                for (var m = 0, n = account.accountofferings[i].offerings.length; m < n; m++) {
                                    if (account.accountofferings[i].offerings[m].objectId === offeringId) {
                                        accountsByOfferingId.push(account);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                });

                return accountsByOfferingId;
            }

        };

    }]);