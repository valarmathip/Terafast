﻿'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.DocumentDataFactory
 * @description
 * # DocumentDataFactory
 * Service in the p2AdvanceApp MediaManagement for Document Generation related Api calls
 */
angular.module('p2AdvanceApp')
    .factory('DocumentDataFactory', ['$http', '$q', 'ConfirmationModalFactory', 'QueryDialog', 'ENV_MEDIA_MANAGEMENT', 'PPMENV', function ($http, $q, ConfirmationModalFactory, QueryDialog, ENV_MEDIA_MANAGEMENT, PPMENV) {

        var mediaApi = ENV_MEDIA_MANAGEMENT.mediaApiEndpoint;
        var docGenerationApi = ENV_MEDIA_MANAGEMENT.docGenerationApiEndpoint;
        var restApiEndpoint = ENV_MEDIA_MANAGEMENT.restApiEndpoint;
        var restSearchApiEndpoint = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint;
        var selectedTemplateFromModal = [];
        var generatedDocumentJson = {};
        var templateSourceErrorMsg = '';
        //var isForUnitTemplates = false; // a flag to be sent to select templates dialog to separate unit templates from plan templates

        function DocumentDataService() {
            var self = this;
            self.getDocuments = function (filterQuery) {
                var docsApi = '';
                if (angular.isDefined(filterQuery)) {
                    docsApi = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint + filterQuery;
                }
                else {
                    docsApi = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint + encodeURI('TYPE:"document" &associationExpansionLevel=1 &start=0&rows=20&sort=lastModificationDate desc');
                }

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of documents, please wait...')

                $http.get(docsApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                //Now return the promise
                return defer.promise;
            };

            self.getDocument = function (documentId) {

                var docApi = ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/documents/' + documentId + '/content';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading document, please wait...')

                $http.get(encodeURI(docApi)).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                //Now return the promise
                return defer.promise;
            };

            self.getDocumentById = function (documentId) {
                return $http.get(encodeURI(restApiEndpoint + '/documents/' + documentId));
            };

            self.getDocumentByName = function (name) {
                return $http.get(encodeURI(restSearchApiEndpoint + 'TYPE:"document" AND docName:' + '"' + name + '"'));
            };

            self.uniqueNameCheck = function (documentName, format) {
                return $http({
                    method: 'POST',
                    url: ENV_MEDIA_MANAGEMENT.mediaApiEndpoint + '/document/nameCheck',
                    data: {
                        'name': documentName,
                        'format': format
                    },
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            };
            
            ENV_MEDIA_MANAGEMENT.restDistributionApiEndpoint = 'http://10.22.135.10:8080/gateway/distribution/api/v1'; // Should be in Gruntfile.js

            self.downloadDocuments = function (documentIds) {
                return $http({
                    method: 'POST',
                    url: ENV_MEDIA_MANAGEMENT.restDistributionApiEndpoint + '/document/download',
                    responseType: 'arraybuffer',
                    data: {
                        'documents': documentIds
                    },
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
            };

            self.getDocTypes = function () {
                var docTypeApi = mediaApi + '/DocumentType';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of document types, please wait...')
                $http.get(docTypeApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getDocListFilterMeta = function () {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getDocumentListFilterMeta();

                $http.get(fieldUrl).success(function (response) {
                    if (!response.error) { // According Hasan request, now backend return data, or error.
                        defer.resolve(response);
                    } else {
                        defer.reject(response.message);
                    }
                }).error(function (reason) {
                    defer.reject(reason);
                });
                return defer.promise;
            };

            self.getTemplates = function (filterQuery) {
                var templateApi = '';
                if (angular.isDefined(filterQuery)) {
                    templateApi = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint + filterQuery;
                }
                else {
                    templateApi = ENV_MEDIA_MANAGEMENT.restSearchApiEndpoint + encodeURI('TYPE:"template" &associationExpansionLevel=1 &start=0&rows=20&sort=lastModificationDate desc');
                }

                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of templates, please wait...')
                $http.get(templateApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                return defer.promise;
            };
            // get template By documentType and templateStatus needs to equal to 'Published'
            self.getAllTemplates = function (sourceType, docType, searchQuery) {
                var query = '';
                var docTypeStr = (docType ? ' AND documentType: "' + docType + '" ' : '');

                switch (sourceType) {
                    case 'multi':
                        query = 'TYPE:"template" AND templateStatus:"Published" AND NOT numSources:1 AND isUnit:false' + docTypeStr + '&associationExpansionLevel=1';
                        break;
                    case 'single':
                        query = 'TYPE:"template" AND templateStatus:"Published" AND numSources:1 ' + docTypeStr + '&associationExpansionLevel=1';
                        break;
                    case 'all':
                        query = 'TYPE:"template" AND templateStatus:"Published" ' + docTypeStr + '&associationExpansionLevel=1';
                        break;
                    default:
                        query = 'TYPE:"template" AND templateStatus:"Published" ' + docTypeStr + '&associationExpansionLevel=1';
                        break;
                }

                if (docType) {
                    query += ' &start=0&rows=20';
                }

                if (searchQuery) {
                    query = searchQuery;
                }
                var templatesByDocTypeApi = restSearchApiEndpoint + query;
                var defer = $q.defer();

                // ConfirmationModalFactory.open('Loading a list of templates, please wait...');
                $http.get(encodeURI(templatesByDocTypeApi)).success(function (response) {
                    // ConfirmationModalFactory.close();
                    defer.resolve(response);
                }).error(function (response) {
                    // ConfirmationModalFactory.close();
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getDocumentTypes = function () {
                var docTypeApi = restApiEndpoint + '/types/template';
                var defer = $q.defer();

                $http.get(docTypeApi).success(function (response) {

                    var docTypeEntity = response[0].properties.documentType; //get the template json schema then retrieve the documentType enum

                    if (docTypeEntity != null) {
                        if (docTypeEntity.datatype === 'enum') {
                            if (docTypeEntity.type === 'string') {
                                /*jshint -W024 */
                                defer.resolve(docTypeEntity.enum);
                            } else if (docTypeEntity.type === 'array') {
                                /*jshint -W024 */
                                defer.resolve(docTypeEntity.items.enum);
                            } else {
                                defer.reject(response);
                            }
                        }
                    } else {
                        defer.reject(response);
                    }

                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getDocumentMetadata = function () {
                var docSchemaApi = restApiEndpoint + '/types/document';
                var defer = $q.defer();

                $http.get(docSchemaApi).success(function (response) {
                    defer.resolve(response);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getDocumentFormats = function () {
                var docFormatApi = restApiEndpoint + '/types/document';
                var defer = $q.defer();

                $http.get(docFormatApi).success(function (response) {

                    var docFormatEntity = response[0].properties.documentFormat; //get the document json schema then retrieve the documentFormat enum

                    if (docFormatEntity != null) {
                        if (docFormatEntity.datatype === 'enum') {
                            if (docFormatEntity.type === 'string') {
                                /*jshint -W024 */
                                defer.resolve(docFormatEntity.enum);
                            } else if (docFormatEntity.type === 'array') {
                                /*jshint -W024 */
                                defer.resolve(docFormatEntity.items.enum);
                            } else {
                                defer.reject(response);
                            }
                        }
                    } else {
                        defer.reject(response);
                    }

                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getProducts = function () {
                var productApi = restApiEndpoint + '/products';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of products, please wait...')

                $http.get(productApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getPlans = function (searchQuery) {

                var planApi = restSearchApiEndpoint;
                planApi += (searchQuery) ? searchQuery : 'TYPE:"plan" &start=0&rows=20&associationExpansionLevel=1';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of available plans, please wait...')
                $http.get(encodeURI(planApi)).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });
                return defer.promise;
            };

            self.getProductById = function (productId) {
                return $http.get(encodeURI(restApiEndpoint + '/products/' + productId));
            };

            self.getPlanById = function (planId) {
                return $http.get(encodeURI(restApiEndpoint + '/plans/' + planId));
            };

            self.getUnits = function (searchQuery) {
                var unitApi = restSearchApiEndpoint;
                unitApi += (searchQuery) ? searchQuery : 'TYPE:"unit" &start=0&rows=20&associationExpansionLevel=1';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading a list of available units, please wait...')

                $http.get(encodeURI(unitApi)).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getUnitById = function (unitId) {
                return $http.get(encodeURI(restApiEndpoint + '/units/' + unitId));
            };

            self.getUnitSchema = function () {
                var unitSchemaApi = restApiEndpoint + '/types/unit';
                var defer = $q.defer();

                $http.get(unitSchemaApi).success(function (response) {
                    defer.resolve(response[0].properties);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };           

            self.getTemplateSchema = function () {
                var templatesSchemaApi = restApiEndpoint + '/types/template';
                var defer = $q.defer();

                $http.get(templatesSchemaApi).success(function (response) {
                    defer.resolve(response[0].properties);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };

            self.getAspectDefinitions = function () {
                var aspectDefinitionsApi = restApiEndpoint + '/types/aspectDefinitions';
                var defer = $q.defer();

                $http.get(aspectDefinitionsApi).success(function (response) {
                    defer.resolve(response[0].properties);
                }).error(function (response) {
                    defer.reject(response);
                });

                return defer.promise;
            };

            // call Document Generation API for both single source and multi source
            self.generateDocuments = function (postJsonData) {
                var docGenApi = docGenerationApi + '/Document/GenerateDocument';

                var defer = $q.defer();
                var responseObj = {};
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Generating document(s) with selected multi-source template, please wait...')

                $http.post(docGenApi, postJsonData, {
                    'Content-Type': 'application/json',
                    'skipInterceptorError': true
                    }).success(function (response, status) {
                        if (status === 200) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            defer.resolve(response);
                        } else {
                            responseObj = {
                                errorCode: 'Unable to Generate Document',
                                errorDetails: response ? response : 'Error occured when generating document.',
                                errorId: status,
                                errorMessage: 'Unable to Generate Document',
                                httpStatus: response ? response.httpStatus : 'Server Error',
                                httpStatusCode: response ? response.httpStatusCode : status
                            };

                            QueryDialog.open(responseObj.httpStatus, responseObj, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');

                            defer.reject(response, status);
                        }
                    })
                    .error(function (response, status) {
                        if (status === 408) {  //if http timeout
                            responseObj = {
                                errorCode: 'Generating Document',
                                errorDetails: 'The system is generating the document. Please check back later.',
                                errorId: status,
                                errorMessage: 'Generating Document',
                                httpStatus: 'Timed out',
                                httpStatusCode: status
                            };

                            QueryDialog.open(responseObj.httpStatus, responseObj, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');

                        } else if (status === 500 && response.message && response.message.indexOf('Read timed out') > -1 && response.exception && response.exception.indexOf('java.net.SocketTimeoutException') > -1) {

                            responseObj = {
                                errorCode: 'Generating Document',
                                errorDetails: 'The system is generating the document. Please check back later.',
                                errorId: status,
                                errorMessage: 'Generating Document',
                                httpStatus: 'Timed out',
                                httpStatusCode: status
                            };

                            QueryDialog.open(responseObj.httpStatus, responseObj, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');

                        } else {

                            responseObj = {
                                errorCode: 'Unable to Generate Document',
                                errorDetails: response ? response : 'Error occured when generating document.',
                                errorId: status,
                                errorMessage: 'Unable to Generate Document',
                                httpStatus: response ? response.httpStatus : 'Server Error',
                                httpStatusCode: response ? response.httpStatusCode : status
                            };

                            QueryDialog.open(responseObj.httpStatus, responseObj, 'minus', 'ppm-modal-dialog-error', 'views/product-plan-management/template/dialog/modal-dialog-content-backend-exception.html');

                        }
                        defer.reject(response, status);
                    });

                return defer.promise;
            };

            self.error = {
                subject: '',
                detail: ''
            };

            self.showError = function () {
                ConfirmationModalFactory.open(self.error.subject, self.error.detail, ENV_MEDIA_MANAGEMENT.modalErrorTimeout);
            };

            self.getTemplateById = function (templateId) {
                var getTemplateApi = restApiEndpoint + '/templates/' + templateId + '?associationExpansionLevel=1';
                var defer = $q.defer();
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Defining Template, please wait...')

                $http.get(getTemplateApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                //Now return the promise
                return defer.promise;
            };

            self.getTemplateListFilterMeta = function () {
                var defer = $q.defer();
                var fieldUrl = PPMENV.getTemplateListFilterMeta();

                $http.get(fieldUrl).success(function (response) {
                    if (!response.error) { // According Hasan request, now backend return data, or error.
                        defer.resolve(response);
                    } else {
                        defer.reject(response.message);
                    }
                }).error(function (reason) {
                    defer.reject(reason);
                });
                return defer.promise;
            };

            self.defineTemplate = function (/*skipMessage*/) {
                var defineTemplateApi = restApiEndpoint + '/types/template';
                var defer = $q.defer();
                //if (!skipMessage) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Defining Template, please wait...')
                //}
                $http.get(defineTemplateApi).success(function (response) {
                    //if (!skipMessage) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    //}
                    defer.resolve(response);
                }).error(function (response) {
                    //if (!skipMessage) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    //}
                    defer.reject(response);
                });

                //Now return the promise
                return defer.promise;
            };

            self.defineTemplateProductProperties = function (/*skipMessage*/) {
                var defineTemplateProductPropertiesApi = restApiEndpoint + '/types/aspectDefinitions';
                var defer = $q.defer();
                //if(!skipMessage) {
                /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading aspectDefinitions, please wait...')
                //}
                $http.get(defineTemplateProductPropertiesApi).success(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.resolve(response);
                }).error(function (response) {
                    /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                    defer.reject(response);
                });

                //Now return the promise
                return defer.promise;
            };

            self.updateTemplate = function (patchData, templateId) {
                var defer = $q.defer();
                var updateTemplateApi = restApiEndpoint + '/templates/' + templateId;
                $http({
                    method: 'PATCH',
                    url: updateTemplateApi,
                    data: JSON.stringify(patchData)
                }).success(function (data) {
                    defer.resolve(data);
                })
                    .error(function (reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            };

            self.updateTemplateSource = function (patchData, templateSourceId) {
                var defer = $q.defer();
                var updateTemplateSourceApi = restApiEndpoint + '/templateSources/' + templateSourceId;
                $http({
                    method: 'PATCH',
                    url: updateTemplateSourceApi,
                    data: JSON.stringify(patchData)
                }).success(function (data) {
                    defer.resolve(data);
                })
                    .error(function (reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            };

            self.getTemplateSourceErrorMsg = function () {
                return templateSourceErrorMsg;
            };

            self.setTemplateSourceErrorMsg = function (data) {
                templateSourceErrorMsg = data;
            };

            self.getSelectedTemplate = function () {
                return selectedTemplateFromModal;
            };

            self.setSelectedTemplate = function (data) {
                selectedTemplateFromModal = data;
            };

            self.getGeneratedDocJson = function () {
                return generatedDocumentJson;
            };

            self.setGeneratedDocJson = function (data) {
                generatedDocumentJson = data;
            };

        }

        return new DocumentDataService();

    }]);
