﻿'use strict';

angular.module('p2AdvanceApp')
    .factory('ModalDialogFactory', ['$modal', '$rootScope', function ($modal, $rootScope) {

        var modalDialogDefaults = {
            backdrop: 'static',
            keyboard: false,
            scope: $rootScope.$new()
        };

        var modalInstance;

        // Public API here
        return {
            showDialog: function (modalOptions) {
                var modalConfig = {};
                angular.extend(modalConfig, modalDialogDefaults, modalOptions);
                modalInstance = $modal.open(modalConfig);
                return modalInstance.result;
            },

            closeDialog: function (selectedObjs) {
                if (modalInstance != null) {
                    modalInstance.close(selectedObjs);
                }
            }
        };

    }]);