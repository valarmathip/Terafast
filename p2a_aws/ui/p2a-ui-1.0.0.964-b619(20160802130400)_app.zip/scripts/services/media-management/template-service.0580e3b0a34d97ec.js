'use strict';

/**
 * @ngdoc service
 * @name p2AdvanceApp.TemplateService
 * @description
 * # TemplateService
 * Service in the p2AdvanceApp.
 */
angular.module('p2AdvanceApp')
  .service('TemplateService', function ($http, ENV_MEDIA_MANAGEMENT, dialogFactorySvc) {
    // AngularJS will instantiate a singleton by calling "new" on this function
    return {
        extractContentControls : function(templateId) {
            return $http.get(encodeURI(ENV_MEDIA_MANAGEMENT.mediaApiEndpoint + '/Template/ExtractContentControls/' + templateId));
        },

        updateStatus : function(objectId, status) {
            return $http({
                    method: 'PATCH',
                    url: ENV_MEDIA_MANAGEMENT.restApiEndpoint + '/templates/' + objectId,
                    data: {
                        'templateStatus': status
                    },
                    headers: {
                        'Content-Type': 'application/json'
                    }
            });
        },

        uniqueNameCheck : function(templateName) {
            return $http({
                method: 'POST',
                url: ENV_MEDIA_MANAGEMENT.mediaApiEndpoint + '/template/nameCheck',
                data: {
                    'name': templateName
                },
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        },

        showTemplateSummaryDialog: function (templateId) {
            var dlgUrl = 'views/media-management/template-summary.html';
            var controller = 'TemplateSummaryDialogCtrl';
            var data = {
                getTemplate: ['DocumentDataFactory', function (DocumentDataFactory) {
                    return DocumentDataFactory.getTemplateById(templateId);
                }]
            };
            var options = {
                size: 'lg'
            };
            dialogFactorySvc.openModalDialog(dlgUrl, controller, data, options);
        }
    };
  });
