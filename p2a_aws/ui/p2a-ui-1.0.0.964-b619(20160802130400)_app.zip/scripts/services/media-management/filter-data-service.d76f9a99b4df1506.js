﻿'use strict';

angular.module('p2AdvanceApp')
    .factory('FilterDataService', ['PPMFilterMetaSvc', function(PPMFilterMetaSvc) {
        var batchFilters = {
            'Status': {
                'batchStatus': 'Status'
            },
            'Submitted By': {
                'batchSubmittedBy': {
                    'Submitted By': ['']
                }
            },
            'Submitted within': {
                'batchSubmittedDate': {
                    'Submitted Within': ['Last 15 days', 'Last 30 days', 'Last 60 days', 'Date Range']
                }
            }
        };

        var accountFilters = {
            'accountStatus': 'Account Status',
            'renewalStartDate': {
                'Renewal Start Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
            },
            'renewalEndDate': {
                'Renewal End Date': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
            },
            'marketSegment': 'Account Market Segment'
        };


        var pushAttributeToFilter = function(attrData, propertyName, attrName) {

            var filterValueJson = [];

            if (attrData[propertyName] != null) {
                if (attrData[propertyName].datatype === 'enum') {
                    if (attrData[propertyName].type === 'string') {
                        /*jshint -W024 */
                        angular.forEach(attrData[propertyName].enum, function(arrVal) {
                            var attrObj = {};
                            attrObj['AttributeId'] = propertyName;
                            attrObj['AttributeName'] = attrName;
                            attrObj['AttributeValue'] = arrVal;
                            attrObj['DisplayValue'] = arrVal;

                            filterValueJson.push(attrObj);
                        });

                    } else if (attrData[propertyName].type === 'array') {
                        /*jshint -W024 */
                        angular.forEach(attrData[propertyName].items.enum, function(arrVal) {
                            var attrObj = {};
                            attrObj['AttributeId'] = propertyName;
                            attrObj['AttributeName'] = attrName;
                            attrObj['AttributeValue'] = arrVal;
                            attrObj['DisplayValue'] = arrVal;

                            filterValueJson.push(attrObj);
                        });
                    }
                }
            }

            var filterItem = {
                'name': attrName,
                'values': filterValueJson
            };

            return filterItem;
        };

        var buildShowHSAFilter = function(attrData, propertyName, attrName) {
            var filterValueJson = [];

            if (attrData[propertyName] != null) {
                var attrObj1 = {};
                attrObj1['AttributeId'] = propertyName;
                attrObj1['AttributeName'] = attrName;
                attrObj1['AttributeValue'] = true;
                attrObj1['DisplayValue'] = 'Yes';
                filterValueJson.push(attrObj1);

                var attrObj2 = {};
                attrObj2['AttributeId'] = propertyName;
                attrObj2['AttributeName'] = attrName;
                attrObj2['AttributeValue'] = false;
                attrObj2['DisplayValue'] = 'No';
                filterValueJson.push(attrObj2);
            }

            var filterItem = {
                'name': attrName,
                'values': filterValueJson
            };

            return filterItem;
        };

        var buildCreatedByFilter = function(units, propertyName, attrName, attrVal) {
            var totalCreatedByArr = [];

            totalCreatedByArr = [{
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: attrVal,
                DisplayValue: 'Me'
            }];

            var filterItem = {
                'name': attrName,
                'values': totalCreatedByArr
            };
            return filterItem;
        };

        var buildLastModifiedByFilter = function(units, propertyName, attrName, attrVal) {
            var totalLastModifiedByArr = [];

            totalLastModifiedByArr = [{
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: attrVal,
                DisplayValue: 'Me'
            }];

            var filterItem = {
                'name': attrName,
                'values': totalLastModifiedByArr
            };
            return filterItem;
        };

        var buildUnitPlanYearFilter = function(propertyName, attrName) {

            var currentYear = new Date().getFullYear();

            var unitPlanYearAttributes = [{
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: (currentYear - 1).toString(),
                DisplayValue: (currentYear - 1).toString()
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: currentYear.toString(),
                DisplayValue: currentYear.toString()
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: (currentYear + 1).toString(),
                DisplayValue: (currentYear + 1).toString()
            }];

            var filterItem = {
                'name': attrName,
                'values': unitPlanYearAttributes
            };
            return filterItem;

        };


        var buildTemplatePlanYearFilter = function (propertyName, attrName) {

            var templatePlanYearAttributes = [{
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'Current Year + 1',
                DisplayValue: 'Current Year + 1'
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'Current Year',
                DisplayValue: 'Current Year'
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'Current Year - 1',
                DisplayValue: 'Current Year - 1'
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'text',
                DisplayValue: 'text'
            }];

            var filterItem = {
                'name': attrName,
                'values': templatePlanYearAttributes
            };
            return filterItem;

        };


        var buildModifiedWithinFilter = function(propertyName, attrName) {

            var modifiedWithinAttributes = [{
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'Last 15 Days',
                DisplayValue: 'Last 15 Days'
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'Last 30 Days',
                DisplayValue: 'Last 30 Days'
            }, {
                AttributeId: propertyName,
                AttributeName: attrName,
                AttributeValue: 'Last 60 Days',
                DisplayValue: 'Last 60 Days'
            }];

            var filterItem = {
                'name': attrName,
                'values': modifiedWithinAttributes
            };
            return filterItem;

        };

        var datesData = {
            effectiveDate: {
                datatype: 'enum',
                type: 'string',
                'enum': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
            },
            endDate: {
                datatype: 'enum',
                type: 'string',
                'enum': ['Last 6 months', 'Next 6 months', 'Last 12 months', 'Next 12 months']
            }
        };

        return {
            //later might need to get plan filters and product filters this way
            getUnitFilters: function(unitPropertiesData, aspectDefsData, totalUnits, unitOwner) {
                var allFilterData = [];
                var applicableCoverageTiersFilter = [];
                var distributionChannelsFilter = [];
                var fundingArrangementsFilter = [];
                var lineOfBusinessFilter = [];
                var marketSegmentsFilter = [];
                var productRegulatoryApprovalFilter = [];
                var productTypesFilter = [];
                var unitPlanYearFilter = [];
                var showHSAFilter = [];
                var createdByFilter = [];
                var lastModifiedByFilter = [];
                var modifiedWithinFilter = [];

                applicableCoverageTiersFilter = pushAttributeToFilter(unitPropertiesData, 'applicableCoverageTiers', 'Applicable Coverage Tiers');
                distributionChannelsFilter = pushAttributeToFilter(unitPropertiesData, 'distributionChannels', 'Distribution Channels');
                fundingArrangementsFilter = pushAttributeToFilter(aspectDefsData, 'fundingArrangements', 'Funding Arrangements');
                lineOfBusinessFilter = pushAttributeToFilter(unitPropertiesData, 'lineOfBusiness', 'Line Of Business');
                marketSegmentsFilter = pushAttributeToFilter(aspectDefsData, 'marketSegments', 'Market Segments');
                productRegulatoryApprovalFilter = pushAttributeToFilter(unitPropertiesData, 'productRegulatoryApproval', 'Product Regulatory Approval');
                productTypesFilter = pushAttributeToFilter(aspectDefsData, 'productTypes', 'Product Types');
                unitPlanYearFilter = buildUnitPlanYearFilter('unitPlanYear', 'Unit Plan Year');
                showHSAFilter = buildShowHSAFilter(unitPropertiesData, 'showHSA', 'Show HSA');
                createdByFilter = buildCreatedByFilter(totalUnits, 'createdBy', 'Created By', unitOwner);
                lastModifiedByFilter = buildLastModifiedByFilter(totalUnits, 'lastModifiedBy', 'Last Modified By', unitOwner);
                modifiedWithinFilter = buildModifiedWithinFilter('lastModificationDate', 'Modified Within');

                allFilterData.push(applicableCoverageTiersFilter);
                allFilterData.push(distributionChannelsFilter);
                allFilterData.push(fundingArrangementsFilter);
                allFilterData.push(lineOfBusinessFilter);
                allFilterData.push(marketSegmentsFilter);
                allFilterData.push(productRegulatoryApprovalFilter);
                allFilterData.push(productTypesFilter);
                allFilterData.push(unitPlanYearFilter);
                allFilterData.push(showHSAFilter);
                allFilterData.push(createdByFilter);
                allFilterData.push(lastModifiedByFilter);
                allFilterData.push(modifiedWithinFilter);

                return allFilterData;
            },

            getTemplateFilters: function(templatePropertiesData, aspectDefsData, templates, createdByVal) {

                // certain filters are commented out because they are not currently supported in multi-source templates
                // TODO: fix or remove them depending on whether filtering will be possible on those attributes
                var allFilterData = [];
                var documentClassFilter = [];
                //var productClassesFilter = [];
                //var productTypesFilter = [];
                //var marketSegmentsFilter = [];
                //var providerTiersFilter = [];
                var startDatesFilter = [];
                var endDatesFilter = [];
                var createdByFilter = [];
                var templatePlanYearFilter = [];
                //var fundingArrangementsFilter = [];


                documentClassFilter = pushAttributeToFilter(templatePropertiesData, 'businessEntity', 'Document Class');
                //productClassesFilter = pushAttributeToFilter(aspectDefsData, 'productClasses', 'Products');
                //productTypesFilter = pushAttributeToFilter(aspectDefsData, 'productTypes', 'Product Types');
                //marketSegmentsFilter = pushAttributeToFilter(aspectDefsData, 'marketSegments', 'Market Segments');
                // provider tiers
                startDatesFilter = pushAttributeToFilter(datesData, 'effectiveDate', 'Effective Start Date');
                endDatesFilter = pushAttributeToFilter(datesData, 'endDate', 'Effective End Date');
                createdByFilter = buildCreatedByFilter(templates, 'createdBy', 'Created By', createdByVal);
                templatePlanYearFilter = buildTemplatePlanYearFilter('templatePlanYear', 'Plan Year');
                //fundingArrangementsFilter = pushAttributeToFilter(aspectDefsData, 'fundingArrangements', 'Funding Arrangements');


                allFilterData.push(documentClassFilter);
                //allFilterData.push(productClassesFilter);
                //allFilterData.push(productTypesFilter);
                //allFilterData.push(marketSegmentsFilter);
                // provider tiers
                allFilterData.push(startDatesFilter);
                allFilterData.push(endDatesFilter);
                // effective end date
                allFilterData.push(createdByFilter);
                allFilterData.push(templatePlanYearFilter);
                //allFilterData.push(fundingArrangementsFilter);


                return allFilterData;
            },
            updateValidationFilters: function(filtersMeta) {
                var validationFilters = {
                    'Status': {
                        'ruleStatus': 'Status'
                    },
                    'Severity': {
                        'severity': 'Severity'
                    },
                    'Created Within': {
                        'creationDate': {
                            'Created Within': ['Last 15 days', 'Last 30 days', 'Last 60 days', 'Date Range']
                        }
                    },
                    'Modified within': {
                        'lastModificationDate': {
                            'Modified within': ['Last day', 'Last 7 days', 'Last 15 days', 'Last 30 days', 'Last 60 days', 'Date Range']
                        }
                    }
                };

                var initArr = [];
                initArr.push(validationFilters);
                var filterArray = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, filtersMeta[0].properties, []);
                var filters = [];
                angular.forEach(filterArray, function(filterGroups) {
                    angular.forEach(filterGroups, function(item) {
                        filters.push(item[0]);
                    });
                });
                return filters;
            },
            updateListBatchFilters: function(filtersMeta, submittedBy) {
                var filters = [];
                var statusProp = filtersMeta[0].properties; //Contains batch list status information
                batchFilters['Submitted By']['batchSubmittedBy']['Submitted By'] = [];
                angular.forEach(submittedBy, function(key) {
                    if (key !== null && angular.isDefined(key)) {
                        batchFilters['Submitted By']['batchSubmittedBy']['Submitted By'].push(key);
                    }
                });
                var initArr = this.batchFiltersMeta();
                var filterArray = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, statusProp, []);
                angular.forEach(filterArray, function(filterGroups) {
                    angular.forEach(filterGroups, function(item) {
                        filters.push(item[0]);
                    });
                });
                return filters;
            },
            batchFiltersMeta: function() {
                var initArr = [];
                initArr.push(batchFilters);
                return initArr;
            },
            buildAccountFilters: function (accountProp) {
                var initArr = [];
                var filterObj = {
                    'Account Filters': accountFilters
                };
                initArr.push(filterObj);
                var filterGroups = PPMFilterMetaSvc.assignPropertiesToFiltersGroups(initArr, accountProp, []);
                return filterGroups;
            }
        };
    }]);