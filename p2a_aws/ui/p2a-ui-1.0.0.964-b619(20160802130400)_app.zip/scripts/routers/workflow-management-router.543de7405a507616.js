'use strict';

angular.module('p2AdvanceApp')
    .config(['$stateProvider', function($stateProvider) {

        $stateProvider
            .state('home.workflow', {
                'abstract': true,
                url: '/workflow',
                template: '<ui-view/>',
                controller: ['$rootScope', 'mainNavBarTabs', function($rootScope, mainNavBarTabs) {
                    $rootScope.mainNavBarTabs = mainNavBarTabs;
                }],
                resolve: {
                    mainNavBarTabs: function() {
                        return [{
                            badgetInfoNum: 0,
                            badgetErrorNum: 0,
                            locationPath: '/workflow/tasks',
                            name: 'MY TASKS',
                            routerState: 'workflow.tasks',
                            permission: '|workflow.read,|all.read'
                        }, {
                            badgetInfoNum: 0,
                            badgetErrorNum: 0,
                            locationPath: '/workflow/cases',
                            name: 'CASES',
                            routerState: 'workflow.cases',
                            permission: '|workflow.read,|all.read'
                        }];
                    }
                }
            })
            .state('home.workflow.tasks', {
                cache: false,
                url: '/tasks',
                templateUrl: 'views/workflow-management/task-list.html',
                controller: 'TaskListCtrl',
                resolve: {
                    filtersGroupsMeta: ['WorkflowDataFactory', function(WorkflowDataFactory) {
                        return WorkflowDataFactory.getTaskListFilterMeta()
                            .then(function(data) {
                                return data.data[0].Filters;
                            });
                    }]
                }
            })
            .state('home.workflow.cases', {
                cache: false,
                url: '/cases',
                templateUrl: 'views/workflow-management/case-list.html',
                controller: 'CaseListCtrl',
                resolve: {
                    filtersGroupsMeta: ['WorkflowDataFactory', function(WorkflowDataFactory) {
                        return WorkflowDataFactory.getCaseListFilterMeta()
                            .then(function(data) {
                                return data.data[0].Filters;
                            });
                    }]
                }
            })
            .state('home.workflow.taskForm', {
                cache: false,
                url: '/tasks/:taskId',
                templateUrl: 'views/workflow-management/task-dynamic-form.html',
                controller: 'TaskDynamicFormCtrl',
                resolve: {
                    TaskDetails: ['WorkflowDataFactory', '$stateParams', function(WorkflowDataFactory, $stateParams) {
                        if ($stateParams.taskId) {
                            return WorkflowDataFactory.getTaskDetails($stateParams.taskId)
                                .then(function(data) {
                                    return data.data;
                                });
                        }
                    }]
                }
            });

    }]);
