﻿'use strict';

angular.module('p2AdvanceApp')
    .config(['$stateProvider', function($stateProvider) {

        $stateProvider
            .state('home.media-management', {
                url: '/media-management',
                'abstract': true,
                template: '<ui-view/>',
                controller: ['$rootScope', 'mainNavBarTabs', function ($rootScope, mainNavBarTabs) {
                    $rootScope.mainNavBarTabs = mainNavBarTabs;
                }],
                resolve: {
                    mainNavBarTabs: function () {
                        return [{
                            badgetInfoNum: 0,
                            badgetErrorNum: 0,
                            locationPath: '/media-management/documents',
                            name: 'DOCUMENTS',
                            routerState: 'media-management.documents',
                            permission: '|document.read,|all.read'
                        }, {
                            badgetInfoNum: 0,
                            badgetErrorNum: 0,
                            locationPath: '/media-management/templates',
                            name: 'TEMPLATES',
                            routerState: 'media-management.templates',
                            permission: '|template.read,|all.read'
                        }, {
                            badgetInfoNum: 0,
                            badgetErrorNum: 0,
                            locationPath: '/media-management/listBatch',
                            name: 'BATCHES',
                            routerState: 'media-management.listBatch',
                            permission: '|batch.read,|all.read'
                        }];
                    }
                }
            })
            .state('home.media-management.documents', {
                cache: false,
                url: '/documents',
                templateUrl: 'views/media-management/list-documents.html',
                controller: 'DocsCtrl',
                resolve: {
                    documentsPromise: ['DocumentDataFactory',
                        function (DocumentDataFactory) {
                            return DocumentDataFactory.getDocuments().then(function (data) {
                                return data;
                            });
                        }
                    ],
                    filtersGroupsMeta: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.getDocListFilterMeta();
                    }],
                    docFiltersMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.getDocumentMetadata(true);
                    }],
                    docFiltersProductPropertiesMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.defineTemplateProductProperties(true); // do not show "loading aspectDefinitions" message
                    }],
                    authorizedUserInfo: ['$auth', function ($auth) {
                        return $auth.requestUserInfo();
                    }]
                }
            })
            .state('home.media-management.templates', {
                url: '/templates',
                templateUrl: 'views/media-management/list-templates.html',
                controller: 'TemplatesCtrl',
                resolve: {
                    templatesPromise: ['DocumentDataFactory',
                        'ConfirmationModalFactory',
                        '$log',
                        'ENV',
                        function (DocumentDataFactory, ConfirmationModalFactory, $log, ENV) {
                            return DocumentDataFactory.getTemplates().then(function (data) {
                                return data;
                            }, function (reason) {
                                $log.error(reason);
                                ConfirmationModalFactory.open('Error Message', 'Error occured when loading available templates.', ENV.modalErrorTimeout);
                            });
                        }
                    ],
                    filtersGroupsMeta: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.getTemplateListFilterMeta();
                    }],
                    templateFiltersMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.defineTemplate(true);
                    }],
                    templateFiltersProductPropertiesMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.defineTemplateProductProperties(true); // do not show "loading aspectDefinitions" message
                    }],
                    authorizedUserInfo: ['$auth', function ($auth) {
                        return $auth.requestUserInfo();
                    }]
                }
            })
            .state('home.media-management.generateDocument', {
                url: '/generate-document',
                params: {
                    'docType': '',
                    'batchObjectId': '',
                    'businessEntity': '',
                    'dataSourceId': ''
                },
                templateUrl: 'views/media-management/generate-document.html',
                controller: 'GenerateDocCtrl',
                resolve: {
                    docTypePromise: ['DocumentDataFactory',
                        'ConfirmationModalFactory',
                        '$log',
                        function (DocumentDataFactory, ConfirmationModalFactory, $log) {
                            return DocumentDataFactory.getDocumentTypes().then(function (data) {
                                return data;
                            }, function (response) {
                                $log.error(response);
                            });
                        }
                    ],
                    docFormatPromise: ['DocumentDataFactory',
                        'ConfirmationModalFactory',
                        '$log',
                        function (DocumentDataFactory, ConfirmationModalFactory, $log) {
                            return DocumentDataFactory.getDocumentFormats().then(function (data) {
                                return data;
                            }, function (response) {
                                $log.error(response);
                            });
                        }
                    ],
                    allTemplatesPromise: ['DocumentDataFactory',
                        'ConfirmationModalFactory',
                        '$log',
                        function (DocumentDataFactory, ConfirmationModalFactory, $log) {
                            //initially load the first doc type which is "SBC" related templates
                            //var isMultiSource = $stateParams.isMultiSource;
                            return DocumentDataFactory.getAllTemplates('all').then(function (data) {
                                return data;
                            }, function (reason) {
                                $log.error(reason);
                            });
                        }
                    ],
                    selectedDocType: ['$stateParams', function ($stateParams) {
                        return $stateParams.docType;
                    }],
                    batchObjectIdParam: ['$stateParams', function ($stateParams) {
                        return $stateParams.batchObjectId;
                    }],
                    businessEntity: ['$stateParams', function ($stateParams) {
                        return {'entityType': $stateParams.businessEntity ? $stateParams.businessEntity : '', 'dataSourceId': $stateParams.dataSourceId ? $stateParams.dataSourceId : '' };
                    }]
                }
            })
            .state('home.media-management.generateDocument.singleSource', {
                url: '/single-source',
                templateUrl: 'views/media-management/document-snippet-single-source.html',
                controller: 'GenerateDocSingleSourceCtrl'
            })
            .state('home.media-management.generateDocument.multiSource', {
                url: '/multi-source',
                templateUrl: 'views/media-management/document-snippet-multi-source.html',
                controller: 'GenerateDocMultiSourceCtrl'
            })
            .state('home.media-management.generateDocument.multiSource.offeringsAndPlans', {
                url: '/offerings-and-plans',
                params: {
                    'accountId': '',
                    'accountType': ''
                },
                onEnter: ['OfferingAccountService', 'ModalDialogFactory', function (OfferingAccountService, ModalDialogFactory) {

                    var dialogOptions = {
                        templateUrl: 'views/media-management/offerings-plans-modal.html',
                        controller: 'OfferingsAndPlansCtrl',
                        size: 'lg',
                        backdrop: false,
                        resolve: {
                            parentState: function () {
                                return 'home.media-management.generateDocument.multiSource';
                            },
                            accountObjectId: function ($stateParams) {
                                return $stateParams.accountId;
                            }
                        }
                    };

                    ModalDialogFactory.showDialog(dialogOptions);

                }],
                views: {
                    'modalbody@': {
                        url: '/select-offering',
                        templateUrl: 'views/media-management/select-offering.html',
                        controller: 'SelectOfferingCtrl',
                        resolve: {
                            offeringList: ['ProductPlanMgmtSvc', function (ProductPlanMgmtSvc) {
                                    var associationExpansionLevel = 0;
                                    return ProductPlanMgmtSvc.getOfferintListViaSearchApi('', associationExpansionLevel);
                                }
                            ],
                            offeringsFieldsMeta: ['ProductPlanMgmtSvc', function (ProductPlanMgmtSvc) {
                                return ProductPlanMgmtSvc.getOfferings();
                            }],
                            plansAspectDefs: ['ProductPlanMgmtSvc', function (ProductPlanMgmtSvc) {
                                return ProductPlanMgmtSvc.getAspectDefinitions();
                            }],
                            selectedAccount: ['OfferingAccountService', '$stateParams', function (OfferingAccountService, $stateParams) {
                                if ($stateParams.accountId && $stateParams.accountId !== '' && $stateParams.accountType && $stateParams.accountType !== '') {
                                    var associationExpansionLevel = 2;

                                    if ($stateParams.accountType.toLowerCase() === 'account') {                                        
                                        return OfferingAccountService.getAccountByAccountId(associationExpansionLevel, $stateParams.accountId);
                                    }
                                    else if ($stateParams.accountType.toLowerCase() === 'group') {
                                        return OfferingAccountService.getGroupByGroupId(associationExpansionLevel, $stateParams.accountId);
                                    }
                                } else {
                                    return null;
                                }
                            }]
                        }
                    }
                }
            })
            .state('home.media-management.generateDocument.multiSource.offeringsAndPlans.offerings', {
                url: '/select-offering',
                views: {
                    'modalbody@': {
                        //url: '/select-offering',
                        templateUrl: 'views/media-management/select-offering.html',
                        controller: 'SelectOfferingCtrl',
                        resolve: {
                            offeringList: ['ProductPlanMgmtSvc', function (ProductPlanMgmtSvc) {
                                    var associationExpansionLevel = 0;
                                    return ProductPlanMgmtSvc.getOfferintListViaSearchApi('', associationExpansionLevel);
                                }
                            ],
                            offeringsFieldsMeta: ['ProductPlanMgmtSvc', function (ProductPlanMgmtSvc) {
                                return ProductPlanMgmtSvc.getOfferings();
                            }],
                            plansAspectDefs: ['ProductPlanMgmtSvc', function (ProductPlanMgmtSvc) {
                                return ProductPlanMgmtSvc.getAspectDefinitions();
                            }],
                            selectedAccount: ['OfferingAccountService', '$stateParams', function (OfferingAccountService, $stateParams) {
                                if ($stateParams.accountId && $stateParams.accountId !== '') {
                                    var associationExpansionLevel = 2;
                                    return OfferingAccountService.getAccountByAccountId(associationExpansionLevel, $stateParams.accountId);
                                } else {
                                    return null;
                                }
                            }]
                        }
                    }
                }
            })
            .state('home.media-management.generateDocument.multiSource.offeringsAndPlans.plans', {
                url: '/select-offering-plans/:offeringId',
                params: {
                    'offeringId': ''
                },
                views: {
                    'modalbody@': {
                        templateUrl: 'views/media-management/select-plans-of-offering.html',
                        controller: 'SelectOfferingPlansCtrl',
                        resolve: {
                            offeringPlans: ['OfferingAccountService', '$log', '$stateParams', function (OfferingAccountService, $log, $stateParams) {
                                return OfferingAccountService.getPlansByOfferingId($stateParams.offeringId).then(function (data) {
                                    return data.offeringplans;
                                }, function (response) {
                                    $log.error(response);
                                });
                            }]
                        }
                    }
                }
            })
            .state('home.media-management.finalGenerateDoc', {
                url: '/document-generated',
                templateUrl: 'views/media-management/document-generated.html',
                params: {
                    'generatorType': '',
                    'documentId': '',
                    'batchName': '',
                    'multiSource': false,
                    'editingBatch': false
                },
                controller: 'DocGeneratedCtrl'
            })
            .state('home.media-management.defineTemplate', {
                resolve: {
                    defineTemplateFieldsMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.defineTemplate();
                    }],
                    defineTemplateProductPropertiesMetaData: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.defineTemplateProductProperties();
                    }],
                    getTemplate: ['DocumentDataFactory', '$stateParams', function (DocumentDataFactory, $stateParams) {
                        return DocumentDataFactory.getTemplateById($stateParams.templateId);
                    }],
                    getTemplateList: ['DocumentDataFactory', function (DocumentDataFactory) {
                        return DocumentDataFactory.getTemplates();
                    }],
                    actionItem: ['$stateParams', function ($stateParams) {
                        return {
                            objectId: $stateParams.templateId,
                            name: $stateParams.docName
                        };
                    }]
                },
                url: '/define-template/{templateId}/{docName}',
                templateUrl: 'views/media-management/define-template.html',
                controller: 'DefineTemplateCtrl'
            })
            .state('home.media-management.listBatch', {
                cache: false,
                url: '/listBatch',
                templateUrl: 'views/media-management/list-batch.html',
                controller: 'listBatchCtrl',
                resolve: {
                    batchList: ['BatchService', '$log', function (BatchService, $log) {
                        return BatchService.getBatchList().then(function (data) {
                            return data.data;
                        }, function (reason) {
                            $log.error(reason);
                        });
                    }],
                    filtersMeta: ['BatchService', '$log', function (BatchService, $log) {
                        return BatchService.getBatchFilters().then(function (data) {
                            return data.data;
                        }, function (reason) {
                            $log.error(reason);
                        });
                    }],
                    submittedByUsers: ['BatchService', '$log', function (BatchService, $log) {
                        return BatchService.getBatchSubmittedByUsers().then(function (data) {
                            var submittedUsers = {};
                            var results = data.data;
                            angular.forEach(results, function (item) {
                                submittedUsers[item.batchSubmittedBy] = item.batchSubmittedBy;
                            });
                            return submittedUsers;
                        }, function (reason) {
                            $log.error(reason);
                        });
                    }]
                }
            })
            .state('home.media-management.generateDocument.units', {
                parent: 'home.media-management.generateDocument',
                onEnter: ['$modal', 'ModalDialogFactory', 'DocumentDataFactory', 'BatchService', function ($modal, ModalDialogFactory, DocumentDataFactory, BatchService) {
                    BatchService.getCurrentBatch(); //retain current batch object
                    BatchService.getCurrentBatchJobInEdit();  // retain current batch job in editing
                    BatchService.getBatchPaneCollapsed();
                    BatchService.getBatchJobDocNameEdited();

                    var dialogOptions = {
                        templateUrl: 'views/media-management/units-modal.html',
                        controller: 'UnitsModalCtrl',
                        size: 'lg',
                        windowClass: 'xx-dialog',
                        backdrop: false,
                        resolve: {
                            parentState: function () {
                                return 'home.media-management.generateDocument';
                            },
                            modalTitle: function () {
                                return 'Select Unit(s)';
                            }
                        }
                    };

                    ModalDialogFactory.showDialog(dialogOptions).then(function (result) {
                        var selectedUnits = [];
                        angular.forEach(result, function (unit) {
                            var unitJSON = {
                                'id': unit.objectId,
                                'name': unit.name,
                                'documentName': unit.documentName,
                                'unitPlanYear': unit.unitPlanYear
                            };
                            selectedUnits.push(unitJSON);
                        });

                        DocumentDataFactory.setSelectedUnits(selectedUnits);
                    });

                }],
                views: {
                    'modalbody@': {
                        templateUrl: 'views/media-management/list-units.html',
                        controller: 'UnitsCtrl',
                        resolve: {
                            unitsPromise: ['DocumentDataFactory',
                                'ConfirmationModalFactory',
                                '$log',
                                'ENV',
                                function (DocumentDataFactory, ConfirmationModalFactory, $log, ENV) {
                                    return DocumentDataFactory.getUnits().then(function (data) {
                                        return data;
                                    }, function (reason) {
                                        $log.error(reason);
                                        ConfirmationModalFactory.open('Error Message', 'Error occured when loading available units.', ENV.modalErrorTimeout);
                                    });
                                }
                            ],

                            unitFiltersMetaData: ['DocumentDataFactory',
                                'ConfirmationModalFactory',
                                '$log',
                                'ENV',
                                function (DocumentDataFactory, ConfirmationModalFactory, $log, ENV) {
                                    return DocumentDataFactory.getUnitSchema().then(function (data) {
                                        return data;
                                    }, function (reason) {
                                        $log.error(reason);
                                        ConfirmationModalFactory.open('Error Message', 'Error occured when loading unit schema.', ENV.modalErrorTimeout);
                                    });
                                }
                            ],

                            aspectsMetaData: ['DocumentDataFactory',
                                'ConfirmationModalFactory',
                                '$log',
                                'ENV',
                                function (DocumentDataFactory, ConfirmationModalFactory, $log, ENV) {
                                    return DocumentDataFactory.getAspectDefinitions().then(function (data) {
                                        return data;
                                    }, function (reason) {
                                        $log.error(reason);
                                        ConfirmationModalFactory.open('Error Message', 'Error occured when loading aspect definitions.', ENV.modalErrorTimeout);
                                    });
                                }
                            ],

                            authorizedUserInfo: ['$auth', function ($auth) {
                                return $auth.requestUserInfo();
                            }]
                        }
                    }
                }
            });
    }]);