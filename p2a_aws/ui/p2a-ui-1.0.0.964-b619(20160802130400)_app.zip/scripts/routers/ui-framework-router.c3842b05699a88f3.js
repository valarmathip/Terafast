'use strict';

angular.module('p2AdvanceApp')
    .config(function($stateProvider) {

        $stateProvider
            .state('home.ui-framework', {
                url: '/ui-framework',
                templateUrl: 'views/ui-framework/ui-framework.html'
            })
            .state('home.ui-framework.theme', {
                url: '/theme',
                templateUrl: 'views/ui-framework/theme.html'
            })
            .state('home.ui-framework.i18n', {
                url: '/i18n',
                templateUrl: 'views/ui-framework/i18n.html',
                controller: 'I18nCtrl'
            })
            .state('home.ui-framework.menu', {
                url: '/menu',
                templateUrl: 'views/ui-framework/menu.html',
                controller: 'MenuCtrl'
            })
            .state('home.ui-framework.hotkeys', {
                url: '/hotkeys',
                templateUrl: 'views/ui-framework/hotkeys.html',
                controller: 'HotkeysCtrl'
            })
            .state('home.ui-framework.widgets', {
                url: '/widgets',
                templateUrl: 'views/ui-framework/widgets.html',
                controller: 'WidgetsCtrl'
            })
            .state('home.ui-framework.widgets.subnavbar', {
                url: '/subnavbar/{sectionId}',
                views: {
                    'subnavbar': {
                        templateUrl: 'views/ui-framework/subnavbar-section-example.html',
                        controller: ['$scope','$stateParams', function($scope, $stateParams) {
                            $scope.sectionNumber = $stateParams.sectionId;
                        }]
                    }
                }
            })
            .state('home.ui-framework.grids', {
                url: '/grids',
                templateUrl: 'views/ui-framework/grids.html',
                controller: 'GridsCtrl'
            })
            .state('home.ui-framework.productList', {
                url: '/productList',
                templateUrl: 'views/ui-framework/productList.html',
                controller: 'ProductListDemoCtrl'
            });

    });