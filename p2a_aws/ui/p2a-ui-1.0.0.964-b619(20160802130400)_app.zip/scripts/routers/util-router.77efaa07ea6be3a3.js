'use strict';

angular.module('p2AdvanceApp')
    .config(function($stateProvider) {

        $stateProvider
            .state('home.util', {
                'abstract': true,
                url: '/util',
                template: '<ui-view/>'
            })
            .state('home.util.file-select', {
                url: '/file-select/:objectType',
                templateUrl: 'views/util/file-select.html',
                controller: 'FileSelectCtrl'
            })
            .state('home.util.document-search', {
                resolve: {
                    documentDetailFieldsMetaData: ['ProductPlanMgmtSvc',  function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getDocumentDetailFieldMetaInfo();
                    }]
                },
                url: '/document-search',
                templateUrl: 'views/product-plan-management/document-search.html',
                controller: 'DocumentSearchCtrl'
            });
    });