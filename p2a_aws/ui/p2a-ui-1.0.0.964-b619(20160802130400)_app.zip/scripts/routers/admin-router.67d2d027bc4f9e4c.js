﻿'use strict';

angular.module('p2AdvanceApp')
    .config(['$stateProvider', function($stateProvider) {
        $stateProvider
            .state('home.admin', {
                url: '/admin',
                'abstract': true,
                template: '<ui-view/>',
                controller: ['$rootScope', 'mainNavBarTabs', function($rootScope, mainNavBarTabs) {
                    $rootScope.mainNavBarTabs = mainNavBarTabs;
                }],
                resolve: {
                    mainNavBarTabs: function() {
                        return [
                            // {
                            //     badgetInfoNum: 0,
                            //     badgetErrorNum: 0,
                            //     locationPath: '/admin/account-management',
                            //     name: 'ACCOUNT MANAGEMENT',
                            //     routerState: 'admin.account-management'
                            // }, {
                            //     badgetInfoNum: 0,
                            //     badgetErrorNum: 0,
                            //     locationPath: '/admin/distribution',
                            //     name: 'DISTRIBUTION',
                            //     routerState: 'admin.distribution'
                            // },
                            {
                                badgetInfoNum: 0,
                                badgetErrorNum: 0,
                                locationPath: '/admin/media-management',
                                name: 'MEDIA MANAGEMENT',
                                routerState: 'admin.media-management.landing-page',
                                permission: '|all.read,|document.read,|template.read,|contentrule.read,|findreplacerule.read,|showrule.read'
                            }, {
                                badgetInfoNum: 0,
                                badgetErrorNum: 0,
                                locationPath: '/admin/ppm',
                                name: 'PRODUCT/PLAN MANAGEMENT',
                                routerState: 'admin.ppm.landing-page',
                                permission: '|all.read,|plan.read,|product.read,|rulesexpression.read'
                            },
                            {
                              badgetInfoNum: 0,
                              badgetErrorNum: 0,
                              locationPath: '/admin/distribution',
                              name: 'DISTRIBUTION',
                              routerState: 'admin.distribution',
                              permission: '|all.read,|distribution.read'
                            }
                        ];
                    }
                }
            })
            .state('home.admin.media-management', {
                url: '/media-management',
                'abstract': true,
                template: '<ui-view/>'
            })
            .state('home.admin.landing-page', {
                url: '/landing-page',
                templateUrl: 'views/admin/main/admin-landing-page.html',
                controller: 'AdminLandingPageCtrl'
            })
          .state('home.admin.distribution', {
            url: '/distribution',
            templateUrl: 'views/admin/distribution/landing-page.html',
            controller: 'distributionController'
          })

        .state('home.admin.ppm', {
            url: '/ppm',
            'abstract': true,
            template: '<ui-view/>'
        })

        .state('home.admin.ppm.landing-page', {
                url: '/ppm-landing',
                templateUrl: 'views/admin/product-plan/landing-page.html'
            })
            .state('home.admin.media-management.landing-page', {
                url: '/media-management-landing',
                templateUrl: 'views/admin/media-management/landing-page.html'
            })
            .state('home.admin.media-management.rule-builder', {
                url: '/rule-builder',
                templateUrl: 'views/admin/media-management/rule-builder.html',
                controller: 'RuleBuilderCtrl'
            })
            .state('home.admin.media-management.rules', {
                url: '/rules',
                templateUrl: 'views/admin/media-management/rules.html',
                controller: 'RulesCtrl',
                resolve: {
                    authorizedUserInfo: ['$auth', function($auth) {
                        return $auth.requestUserInfo();
                    }]
                }
            })
            .state('home.admin.media-management.rules.conditions', {
                url: '/conditions',
                templateUrl: 'views/admin/media-management/conditions.html',
                params: {
                    'ruleId': '',
                    'rulesData': '',
                    'isRuleNOTEmpty': false
                },
                controller: 'ConditionCtrl',
                resolve: {
                    rules: ['RuleDataService',
                        'ConfirmationModalFactory',
                        '$log',
                        'ENV',
                        function(RuleDataService, ConfirmationModalFactory, $log, ENV) {
                            return RuleDataService.getConditionRules().then(function(data) {
                                return data.response.docs;
                            }, function(reason) {
                                $log.error(reason);
                                ConfirmationModalFactory.open('Error Message', 'Error occured when loading condition rules.', ENV.modalErrorTimeout);
                            });
                        }
                    ]
                }
            })
            .state('home.admin.media-management.rules.findreplacerules', {
                url: '/findreplacerules',
                templateUrl: 'views/admin/media-management/find-replace-rules.html',
                params: {
                    'ruleId': '',
                    'rulesData': '',
                    'isRuleNOTEmpty': false
                },
                controller: 'FindReplaceRulesCtrl',
                resolve: {
                    rules: ['RuleDataService',
                        'ConfirmationModalFactory',
                        '$log',
                        'ENV',
                        function(RuleDataService, ConfirmationModalFactory, $log, ENV) {
                            return RuleDataService.getFindReplaceRules().then(function(data) {
                                return data;
                            }, function(reason) {
                                $log.error(reason);
                                ConfirmationModalFactory.open('Error Message', 'Error occured when loading find replace rules.', ENV.modalErrorTimeout);
                            });
                        }
                    ]
                }
            })
            .state('home.admin.media-management.rules.showrules', {
                url: '/showrules',
                templateUrl: 'views/admin/media-management/list-show-hide.html',
                params: {
                    'ruleId': ' ',
                    'rulesData': '',
                    'isRuleNOTEmpty': false
                },
                controller: 'ShowRulesCtrl',
                resolve: {
                    rules: ['RuleDataService',
                        'ConfirmationModalFactory',
                        '$log',
                        'ENV',
                        function(RuleDataService, ConfirmationModalFactory, $log, ENV) {
                            return RuleDataService.getShowRules().then(function(data) {
                                return data;
                            }, function(reason) {
                                $log.error(reason);
                                ConfirmationModalFactory.open('Error Message', 'Error occured when loading find replace rules.', ENV.modalErrorTimeout);
                            });
                        }
                    ]
                }
            })
            .state('home.admin.media-management.rules.trim', {
                url: '/trim',
                templateUrl: 'views/admin/media-management/trim.html',
                params: {
                    'ruleId': ' ',
                    'rulesData': '',
                    'isRuleNOTEmpty': false
                },
                controller: 'TrimCtrl',
                resolve: {
                    rules: ['RuleDataService',
                        'ConfirmationModalFactory',
                        '$log',
                        'ENV',
                        function(RuleDataService, ConfirmationModalFactory, $log, ENV) {
                            return RuleDataService.getDeletionRules().then(function(data) {
                                return data;
                            }, function(reason) {
                                $log.error(reason);
                                ConfirmationModalFactory.open('Error Message', 'Error occured when loading deletion rules.', ENV.modalErrorTimeout);
                            });
                        }
                    ]
                }
            })
            .state('home.admin.media-management.rules.all', {
                url: '/all',
                templateUrl: 'views/admin/media-management/all.html',
                controller: 'AllCtrl'
            })
            .state('home.admin.media-management.delete-rule-definition', {
                params: {
                    'ruleId': ''
                },
                url: '/delete-rule-def',
                templateUrl: 'views/admin/media-management/delete-rule-def.html',
                controller: 'DeleteRuleDefCtrl'
            })
            .state('home.admin.media-management.findandreplace-rule-definition', {
                url: '/findandreplace-rule-def',
                templateUrl: 'views/admin/media-management/findandreplace-rule-def.html',
                params: {
                    'ruleId': ''
                },
                controller: 'FindandReplaceRuleDefCtrl'
            })
            .state('home.admin.media-management.condition-expression-definition', {
                url: '/condition-expression-def',
                templateUrl: 'views/admin/media-management/condition-expression-def.html',
                params: {
                    'ruleId': ''
                },
                controller: 'ConditionExpressionDefCtrl'
            })
            .state('home.admin.media-management.showhide-rule-definition', {
                url: '/showhide-rule-def',
                templateUrl: 'views/admin/media-management/showhide-rule-def.html',
                params: {
                    'ruleId': '',
                    'dataFields': ''
                },
                controller: 'ShowHideRuleDefCtrl'
            })
            .state('home.admin.media-management.short-name-list', {
                url: '/short-names',
                templateUrl: 'views/admin/media-management/filtered-list-short-names.html',
                controller: 'ListShortNamesCtrl',
                resolve: {
                    isModal: function() {
                        return false;
                    },
                    filterList: function($q, ConfirmationModalFactory, ShortNameDictionaryService) {
                        var deferred = $q.defer();
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading Short Name Filters, please wait...')
                        ShortNameDictionaryService.getFilterValues().success(function(response) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            deferred.resolve(response);
                        }).error(function(response) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            deferred.reject(response);
                        });
                        return deferred.promise;
                    }
                }
            })
            .state('home.admin.account-management', {
                url: '/media-management/rule-builder',
                templateUrl: 'views/admin/media-management/rule-builder.html',
                controller: 'RuleBuilderCtrl'
            })
            /*
            .state('home.admin.ppm', {
                url: '/media-management/rule-builder',
                templateUrl: 'views/admin/media-management/rule-builder.html',
                controller: 'RuleBuilderCtrl'
            })
            */
            .state('home.admin.ppm.rules', {
                url: '/rules',
                templateUrl: 'views/admin/product-plan/validation-rules.html',
                controller: 'PPMRulesCtrl',
                params: {
                    'ruleId': ''
                },
                resolve: {
                    rules: function($q, ConfirmationModalFactory, ValidationRuleDataService) {
                        var deferred = $q.defer();
                        /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading list of validation rules, please wait…')
                        ValidationRuleDataService.getValidationRuleListBySearch().then(function(data) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            deferred.resolve(data.data);
                        }, function(response) {
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                            deferred.reject(response);
                        });
                        return deferred.promise;
                    },
                    newlyAddedRule: function($q, ConfirmationModalFactory, ValidationRuleDataService, $stateParams) {
                        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                            var deferred = $q.defer();
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the validation rule, please wait…')
                            ValidationRuleDataService.getValidationRuleById($stateParams.ruleId).success(function(response) {
                                var newlyAddedRule = {
                                    'objectId': response.objectId,
                                    'name': response.name,
                                    'modifier': response.lastModifiedBy,
                                    'lastModificationDate': response.lastModificationDate,
                                    'creationDate': response.creationDate,
                                    'severity': response.severity,
                                    'errorText': response.validationMessage,
                                    'condition': angular.isDefined(response.expression) ? response.expression : '',
                                    'ruleStatus': response.ruleStatus
                                };
                                deferred.resolve(newlyAddedRule);
                            }).error(function(response) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                deferred.reject(response);
                            });
                            return deferred.promise;
                        } else {
                            return null;
                        }
                    },
                    metaData: function($q, ConfirmationModalFactory, ValidationRuleDataService) {
                        var deferred = $q.defer();
                        ValidationRuleDataService.getValidationMetaData().then(function(data) {
                            deferred.resolve(data.data);
                        }, function(response) {
                            deferred.reject(response);
                        });
                        return deferred.promise;
                    }
                }
            })
            .state('home.admin.ppm.validation-rule-builder', {
                url: '/validation-rule-builder',
                templateUrl: 'views/admin/product-plan/validation-rule-builder.html',
                controller: 'ValidationRuleBuilderCtrl',
                params: {
                    'ruleId': ''
                },
                resolve: {
                    currentRule: function($q, ConfirmationModalFactory, ValidationRuleDataService, $stateParams) {
                        if ($stateParams.ruleId !== null && $stateParams.ruleId.trim().toString().length > 0) {
                            var deferred = $q.defer();
                            /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading the validation rule, please wait…')
                            ValidationRuleDataService.getValidationRuleById($stateParams.ruleId).success(function(response) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                deferred.resolve(response);
                            }).error(function(response) {
                                /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
                                deferred.reject(response);
                            });
                            return deferred.promise;
                        } else {
                            return null;
                        }
                    }
                }
            });


        // .state('home.admin.ppm.rules.validation-rule-list', {
        //     url: '/validation-rule-list',
        //     templateUrl: 'views/admin/product-plan/validation-rule-list.html',
        //     controller: 'ValidationRuleListctrl',
        //     params: {
        //         'ruleId': ''
        //     },
        //     resolve: {
        //         rules: function($q, ConfirmationModalFactory, ValidationRuleDataService) {
        //             var deferred = $q.defer();
        //             /*comment-out-for-spinner*/ // ConfirmationModalFactory.open('Loading list of validation rules, please wait…')
        //             ValidationRuleDataService.getValidationRuleList().then(function(data) {
        //                 /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
        //                 deferred.resolve(data.data);
        //             }, function(response) {
        //                 /*comment-out-for-spinner*/ // ConfirmationModalFactory.close()
        //                 deferred.reject(response);
        //             });
        //             return deferred.promise;
        //         }
        //     }
        // });
    }]);
