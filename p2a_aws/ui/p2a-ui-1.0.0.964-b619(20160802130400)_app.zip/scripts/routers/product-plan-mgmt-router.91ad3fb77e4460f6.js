'use strict';

angular.module('p2AdvanceApp')
    .config(function($stateProvider) {

        $stateProvider
            .state('home.ppm', {
                'abstract': true,
                url: '/ppm',
                template: '<ui-view/>',
                controller: ['$rootScope', 'mainNavBarTabs', function($rootScope, mainNavBarTabs) {
                    $rootScope.mainNavBarTabs = mainNavBarTabs;
                }],
                resolve: {
                    mainNavBarTabs: function() {
                        return [{
                                badgetInfoNum: 0,
                                badgetErrorNum: 0,
                                locationPath: '/panel/product',
                                name: 'PRODUCTS',
                                routerState: 'ppm.product.product-list',
                                permission: '|product.read,|all.read'
                            }, {
                                badgetInfoNum: 0,
                                badgetErrorNum: 0,
                                locationPath: '/panel/plan-list',
                                name: 'PLANS',
                                routerState: 'ppm.plan.plan-list',
                                permission: '|plan.read,|all.read'
                            },
                            /*{
                                badgetInfoNum: 0,
                                badgetErrorNum: 0,
                                locationPath: '/panel/',
                                name: 'RIDERS',
                                routerState: 'ppm.rider'
                            }, */
                            {
                                badgetInfoNum: 0,
                                badgetErrorNum: 0,
                                locationPath: '/offering/offering-list',
                                name: 'OFFERINGS',
                                routerState: 'ppm.offering.offering-list',
                                permission: '|offering.read, |all.read'
                            }
                        ];
                    }
                }
            })
            .state('home.ppm.panel', {
                url: '/panel',
                templateUrl: 'views/product-plan-management/product-plan-management.html',
                controller: 'ProductPlanManagementCtrl'
            })
            .state('home.ppm.product', {
                'abstract': true,
                url: '/product',
                template: '<ui-view/>'
            })
            .state('home.ppm.product.product-details', {
                resolve: {
                    productDetailFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getProductDetailFieldMetaInfo();
                    }]
                },
                url: '/product-details/{objectId}',
                templateUrl: 'views/product-plan-management/product-details.html',
                controller: 'ProductDetailsCtrl'
            })
            .state('home.ppm.product.product-list', {
                url: '/product-list',
                templateUrl: 'views/product-plan-management/product-list.html',
                controller: 'ProductListCtrl',
                resolve: {
                    filtersGroupsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getProductListFilterMeta();
                    }]
                }
            })
            .state('home.ppm.product.edit', {
                params: {
                    'productId': null,
                    'productDetails': null
                },
                'abstract': true,
                url: '/edit/{productId}',
                template: '<ui-view/>',
                controller: 'ProductEditRootCtrl',
                onExit: function(ProductCostShareFacadeSvc, $log) {
                    ProductCostShareFacadeSvc.clearCache();
                    if (ProductCostShareFacadeSvc.productExpandable3()) {
                        $log.error('should be not set');
                    }
                },
                resolve: {
                    LockEditProductFirst: function($stateParams, $log, $q, $timeout, $state, PlanLockSvc) {
                        if ($stateParams.productId) {
                            return $timeout(function() {
                                return PlanLockSvc.lockProductForEdit($stateParams.productId)
                                    .then(function() {
                                        $log.log('resolve after lockProductForEdit at home.ppm.product.edit');
                                        return true;
                                    }, function() {
                                        $log.log('reject after lockProductForEdit at home.ppm.product.edit');
                                        $state.go('home.ppm.product.product-list');
                                        return $q.reject();
                                    });
                            }, 100);
                        } else {
                            $log.log('resolved for that $stateParams.productId does not exist at home.ppm.product.edit');
                            return $q.when(true); // $q.when is necessary, otherwise, it is not return promoise
                        }
                    }
                }
            })
            .state('home.ppm.product.edit.product-details', {
                // onEnter: function($log) {
                //     $log.log('>>>>>>>>> onEnter at home.ppm.plan.edit.plan-details');f
                // },
                resolve: {
                    productDetailFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getProductDetailFieldMetaInfo();
                    }],
                    ProductL3: ['$stateParams', 'ProductCostShareFacadeSvc', function($stateParams, ProductCostShareFacadeSvc) {
                        angular.noop(ProductCostShareFacadeSvc.clearCache());
                        var productId = $stateParams.productId;
                        /*var product;
                        CostShareFacadeSvc.getProductExpandableL3(productId).then(function(data) {
                            product = data;
                        });*/
                        if (productId != null) {
                            return ProductCostShareFacadeSvc.getProductExpandableL3(productId);
                        } else {
                            return null;
                        }

                    }]
                },
                url: '/product-details?productId',
                templateUrl: 'views/product-plan-management/product-details.html',
                controller: 'ProductDetailsCtrl'
            })
            .state('home.ppm.product.edit.product-details.content', {
                url: '/{tabName}',
                templateUrl: function($stateParams) {
                    var tabName = $stateParams.tabName;
                    return 'views/product-plan-management/template/product-details/' + tabName + '.html';
                }
            })
            .state('home.ppm.product.edit.service-list', {
                url: '/service-list',
                templateUrl: 'views/product-plan-management/product-service-list.html',
                controller: 'ProductServiceListCtrl',
                resolve: {
                    productDetails: ['$stateParams', function($stateParams) {
                        return $stateParams.productDetails;
                    }],
                    filtersMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getServiceListFilterMeta();
                    }],
                    productL3: function($stateParams, ProductCostShareFacadeSvc, PlanLockSvc, LockEditProductFirst) {
                        angular.noop(LockEditProductFirst);
                        return ProductCostShareFacadeSvc.getProductExpandableL3($stateParams.productId)
                            .then(function(product) {
                                return ProductCostShareFacadeSvc.populateProductLinkedServiceIfNotLoaded(product);
                            });
                    }
                }
            })
            .state('home.ppm.plan', {
                'abstract': true,
                url: '/plan',
                template: '<ui-view/>'
            })
            .state('home.ppm.plan.plan-list', {
                url: '/plan-list',
                templateUrl: 'views/product-plan-management/plan-list.html',
                controller: 'PlanListCtrl',
                resolve: {
                    filtersGroupsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanListFilterMeta();
                    }],
                    plansFieldsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlans();
                    }],
                    plansAspectDefs: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getAspectDefinitions();
                    }],
                    authorizedUserInfo: ['$auth', function($auth) {
                        return $auth.requestUserInfo();
                    }]
                }
            })
            .state('home.ppm.plan.edit', {
                'abstract': true,
                url: '/edit/{planId}',
                template: '<ui-view/>',
                controller: 'PlanEditRootCtrl',
                // onEnter: function(CostShareFacadeSvc, $log) {
                //     // this is called after its sub state resolve part is done, cannot used as clean
                //     $log.log('>>>>>>>>> onEnter at home.ppm.plan.edit');
                // },
                onExit: function(CostShareFacadeSvc, $log) {
                    // $log.log('>>>>>>>> called from onExit edit state');

                    CostShareFacadeSvc.clearCache();
                    if (CostShareFacadeSvc.PlanExpandable3()) {
                        $log.error('should be not set');
                    }
                },
                resolve: {
                    editPlanCacheClean: function(CostShareFacadeSvc, $log) {
                        // $log.log('>>>>>>>> called from resolve edit state');

                        CostShareFacadeSvc.clearCache();
                        if (CostShareFacadeSvc.PlanExpandable3()) {
                            $log.error('should be not set');
                        }

                        return true;
                    },
                    LockEditPlanFirst: function($stateParams, $log, $q, $timeout, $state, PlanLockSvc) {
                        if ($stateParams.planId) {
                            return $timeout(function() { // Sometime, me is loaed after the plan status loaded
                                return PlanLockSvc.lockPlanForEdit($stateParams.planId)
                                    .then(function() {
                                        $log.log('resolve after lockPlanForEdit at home.ppm.plan.edit');
                                        return true;
                                    }, function() {
                                        $log.log('reject after lockPlanForEdit at home.ppm.plan.edit');
                                        $state.go('home.ppm.plan.plan-list');
                                        return $q.reject();
                                    });
                            }, 100);
                        } else {
                            $log.log('resolved for that $stateParams.planId does not exist at home.ppm.plan.edit');
                            return $q.when(true); // $q.when is necessary, otherwise, it is not return promoise
                        }
                    }

                }
            })
            .state('home.ppm.plan.edit.plan-details', {
                // onEnter: function($log) {
                //     $log.log('>>>>>>>>> onEnter at home.ppm.plan.edit.plan-details');
                // },
                resolve: {
                    planDetailFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanDetailFieldMetaInfo();
                    }],
                    PlanL3: function($stateParams, CostShareFacadeSvc, PlanLockSvc, $log, LockEditPlanFirst) { // LockEditPlanFirst is necessary, to make sure the parent is resolved
                        angular.noop(LockEditPlanFirst); // LockEditPlanFirst parameter is necessary to make this function wait untile it is resolved
                        $log.log('>>>>>>>>> load PL3 at home.ppm.plan.edit.plan-details');

                        var planId = $stateParams.planId;
                        // do not need to check the isEditable, because if is locked by other, the reject is called
                        // Load plan level 1
                        return CostShareFacadeSvc.getPlanExpandableL3(planId) // in fact load at level 1
                            .then(function(plan) {
                                var productId = plan['linkedProducts'][0].objectId;
                                // loaded linked product level 1
                                // Because current product is level 0, no global cost share details, and this is needed
                                // and there is no way to directly load prodct related cost share
                                return CostShareFacadeSvc.getProductExpandableL3(productId)
                                    .then(function(product) {
                                        // put the product into plan
                                        plan['linkedProducts'] = [product];
                                        return plan;
                                    });
                            });
                    }
                },
                url: '/plan-details?planId',
                templateUrl: 'views/product-plan-management/plan-details.html',
                controller: 'PlanDetailsCtrl'
            })
            .state('home.ppm.plan.edit.plan-details.content', {
                url: '/{tabName}',
                templateUrl: function($stateParams) {
                    var tabName = $stateParams.tabName;
                    return 'views/product-plan-management/template/plan-details/' + tabName + '.html';
                }
            })
            .state('home.ppm.plan.edit.service-list', {
                params: { // SLQ Should removed
                    plan: null
                },
                resolve: {
                    filtersMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getServiceListFilterMeta();
                    }],
                    planL3: function($stateParams, CostShareFacadeSvc, PlanLockSvc, LockEditPlanFirst) {
                        angular.noop(LockEditPlanFirst); // LockEditPlanFirst parameter is necessary to make this function wait untile it is resolved
                        return CostShareFacadeSvc.getPlanExpandableL3($stateParams.planId)
                            .then(function(plan) {
                                return CostShareFacadeSvc.populatePlanLinkedServiceIfNotLoaded(plan);
                            });
                    }
                },
                url: '/service-list',
                templateUrl: 'views/product-plan-management/service-list.html',
                controller: 'ServiceListCtrl'
            })
            .state('home.ppm.plan.edit.cost-share', {
                params: { // SLQ Should removed
                    plan: null
                },
                resolve: {
                    CostShareFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getCostShareFieldMetaInfo();
                    }],
                    planL3: function($stateParams, CostShareFacadeSvc, LockEditPlanFirst) {
                        angular.noop(LockEditPlanFirst); // LockEditPlanFirst parameter is necessary to make this function wait untile it is resolved
                        return CostShareFacadeSvc.getPlanExpandableL3($stateParams.planId)
                            .then(function(plan) {
                                // if in the previouse the all service is loaded, there is not should be loaded again
                                // but if go to the plan service cost share with a deep link, this should be called to get all services
                                return CostShareFacadeSvc.populatePlanLinkedServiceIfNotLoaded(plan);
                            });
                    }

                },
                url: '/cost-share?serviceId',
                templateUrl: 'views/product-plan-management/cost-share.html',
                controller: 'CostShareCtrl'
            })
            .state('home.ppm.product.edit.cost-share', {
                params: { // SLQ Should removed
                    plan: null
                },
                resolve: {
                    CostShareFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getProductCostShareFieldMetaInfo();
                    }],
                    productL3: function($stateParams, ProductCostShareFacadeSvc, LockEditProductFirst) {
                        angular.noop(LockEditProductFirst); // LockEditProductFirst parameter is necessary to make this function wait untile it is resolved
                        return ProductCostShareFacadeSvc.getProductExpandableL3($stateParams.productId)
                            .then(function(product) {
                                // if in the previouse the all service is loaded, there is not should be loaded again
                                // but if go to the product service cost share with a deep link, this should be called to get all services
                                return ProductCostShareFacadeSvc.populateProductLinkedServiceIfNotLoaded(product);
                            });
                    }

                },
                url: '/cost-share?serviceId',
                templateUrl: 'views/product-plan-management/product-cost-share.html',
                controller: 'ProductCostShareCtrl'
            })
            .state('home.ppm.plan.edit.cost-share.details', {
                url: '/{svcIdx}/{tierName}',
                templateUrl: function($stateParams) {
                    var tierName = $stateParams.tierName;
                    var tabName = 'cost-share-content';
                    if (tierName === 'properties') {
                        tabName = 'service-properties';
                    }
                    return 'views/product-plan-management/template/cost-share/' + tabName + '.html';
                }
            })
            .state('home.ppm.product.edit.cost-share.details', {
                url: '/{svcIdx}/{tierName}',
                templateUrl: function($stateParams) {
                    var tierName = $stateParams.tierName;
                    var tabName = 'product-cost-share-content';
                    if (tierName === 'properties') {
                        tabName = 'product-service-properties';
                    }
                    return 'views/product-plan-management/template/cost-share/' + tabName + '.html';
                }
            })
            .state('home.ppm.plan.plan-list-search', {
                resolve: {
                    filtersGroupsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanListFilterMeta();
                    }],
                    plansFieldsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlans();
                    }],
                    plansAspectDefs: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getAspectDefinitions();
                    }],
                    allPlansList: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getAllPlans();
                    }]
                },
                url: '/plan-list/searchquery={searchquery}',
                templateUrl: 'views/product-plan-management/plan-list.html',
                controller: 'PlanListCtrl'
            })
            .state('home.ppm.product.product-list-search', {
                url: '/product-list/searchquery={searchquery}',
                templateUrl: 'views/product-plan-management/product-list.html',
                controller: 'ProductListCtrl'
            })
            .state('home.ppm.plan.plan-search', {
                resolve: {
                    filtersGroupsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanListFilterMeta();
                    }],
                    planDetailFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanDetailFieldMetaInfo();
                    }]
                },
                url: '/plan-search',
                templateUrl: 'views/product-plan-management/plan-search.html',
                controller: 'PlanSearchCtrl'
            })
            .state('home.ppm.plan.product-search', {
                resolve: {
                    filtersGroupsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanListFilterMeta();
                    }],
                    productDetailFieldsMetaData: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getProductDetailFieldMetaInfo();
                    }]
                },
                url: '/product-search',
                templateUrl: 'views/product-plan-management/product-search.html',
                controller: 'ProductSearchCtrl'
            })
            .state('home.ppm.service', { // SLQ do we still use this one?
                'abstract': true,
                url: '/service',
                template: '<ui-view/>'
            })
            /**
                Offering UI Router
             */
            .state('home.ppm.offering', {
                'abstract': true,
                url: '/offering',
                template: '<ui-view/>'
            })
            .state('home.ppm.offering.offering-list', {
                templateUrl: 'views/product-plan-management/offering-list.html',
                url: '/offering-list',
                controller: 'OfferingListCtrl',
                resolve: {
                    offeringList: function(ProductPlanMgmtSvc) {
                        var associationExpansionLevel = 0;
                        return ProductPlanMgmtSvc.getOfferintListViaSearchApi('', associationExpansionLevel);
                    },
                    offeringsFieldsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getOfferings();
                    }],
                    plansAspectDefs: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getAspectDefinitions();
                    }]
                }
            })
            .state('home.ppm.offering.edit', {
                resolve: {
                    offeringDetailFieldsMetaData: function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getOfferingDetailFieldMetaInfo();
                    },
                    offeringDetails: function(ProductPlanMgmtSvc, $stateParams, $q, $timeout, $state, PlanLockSvc, ppmUtils, $log) {
                        function lockEditOfferingFirst() {
                            if (ppmUtils.isUuid($stateParams.offeringId)) { // we are try to edit a offering
                                return $timeout(function() { // Sometime, me is loaed after the plan status loaded
                                    var objectType = 'offering'; // this is for offering edit, so I should know its objectType
                                    return PlanLockSvc.lockEntityForEdit($stateParams.offeringId, objectType)
                                        .then(function() {
                                            $log.log('resolve after lockPlanForEdit at home.ppm.plan.edit');
                                            return true;
                                        }, function() {
                                            $log.log('reject after lockPlanForEdit at home.ppm.plan.edit');
                                            $state.go('home.ppm.offering.offering-list');
                                            return $q.reject();
                                        });
                                }, 100);
                            } else {
                                $log.log('resolved for that $stateParams.planId does not exist at home.ppm.offering.edit');
                                return $q.when(true); // $q.when is necessary, otherwise, it is not return promoise
                            }
                        }

                        if ($stateParams.offeringId === 'new') {
                            var deferred = $q.defer();
                            deferred.resolve({});
                            return deferred.promise;
                        } else {
                            return lockEditOfferingFirst().then(function() {
                                // return ProductPlanMgmtSvc.getOfferingDetails($stateParams.offeringId);
                                return ProductPlanMgmtSvc.getEntityViaPpm($stateParams.offeringId, 'offering', 1, '');
                            });
                        }
                    }
                },
                url: '/{offeringId}/details',
                templateUrl: 'views/product-plan-management/offering-details.html',
                controller: 'OfferingDetailsCtrl'
            })
            .state('home.ppm.offering.edit.content', {
                url: '/{tabName}',
                templateUrl: function($stateParams) {
                    var tabName = $stateParams.tabName;
                    return 'views/product-plan-management/template/offering-details/' + tabName + '.html';
                }
            }); /* End of Offering UI Router*/
    });