'use strict';

angular.module('p2AdvanceApp')
    .config(function($stateProvider) {

        $stateProvider
            .state('home.am', {
                'abstract': true,
                url: '/am',
                template: '<ui-view/>',
                controller: ['$rootScope', 'mainNavBarTabs', function($rootScope, mainNavBarTabs) {
                    $rootScope.mainNavBarTabs = mainNavBarTabs;
                }],
                resolve: {
                    mainNavBarTabs: function() {
                        return [{
                            badgetInfoNum: 0,
                            badgetErrorNum: 0,
                            locationPath: '/account-list',
                            name: 'ACCOUNTS',
                            routerState: 'am.account-list',
                            permission: '|plan.read,|all.read'
                        }];
                    }
                }
            })
            .state('home.am.account-list', {
                url: '/account-list',
                templateUrl: 'views/account-management/account-list.html',
                controller: 'AccountListCtrl',
                resolve: {
                    filtersGroupsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlanListFilterMeta();
                    }],
                    plansFieldsMeta: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getPlans();
                    }],
                    plansAspectDefs: ['ProductPlanMgmtSvc', function(ProductPlanMgmtSvc) {
                        return ProductPlanMgmtSvc.getAspectDefinitions();
                    }],
                    accountListData: ['AccountMgmtSvc', function(AccountMgmtSvc) {
                        var associationExpansionLevel = 1; // we use -1 because the property "offering" is filter out so there is too much data
                        return AccountMgmtSvc.getAccountListViaSearchApi('', associationExpansionLevel);
                    }],
                    authorizedUserInfo: ['$auth', function($auth) {
                        return $auth.requestUserInfo();
                    }]
                }
            });

    });
