'use strict';

/*
 * distribution tabs router
 */
angular.module('p2AdvanceApp')
  .config(function($stateProvider) {

    $stateProvider
      .state('home.distribution', {
        url: '/distribution',
        templateUrl: 'views/distribution/distribution.html',
        controller: ['$rootScope', 'mainNavBarTabs', function($rootScope, mainNavBarTabs) {
          $rootScope.mainNavBarTabs = mainNavBarTabs;
        }],
        resolve: {
          mainNavBarTabs: function() {
            return [
              {
                badgetInfoNum: 0,
                badgetErrorNum: 0,
                locationPath: '/draft',
                name: 'DRAFT DISTRIBUTION(s)',
                routerState: 'draft',
                permission: '|distribution.read,|all.read'
              },
              {
              badgetInfoNum: 0,
              badgetErrorNum: 0,
              locationPath: '/sent',
              name: 'SENT DISTRIBUTION(s)',
              routerState: 'sent',
              permission: '|distribution.read,|all.read'
            }
            ];
          }
        }
      })

      .state('home.sent', {
        url: '/sent',
        templateUrl: 'views/distribution/distribution-sent.html',
        controller: 'distributionController'
      })
      .state('home.draft', {
        url: '/draft',
        templateUrl: 'views/distribution/distribution-drafts.html',
        controller: 'distributionController'
      });
  });
