'use strict';

angular.module('p2AdvanceApp').
config(function($stateProvider) {
    $stateProvider
        .state('home.landing-page', {
            url: '/landing-page',
            templateUrl: 'views/main/landing-page.html',
            controller: 'LandingPageCtrl'
        });
});